from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,re,json,hashlib,sys
root=Path(__file__).resolve().parent
repo=root/'qsym';out=root/'focused'
inputs=[p for group in ['cutoff','tensors'] for p in sorted((repo/'build'/group).glob('*.lean'))]


inputs += [p for p in [repo/'build/ReplTensors.lean'] if p.exists()]
if len(sys.argv)>1: inputs=[p for p in inputs if p.stem in sys.argv[1:]]
previous=json.loads((root/'certificates-results.json').read_text()) if (root/'certificates-results.json').exists() else []
old={r['source']:r for r in previous}
helper_hash=hashlib.sha256(b''.join((repo/'lean/QSym'/name).read_bytes() for name in ['Binding.lean','Tensor.lean','Recursion.lean'])).hexdigest()
imports='\n'.join('import '+m for m in ['QSym.Tensor','QSym.Binding','QSym.AxiomCheck','QSym.Numeric','QSym.Bag','QSym.Conditionals','FocusedRules','ExtraRules','AdditionalRules','NameRules','RecurrenceRules','SolverExtraRules','SelectedRules','FocusedReplay','FocusedSum','FocusedRegion','TensorRules'])+'\n'
def check(p):
 source=p.read_text();dest=out/(p.parent.name+'-'+p.name)
 prior=old.get(str(p.relative_to(repo)))
 if prior and prior.get('passed') and prior.get('helper_hash')==helper_hash and prior['sha256']==hashlib.sha256(source.encode()).hexdigest(): return prior
 dest.write_text(source.replace('import QSym\n',imports))
 assert not re.search(r'\b(by|decreasing_by|sorry|admit|native_decide)\b',source)
 try:
  r=subprocess.run(['lake','env','bash','-c','export LEAN_PATH="$1:$LEAN_PATH"; exec lean "$2"','check',str(out),str(dest)],cwd=repo/'lean',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  output=r.stdout;status=r.returncode
 except subprocess.TimeoutExpired as e:
  output=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else (e.stdout or '')
  status='timeout'
 dest.with_suffix('.log').write_text(output)
 dest.with_suffix('.exit').write_text(str(status)+'\n')
 record={'source':str(p.relative_to(repo)),'sha256':hashlib.sha256(source.encode()).hexdigest(),'exit':status,'passed':status==0 and 'sorryAx' not in output and "declaration uses 'sorry'" not in output,'axiom_checks':output.count('checked axioms for'),'imports_adjusted':True,'helper_hash':helper_hash}
 print(('passed ' if record['passed'] else 'FAILED ')+str(p.relative_to(repo)),flush=True)
 return record
with ThreadPoolExecutor(max_workers=2) as pool: records=list(pool.map(check,inputs))
merged={r['source']:r for r in previous};merged.update({r['source']:r for r in records})
(root/'certificates-results.json').write_text(json.dumps(list(merged.values()),indent=2)+'\n')
print(str(sum(r['passed'] for r in records))+'/'+str(len(records))+' focused certificates passed',flush=True)
raise SystemExit(0 if all(r['passed'] for r in records) else 1)
