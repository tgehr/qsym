from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
root=Path(__file__).resolve().parent;repo=root/'qsym'
suites=['all','language','binding','functional','subsets','refinements','type_values','recursion','higher_equality','binder_names','recurrences','discrete','trig_algebra']
def run(name):
 binary='build/current-'+name
 cmd=['ldc2','-boundscheck=on','-unittest','-I..','-Ideps','-i','tests/'+name+'.d','-of='+binary]
 log=root/('native-'+name+'.log')
 with log.open('w') as f:
  build=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  args=['./'+binary] if name=='all' else ['./'+binary,'--DRT-testmode=run-main','build/'+({'type_values':'type-values','higher_equality':'higher-equality','binder_names':'binder-names','trig_algebra':'trig-algebra'}.get(name,name))]
  check=subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT) if build.returncode==0 else None
 record={'suite':name,'build_exit':build.returncode,'test_exit':check.returncode if check else None};print(record,flush=True);return record
with ThreadPoolExecutor(max_workers=1) as pool:results=list(pool.map(run,suites))
(root/'native-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(0 if all(r['test_exit']==0 for r in results) else 1)
