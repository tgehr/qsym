import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n10 : Expr .natural := (.varN 0)
def n14 : Expr .natural := (.varN 1)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: c0
abbrev c2 : List Binding.Ty := (.scalar .natural) :: c1
abbrev c3 : List Binding.Ty := (.scalar .natural) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c2 (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.subN.apply (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t2 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .integer) := .unary Functions.castNZ.apply (t0 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Functions.nonzeroZ.apply (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n10
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t9 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n14
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .binary Functions.leN.apply (t0 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t14 γ) (t4 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t14 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t16 γ) (t6 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t12 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t11 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c1 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t21 γ))
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .var .here
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n14
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Functions.leN.apply (t23 γ) (t24 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n10
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Binding.guardValue (t25 γ) (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t27 γ)
noncomputable def rec22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t11 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t12 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.branch (.constant (fun x => (t14 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t3 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))) (.branch (.constant (fun x => (t16 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t5 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0)))) (.constant (fun _ => some 0))))
theorem fixed22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = some (FixedPoint.value (rec22 γ ξ ρ).functional) := Recursion.fixed_program (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem unroll22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (Binding.Expr.app (.lam (t21 γ)) (t22 γ)).eval ξ ρ := Recursion.program_unfold (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem solve22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t28 γ).eval ξ ρ :=
  Eq.trans (fixed22 γ ξ ρ) (congrArg some (Recursion.solve_nat_cutoff (rec22 γ ξ ρ) ((n10.eval ξ).getD 0) ((n14.eval ξ).getD 0) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _)))).symm)))
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 γ))
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t28 γ) := .ofEq (fun ξ ρ => solve22 γ ξ ρ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p3 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p5 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .lam (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t28 γ) := .trans (p2 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t28 γ) := .trans (p1 γ) (p9 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t28 γ) := (p10 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t28 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t22 γ).eval ξ ρ) ↔ Value.Defined ((t28 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
