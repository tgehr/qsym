import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_27 ρ)) (Value.refines_refl (v27 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v27 ρ) := (total_27 ρ)
def d27 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .integer := (.castNZ n0)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
def n8 : Expr .rational := (.castZQ n7)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
def n9 : Expr .real := (.castQR n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
def n10 : Expr .complex := (.castRC n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
def n26 : Expr .complex := (.conj n10)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v10 ρ)
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v27 ρ) :=
  Domain.total1 Functions.castNZ (x := (v0 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q0 ρ)
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v27 ρ) :=
  Domain.total1 Functions.castZQ (x := (v7 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q7 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v27 ρ) :=
  Domain.total1 Functions.castQR (x := (v8 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v27 ρ) :=
  Domain.total1 Functions.castRC (x := (v9 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q26 (ρ : Env) : Domain.Correct (v26 ρ) (v27 ρ) :=
  Domain.transport (x := (v10 ρ)) (d := (v27 ρ)) (Value.defined_conj (v10 ρ)) (q10 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n26) (Expr.eval ρ Certificate.n27) :=
  Domain.simplify (q26 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n27) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n26 ↔ (Expr.eval ρ Certificate.n27) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n0)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n12 : Expr .integer := (.int (1))
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n15 : Expr .real := (.castQR n14)
def n16 : Expr .real := (.real (1))
def n17 : Expr .complex := (.castRC n16)
def n26 : Expr .complex := (.conj n10)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v16 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v10 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v26 ρ) (v10 ρ) :=
  (Generated.r_conjugate_real_cast (v9 ρ))

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_7 ρ) (eval_12 ρ)) (Numeric.sound ρ n7 n12 rfl)

theorem p2 (ρ : Env) : Value.Refines (v8 ρ) (v13 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem p4 (ρ : Env) : Value.Refines (v8 ρ) (v14 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (Numeric.sound ρ n15 n16 rfl)

theorem p7 (ρ : Env) : Value.Refines (v9 ρ) (v16 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v10 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v17 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_11 ρ)) (Numeric.sound ρ n17 n11 rfl)

theorem p10 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v26 ρ) (v11 ρ) :=
  (p0 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v11 ρ) (v10 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_11 ρ) (eval_10 ρ)) (Numeric.sound ρ n11 n10 rfl)

theorem p13 (ρ : Env) : Value.Refines (v26 ρ) (v10 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n26) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_26 ρ) (eval_10 ρ)) (p13 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n26) : (Expr.eval ρ n26) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := ∃ x, (v0 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.castNZ.defined (v0 ρ)

def d8 (ρ : Env) : Prop := ∃ x, (v7 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castZQ.defined (v7 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castQR.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castRC.defined (v9 ρ)

def d26 (ρ : Env) : Prop := (d10 ρ)
theorem domain_26 (ρ : Env) : Value.Defined (v26 ρ) ↔ d26 ρ :=
  (Value.defined_conj (v10 ρ)).trans (domain_10 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n26 ↔ (d26 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_26 ρ))).trans (domain_26 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v0 ρ) (total_0 ρ)
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v7 ρ) (total_7 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  (Value.defined_conj (v10 ρ)).mpr (total_10 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n26 := Eq.mpr (congrArg Value.Defined (eval_26 ρ)) (total_26 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_27 ρ)) (Value.refines_refl (v27 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v27 ρ) := (total_27 ρ)
def d27 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .integer := (.castNZ n0)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
def n8 : Expr .rational := (.castZQ n7)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
def n9 : Expr .real := (.castQR n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
def n10 : Expr .complex := (.castRC n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
def n11 : Expr .complex := (.complex (1) (0))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
def n28 : Expr .complex := (.mulC n10 n11)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v10 ρ) (v11 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v27 ρ) :=
  Domain.total1 Functions.castNZ (x := (v0 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q0 ρ)
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v27 ρ) :=
  Domain.total1 Functions.castZQ (x := (v7 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q7 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v27 ρ) :=
  Domain.total1 Functions.castQR (x := (v8 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v27 ρ) :=
  Domain.total1 Functions.castRC (x := (v9 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q28 (ρ : Env) : Domain.Correct (v28 ρ) (v27 ρ) :=
  Domain.strict2 (x := (v10 ρ)) (y := (v11 ρ)) (dx := (v27 ρ)) (dy := (v27 ρ)) (Value.defined_mul (v10 ρ) (v11 ρ)) (q10 ρ) (q11 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n28) (Expr.eval ρ Certificate.n27) :=
  Domain.simplify (q28 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n27) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n28 ↔ (Expr.eval ρ Certificate.n27) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n0)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n12 : Expr .integer := (.int (1))
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n15 : Expr .real := (.castQR n14)
def n16 : Expr .real := (.real (1))
def n17 : Expr .complex := (.castRC n16)
def n28 : Expr .complex := (.mulC n10 n11)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v16 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v10 ρ) (v11 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v28 ρ) (v10 ρ) :=
  let ac10 : Replay.Tree := (.leaf 0)
  let ac11 : Replay.Tree := .unit
  let ac28 : Replay.Tree := (.node ac10 ac11)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v10 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac28 ac10 rfl)

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_7 ρ) (eval_12 ρ)) (Numeric.sound ρ n7 n12 rfl)

theorem p2 (ρ : Env) : Value.Refines (v8 ρ) (v13 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem p4 (ρ : Env) : Value.Refines (v8 ρ) (v14 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (Numeric.sound ρ n15 n16 rfl)

theorem p7 (ρ : Env) : Value.Refines (v9 ρ) (v16 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v10 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v17 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_11 ρ)) (Numeric.sound ρ n17 n11 rfl)

theorem p10 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v28 ρ) (v11 ρ) :=
  (p0 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v11 ρ) (v10 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_11 ρ) (eval_10 ρ)) (Numeric.sound ρ n11 n10 rfl)

theorem p13 (ρ : Env) : Value.Refines (v28 ρ) (v10 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n28) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_28 ρ) (eval_10 ρ)) (p13 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n28) : (Expr.eval ρ n28) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := ∃ x, (v0 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.castNZ.defined (v0 ρ)

def d8 (ρ : Env) : Prop := ∃ x, (v7 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castZQ.defined (v7 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castQR.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castRC.defined (v9 ρ)

def d11 (ρ : Env) : Prop := True
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d28 (ρ : Env) : Prop := (d10 ρ) ∧ (d11 ρ)
theorem domain_28 (ρ : Env) : Value.Defined (v28 ρ) ↔ d28 ρ :=
  (Value.defined_mul (v10 ρ) (v11 ρ)).trans (and_congr (domain_10 ρ) (domain_11 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n28 ↔ (d28 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_28 ρ))).trans (domain_28 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v0 ρ) (total_0 ρ)
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v7 ρ) (total_7 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_28 (ρ : Env) : Value.Defined (v28 ρ) :=
  (Value.defined_mul (v10 ρ) (v11 ρ)).mpr ⟨(total_10 ρ), (total_11 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n28 := Eq.mpr (congrArg Value.Defined (eval_28 ρ)) (total_28 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_27 ρ)) (Value.refines_refl (v27 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v27 ρ) := (total_27 ρ)
def d27 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n1 : Expr .complex := (.complex (0) (1))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
def n29 : Expr .complex := (.conj n1)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v1 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q29 (ρ : Env) : Domain.Correct (v29 ρ) (v27 ρ) :=
  Domain.transport (x := (v1 ρ)) (d := (v27 ρ)) (Value.defined_conj (v1 ρ)) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n29) (Expr.eval ρ Certificate.n27) :=
  Domain.simplify (q29 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n27) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n29 ↔ (Expr.eval ρ Certificate.n27) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .complex := (.complex (0) (1))
def n29 : Expr .complex := (.conj n1)
def n30 : Expr .complex := (.complex (0) (-1))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v1 ρ)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v29 ρ) (v30 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_29 ρ) (eval_30 ρ)) (Numeric.sound ρ n29 n30 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n29) (Expr.eval ρ n30) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_29 ρ) (eval_30 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n29) : (Expr.eval ρ n29) = (Expr.eval ρ n30) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_29 (ρ : Env) : Value.Defined (v29 ρ) :=
  (Value.defined_conj (v1 ρ)).mpr (total_1 ρ)
theorem total_root (ρ : Env) : Value.Defined (v29 ρ) := (total_29 ρ)
def d29 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n29 ↔ (d29 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_29 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n29 := Eq.mpr (congrArg Value.Defined (eval_29 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_27 ρ)) (Value.refines_refl (v27 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v27 ρ) := (total_27 ρ)
def d27 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n1 : Expr .complex := (.complex (0) (1))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
def n30 : Expr .complex := (.complex (0) (-1))
noncomputable def v30 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
def n31 : Expr .complex := (.mulC n30 n1)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v30 ρ) (v1 ρ)
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q31 (ρ : Env) : Domain.Correct (v31 ρ) (v27 ρ) :=
  Domain.strict2 (x := (v30 ρ)) (y := (v1 ρ)) (dx := (v27 ρ)) (dy := (v27 ρ)) (Value.defined_mul (v30 ρ) (v1 ρ)) (q30 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n31) (Expr.eval ρ Certificate.n27) :=
  Domain.simplify (q31 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n27) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n31 ↔ (Expr.eval ρ Certificate.n27) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .complex := (.complex (0) (1))
def n7 : Expr .integer := (.castNZ n0)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n30 : Expr .complex := (.complex (0) (-1))
def n31 : Expr .complex := (.mulC n30 n1)
def b32 : Region (Expr .complex) := .join (.item n1 .one) (.item n30 .one)
def n32 : Expr .complex := Expr.productC b32
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v30 ρ) (v1 ρ)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v1 ρ) (v30 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v31 ρ) (v32 ρ) :=
  let ac1 : Replay.Tree := (.leaf 0)
  let ac30 : Replay.Tree := (.leaf 1)
  let ac31 : Replay.Tree := (.node ac30 ac1)
  let ac32 : Replay.Tree := (.node ac1 ac30)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v1 ρ),(v30 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac31 ac32 rfl)

theorem p1 (ρ : Env) : Value.Refines (v32 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_32 ρ) (eval_11 ρ)) (Numeric.sound ρ n32 n11 rfl)

theorem p2 (ρ : Env) : Value.Refines (v31 ρ) (v11 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v11 ρ) (v10 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_11 ρ) (eval_10 ρ)) (Numeric.sound ρ n11 n10 rfl)

theorem p4 (ρ : Env) : Value.Refines (v31 ρ) (v10 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n31) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_31 ρ) (eval_10 ρ)) (p4 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n31) : (Expr.eval ρ n31) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  (Value.defined_mul (v30 ρ) (v1 ρ)).mpr ⟨(total_30 ρ), (total_1 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v31 ρ) := (total_31 ρ)
def d31 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n31 ↔ (d31 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_31 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n31 := Eq.mpr (congrArg Value.Defined (eval_31 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_27 ρ)) (Value.refines_refl (v27 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v27 ρ) := (total_27 ρ)
def d27 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .integer := (.castNZ n0)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
def n8 : Expr .rational := (.castZQ n7)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
def n9 : Expr .real := (.castQR n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
def n10 : Expr .complex := (.castRC n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
def n18 : Expr .complex := (.complex (0) (0))
noncomputable def v18 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
def n33 : Expr .complex := (.addC n10 n18)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v18 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v27 ρ) :=
  Domain.total1 Functions.castNZ (x := (v0 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q0 ρ)
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v27 ρ) :=
  Domain.total1 Functions.castZQ (x := (v7 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q7 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v27 ρ) :=
  Domain.total1 Functions.castQR (x := (v8 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v27 ρ) :=
  Domain.total1 Functions.castRC (x := (v9 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v27 ρ) :=
  Domain.strict2 (x := (v10 ρ)) (y := (v18 ρ)) (dx := (v27 ρ)) (dy := (v27 ρ)) (Value.defined_add (v10 ρ) (v18 ρ)) (q10 ρ) (q18 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n33) (Expr.eval ρ Certificate.n27) :=
  Domain.simplify (q33 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n27) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n33 ↔ (Expr.eval ρ Certificate.n27) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n0)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n12 : Expr .integer := (.int (1))
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n15 : Expr .real := (.castQR n14)
def n16 : Expr .real := (.real (1))
def n17 : Expr .complex := (.castRC n16)
def n18 : Expr .complex := (.complex (0) (0))
def n33 : Expr .complex := (.addC n10 n18)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v16 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v18 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v33 ρ) (v10 ρ) :=
  let ac10 : Replay.Tree := (.leaf 0)
  let ac18 : Replay.Tree := .unit
  let ac33 : Replay.Tree := (.node ac10 ac18)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addC (fun i => ([(v10 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac33 ac10 rfl)

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_7 ρ) (eval_12 ρ)) (Numeric.sound ρ n7 n12 rfl)

theorem p2 (ρ : Env) : Value.Refines (v8 ρ) (v13 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem p4 (ρ : Env) : Value.Refines (v8 ρ) (v14 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (Numeric.sound ρ n15 n16 rfl)

theorem p7 (ρ : Env) : Value.Refines (v9 ρ) (v16 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v10 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v17 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_11 ρ)) (Numeric.sound ρ n17 n11 rfl)

theorem p10 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v33 ρ) (v11 ρ) :=
  (p0 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v11 ρ) (v10 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_11 ρ) (eval_10 ρ)) (Numeric.sound ρ n11 n10 rfl)

theorem p13 (ρ : Env) : Value.Refines (v33 ρ) (v10 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_10 ρ)) (p13 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := ∃ x, (v0 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.castNZ.defined (v0 ρ)

def d8 (ρ : Env) : Prop := ∃ x, (v7 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castZQ.defined (v7 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castQR.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castRC.defined (v9 ρ)

def d18 (ρ : Env) : Prop := True
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d33 (ρ : Env) : Prop := (d10 ρ) ∧ (d18 ρ)
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  (Value.defined_add (v10 ρ) (v18 ρ)).trans (and_congr (domain_10 ρ) (domain_18 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (domain_33 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v0 ρ) (total_0 ρ)
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v7 ρ) (total_7 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  ⟨_, rfl⟩
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  (Value.defined_add (v10 ρ) (v18 ρ)).mpr ⟨(total_10 ρ), (total_18 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_33 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_27 ρ)) (Value.refines_refl (v27 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v27 ρ) := (total_27 ρ)
def d27 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .integer := (.castNZ n0)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
def n8 : Expr .rational := (.castZQ n7)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
def n9 : Expr .real := (.castQR n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
def n10 : Expr .complex := (.castRC n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
def n27 : Expr .bool := (.bool true)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := some true
def n34 : Expr .complex := (.addC n10 n10)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v10 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v27 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v27 ρ) :=
  Domain.total1 Functions.castNZ (x := (v0 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q0 ρ)
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v27 ρ) :=
  Domain.total1 Functions.castZQ (x := (v7 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q7 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v27 ρ) :=
  Domain.total1 Functions.castQR (x := (v8 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v27 ρ) :=
  Domain.total1 Functions.castRC (x := (v9 ρ)) (d := (v27 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q34 (ρ : Env) : Domain.Correct (v34 ρ) (v27 ρ) :=
  Domain.strict2 (x := (v10 ρ)) (y := (v10 ρ)) (dx := (v27 ρ)) (dy := (v27 ρ)) (Value.defined_add (v10 ρ) (v10 ρ)) (q10 ρ) (q10 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n34) (Expr.eval ρ Certificate.n27) :=
  Domain.simplify (q34 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n27) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n34 ↔ (Expr.eval ρ Certificate.n27) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n0)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n12 : Expr .integer := (.int (1))
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n15 : Expr .real := (.castQR n14)
def n16 : Expr .real := (.real (1))
def n17 : Expr .complex := (.castRC n16)
def n34 : Expr .complex := (.addC n10 n10)
def n36 : Expr .complex := (.complex (2) (0))
def n38 : Expr .natural := (.nat (2))
def n39 : Expr .integer := (.castNZ n38)
def n40 : Expr .rational := (.castZQ n39)
def n41 : Expr .real := (.castQR n40)
def n42 : Expr .complex := (.castRC n41)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v16 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v10 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v10 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v36 ρ) (v11 ρ)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v38 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v39 ρ)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v40 ρ)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v41 ρ)
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_34 (ρ : Env) : (Expr.eval ρ n34) = (v34 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl
theorem eval_42 (ρ : Env) : (Expr.eval ρ n42) = (v42 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v34 ρ) (v35 ρ) :=
  Value.refines_refl (v34 ρ)

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_7 ρ) (eval_12 ρ)) (Numeric.sound ρ n7 n12 rfl)

theorem p2 (ρ : Env) : Value.Refines (v8 ρ) (v13 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem p4 (ρ : Env) : Value.Refines (v8 ρ) (v14 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (Numeric.sound ρ n15 n16 rfl)

theorem p7 (ρ : Env) : Value.Refines (v9 ρ) (v16 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v10 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v17 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_11 ρ)) (Numeric.sound ρ n17 n11 rfl)

theorem p10 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v35 ρ) (v37 ρ) :=
  Value.refines_repeat_addC (.twice .one) 2 (Positive.toNat_twice .one 1 Positive.toNat_one) (x := (v10 ρ)) (y := (v11 ρ)) (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v37 ρ) (v36 ρ) :=
  let ac11 : Replay.Tree := .unit
  let ac36 : Replay.Tree := (.leaf 0)
  let ac37 : Replay.Tree := (.node ac36 ac11)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v36 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac37 ac36 rfl)

theorem p13 (ρ : Env) : Value.Refines (v35 ρ) (v36 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem p14 (ρ : Env) : Value.Refines (v34 ρ) (v36 ρ) :=
  (p0 ρ).trans (p13 ρ)

theorem p15 (ρ : Env) : Value.Refines (v36 ρ) (v42 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_36 ρ) (eval_42 ρ)) (Numeric.sound ρ n36 n42 rfl)

theorem p16 (ρ : Env) : Value.Refines (v34 ρ) (v42 ρ) :=
  (p14 ρ).trans (p15 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n34) (Expr.eval ρ n42) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_34 ρ) (eval_42 ρ)) (p16 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n34) : (Expr.eval ρ n34) = (Expr.eval ρ n42) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := ∃ x, (v0 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.castNZ.defined (v0 ρ)

def d8 (ρ : Env) : Prop := ∃ x, (v7 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castZQ.defined (v7 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castQR.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castRC.defined (v9 ρ)

def d34 (ρ : Env) : Prop := (d10 ρ) ∧ (d10 ρ)
theorem domain_34 (ρ : Env) : Value.Defined (v34 ρ) ↔ d34 ρ :=
  (Value.defined_add (v10 ρ) (v10 ρ)).trans (and_congr (domain_10 ρ) (domain_10 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n34 ↔ (d34 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_34 ρ))).trans (domain_34 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v0 ρ) (total_0 ρ)
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v7 ρ) (total_7 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_34 (ρ : Env) : Value.Defined (v34 ρ) :=
  (Value.defined_add (v10 ρ) (v10 ρ)).mpr ⟨(total_10 ρ), (total_10 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n34 := Eq.mpr (congrArg Value.Defined (eval_34 ρ)) (total_34 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .complex := (.complex (0) (1))
def n7 : Expr .integer := (.castNZ n0)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n18 : Expr .complex := (.complex (0) (0))
def n26 : Expr .complex := (.conj n10)
def n27 : Expr .bool := (.bool true)
def n28 : Expr .complex := (.mulC n10 n11)
def n29 : Expr .complex := (.conj n1)
def n30 : Expr .complex := (.complex (0) (-1))
def n31 : Expr .complex := (.mulC n30 n1)
def n33 : Expr .complex := (.addC n10 n18)
def n34 : Expr .complex := (.addC n10 n10)
def n38 : Expr .natural := (.nat (2))
def n39 : Expr .integer := (.castNZ n38)
def n40 : Expr .rational := (.castZQ n39)
def n41 : Expr .real := (.castQR n40)
def n42 : Expr .complex := (.castRC n41)
abbrev c0 : List Binding.Ty := []
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n1
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n10
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 0) := .constant Tensor.nilValue
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t1 γ) (t6 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t5 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n11
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t9 γ) (t7 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary (Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 2) (t8 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n18
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .unary Value.conj (t1 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t13 γ) (t1 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t14 γ) (t12 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .unary Value.conj (t5 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t16 γ) (t9 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t17 γ) (t15 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n26
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n27
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t20 γ) (t5 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t5 γ) (t9 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n28
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n29
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n30
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t20 γ) (t25 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t25 γ) (t1 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n31
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t5 γ) (t12 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n33
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t5 γ) (t5 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n34
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n42
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t20 γ) (t33 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p5 γ) (p3 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.vector (.scalar .complex) 2)) (b := (.vector (.scalar .complex) 2)) (c := (.scalar .complex)) (Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 2) (p4 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t18 γ) := .ofEq (fun ξ ρ => (Eq.mpr (congrArg (fun w0 : Option ((.scalar .complex) : Binding.Ty).denote => ((Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 2) (Tensor.consValue w0 (Tensor.consValue ((t1 γ).eval ξ ρ) ((t6 γ).eval ξ ρ))) (Tensor.consValue ((t9 γ).eval ξ ρ) (Tensor.consValue ((t1 γ).eval ξ ρ) ((t6 γ).eval ξ ρ)))) = (Value.add (Value.mul (Value.conj w0) ((t9 γ).eval ξ ρ)) (Value.add (Value.mul (Value.conj ((t1 γ).eval ξ ρ)) ((t1 γ).eval ξ ρ)) ((t12 γ).eval ξ ρ)))) (show n10.eval ξ = some (Functions.castRC.value (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0))))) from Eq.trans (congrArg Functions.castRC.apply (show n9.eval ξ = some (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0)))) from Eq.trans (congrArg Functions.castQR.apply (show n8.eval ξ = some (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0))) from Eq.trans (congrArg Functions.castZQ.apply (show n7.eval ξ = some (Functions.castNZ.value ((n0.eval ξ).getD 0)) from Eq.trans (congrArg Functions.castNZ.apply (show n0.eval ξ = some ((n0.eval ξ).getD 0) from rfl)) (Tensor.apply_some Functions.castNZ ((n0.eval ξ).getD 0) True.intro))) (Tensor.apply_some Functions.castZQ (Functions.castNZ.value ((n0.eval ξ).getD 0)) True.intro))) (Tensor.apply_some Functions.castQR (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0))) True.intro))) (Tensor.apply_some Functions.castRC (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0)))) True.intro))) rfl))
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .unary (a := (.scalar .complex)) (b := (.scalar .complex)) Value.conj (p0 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t19 γ) := .ofEq (fun _ _ => rfl)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .refl (t19 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t21 γ) := .scalarSimplify n26 n27 n10 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p13 γ) (p0 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t5 γ) := .guardTrue (t5 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t5 γ) := .trans (p15 γ) (p0 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t5 γ) := .trans (p14 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t5 γ) := .trans (p12 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t5 γ) := .trans (p11 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t5 γ) := .trans (p10 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t5 γ) := .trans (p9 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t22 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p21 γ) (p5 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t23 γ) := .ofEq (fun _ _ => rfl)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t21 γ) := .scalarSimplify n28 n27 n10 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t5 γ) := .trans (p25 γ) (p17 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t5 γ) := .trans (p24 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t5 γ) := .trans (p23 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t5 γ) := .trans (p22 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .unary (a := (.scalar .complex)) (b := (.scalar .complex)) Value.conj (p1 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t24 γ) := .ofEq (fun _ _ => rfl)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t26 γ) := .scalarSimplify n29 n27 n30 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .refl (t25 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p13 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t25 γ) := .guardTrue (t25 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t25 γ) := .trans (p36 γ) (p34 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t25 γ) := .trans (p35 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t25 γ) := .trans (p33 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t25 γ) := .trans (p32 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t25 γ) := .trans (p31 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t25 γ) := .trans (p30 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t27 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p42 γ) (p1 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t28 γ) := .ofEq (fun _ _ => rfl)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .refl (t28 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t21 γ) := .scalarSimplify n31 n27 n10 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t5 γ) := .trans (p46 γ) (p17 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t5 γ) := .trans (p45 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t5 γ) := .trans (p44 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t5 γ) := .trans (p43 γ) (p49 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t29 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p50 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t30 γ) := .ofEq (fun _ _ => rfl)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .refl (t30 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t21 γ) := .scalarSimplify n33 n27 n10 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t5 γ) := .trans (p55 γ) (p17 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t5 γ) := .trans (p54 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t5 γ) := .trans (p53 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t5 γ) := .trans (p52 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t31 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p29 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t32 γ) := .ofEq (fun _ _ => rfl)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .refl (t32 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t34 γ) := .scalarSimplify n34 n27 n42 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .refl (t33 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t34 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p13 γ) (p64 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t33 γ) := .guardTrue (t33 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t33 γ) := .trans (p66 γ) (p64 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t33 γ) := .trans (p65 γ) (p67 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t33 γ) := .trans (p63 γ) (p68 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t33 γ) := .trans (p62 γ) (p69 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t33 γ) := .trans (p61 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t33 γ) := .trans (p60 γ) (p71 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t33 γ) := .trans (p8 γ) (p72 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t33 γ) := .trans (p7 γ) (p73 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t33 γ) := (p74 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t11 γ).eval ξ ρ = (t33 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t11 γ).eval ξ ρ) ↔ Value.Defined ((t33 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t11 γ).eval ξ ρ = n42.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n38 : Expr .natural := (.nat (2))
def n39 : Expr .integer := (.castNZ n38)
def n40 : Expr .rational := (.castZQ n39)
def n41 : Expr .real := (.castQR n40)
def n42 : Expr .complex := (.castRC n41)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v38 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v39 ρ)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v40 ρ)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v41 ρ)
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl
theorem eval_42 (ρ : Env) : (Expr.eval ρ n42) = (v42 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n42) (Expr.eval ρ n42) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_42 ρ) (eval_42 ρ)) (Value.refines_refl (v42 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n42) : (Expr.eval ρ n42) = (Expr.eval ρ n42) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d38 (ρ : Env) : Prop := True
theorem domain_38 (ρ : Env) : Value.Defined (v38 ρ) ↔ d38 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d39 (ρ : Env) : Prop := ∃ x, (v38 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_39 (ρ : Env) : Value.Defined (v39 ρ) ↔ d39 ρ :=
  Functions.castNZ.defined (v38 ρ)

def d40 (ρ : Env) : Prop := ∃ x, (v39 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_40 (ρ : Env) : Value.Defined (v40 ρ) ↔ d40 ρ :=
  Functions.castZQ.defined (v39 ρ)

def d41 (ρ : Env) : Prop := ∃ x, (v40 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  Functions.castQR.defined (v40 ρ)

def d42 (ρ : Env) : Prop := ∃ x, (v41 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_42 (ρ : Env) : Value.Defined (v42 ρ) ↔ d42 ρ :=
  Functions.castRC.defined (v41 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n42 ↔ (d42 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_42 ρ))).trans (domain_42 ρ)
#qsym_check_axioms definedness
theorem total_38 (ρ : Env) : Value.Defined (v38 ρ) :=
  ⟨_, rfl⟩
theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v38 ρ) (total_38 ρ)
theorem total_40 (ρ : Env) : Value.Defined (v40 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v39 ρ) (total_39 ρ)
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v40 ρ) (total_40 ρ)
theorem total_42 (ρ : Env) : Value.Defined (v42 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v41 ρ) (total_41 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n42 := Eq.mpr (congrArg Value.Defined (eval_42 ρ)) (total_42 ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t11 γ).eval ξ ρ) (FunctionScalar.n42.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n42.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t11 γ).eval ξ ρ)) : ((BindingCertificate.t11 γ).eval ξ ρ) = (FunctionScalar.n42.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
