import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .real := (.real (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
def n2 : Expr .real := (.real (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((3 : Int) : ℝ)
def n10 : Expr .real := (.mulR n0 n2)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v2 ρ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v15 ρ) :=
  Domain.strict2 (x := (v0 ρ)) (y := (v2 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (Value.defined_mul (v0 ρ) (v2 ρ)) (q0 ρ) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n10) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q10 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n10 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .real := (.real (1))
def n2 : Expr .real := (.real (3))
def n10 : Expr .real := (.mulR n0 n2)
def n11 : Expr .natural := (.nat (3))
def n12 : Expr .integer := (.castNZ n11)
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .real := (.castQR n13)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((3 : Int) : ℝ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v2 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v11 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
theorem eval_2 (ρ : Env) : (Expr.eval ρ n2) = (v2 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v10 ρ) (v2 ρ) :=
  let ac0 : Replay.Tree := .unit
  let ac2 : Replay.Tree := (.leaf 0)
  let ac10 : Replay.Tree := (.node ac0 ac2)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulR (fun i => ([(v2 ρ)] : List (Option (Ty.denote .real))).getD i none) ac10 ac2 rfl)

theorem p1 (ρ : Env) : Value.Refines (v2 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_2 ρ) (eval_14 ρ)) (Numeric.sound ρ n2 n14 rfl)

theorem p2 (ρ : Env) : Value.Refines (v10 ρ) (v14 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n14) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_14 ρ)) (p2 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n14) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  (Value.defined_mul (v0 ρ) (v2 ρ)).mpr ⟨(total_0 ρ), (total_2 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v10 ρ) := (total_10 ρ)
def d10 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .real := (.real (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some ((2 : Int) : ℝ)
def n3 : Expr .real := (.real (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .real) := some ((4 : Int) : ℝ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .real := (.mulR n1 n3)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v3 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v15 ρ) :=
  Domain.strict2 (x := (v1 ρ)) (y := (v3 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (Value.defined_mul (v1 ρ) (v3 ρ)) (q1 ρ) (q3 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n20) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q20 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n20 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .real := (.real (2))
def n3 : Expr .real := (.real (4))
def n20 : Expr .real := (.mulR n1 n3)
def b21 : Region (Expr .real) := .join (.item n1 .one) (.item n3 .one)
def n21 : Expr .real := Expr.productR b21
def n22 : Expr .real := (.real (8))
def n23 : Expr .natural := (.nat (8))
def n24 : Expr .integer := (.castNZ n23)
def n25 : Expr .rational := (.castZQ n24)
def n26 : Expr .real := (.castQR n25)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some ((2 : Int) : ℝ)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .real) := some ((4 : Int) : ℝ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v3 ρ)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v3 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .real) := some ((8 : Int) : ℝ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v23 ρ)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v25 ρ)
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v20 ρ) (v21 ρ) :=
  Value.refines_refl (v20 ρ)

theorem p1 (ρ : Env) : Value.Refines (v21 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_21 ρ) (eval_22 ρ)) (Numeric.sound ρ n21 n22 rfl)

theorem p2 (ρ : Env) : Value.Refines (v20 ρ) (v22 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v22 ρ) (v26 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_26 ρ)) (Numeric.sound ρ n22 n26 rfl)

theorem p4 (ρ : Env) : Value.Refines (v20 ρ) (v26 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n26) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_26 ρ)) (p4 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n26) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  (Value.defined_mul (v1 ρ) (v3 ρ)).mpr ⟨(total_1 ρ), (total_3 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v20 ρ) := (total_20 ρ)
def d20 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n4 : Expr .real := (.real (0))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .natural := (.nat (8))
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n24 : Expr .integer := (.castNZ n23)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v23 ρ)
def n25 : Expr .rational := (.castZQ n24)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
def n26 : Expr .real := (.castQR n25)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v25 ρ)
def n31 : Expr .real := (.addR n26 n4)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .real) := Value.add (v26 ρ) (v4 ρ)
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v15 ρ) :=
  Domain.total1 Functions.castNZ (x := (v23 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q23 ρ)
theorem q25 (ρ : Env) : Domain.Correct (v25 ρ) (v15 ρ) :=
  Domain.total1 Functions.castZQ (x := (v24 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q24 ρ)
theorem q26 (ρ : Env) : Domain.Correct (v26 ρ) (v15 ρ) :=
  Domain.total1 Functions.castQR (x := (v25 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q25 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q31 (ρ : Env) : Domain.Correct (v31 ρ) (v15 ρ) :=
  Domain.strict2 (x := (v26 ρ)) (y := (v4 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (Value.defined_add (v26 ρ) (v4 ρ)) (q26 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n31) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q31 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n31 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n4 : Expr .real := (.real (0))
def n22 : Expr .real := (.real (8))
def n23 : Expr .natural := (.nat (8))
def n24 : Expr .integer := (.castNZ n23)
def n25 : Expr .rational := (.castZQ n24)
def n26 : Expr .real := (.castQR n25)
def n27 : Expr .integer := (.int (8))
def n28 : Expr .rational := (.castZQ n27)
def n29 : Expr .rational := (.rat ((8) / (1) : ℚ))
def n30 : Expr .real := (.castQR n29)
def n31 : Expr .real := (.addR n26 n4)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .real) := some ((8 : Int) : ℝ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v23 ρ)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v25 ρ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .integer) := some (8)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v27 ρ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .rational) := some ((8) / (1) : ℚ)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v29 ρ)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .real) := Value.add (v26 ρ) (v4 ρ)
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v31 ρ) (v26 ρ) :=
  let ac4 : Replay.Tree := .unit
  let ac26 : Replay.Tree := (.leaf 0)
  let ac31 : Replay.Tree := (.node ac26 ac4)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addR (fun i => ([(v26 ρ)] : List (Option (Ty.denote .real))).getD i none) ac31 ac26 rfl)

theorem p1 (ρ : Env) : Value.Refines (v24 ρ) (v27 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_24 ρ) (eval_27 ρ)) (Numeric.sound ρ n24 n27 rfl)

theorem p2 (ρ : Env) : Value.Refines (v25 ρ) (v28 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v28 ρ) (v29 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_28 ρ) (eval_29 ρ)) (Numeric.sound ρ n28 n29 rfl)

theorem p4 (ρ : Env) : Value.Refines (v25 ρ) (v29 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v26 ρ) (v30 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v30 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_30 ρ) (eval_22 ρ)) (Numeric.sound ρ n30 n22 rfl)

theorem p7 (ρ : Env) : Value.Refines (v26 ρ) (v22 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v31 ρ) (v22 ρ) :=
  (p0 ρ).trans (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v22 ρ) (v26 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_26 ρ)) (Numeric.sound ρ n22 n26 rfl)

theorem p10 (ρ : Env) : Value.Refines (v31 ρ) (v26 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n31) (Expr.eval ρ n26) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_31 ρ) (eval_26 ρ)) (p10 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n31) : (Expr.eval ρ n31) = (Expr.eval ρ n26) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d23 (ρ : Env) : Prop := True
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d24 (ρ : Env) : Prop := ∃ x, (v23 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_24 (ρ : Env) : Value.Defined (v24 ρ) ↔ d24 ρ :=
  Functions.castNZ.defined (v23 ρ)

def d25 (ρ : Env) : Prop := ∃ x, (v24 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_25 (ρ : Env) : Value.Defined (v25 ρ) ↔ d25 ρ :=
  Functions.castZQ.defined (v24 ρ)

def d26 (ρ : Env) : Prop := ∃ x, (v25 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_26 (ρ : Env) : Value.Defined (v26 ρ) ↔ d26 ρ :=
  Functions.castQR.defined (v25 ρ)

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d31 (ρ : Env) : Prop := (d26 ρ) ∧ (d4 ρ)
theorem domain_31 (ρ : Env) : Value.Defined (v31 ρ) ↔ d31 ρ :=
  (Value.defined_add (v26 ρ) (v4 ρ)).trans (and_congr (domain_26 ρ) (domain_4 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n31 ↔ (d31 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_31 ρ))).trans (domain_31 ρ)
#qsym_check_axioms definedness
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v23 ρ) (total_23 ρ)
theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v24 ρ) (total_24 ρ)
theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v25 ρ) (total_25 ρ)
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  (Value.defined_add (v26 ρ) (v4 ρ)).mpr ⟨(total_26 ρ), (total_4 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n31 := Eq.mpr (congrArg Value.Defined (eval_31 ρ)) (total_31 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n11 : Expr .natural := (.nat (3))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n12 : Expr .integer := (.castNZ n11)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v11 ρ)
def n13 : Expr .rational := (.castZQ n12)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
def n14 : Expr .real := (.castQR n13)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .natural := (.nat (8))
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n24 : Expr .integer := (.castNZ n23)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v23 ρ)
def n25 : Expr .rational := (.castZQ n24)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
def n26 : Expr .real := (.castQR n25)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v25 ρ)
def n32 : Expr .real := (.addR n14 n26)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .real) := Value.add (v14 ρ) (v26 ρ)
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v15 ρ) :=
  Domain.total1 Functions.castNZ (x := (v11 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q11 ρ)
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v15 ρ) :=
  Domain.total1 Functions.castZQ (x := (v12 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q12 ρ)
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v15 ρ) :=
  Domain.total1 Functions.castQR (x := (v13 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q13 ρ)
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v15 ρ) :=
  Domain.total1 Functions.castNZ (x := (v23 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q23 ρ)
theorem q25 (ρ : Env) : Domain.Correct (v25 ρ) (v15 ρ) :=
  Domain.total1 Functions.castZQ (x := (v24 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q24 ρ)
theorem q26 (ρ : Env) : Domain.Correct (v26 ρ) (v15 ρ) :=
  Domain.total1 Functions.castQR (x := (v25 ρ)) (d := (v15 ρ)) (fun _ => True.intro) (q25 ρ)
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v15 ρ) :=
  Domain.strict2 (x := (v14 ρ)) (y := (v26 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (Value.defined_add (v14 ρ) (v26 ρ)) (q14 ρ) (q26 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n32) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q32 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n32 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .real := (.real (3))
def n11 : Expr .natural := (.nat (3))
def n12 : Expr .integer := (.castNZ n11)
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .real := (.castQR n13)
def n16 : Expr .integer := (.int (3))
def n17 : Expr .rational := (.castZQ n16)
def n18 : Expr .rational := (.rat ((3) / (1) : ℚ))
def n19 : Expr .real := (.castQR n18)
def n22 : Expr .real := (.real (8))
def n23 : Expr .natural := (.nat (8))
def n24 : Expr .integer := (.castNZ n23)
def n25 : Expr .rational := (.castZQ n24)
def n26 : Expr .real := (.castQR n25)
def n27 : Expr .integer := (.int (8))
def n28 : Expr .rational := (.castZQ n27)
def n29 : Expr .rational := (.rat ((8) / (1) : ℚ))
def n30 : Expr .real := (.castQR n29)
def n32 : Expr .real := (.addR n14 n26)
def b35 : Region (Expr .real) := .join (.item n2 .one) (.item n22 .one)
def n35 : Expr .real := Expr.sumR b35
def n36 : Expr .real := (.real (11))
def n37 : Expr .natural := (.nat (11))
def n38 : Expr .integer := (.castNZ n37)
def n39 : Expr .rational := (.castZQ n38)
def n40 : Expr .real := (.castQR n39)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((3 : Int) : ℝ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v11 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .integer) := some (3)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v16 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v18 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .real) := some ((8 : Int) : ℝ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v23 ρ)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v25 ρ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .integer) := some (8)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v27 ρ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .rational) := some ((8) / (1) : ℚ)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v29 ρ)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .real) := Value.add (v14 ρ) (v26 ρ)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .real) := Value.add (v14 ρ) (v26 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .real) := Value.add (v2 ρ) (v22 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .real) := Value.add (v2 ρ) (v22 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .real) := some ((11 : Int) : ℝ)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := some (11)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v37 ρ)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v38 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v39 ρ)
theorem eval_2 (ρ : Env) : (Expr.eval ρ n2) = (v2 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl
theorem eval_35 (ρ : Env) : (Expr.eval ρ n35) = (v35 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v32 ρ) (v33 ρ) :=
  Value.refines_refl (v32 ρ)

theorem p1 (ρ : Env) : Value.Refines (v12 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_12 ρ) (eval_16 ρ)) (Numeric.sound ρ n12 n16 rfl)

theorem p2 (ρ : Env) : Value.Refines (v13 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v17 ρ) (v18 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_18 ρ)) (Numeric.sound ρ n17 n18 rfl)

theorem p4 (ρ : Env) : Value.Refines (v13 ρ) (v18 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v14 ρ) (v19 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v19 ρ) (v2 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_2 ρ)) (Numeric.sound ρ n19 n2 rfl)

theorem p7 (ρ : Env) : Value.Refines (v14 ρ) (v2 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v24 ρ) (v27 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_24 ρ) (eval_27 ρ)) (Numeric.sound ρ n24 n27 rfl)

theorem p9 (ρ : Env) : Value.Refines (v25 ρ) (v28 ρ) :=
  Value.refines_function1 Functions.castZQ (p8 ρ)

theorem p10 (ρ : Env) : Value.Refines (v28 ρ) (v29 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_28 ρ) (eval_29 ρ)) (Numeric.sound ρ n28 n29 rfl)

theorem p11 (ρ : Env) : Value.Refines (v25 ρ) (v29 ρ) :=
  (p9 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v26 ρ) (v30 ρ) :=
  Value.refines_function1 Functions.castQR (p11 ρ)

theorem p13 (ρ : Env) : Value.Refines (v30 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_30 ρ) (eval_22 ρ)) (Numeric.sound ρ n30 n22 rfl)

theorem p14 (ρ : Env) : Value.Refines (v26 ρ) (v22 ρ) :=
  (p12 ρ).trans (p13 ρ)

theorem p15 (ρ : Env) : Value.Refines (v33 ρ) (v32 ρ) :=
  Value.refines_refl (v33 ρ)

theorem p16 (ρ : Env) : Value.Refines (v32 ρ) (v34 ρ) :=
  Value.refines_add (p7 ρ) (p14 ρ)

theorem p17 (ρ : Env) : Value.Refines (v33 ρ) (v34 ρ) :=
  (p15 ρ).trans (p16 ρ)

theorem p18 (ρ : Env) : Value.Refines (v34 ρ) (v35 ρ) :=
  Value.refines_refl (v34 ρ)

theorem p19 (ρ : Env) : Value.Refines (v33 ρ) (v35 ρ) :=
  (p17 ρ).trans (p18 ρ)

theorem p20 (ρ : Env) : Value.Refines (v35 ρ) (v36 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_35 ρ) (eval_36 ρ)) (Numeric.sound ρ n35 n36 rfl)

theorem p21 (ρ : Env) : Value.Refines (v33 ρ) (v36 ρ) :=
  (p19 ρ).trans (p20 ρ)

theorem p22 (ρ : Env) : Value.Refines (v32 ρ) (v36 ρ) :=
  (p0 ρ).trans (p21 ρ)

theorem p23 (ρ : Env) : Value.Refines (v36 ρ) (v40 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_36 ρ) (eval_40 ρ)) (Numeric.sound ρ n36 n40 rfl)

theorem p24 (ρ : Env) : Value.Refines (v32 ρ) (v40 ρ) :=
  (p22 ρ).trans (p23 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n32) (Expr.eval ρ n40) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_32 ρ) (eval_40 ρ)) (p24 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n32) : (Expr.eval ρ n32) = (Expr.eval ρ n40) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d11 (ρ : Env) : Prop := True
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x, (v11 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.castNZ.defined (v11 ρ)

def d13 (ρ : Env) : Prop := ∃ x, (v12 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.castZQ.defined (v12 ρ)

def d14 (ρ : Env) : Prop := ∃ x, (v13 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.castQR.defined (v13 ρ)

def d23 (ρ : Env) : Prop := True
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d24 (ρ : Env) : Prop := ∃ x, (v23 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_24 (ρ : Env) : Value.Defined (v24 ρ) ↔ d24 ρ :=
  Functions.castNZ.defined (v23 ρ)

def d25 (ρ : Env) : Prop := ∃ x, (v24 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_25 (ρ : Env) : Value.Defined (v25 ρ) ↔ d25 ρ :=
  Functions.castZQ.defined (v24 ρ)

def d26 (ρ : Env) : Prop := ∃ x, (v25 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_26 (ρ : Env) : Value.Defined (v26 ρ) ↔ d26 ρ :=
  Functions.castQR.defined (v25 ρ)

def d32 (ρ : Env) : Prop := (d14 ρ) ∧ (d26 ρ)
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  (Value.defined_add (v14 ρ) (v26 ρ)).trans (and_congr (domain_14 ρ) (domain_26 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n32 ↔ (d32 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_32 ρ))).trans (domain_32 ρ)
#qsym_check_axioms definedness
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v11 ρ) (total_11 ρ)
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v12 ρ) (total_12 ρ)
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v13 ρ) (total_13 ρ)
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v23 ρ) (total_23 ρ)
theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v24 ρ) (total_24 ρ)
theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v25 ρ) (total_25 ρ)
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  (Value.defined_add (v14 ρ) (v26 ρ)).mpr ⟨(total_14 ρ), (total_26 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n32 := Eq.mpr (congrArg Value.Defined (eval_32 ρ)) (total_32 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .real := (.real (1))
def n1 : Expr .real := (.real (2))
def n2 : Expr .real := (.real (3))
def n3 : Expr .real := (.real (4))
def n4 : Expr .real := (.real (0))
def n10 : Expr .real := (.mulR n0 n2)
def n11 : Expr .natural := (.nat (3))
def n12 : Expr .integer := (.castNZ n11)
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .real := (.castQR n13)
def n15 : Expr .bool := (.bool true)
def n20 : Expr .real := (.mulR n1 n3)
def n23 : Expr .natural := (.nat (8))
def n24 : Expr .integer := (.castNZ n23)
def n25 : Expr .rational := (.castZQ n24)
def n26 : Expr .real := (.castQR n25)
def n31 : Expr .real := (.addR n26 n4)
def n32 : Expr .real := (.addR n14 n26)
def n37 : Expr .natural := (.nat (11))
def n38 : Expr .integer := (.castNZ n37)
def n39 : Expr .rational := (.castZQ n38)
def n40 : Expr .real := (.castQR n39)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n2
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n3
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 1) := .binary Tensor.consValue (t6 γ) (t2 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary Tensor.consValue (t5 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (t4 γ) (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n4
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.mul (t1 γ) (t6 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t11 γ) (t10 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.mul (t0 γ) (t5 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t13 γ) (t12 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n10
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n15
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n14
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t16 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n20
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n26
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t16 γ) (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t20 γ) (t10 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n31
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t17 γ) (t20 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n32
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n40
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t16 γ) (t26 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 1)) (c := (.vector (.scalar .real) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 1)) Tensor.consValue (p6 γ) (p2 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 1)) (c := (.vector (.scalar .real) 2)) Tensor.consValue (p5 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .binary (a := (.vector (.scalar .real) 2)) (b := (.vector (.scalar .real) 2)) (c := (.scalar .real)) (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (p4 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t14 γ) := .ofEq (fun ξ ρ => rfl)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.mul (p0 γ) (p5 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t15 γ) := .ofEq (fun _ _ => rfl)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .refl (t15 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t18 γ) := .scalarSimplify n10 n15 n14 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p15 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t17 γ) := .guardTrue (t17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t17 γ) := .trans (p18 γ) (p16 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t17 γ) := .trans (p17 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t17 γ) := .trans (p14 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t17 γ) := .trans (p13 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t17 γ) := .trans (p12 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t17 γ) := .trans (p11 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.mul (p1 γ) (p6 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t19 γ) := .ofEq (fun _ _ => rfl)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .refl (t19 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t21 γ) := .scalarSimplify n20 n15 n26 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p15 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t20 γ) := .guardTrue (t20 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t20 γ) := .trans (p31 γ) (p29 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t20 γ) := .trans (p30 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t20 γ) := .trans (p28 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t20 γ) := .trans (p27 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t20 γ) := .trans (p26 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t20 γ) := .trans (p25 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .refl (t10 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t22 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.add (p37 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t23 γ) := .ofEq (fun _ _ => rfl)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t21 γ) := .scalarSimplify n31 n15 n26 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t20 γ) := .trans (p42 γ) (p33 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t20 γ) := .trans (p41 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t20 γ) := .trans (p40 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t20 γ) := .trans (p39 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t24 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.add (p24 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t25 γ) := .ofEq (fun _ _ => rfl)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .refl (t25 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t27 γ) := .scalarSimplify n32 n15 n40 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p15 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t26 γ) := .guardTrue (t26 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t26 γ) := .trans (p53 γ) (p51 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t26 γ) := .trans (p52 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t26 γ) := .trans (p50 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t26 γ) := .trans (p49 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t26 γ) := .trans (p48 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t26 γ) := .trans (p47 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t26 γ) := .trans (p10 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t26 γ) := .trans (p9 γ) (p60 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t26 γ) := (p61 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t9 γ).eval ξ ρ = (t26 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t9 γ).eval ξ ρ) ↔ Value.Defined ((t26 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t9 γ).eval ξ ρ = n40.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n37 : Expr .natural := (.nat (11))
def n38 : Expr .integer := (.castNZ n37)
def n39 : Expr .rational := (.castZQ n38)
def n40 : Expr .real := (.castQR n39)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := some (11)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v37 ρ)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v38 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v39 ρ)
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n40) (Expr.eval ρ n40) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_40 ρ) (eval_40 ρ)) (Value.refines_refl (v40 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n40) : (Expr.eval ρ n40) = (Expr.eval ρ n40) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d37 (ρ : Env) : Prop := True
theorem domain_37 (ρ : Env) : Value.Defined (v37 ρ) ↔ d37 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d38 (ρ : Env) : Prop := ∃ x, (v37 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_38 (ρ : Env) : Value.Defined (v38 ρ) ↔ d38 ρ :=
  Functions.castNZ.defined (v37 ρ)

def d39 (ρ : Env) : Prop := ∃ x, (v38 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_39 (ρ : Env) : Value.Defined (v39 ρ) ↔ d39 ρ :=
  Functions.castZQ.defined (v38 ρ)

def d40 (ρ : Env) : Prop := ∃ x, (v39 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_40 (ρ : Env) : Value.Defined (v40 ρ) ↔ d40 ρ :=
  Functions.castQR.defined (v39 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n40 ↔ (d40 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_40 ρ))).trans (domain_40 ρ)
#qsym_check_axioms definedness
theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  ⟨_, rfl⟩
theorem total_38 (ρ : Env) : Value.Defined (v38 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v37 ρ) (total_37 ρ)
theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v38 ρ) (total_38 ρ)
theorem total_40 (ρ : Env) : Value.Defined (v40 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v39 ρ) (total_39 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n40 := Eq.mpr (congrArg Value.Defined (eval_40 ρ)) (total_40 ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t9 γ).eval ξ ρ) (FunctionScalar.n40.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n40.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t9 γ).eval ξ ρ)) : ((BindingCertificate.t9 γ).eval ξ ρ) = (FunctionScalar.n40.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
