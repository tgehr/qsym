import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n37 : Expr .bool := (.bool true)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n37) (Expr.eval ρ n37) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_37 ρ) (eval_37 ρ)) (Value.refines_refl (v37 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n37) : (Expr.eval ρ n37) = (Expr.eval ρ n37) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v37 ρ) := (total_37 ρ)
def d37 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n37 ↔ (d37 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_37 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n37 := Eq.mpr (congrArg Value.Defined (eval_37 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n8 : Expr .natural := (.nat (3))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n12 : Expr .natural := (.nat (2))
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n31 : Expr .natural := (.varN 3)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 3)
def n32 : Expr .natural := (.mulN n31 n12)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v31 ρ) (v12 ρ)
def n33 : Expr .natural := (.addN n8 n32)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v8 ρ) (v32 ρ)
def n37 : Expr .bool := (.bool true)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v37 ρ) :=
  Domain.leaf _
theorem q31 (ρ : Env) : Domain.Correct (v31 ρ) (v37 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v37 ρ) :=
  Domain.leaf _
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v37 ρ) :=
  Domain.total2 Functions.mulN (x := (v31 ρ)) (y := (v12 ρ)) (dx := (v37 ρ)) (dy := (v37 ρ)) (fun _ _ => True.intro) (q31 ρ) (q12 ρ)
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v37 ρ) :=
  Domain.total2 Functions.addN (x := (v8 ρ)) (y := (v32 ρ)) (dx := (v37 ρ)) (dy := (v37 ρ)) (fun _ _ => True.intro) (q8 ρ) (q32 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n33) (Expr.eval ρ Certificate.n37) :=
  Domain.simplify (q33 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n37) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n33 ↔ (Expr.eval ρ Certificate.n37) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .natural := (.nat (3))
def n12 : Expr .natural := (.nat (2))
def n31 : Expr .natural := (.varN 3)
def n32 : Expr .natural := (.mulN n31 n12)
def n33 : Expr .natural := (.addN n8 n32)
def n34 : Expr .natural := (.mulN n12 n31)
def n36 : Expr .natural := (.addN n34 n8)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 3)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v31 ρ) (v12 ρ)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v8 ρ) (v32 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v12 ρ) (v31 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v8 ρ) (v34 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v34 ρ) (v8 ρ)
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v32 ρ) (v34 ρ) :=
  (Generated.r_natural_literal_coefficient (v31 ρ) (v12 ρ))

theorem p1 (ρ : Env) : Value.Refines (v33 ρ) (v35 ρ) :=
  Value.refines_function2 Functions.addN (Value.refines_refl (v8 ρ)) (p0 ρ)

theorem p2 (ρ : Env) : Value.Refines (v35 ρ) (v36 ρ) :=
  (Generated.r_natural_literal_constant (v34 ρ) (v8 ρ))

theorem p3 (ρ : Env) : Value.Refines (v33 ρ) (v36 ρ) :=
  (p1 ρ).trans (p2 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n36) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_36 ρ)) (p3 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n36) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d31 (ρ : Env) : Prop := True
theorem domain_31 (ρ : Env) : Value.Defined (v31 ρ) ↔ d31 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := True
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d32 (ρ : Env) : Prop := ∃ x y, (v31 ρ) = some x ∧ (v12 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  Functions.mulN.defined (v31 ρ) (v12 ρ)

def d33 (ρ : Env) : Prop := ∃ x y, (v8 ρ) = some x ∧ (v32 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  Functions.addN.defined (v8 ρ) (v32 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (domain_33 ρ)
#qsym_check_axioms definedness
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v31 ρ) (v12 ρ) (total_31 ρ) (total_12 ρ)
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v8 ρ) (v32 ρ) (total_8 ρ) (total_32 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_33 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n37 : Expr .bool := (.bool true)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n37) (Expr.eval ρ n37) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_37 ρ) (eval_37 ρ)) (Value.refines_refl (v37 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n37) : (Expr.eval ρ n37) = (Expr.eval ρ n37) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v37 ρ) := (total_37 ρ)
def d37 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n37 ↔ (d37 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_37 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n37 := Eq.mpr (congrArg Value.Defined (eval_37 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n8 : Expr .natural := (.nat (3))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n12 : Expr .natural := (.nat (2))
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n37 : Expr .bool := (.bool true)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .bool) := some true
def n43 : Expr .natural := (.mulN n12 n8)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v12 ρ) (v8 ρ)
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v37 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v37 ρ) :=
  Domain.leaf _
theorem q43 (ρ : Env) : Domain.Correct (v43 ρ) (v37 ρ) :=
  Domain.total2 Functions.mulN (x := (v12 ρ)) (y := (v8 ρ)) (dx := (v37 ρ)) (dy := (v37 ρ)) (fun _ _ => True.intro) (q12 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n43) (Expr.eval ρ Certificate.n37) :=
  Domain.simplify (q43 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n37) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n43 ↔ (Expr.eval ρ Certificate.n37) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .natural := (.nat (3))
def n12 : Expr .natural := (.nat (2))
def n43 : Expr .natural := (.mulN n12 n8)
def n44 : Expr .natural := (.nat (6))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v12 ρ) (v8 ρ)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .natural) := some (6)
theorem eval_43 (ρ : Env) : (Expr.eval ρ n43) = (v43 ρ) := rfl
theorem eval_44 (ρ : Env) : (Expr.eval ρ n44) = (v44 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v43 ρ) (v44 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_43 ρ) (eval_44 ρ)) (Numeric.sound ρ n43 n44 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n43) (Expr.eval ρ n44) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_43 ρ) (eval_44 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n43) : (Expr.eval ρ n43) = (Expr.eval ρ n44) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d12 (ρ : Env) : Prop := True
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d43 (ρ : Env) : Prop := ∃ x y, (v12 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_43 (ρ : Env) : Value.Defined (v43 ρ) ↔ d43 ρ :=
  Functions.mulN.defined (v12 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n43 ↔ (d43 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_43 ρ))).trans (domain_43 ρ)
#qsym_check_axioms definedness
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_43 (ρ : Env) : Value.Defined (v43 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v12 ρ) (v8 ρ) (total_12 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n43 := Eq.mpr (congrArg Value.Defined (eval_43 ρ)) (total_43 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n37 : Expr .bool := (.bool true)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n37) (Expr.eval ρ n37) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_37 ρ) (eval_37 ρ)) (Value.refines_refl (v37 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n37) : (Expr.eval ρ n37) = (Expr.eval ρ n37) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v37 ρ) := (total_37 ρ)
def d37 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n37 ↔ (d37 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_37 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n37 := Eq.mpr (congrArg Value.Defined (eval_37 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n8 : Expr .natural := (.nat (3))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n37 : Expr .bool := (.bool true)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .bool) := some true
def n44 : Expr .natural := (.nat (6))
noncomputable def v44 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n45 : Expr .natural := (.addN n44 n8)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v44 ρ) (v8 ρ)
theorem q44 (ρ : Env) : Domain.Correct (v44 ρ) (v37 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v37 ρ) :=
  Domain.leaf _
theorem q45 (ρ : Env) : Domain.Correct (v45 ρ) (v37 ρ) :=
  Domain.total2 Functions.addN (x := (v44 ρ)) (y := (v8 ρ)) (dx := (v37 ρ)) (dy := (v37 ρ)) (fun _ _ => True.intro) (q44 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n45) (Expr.eval ρ Certificate.n37) :=
  Domain.simplify (q45 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n37) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n45 ↔ (Expr.eval ρ Certificate.n37) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .natural := (.nat (3))
def n44 : Expr .natural := (.nat (6))
def n45 : Expr .natural := (.addN n44 n8)
def n46 : Expr .natural := (.nat (9))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v44 ρ) (v8 ρ)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (9)
theorem eval_45 (ρ : Env) : (Expr.eval ρ n45) = (v45 ρ) := rfl
theorem eval_46 (ρ : Env) : (Expr.eval ρ n46) = (v46 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v45 ρ) (v46 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_45 ρ) (eval_46 ρ)) (Numeric.sound ρ n45 n46 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n45) (Expr.eval ρ n46) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_45 ρ) (eval_46 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n45) : (Expr.eval ρ n45) = (Expr.eval ρ n46) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d44 (ρ : Env) : Prop := True
theorem domain_44 (ρ : Env) : Value.Defined (v44 ρ) ↔ d44 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d45 (ρ : Env) : Prop := ∃ x y, (v44 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_45 (ρ : Env) : Value.Defined (v45 ρ) ↔ d45 ρ :=
  Functions.addN.defined (v44 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n45 ↔ (d45 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_45 ρ))).trans (domain_45 ρ)
#qsym_check_axioms definedness
theorem total_44 (ρ : Env) : Value.Defined (v44 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_45 (ρ : Env) : Value.Defined (v45 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v44 ρ) (v8 ρ) (total_44 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n45 := Eq.mpr (congrArg Value.Defined (eval_45 ρ)) (total_45 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n8 : Expr .natural := (.nat (3))
def n12 : Expr .natural := (.nat (2))
def n31 : Expr .natural := (.varN 3)
def n32 : Expr .natural := (.mulN n31 n12)
def n33 : Expr .natural := (.addN n8 n32)
def n34 : Expr .natural := (.mulN n12 n31)
def n36 : Expr .natural := (.addN n34 n8)
def n37 : Expr .bool := (.bool true)
def n43 : Expr .natural := (.mulN n12 n8)
def n44 : Expr .natural := (.nat (6))
def n45 : Expr .natural := (.addN n44 n8)
def n46 : Expr .natural := (.nat (9))
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: c0
abbrev c2 : List Binding.Ty := (.scalar .natural) :: c1
abbrev c3 : List Binding.Ty := (.scalar .natural) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c2 (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.subN.apply (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .integer) := .unary Functions.castNZ.apply (t0 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Functions.nonzeroZ.apply (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t6 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n8
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t7 γ) (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t7 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n12
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t4 γ) (t11 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t10 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t9 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c1 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t14 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t15 γ))
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n8
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .app (t16 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n12
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t19 γ) (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t18 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n8
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .var .here
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n12
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Functions.mulN.apply (t24 γ) (t25 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Functions.addN.apply (t23 γ) (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Functions.mulN.apply (t25 γ) (t24 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Functions.addN.apply (t29 γ) (t23 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t30 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .app (t31 γ) (t17 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t19 γ) (t17 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t33 γ) (t17 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .seq (t17 γ) (t34 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n43
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n37
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n44
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t37 γ) (t38 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t38 γ) (t17 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n45
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n46
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t37 γ) (t42 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .seq (t17 γ) (t42 γ)
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t42 γ) (t21 γ)
noncomputable def rec16 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t9 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t10 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.call (.constant (fun x => (t3 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun x => (t11 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))))
theorem fixed16 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t16 γ).eval ξ ρ = some (FixedPoint.value (rec16 γ ξ ρ).functional) := Recursion.fixed_program (rec16 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _))))))
theorem unroll16 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t16 γ).eval ξ ρ = (Binding.Expr.app (.lam (t15 γ)) (t16 γ)).eval ξ ρ := Recursion.program_unfold (rec16 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _))))))
theorem solve16 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t16 γ).eval ξ ρ = (t28 γ).eval ξ ρ :=
  Eq.trans (fixed16 γ ξ ρ) (congrArg some (Recursion.solve_nat_step (rec16 γ ξ ρ) Functions.addN.apply (n8.eval ξ) (n12.eval ξ) (fun (x : ℕ) => (t27 γ).eval ξ (Binding.Env.cons (a := .scalar .natural) (some x) ρ)) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))).symm) (Generated.r_natural_recurrence_add_base (n8.eval ξ) (n12.eval ξ) ⟨_, rfl⟩) (fun x => Eq.trans (congrArg (fun (z : Option ℕ) => (t27 γ).eval ξ (Binding.Env.cons (a := .scalar .natural) z ρ)) (Recursion.nat_successor x).symm) (Generated.r_natural_recurrence_add_step (n8.eval ξ) (n12.eval ξ) (some x)).symm)))
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .refl (t15 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 γ))
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t28 γ) := .ofEq (fun ξ ρ => solve16 γ ξ ρ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .refl (t25 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p3 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .lam (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t31 γ) := .lamPointwise (fun ξ ρ x => (Binding.preserveDomain (n33.eval ({ ξ with natural := fun i => if i = 3 then x else ξ.natural i })) (n36.eval ({ ξ with natural := fun i => if i = 3 then x else ξ.natural i })) (n37.eval ({ ξ with natural := fun i => if i = 3 then x else ξ.natural i })) (QSym.BindingScalar0.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 3 then x else ξ.natural i })) (QSym.BindingScalar0.ValueCertificate.refinement ({ ξ with natural := fun i => if i = 3 then x else ξ.natural i }))))
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p5 γ) (p4 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p10 γ) (p3 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .lam (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t31 γ) := .trans (p9 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t31 γ) := .trans (p8 γ) (p13 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t31 γ) := .trans (p2 γ) (p14 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t31 γ) := .trans (p1 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t32 γ) := .app (p16 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t35 γ) := .beta (t30 γ) (t17 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .refl (t19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p20 γ) (p17 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t36 γ) := .ofEq (fun _ _ => rfl)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .refl (t36 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t39 γ) := .scalarSimplify n43 n37 n44 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .refl (t37 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .refl (t38 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p25 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .guardTrue (t38 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .trans (p28 γ) (p26 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .trans (p27 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p24 γ) (p30 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p23 γ) (p31 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t38 γ) := .trans (p22 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t38 γ) := .trans (p21 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t40 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p34 γ) (p17 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t41 γ) := .ofEq (fun _ _ => rfl)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .refl (t41 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t43 γ) := .scalarSimplify n45 n37 n46 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .refl (t42 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t43 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p25 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .guardTrue (t42 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .trans (p41 γ) (p39 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .trans (p40 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t42 γ) := .trans (p38 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t42 γ) := .trans (p37 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t42 γ) := .trans (p36 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t42 γ) := .trans (p35 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t44 γ) := .seq (p17 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t42 γ) := .seqScalar n8 (t42 γ) (fun _ => ⟨_, rfl⟩)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t42 γ) := .trans (p49 γ) (p39 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t42 γ) := .trans (p48 γ) (p50 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t42 γ) := .trans (p19 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t42 γ) := .trans (p18 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p20 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t45 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p53 γ) (p55 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t45 γ) := (p56 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t45 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t22 γ).eval ξ ρ) ↔ Value.Defined ((t45 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
