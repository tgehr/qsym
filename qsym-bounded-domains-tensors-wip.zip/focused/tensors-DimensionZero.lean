import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
abbrev c0 (δ : ℕ → ℕ) : List Binding.Ty := []
noncomputable def t1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) .type := .constant (some (.vector (.scalar .real) (δ 0)))
noncomputable def t2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) .type := .constant (some (.vector (.scalar .real) 0))
noncomputable def t3 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.scalar .bool) := .binary Binding.typeEqValue (t1 δ γ) (t2 δ γ)
theorem p0 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t1 δ γ) (t1 δ γ) := .refl (t1 δ γ)
theorem p1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t2 δ γ) (t2 δ γ) := .refl (t2 δ γ)
theorem p2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t3 δ γ) (t3 δ γ) := .binary (a := .type) (b := .type) (c := (.scalar .bool)) Binding.typeEqValue (p0 δ γ) (p1 δ γ)
theorem reduction (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t3 δ γ) (t3 δ γ) := (p2 δ γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : (t3 ξ.natural γ).eval ξ ρ = (t3 ξ.natural γ).eval ξ ρ := Binding.Reduction.sound (reduction ξ.natural γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : Value.Defined ((t3 ξ.natural γ).eval ξ ρ) ↔ Value.Defined ((t3 ξ.natural γ).eval ξ ρ) := Binding.Reduction.defined (reduction ξ.natural γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
