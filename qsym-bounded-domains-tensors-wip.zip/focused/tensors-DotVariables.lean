import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_10 ρ)) (Value.refines_refl (v10 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v10 ρ) := (total_10 ρ)
def d10 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .real := (.varR 0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 0)
def n3 : Expr .real := (.mulR n0 n0)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v0 ρ)
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v10 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v10 ρ) :=
  Domain.strict2 (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v10 ρ)) (dy := (v10 ρ)) (Value.defined_mul (v0 ρ) (v0 ρ)) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n3) (Expr.eval ρ Certificate.n10) :=
  Domain.simplify (q3 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n10) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n3 ↔ (Expr.eval ρ Certificate.n10) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .real := (.varR 0)
def n3 : Expr .real := (.mulR n0 n0)
def n9 : Expr .real := (.powR n0 2)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 0)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v0 ρ)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v0 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v0 ρ)
theorem eval_3 (ρ : Env) : (Expr.eval ρ n3) = (v3 ρ) := rfl
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v3 ρ) (v7 ρ) :=
  Value.refines_refl (v3 ρ)

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v9 ρ) :=
  Value.refines_repeat_mul (.twice .one) 2 (Positive.toNat_twice .one 1 Positive.toNat_one) (x := (v0 ρ)) (y := (v0 ρ)) (Value.refines_refl (v0 ρ))

theorem p2 (ρ : Env) : Value.Refines (v3 ρ) (v9 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n3) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_3 ρ) (eval_9 ρ)) (p2 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n3) : (Expr.eval ρ n3) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  (Value.defined_mul (v0 ρ) (v0 ρ)).mpr ⟨(total_0 ρ), (total_0 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v3 ρ) := (total_3 ρ)
def d3 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n3 ↔ (d3 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_3 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n3 := Eq.mpr (congrArg Value.Defined (eval_3 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_10 ρ)) (Value.refines_refl (v10 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v10 ρ) := (total_10 ρ)
def d10 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .real := (.varR 1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 1)
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
def n11 : Expr .real := (.mulR n1 n1)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v1 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v10 ρ) :=
  Domain.leaf _
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v10 ρ) :=
  Domain.strict2 (x := (v1 ρ)) (y := (v1 ρ)) (dx := (v10 ρ)) (dy := (v10 ρ)) (Value.defined_mul (v1 ρ) (v1 ρ)) (q1 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n11) (Expr.eval ρ Certificate.n10) :=
  Domain.simplify (q11 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n10) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n11 ↔ (Expr.eval ρ Certificate.n10) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .real := (.varR 1)
def n11 : Expr .real := (.mulR n1 n1)
def n13 : Expr .real := (.powR n1 2)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 1)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v1 ρ)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v1 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v1 ρ)
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v11 ρ) (v12 ρ) :=
  Value.refines_refl (v11 ρ)

theorem p1 (ρ : Env) : Value.Refines (v12 ρ) (v13 ρ) :=
  Value.refines_repeat_mul (.twice .one) 2 (Positive.toNat_twice .one 1 Positive.toNat_one) (x := (v1 ρ)) (y := (v1 ρ)) (Value.refines_refl (v1 ρ))

theorem p2 (ρ : Env) : Value.Refines (v11 ρ) (v13 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n11) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_11 ρ) (eval_13 ρ)) (p2 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n11) : (Expr.eval ρ n11) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  (Value.defined_mul (v1 ρ) (v1 ρ)).mpr ⟨(total_1 ρ), (total_1 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v11 ρ) := (total_11 ρ)
def d11 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n11 ↔ (d11 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_11 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n11 := Eq.mpr (congrArg Value.Defined (eval_11 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_10 ρ)) (Value.refines_refl (v10 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v10 ρ) := (total_10 ρ)
def d10 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n1 : Expr .real := (.varR 1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 1)
def n2 : Expr .real := (.real (0))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
def n13 : Expr .real := (.powR n1 2)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v1 ρ)
def n14 : Expr .real := (.addR n13 n2)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Value.add (v13 ρ) (v2 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v10 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v10 ρ) :=
  Domain.transport (x := (v1 ρ)) (d := (v10 ρ)) (Value.defined_map _ (v1 ρ)) (q1 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v10 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v10 ρ) :=
  Domain.strict2 (x := (v13 ρ)) (y := (v2 ρ)) (dx := (v10 ρ)) (dy := (v10 ρ)) (Value.defined_add (v13 ρ) (v2 ρ)) (q13 ρ) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n10) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n10) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n10) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .real := (.varR 1)
def n2 : Expr .real := (.real (0))
def n13 : Expr .real := (.powR n1 2)
def n14 : Expr .real := (.addR n13 n2)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 1)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v1 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Value.add (v13 ρ) (v2 ρ)
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v13 ρ) :=
  let ac2 : Replay.Tree := .unit
  let ac13 : Replay.Tree := (.leaf 0)
  let ac14 : Replay.Tree := (.node ac13 ac2)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addR (fun i => ([(v13 ρ)] : List (Option (Ty.denote .real))).getD i none) ac14 ac13 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_13 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  (Value.defined_map _ (v1 ρ)).mpr (total_1 ρ)
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  (Value.defined_add (v13 ρ) (v2 ρ)).mpr ⟨(total_13 ρ), (total_2 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v14 ρ) := (total_14 ρ)
def d14 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_10 ρ)) (Value.refines_refl (v10 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v10 ρ) := (total_10 ρ)
def d10 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n0 : Expr .real := (.varR 0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 0)
def n1 : Expr .real := (.varR 1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 1)
def n9 : Expr .real := (.powR n0 2)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v0 ρ)
def n10 : Expr .bool := (.bool true)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .bool) := some true
def n13 : Expr .real := (.powR n1 2)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v1 ρ)
def n15 : Expr .real := (.addR n9 n13)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Value.add (v9 ρ) (v13 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v10 ρ) :=
  Domain.leaf _
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v10 ρ) :=
  Domain.transport (x := (v0 ρ)) (d := (v10 ρ)) (Value.defined_map _ (v0 ρ)) (q0 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v10 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v10 ρ) :=
  Domain.transport (x := (v1 ρ)) (d := (v10 ρ)) (Value.defined_map _ (v1 ρ)) (q1 ρ)
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v10 ρ) :=
  Domain.strict2 (x := (v9 ρ)) (y := (v13 ρ)) (dx := (v10 ρ)) (dy := (v10 ρ)) (Value.defined_add (v9 ρ) (v13 ρ)) (q9 ρ) (q13 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n15) (Expr.eval ρ Certificate.n10) :=
  Domain.simplify (q15 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n10) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n15 ↔ (Expr.eval ρ Certificate.n10) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .real := (.varR 0)
def n1 : Expr .real := (.varR 1)
def n9 : Expr .real := (.powR n0 2)
def n13 : Expr .real := (.powR n1 2)
def n15 : Expr .real := (.addR n9 n13)
def b16 : Region (Expr .real) := .join (.item n9 .one) (.item n13 .one)
def n16 : Expr .real := Expr.sumR b16
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 0)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 1)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v0 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v1 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Value.add (v9 ρ) (v13 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := Value.add (v9 ρ) (v13 ρ)
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Value.refines_refl (v15 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  (Value.defined_map _ (v0 ρ)).mpr (total_0 ρ)
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  (Value.defined_map _ (v1 ρ)).mpr (total_1 ρ)
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  (Value.defined_add (v9 ρ) (v13 ρ)).mpr ⟨(total_9 ρ), (total_13 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .real := (.varR 0)
def n1 : Expr .real := (.varR 1)
def n2 : Expr .real := (.real (0))
def n3 : Expr .real := (.mulR n0 n0)
def n9 : Expr .real := (.powR n0 2)
def n10 : Expr .bool := (.bool true)
def n11 : Expr .real := (.mulR n1 n1)
def n13 : Expr .real := (.powR n1 2)
def n14 : Expr .real := (.addR n13 n2)
def n15 : Expr .real := (.addR n9 n13)
def b16 : Region (Expr .real) := .join (.item n9 .one) (.item n13 .one)
def n16 : Expr .real := Expr.sumR b16
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (t4 γ) (t4 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n2
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.mul (t1 γ) (t1 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t7 γ) (t6 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.mul (t0 γ) (t0 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t9 γ) (t8 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n3
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n10
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n9
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t12 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n11
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n13
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t12 γ) (t16 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t16 γ) (t6 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n14
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t13 γ) (t16 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n15
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n16
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t12 γ) (t22 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 1)) (c := (.vector (.scalar .real) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.vector (.scalar .real) 2)) (b := (.vector (.scalar .real) 2)) (c := (.scalar .real)) (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (p4 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t10 γ) := .ofEq (fun ξ ρ => rfl)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.mul (p0 γ) (p0 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t11 γ) := .ofEq (fun _ _ => rfl)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t14 γ) := .scalarSimplify n3 n10 n9 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .refl (t13 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p11 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t13 γ) := .guardTrue (t13 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t13 γ) := .trans (p14 γ) (p12 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t13 γ) := .trans (p13 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t13 γ) := .trans (p10 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t13 γ) := .trans (p9 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t13 γ) := .trans (p8 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t13 γ) := .trans (p7 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.mul (p1 γ) (p1 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t15 γ) := .ofEq (fun _ _ => rfl)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .refl (t15 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t17 γ) := .scalarSimplify n11 n10 n13 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p11 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t16 γ) := .guardTrue (t16 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t16 γ) := .trans (p27 γ) (p25 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t16 γ) := .trans (p26 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t16 γ) := .trans (p24 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t16 γ) := .trans (p23 γ) (p30 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t16 γ) := .trans (p22 γ) (p31 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t16 γ) := .trans (p21 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t18 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.add (p33 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t19 γ) := .ofEq (fun _ _ => rfl)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .refl (t19 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t17 γ) := .scalarSimplify n14 n10 n13 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t16 γ) := .trans (p38 γ) (p29 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t16 γ) := .trans (p37 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t16 γ) := .trans (p36 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t16 γ) := .trans (p35 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t20 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.add (p20 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t21 γ) := .ofEq (fun _ _ => rfl)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t23 γ) := .scalarSimplify n15 n10 n16 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .refl (t22 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p11 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t22 γ) := .guardTrue (t22 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t22 γ) := .trans (p49 γ) (p47 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t22 γ) := .trans (p48 γ) (p50 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t22 γ) := .trans (p46 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t22 γ) := .trans (p45 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t22 γ) := .trans (p44 γ) (p53 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t22 γ) := .trans (p43 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t22 γ) := .trans (p6 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t22 γ) := .trans (p5 γ) (p56 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t22 γ) := (p57 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t5 γ).eval ξ ρ = (t22 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t5 γ).eval ξ ρ) ↔ Value.Defined ((t22 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t5 γ).eval ξ ρ = n16.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .real := (.varR 0)
def n1 : Expr .real := (.varR 1)
def n9 : Expr .real := (.powR n0 2)
def n13 : Expr .real := (.powR n1 2)
def b16 : Region (Expr .real) := .join (.item n9 .one) (.item n13 .one)
def n16 : Expr .real := Expr.sumR b16
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 0)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some (ρ.real 1)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v0 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v1 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := Value.add (v9 ρ) (v13 ρ)
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  (Value.defined_map _ (v0 ρ)).mpr (total_0 ρ)
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  (Value.defined_map _ (v1 ρ)).mpr (total_1 ρ)
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  (Value.defined_add (v9 ρ) (v13 ρ)).mpr ⟨(total_9 ρ), (total_13 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t5 γ).eval ξ ρ) (FunctionScalar.n16.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n16.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t5 γ).eval ξ ρ)) : ((BindingCertificate.t5 γ).eval ξ ρ) = (FunctionScalar.n16.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
