import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n12 : Expr .natural := (.mulN n0 n3)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v3 ρ)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v13 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v3 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q0 ρ) (q3 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n12) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q12 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n12 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (4))
def n12 : Expr .natural := (.mulN n0 n3)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v3 ρ)
theorem eval_3 (ρ : Env) : (Expr.eval ρ n3) = (v3 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v12 ρ) (v3 ρ) :=
  (Generated.r_natural_one_mul (v3 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n3) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_3 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n3) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v3 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.mulN.defined (v0 ρ) (v3 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (domain_12 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v3 ρ) (total_0 ρ) (total_3 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_12 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n14 : Expr .natural := (.mulN n1 n4)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v4 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v13 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v4 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q1 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n4 : Expr .natural := (.nat (5))
def n14 : Expr .natural := (.mulN n1 n4)
def n15 : Expr .natural := (.nat (10))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v4 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (10)
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_14 ρ) (eval_15 ρ)) (Numeric.sound ρ n14 n15 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d14 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.mulN.defined (v1 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (domain_14 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v4 ρ) (total_1 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_14 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n2 : Expr .natural := (.nat (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n16 : Expr .natural := (.mulN n2 n5)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v5 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v13 ρ) :=
  Domain.total2 Functions.mulN (x := (v2 ρ)) (y := (v5 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q2 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n16) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q16 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n16 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (3))
def n5 : Expr .natural := (.nat (6))
def n16 : Expr .natural := (.mulN n2 n5)
def n17 : Expr .natural := (.nat (18))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v5 ρ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (18)
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v16 ρ) (v17 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_16 ρ) (eval_17 ρ)) (Numeric.sound ρ n16 n17 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_17 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d16 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  Functions.mulN.defined (v2 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (domain_16 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v2 ρ) (v5 ρ) (total_2 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_16 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n6 : Expr .natural := (.nat (0))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n17 : Expr .natural := (.nat (18))
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (18)
def n18 : Expr .natural := (.addN n17 n6)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v17 ρ) (v6 ρ)
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v13 ρ) :=
  Domain.total2 Functions.addN (x := (v17 ρ)) (y := (v6 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q17 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n18) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q18 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n18 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n6 : Expr .natural := (.nat (0))
def n17 : Expr .natural := (.nat (18))
def n18 : Expr .natural := (.addN n17 n6)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (18)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v17 ρ) (v6 ρ)
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v18 ρ) (v17 ρ) :=
  (Generated.r_natural_add_zero (v17 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n18) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_18 ρ) (eval_17 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n18) : (Expr.eval ρ n18) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d17 (ρ : Env) : Prop := True
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d18 (ρ : Env) : Prop := ∃ x y, (v17 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  Functions.addN.defined (v17 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n18 ↔ (d18 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_18 ρ))).trans (domain_18 ρ)
#qsym_check_axioms definedness
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v17 ρ) (v6 ρ) (total_17 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n18 := Eq.mpr (congrArg Value.Defined (eval_18 ρ)) (total_18 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n15 : Expr .natural := (.nat (10))
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n17 : Expr .natural := (.nat (18))
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (18)
def n19 : Expr .natural := (.addN n15 n17)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v15 ρ) (v17 ρ)
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q19 (ρ : Env) : Domain.Correct (v19 ρ) (v13 ρ) :=
  Domain.total2 Functions.addN (x := (v15 ρ)) (y := (v17 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q15 ρ) (q17 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n19) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q19 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n19 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .natural := (.nat (10))
def n17 : Expr .natural := (.nat (18))
def n19 : Expr .natural := (.addN n15 n17)
def n20 : Expr .natural := (.nat (28))
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (18)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v15 ρ) (v17 ρ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (28)
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v19 ρ) (v20 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (Numeric.sound ρ n19 n20 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n19) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n19) : (Expr.eval ρ n19) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d15 (ρ : Env) : Prop := True
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d17 (ρ : Env) : Prop := True
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d19 (ρ : Env) : Prop := ∃ x y, (v15 ρ) = some x ∧ (v17 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_19 (ρ : Env) : Value.Defined (v19 ρ) ↔ d19 ρ :=
  Functions.addN.defined (v15 ρ) (v17 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n19 ↔ (d19 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_19 ρ))).trans (domain_19 ρ)
#qsym_check_axioms definedness
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_19 (ρ : Env) : Value.Defined (v19 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v15 ρ) (v17 ρ) (total_15 ρ) (total_17 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n19 := Eq.mpr (congrArg Value.Defined (eval_19 ρ)) (total_19 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .natural := (.nat (28))
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (28)
def n21 : Expr .natural := (.addN n3 n20)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v3 ρ) (v20 ρ)
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q21 (ρ : Env) : Domain.Correct (v21 ρ) (v13 ρ) :=
  Domain.total2 Functions.addN (x := (v3 ρ)) (y := (v20 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q3 ρ) (q20 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n21) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q21 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n21 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n3 : Expr .natural := (.nat (4))
def n20 : Expr .natural := (.nat (28))
def n21 : Expr .natural := (.addN n3 n20)
def n22 : Expr .natural := (.nat (32))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (28)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v3 ρ) (v20 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := some (32)
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v21 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_21 ρ) (eval_22 ρ)) (Numeric.sound ρ n21 n22 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n21) (Expr.eval ρ n22) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_21 ρ) (eval_22 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n21) : (Expr.eval ρ n21) = (Expr.eval ρ n22) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d20 (ρ : Env) : Prop := True
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d21 (ρ : Env) : Prop := ∃ x y, (v3 ρ) = some x ∧ (v20 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_21 (ρ : Env) : Value.Defined (v21 ρ) ↔ d21 ρ :=
  Functions.addN.defined (v3 ρ) (v20 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n21 ↔ (d21 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_21 ρ))).trans (domain_21 ρ)
#qsym_check_axioms definedness
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_21 (ρ : Env) : Value.Defined (v21 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v3 ρ) (v20 ρ) (total_3 ρ) (total_20 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n21 := Eq.mpr (congrArg Value.Defined (eval_21 ρ)) (total_21 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (3))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (5))
def n5 : Expr .natural := (.nat (6))
def n6 : Expr .natural := (.nat (0))
def n12 : Expr .natural := (.mulN n0 n3)
def n13 : Expr .bool := (.bool true)
def n14 : Expr .natural := (.mulN n1 n4)
def n15 : Expr .natural := (.nat (10))
def n16 : Expr .natural := (.mulN n2 n5)
def n17 : Expr .natural := (.nat (18))
def n18 : Expr .natural := (.addN n17 n6)
def n19 : Expr .natural := (.addN n15 n17)
def n20 : Expr .natural := (.nat (28))
def n21 : Expr .natural := (.addN n3 n20)
def n22 : Expr .natural := (.nat (32))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t2 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t1 γ) (t4 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t0 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n5
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t9 γ) (t3 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t8 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t7 γ) (t11 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary (Tensor.dotValue Functions.addN.apply Functions.mulN.apply id 0 3) (t6 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n6
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t2 γ) (t9 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t14 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t1 γ) (t8 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t17 γ) (t16 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t7 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t19 γ) (t18 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n12
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n13
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t7 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n14
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n15
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t25 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n16
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n17
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t28 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t28 γ) (t14 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n18
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t25 γ) (t28 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n19
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n20
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t34 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t7 γ) (t34 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n21
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n22
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t38 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p2 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p1 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p0 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .refl (t8 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p9 γ) (p3 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p8 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p7 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.vector (.scalar .natural) 3)) (b := (.vector (.scalar .natural) 3)) (c := (.scalar .natural)) (Tensor.dotValue Functions.addN.apply Functions.mulN.apply id 0 3) (p6 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t20 γ) := .ofEq (fun ξ ρ => rfl)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p7 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t21 γ) := .ofEq (fun _ _ => rfl)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t23 γ) := .scalarSimplify n12 n13 n3 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .refl (t22 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p7 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t7 γ) := .guardTrue (t7 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t7 γ) := .trans (p21 γ) (p7 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t7 γ) := .trans (p20 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t7 γ) := .trans (p18 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t7 γ) := .trans (p17 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t7 γ) := .trans (p16 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t7 γ) := .trans (p15 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p1 γ) (p8 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t24 γ) := .ofEq (fun _ _ => rfl)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t26 γ) := .scalarSimplify n14 n13 n15 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .refl (t25 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t25 γ) := .guardTrue (t25 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t25 γ) := .trans (p34 γ) (p32 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t25 γ) := .trans (p33 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t25 γ) := .trans (p31 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t25 γ) := .trans (p30 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t25 γ) := .trans (p29 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t25 γ) := .trans (p28 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p2 γ) (p9 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t27 γ) := .ofEq (fun _ _ => rfl)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .refl (t27 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t29 γ) := .scalarSimplify n16 n13 n17 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .refl (t28 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t28 γ) := .guardTrue (t28 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t28 γ) := .trans (p47 γ) (p45 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t28 γ) := .trans (p46 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t28 γ) := .trans (p44 γ) (p49 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t28 γ) := .trans (p43 γ) (p50 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t28 γ) := .trans (p42 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t28 γ) := .trans (p41 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .refl (t14 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t30 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p53 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t31 γ) := .ofEq (fun _ _ => rfl)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .refl (t31 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t29 γ) := .scalarSimplify n18 n13 n17 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t28 γ) := .trans (p58 γ) (p49 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t28 γ) := .trans (p57 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t28 γ) := .trans (p56 γ) (p60 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t28 γ) := .trans (p55 γ) (p61 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t32 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p40 γ) (p62 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t33 γ) := .ofEq (fun _ _ => rfl)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .refl (t33 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t35 γ) := .scalarSimplify n19 n13 n20 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t34 γ) := .refl (t34 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p67 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t34 γ) := .guardTrue (t34 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t34 γ) := .trans (p69 γ) (p67 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t34 γ) := .trans (p68 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t34 γ) := .trans (p66 γ) (p71 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t34 γ) := .trans (p65 γ) (p72 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t34 γ) := .trans (p64 γ) (p73 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t34 γ) := .trans (p63 γ) (p74 γ)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t36 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p27 γ) (p75 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t37 γ) := .ofEq (fun _ _ => rfl)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .refl (t37 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t39 γ) := .scalarSimplify n21 n13 n22 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .refl (t38 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p80 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .guardTrue (t38 γ)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .trans (p82 γ) (p80 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .trans (p81 γ) (p83 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t38 γ) := .trans (p79 γ) (p84 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t38 γ) := .trans (p78 γ) (p85 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p77 γ) (p86 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t38 γ) := .trans (p76 γ) (p87 γ)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t38 γ) := .trans (p14 γ) (p88 γ)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t38 γ) := .trans (p13 γ) (p89 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t38 γ) := (p90 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t13 γ).eval ξ ρ = (t38 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t13 γ).eval ξ ρ) ↔ Value.Defined ((t38 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t13 γ).eval ξ ρ = n22.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n22 : Expr .natural := (.nat (32))
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := some (32)
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n22) (Expr.eval ρ n22) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_22 ρ) (eval_22 ρ)) (Value.refines_refl (v22 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n22) : (Expr.eval ρ n22) = (Expr.eval ρ n22) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v22 ρ) := (total_22 ρ)
def d22 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n22 ↔ (d22 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_22 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n22 := Eq.mpr (congrArg Value.Defined (eval_22 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t13 γ).eval ξ ρ) (FunctionScalar.n22.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n22.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t13 γ).eval ξ ρ)) : ((BindingCertificate.t13 γ).eval ξ ρ) = (FunctionScalar.n22.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
