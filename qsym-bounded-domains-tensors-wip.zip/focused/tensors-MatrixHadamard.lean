import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n9) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_9 ρ) (eval_9 ρ)) (Value.refines_refl (v9 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n9) : (Expr.eval ρ n9) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v9 ρ) := (total_9 ρ)
def d9 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n9 ↔ (d9 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_9 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n9 := Eq.mpr (congrArg Value.Defined (eval_9 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n8 : Expr .natural := (.mulN n0 n0)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v0 ρ)
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v9 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v9 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v9 ρ)) (dy := (v9 ρ)) (fun _ _ => True.intro) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n8) (Expr.eval ρ Certificate.n9) :=
  Domain.simplify (q8 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n9) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n8 ↔ (Expr.eval ρ Certificate.n9) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n8 : Expr .natural := (.mulN n0 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v0 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_8 (ρ : Env) : (Expr.eval ρ n8) = (v8 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v8 ρ) (v0 ρ) :=
  (Generated.r_natural_mul_one (v0 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n8) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_8 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n8) : (Expr.eval ρ n8) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.mulN.defined (v0 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n8 ↔ (d8 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_8 ρ))).trans (domain_8 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v0 ρ) (total_0 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n8 := Eq.mpr (congrArg Value.Defined (eval_8 ρ)) (total_8 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n9) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_9 ρ) (eval_9 ρ)) (Value.refines_refl (v9 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n9) : (Expr.eval ρ n9) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v9 ρ) := (total_9 ρ)
def d9 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n9 ↔ (d9 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_9 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n9 := Eq.mpr (congrArg Value.Defined (eval_9 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
def n10 : Expr .natural := (.mulN n1 n1)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v1 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v9 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v9 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v1 ρ)) (dx := (v9 ρ)) (dy := (v9 ρ)) (fun _ _ => True.intro) (q1 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n10) (Expr.eval ρ Certificate.n9) :=
  Domain.simplify (q10 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n9) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n10 ↔ (Expr.eval ρ Certificate.n9) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n3 : Expr .natural := (.nat (4))
def n10 : Expr .natural := (.mulN n1 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v1 ρ)
theorem eval_3 (ρ : Env) : (Expr.eval ρ n3) = (v3 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v10 ρ) (v3 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_10 ρ) (eval_3 ρ)) (Numeric.sound ρ n10 n3 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n3) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_3 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n3) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d10 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.mulN.defined (v1 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (domain_10 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v1 ρ) (total_1 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_10 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n9) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_9 ρ) (eval_9 ρ)) (Value.refines_refl (v9 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n9) : (Expr.eval ρ n9) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v9 ρ) := (total_9 ρ)
def d9 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n9 ↔ (d9 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_9 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n9 := Eq.mpr (congrArg Value.Defined (eval_9 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n2 : Expr .natural := (.nat (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
def n11 : Expr .natural := (.mulN n2 n2)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v2 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v9 ρ) :=
  Domain.leaf _
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v9 ρ) :=
  Domain.total2 Functions.mulN (x := (v2 ρ)) (y := (v2 ρ)) (dx := (v9 ρ)) (dy := (v9 ρ)) (fun _ _ => True.intro) (q2 ρ) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n11) (Expr.eval ρ Certificate.n9) :=
  Domain.simplify (q11 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n9) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n11 ↔ (Expr.eval ρ Certificate.n9) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (3))
def n11 : Expr .natural := (.mulN n2 n2)
def n12 : Expr .natural := (.nat (9))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v2 ρ)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := some (9)
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v11 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_11 ρ) (eval_12 ρ)) (Numeric.sound ρ n11 n12 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n11) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_11 ρ) (eval_12 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n11) : (Expr.eval ρ n11) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d11 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v2 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  Functions.mulN.defined (v2 ρ) (v2 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n11 ↔ (d11 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_11 ρ))).trans (domain_11 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v2 ρ) (v2 ρ) (total_2 ρ) (total_2 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n11 := Eq.mpr (congrArg Value.Defined (eval_11 ρ)) (total_11 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n9) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_9 ρ) (eval_9 ρ)) (Value.refines_refl (v9 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n9) : (Expr.eval ρ n9) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v9 ρ) := (total_9 ρ)
def d9 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n9 ↔ (d9 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_9 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n9 := Eq.mpr (congrArg Value.Defined (eval_9 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n9 : Expr .bool := (.bool true)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .bool) := some true
def n13 : Expr .natural := (.mulN n3 n3)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v3 ρ)
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v9 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v9 ρ) :=
  Domain.total2 Functions.mulN (x := (v3 ρ)) (y := (v3 ρ)) (dx := (v9 ρ)) (dy := (v9 ρ)) (fun _ _ => True.intro) (q3 ρ) (q3 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n13) (Expr.eval ρ Certificate.n9) :=
  Domain.simplify (q13 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n9) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n13 ↔ (Expr.eval ρ Certificate.n9) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n3 : Expr .natural := (.nat (4))
def n13 : Expr .natural := (.mulN n3 n3)
def n14 : Expr .natural := (.nat (16))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v3 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := some (16)
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n14) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n14) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := ∃ x y, (v3 ρ) = some x ∧ (v3 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.mulN.defined (v3 ρ) (v3 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (domain_13 ρ)
#qsym_check_axioms definedness
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v3 ρ) (v3 ρ) (total_3 ρ) (total_3 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_13 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (3))
def n3 : Expr .natural := (.nat (4))
def n8 : Expr .natural := (.mulN n0 n0)
def n9 : Expr .bool := (.bool true)
def n10 : Expr .natural := (.mulN n1 n1)
def n11 : Expr .natural := (.mulN n2 n2)
def n12 : Expr .natural := (.nat (9))
def n13 : Expr .natural := (.mulN n3 n3)
def n14 : Expr .natural := (.nat (16))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t6 γ) (t2 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t5 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 0) := .constant Tensor.nilValue
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t8 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t4 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.zipValue (Tensor.zipValue Functions.mulN.apply 2) 2) (t11 γ) (t11 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary (Tensor.zipValue Functions.mulN.apply 2) (t4 γ) (t4 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary (Tensor.zipValue Functions.mulN.apply 2) (t8 γ) (t8 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t14 γ) (t9 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t13 γ) (t15 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t0 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t1 γ) (t1 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t18 γ) (t2 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t17 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n8
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n9
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t0 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n10
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t6 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t7 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t5 γ) (t5 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t6 γ) (t6 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t28 γ) (t2 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t27 γ) (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n11
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n12
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t32 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n13
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n14
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t22 γ) (t35 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t35 γ) (t2 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t32 γ) (t37 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t38 γ) (t9 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t26 γ) (t39 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p6 γ) (p2 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p5 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p8 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p4 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.zipValue (Tensor.zipValue Functions.mulN.apply 2) 2) (p11 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t16 γ) := .ofEq (fun ξ ρ => rfl)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 2)) (Tensor.zipValue Functions.mulN.apply 2) (p4 γ) (p4 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t20 γ) := .ofEq (fun ξ ρ => rfl)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p0 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t21 γ) := .ofEq (fun _ _ => rfl)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t23 γ) := .scalarSimplify n8 n9 n0 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .refl (t22 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p20 γ) (p0 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t0 γ) := .guardTrue (t0 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t0 γ) := .trans (p22 γ) (p0 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t0 γ) := .trans (p21 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t0 γ) := .trans (p19 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t0 γ) := .trans (p18 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t0 γ) := .trans (p17 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t0 γ) := .trans (p16 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p1 γ) (p1 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t24 γ) := .ofEq (fun _ _ => rfl)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t25 γ) := .scalarSimplify n10 n9 n3 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p20 γ) (p6 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t6 γ) := .guardTrue (t6 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t6 γ) := .trans (p34 γ) (p6 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t6 γ) := .trans (p33 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t6 γ) := .trans (p32 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t6 γ) := .trans (p31 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t6 γ) := .trans (p30 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t6 γ) := .trans (p29 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t7 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p40 γ) (p2 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t26 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p28 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t26 γ) := .trans (p15 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t26 γ) := .trans (p14 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 2)) (Tensor.zipValue Functions.mulN.apply 2) (p8 γ) (p8 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t30 γ) := .ofEq (fun ξ ρ => rfl)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p5 γ) (p5 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t31 γ) := .ofEq (fun _ _ => rfl)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .refl (t31 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t33 γ) := .scalarSimplify n11 n9 n12 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .refl (t32 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p20 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t32 γ) := .guardTrue (t32 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t32 γ) := .trans (p53 γ) (p51 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t32 γ) := .trans (p52 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t32 γ) := .trans (p50 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t32 γ) := .trans (p49 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t32 γ) := .trans (p48 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t32 γ) := .trans (p47 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p6 γ) (p6 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t34 γ) := .ofEq (fun _ _ => rfl)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t34 γ) := .refl (t34 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t36 γ) := .scalarSimplify n13 n9 n14 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .refl (t35 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p20 γ) (p64 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t35 γ) := .guardTrue (t35 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t35 γ) := .trans (p66 γ) (p64 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t35 γ) := .trans (p65 γ) (p67 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t35 γ) := .trans (p63 γ) (p68 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t35 γ) := .trans (p62 γ) (p69 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t35 γ) := .trans (p61 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t35 γ) := .trans (p60 γ) (p71 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t37 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p72 γ) (p2 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t38 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p59 γ) (p73 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t38 γ) := .trans (p46 γ) (p74 γ)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t38 γ) := .trans (p45 γ) (p75 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t39 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p76 γ) (p9 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t40 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p44 γ) (p77 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t40 γ) := .trans (p13 γ) (p78 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t40 γ) := .trans (p12 γ) (p79 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t40 γ) := (p80 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t12 γ).eval ξ ρ = (t40 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t12 γ).eval ξ ρ) ↔ Value.Defined ((t40 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
