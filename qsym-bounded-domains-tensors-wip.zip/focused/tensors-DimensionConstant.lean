import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .bool := (.bool true)
abbrev c0 : List Binding.Ty := []
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 .type := .constant (some (.vector (.scalar .real) 3))
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Binding.typeEqValue (t1 γ) (t1 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n0
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .seq (t1 γ) (t3 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .binary (a := .type) (b := .type) (c := (.scalar .bool)) Binding.typeEqValue (p0 γ) (p0 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t4 γ) := .typeEqSelf (t1 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .seq (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t3 γ) := .ofEq (fun _ _ => rfl)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t3 γ) := .trans (p5 γ) (p3 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t3 γ) := .trans (p4 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t3 γ) := .trans (p2 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t3 γ) := .trans (p1 γ) (p8 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t3 γ) := (p9 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t2 γ).eval ξ ρ = (t3 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t2 γ).eval ξ ρ) ↔ Value.Defined ((t3 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t2 γ).eval ξ ρ = n0.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .bool := (.bool true)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n0) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_0 ρ) (eval_0 ρ)) (Value.refines_refl (v0 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n0) : (Expr.eval ρ n0) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v0 ρ) := (total_0 ρ)
def d0 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n0 ↔ (d0 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_0 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n0 := Eq.mpr (congrArg Value.Defined (eval_0 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t2 γ).eval ξ ρ) (FunctionScalar.n0.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n0.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t2 γ).eval ξ ρ)) : ((BindingCertificate.t2 γ).eval ξ ρ) = (FunctionScalar.n0.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
