import QSym.Refinement
import QSym.AxiomCheck
namespace QSym.Generated
theorem r_natural_indexed_one (v_n : Option (Ty.denote .natural)) :
    Value.Refines (Functions.powNN.apply (some ((1) : ℕ)) v_n) (some ((1) : ℕ)) := by
  cases v_n
  all_goals qsym_rule

#qsym_check_axioms r_natural_indexed_one


theorem r_natural_indexed_power (v_x : Option (Ty.denote .natural)) (v_n : Nat) :
    Value.Refines (Functions.powNN.apply v_x (some (v_n : ℕ))) (v_x.map (fun x => x ^ v_n)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_indexed_power


theorem r_natural_mul_zero (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.mulN.apply v_x (some ((0) : ℕ))) (some ((0) : ℕ)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_mul_zero


theorem r_natural_pow_one (v_x : Option (Ty.denote .natural)) :
    Value.Refines (v_x.map (fun x => x ^ (1))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_pow_one


theorem r_natural_pow_zero (v_x : Option (Ty.denote .natural)) :
    Value.Refines (v_x.map (fun x => x ^ (0))) (some ((1) : ℕ)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_pow_zero


theorem r_natural_zero_mul (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.mulN.apply (some ((0) : ℕ)) v_x) (some ((0) : ℕ)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_zero_mul


end QSym.Generated
