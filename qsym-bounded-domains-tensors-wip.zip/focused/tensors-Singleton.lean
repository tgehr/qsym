import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t0 γ) (t1 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p0 γ) (p1 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := (p2 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t2 γ).eval ξ ρ = (t2 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t2 γ).eval ξ ρ) ↔ Value.Defined ((t2 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
