import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .complex := (.complex (0) (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n10 : Expr .complex := (.conj n0)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v0 ρ)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v12 ρ) :=
  Domain.transport (x := (v0 ρ)) (d := (v12 ρ)) (Value.defined_conj (v0 ρ)) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n10) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q10 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n10 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .complex := (.complex (0) (1))
def n10 : Expr .complex := (.conj n0)
def n11 : Expr .complex := (.complex (0) (-1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v0 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_10 ρ) (eval_11 ρ)) (Numeric.sound ρ n10 n11 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_11 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  (Value.defined_conj (v0 ρ)).mpr (total_0 ρ)
theorem total_root (ρ : Env) : Value.Defined (v10 ρ) := (total_10 ρ)
def d10 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .complex := (.complex (1) (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n11 : Expr .complex := (.complex (0) (-1))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n13 : Expr .complex := (.mulC n11 n1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v11 ρ) (v1 ρ)
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v12 ρ) :=
  Domain.strict2 (x := (v11 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (Value.defined_mul (v11 ρ) (v1 ρ)) (q11 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n13) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q13 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n13 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .complex := (.complex (1) (0))
def n11 : Expr .complex := (.complex (0) (-1))
def n13 : Expr .complex := (.mulC n11 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v11 ρ) (v1 ρ)
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v13 ρ) (v11 ρ) :=
  let ac1 : Replay.Tree := .unit
  let ac11 : Replay.Tree := (.leaf 0)
  let ac13 : Replay.Tree := (.node ac11 ac1)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v11 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac13 ac11 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_11 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  (Value.defined_mul (v11 ρ) (v1 ρ)).mpr ⟨(total_11 ρ), (total_1 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n2 : Expr .complex := (.complex (0) (0))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n11 : Expr .complex := (.complex (0) (-1))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n14 : Expr .complex := (.addC n11 n2)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v11 ρ) (v2 ρ)
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v12 ρ) :=
  Domain.strict2 (x := (v11 ρ)) (y := (v2 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (Value.defined_add (v11 ρ) (v2 ρ)) (q11 ρ) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .complex := (.complex (0) (0))
def n11 : Expr .complex := (.complex (0) (-1))
def n14 : Expr .complex := (.addC n11 n2)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v11 ρ) (v2 ρ)
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v11 ρ) :=
  let ac2 : Replay.Tree := .unit
  let ac11 : Replay.Tree := (.leaf 0)
  let ac14 : Replay.Tree := (.node ac11 ac2)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addC (fun i => ([(v11 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac14 ac11 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_11 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  (Value.defined_add (v11 ρ) (v2 ρ)).mpr ⟨(total_11 ρ), (total_2 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v14 ρ) := (total_14 ρ)
def d14 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .complex := (.complex (0) (1))
def n1 : Expr .complex := (.complex (1) (0))
def n2 : Expr .complex := (.complex (0) (0))
def n10 : Expr .complex := (.conj n0)
def n11 : Expr .complex := (.complex (0) (-1))
def n12 : Expr .bool := (.bool true)
def n13 : Expr .complex := (.mulC n11 n1)
def n14 : Expr .complex := (.addC n11 n2)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 0) := .constant Tensor.nilValue
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t0 γ) (t1 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n1
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t3 γ) (t1 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary (Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 1) (t2 γ) (t4 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n2
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .unary Value.conj (t0 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t7 γ) (t3 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t8 γ) (t6 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n10
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n12
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n11
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t11 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t12 γ) (t3 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n13
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t12 γ) (t6 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n14
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p0 γ) (p1 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p3 γ) (p1 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.vector (.scalar .complex) 1)) (b := (.vector (.scalar .complex) 1)) (c := (.scalar .complex)) (Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 1) (p2 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t9 γ) := .ofEq (fun ξ ρ => rfl)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .unary (a := (.scalar .complex)) (b := (.scalar .complex)) Value.conj (p0 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t10 γ) := .ofEq (fun _ _ => rfl)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .refl (t10 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t13 γ) := .scalarSimplify n10 n12 n11 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p11 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t12 γ) := .guardTrue (t12 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t12 γ) := .trans (p14 γ) (p12 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t12 γ) := .trans (p13 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t12 γ) := .trans (p10 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t12 γ) := .trans (p9 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t12 γ) := .trans (p8 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t12 γ) := .trans (p7 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t14 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p20 γ) (p3 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t15 γ) := .ofEq (fun _ _ => rfl)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .refl (t15 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t13 γ) := .scalarSimplify n13 n12 n11 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t12 γ) := .trans (p24 γ) (p16 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t12 γ) := .trans (p23 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t12 γ) := .trans (p22 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t12 γ) := .trans (p21 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t16 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p28 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t17 γ) := .ofEq (fun _ _ => rfl)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t13 γ) := .scalarSimplify n14 n12 n11 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t12 γ) := .trans (p33 γ) (p16 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t12 γ) := .trans (p32 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t12 γ) := .trans (p31 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t12 γ) := .trans (p30 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t12 γ) := .trans (p6 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t12 γ) := .trans (p5 γ) (p38 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t12 γ) := (p39 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t5 γ).eval ξ ρ = (t12 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t5 γ).eval ξ ρ) ↔ Value.Defined ((t12 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t5 γ).eval ξ ρ = n11.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n11 : Expr .complex := (.complex (0) (-1))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n11) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_11 ρ) (eval_11 ρ)) (Value.refines_refl (v11 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n11) : (Expr.eval ρ n11) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v11 ρ) := (total_11 ρ)
def d11 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n11 ↔ (d11 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_11 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n11 := Eq.mpr (congrArg Value.Defined (eval_11 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t5 γ).eval ξ ρ) (FunctionScalar.n11.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n11.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t5 γ).eval ξ ρ)) : ((BindingCertificate.t5 γ).eval ξ ρ) = (FunctionScalar.n11.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
