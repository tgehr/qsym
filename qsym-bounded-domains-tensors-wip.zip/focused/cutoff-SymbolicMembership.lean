import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_33 ρ)) (Value.refines_refl (v33 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v33 ρ) := (total_33 ρ)
def d33 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n3 : Expr .natural := (.nat (0))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v33 ρ) :=
  Domain.leaf _
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n3) (Expr.eval ρ Certificate.n33) :=
  Domain.simplify (q3 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n33) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n3 ↔ (Expr.eval ρ Certificate.n33) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_33 ρ)) (Value.refines_refl (v33 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v33 ρ) := (total_33 ρ)
def d33 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n13 : Expr .natural := (.nat (10))
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
def n53 : Expr .natural := (.varN 8)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 8)
def n54 : Expr .bool := (.leN n53 n13)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v53 ρ) (v13 ρ)
theorem q53 (ρ : Env) : Domain.Correct (v53 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q54 (ρ : Env) : Domain.Correct (v54 ρ) (v33 ρ) :=
  Domain.total2 Functions.leN (x := (v53 ρ)) (y := (v13 ρ)) (dx := (v33 ρ)) (dy := (v33 ρ)) (fun _ _ => True.intro) (q53 ρ) (q13 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n54) (Expr.eval ρ Certificate.n33) :=
  Domain.simplify (q54 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n33) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n54 ↔ (Expr.eval ρ Certificate.n33) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .natural := (.nat (10))
def n33 : Expr .bool := (.bool true)
def n56 : Expr .natural := (.varN 9)
def n57 : Expr .bool := (.leN n56 n13)
def n59 : Expr .bool := (.not n57)
def n62 : Expr .bool := (.or n59 n33)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 9)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v56 ρ) (v13 ρ)
noncomputable def v59 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v57 ρ)
noncomputable def v62 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v59 ρ) (v33 ρ)
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_62 (ρ : Env) : (Expr.eval ρ n62) = (v62 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v62 ρ) (v33 ρ) :=
  (Generated.r_bool_or_right_true (v59 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n62) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_62 ρ) (eval_33 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n62) : (Expr.eval ρ n62) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d56 (ρ : Env) : Prop := True
theorem domain_56 (ρ : Env) : Value.Defined (v56 ρ) ↔ d56 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := True
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d57 (ρ : Env) : Prop := ∃ x y, (v56 ρ) = some x ∧ (v13 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_57 (ρ : Env) : Value.Defined (v57 ρ) ↔ d57 ρ :=
  Functions.leN.defined (v56 ρ) (v13 ρ)

def d59 (ρ : Env) : Prop := (d57 ρ)
theorem domain_59 (ρ : Env) : Value.Defined (v59 ρ) ↔ d59 ρ :=
  (Value.defined_not (v57 ρ)).trans (domain_57 ρ)

def d33 (ρ : Env) : Prop := True
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d62 (ρ : Env) : Prop := (v59 ρ) = some true ∨ ((v59 ρ) = some false ∧ (d33 ρ))
theorem domain_62 (ρ : Env) : Value.Defined (v62 ρ) ↔ d62 ρ :=
  (Value.defined_or (v59 ρ) (v33 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_33 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n62 ↔ (d62 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_62 ρ))).trans (domain_62 ρ)
#qsym_check_axioms definedness
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_57 (ρ : Env) : Value.Defined (v57 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v56 ρ) (v13 ρ) (total_56 ρ) (total_13 ρ)
theorem total_59 (ρ : Env) : Value.Defined (v59 ρ) :=
  (Value.defined_not (v57 ρ)).mpr (total_57 ρ)
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_62 (ρ : Env) : Value.Defined (v62 ρ) :=
  Value.defined_or_total (v59 ρ) (v33 ρ) (total_59 ρ) (total_33 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n62 := Eq.mpr (congrArg Value.Defined (eval_62 ρ)) (total_62 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n13 : Expr .natural := (.nat (10))
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
def n56 : Expr .natural := (.varN 9)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 9)
def n57 : Expr .bool := (.leN n56 n13)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v56 ρ) (v13 ρ)
def n58 : Expr .bool := (.and n57 n33)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v57 ρ) (v33 ρ)
def n59 : Expr .bool := (.not n57)
noncomputable def v59 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v57 ρ)
def n62 : Expr .bool := (.or n59 n33)
noncomputable def v62 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v59 ρ) (v33 ρ)
theorem q56 (ρ : Env) : Domain.Correct (v56 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q57 (ρ : Env) : Domain.Correct (v57 ρ) (v33 ρ) :=
  Domain.total2 Functions.leN (x := (v56 ρ)) (y := (v13 ρ)) (dx := (v33 ρ)) (dy := (v33 ρ)) (fun _ _ => True.intro) (q56 ρ) (q13 ρ)
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q58 (ρ : Env) : Domain.Correct (v58 ρ) (v62 ρ) :=
  Domain.and (p := (v57 ρ)) (q := (v33 ρ)) (dp := (v33 ρ)) (dq := (v33 ρ)) (q57 ρ) (q33 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n58) (Expr.eval ρ Certificate.n33) :=
  Domain.simplify (q58 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n33) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n58 ↔ (Expr.eval ρ Certificate.n33) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .natural := (.nat (10))
def n33 : Expr .bool := (.bool true)
def n56 : Expr .natural := (.varN 9)
def n57 : Expr .bool := (.leN n56 n13)
def n58 : Expr .bool := (.and n57 n33)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 9)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v56 ρ) (v13 ρ)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v57 ρ) (v33 ρ)
theorem eval_57 (ρ : Env) : (Expr.eval ρ n57) = (v57 ρ) := rfl
theorem eval_58 (ρ : Env) : (Expr.eval ρ n58) = (v58 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v58 ρ) (v57 ρ) :=
  (Generated.r_bool_and_right_true (v57 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n58) (Expr.eval ρ n57) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_58 ρ) (eval_57 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n58) : (Expr.eval ρ n58) = (Expr.eval ρ n57) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d56 (ρ : Env) : Prop := True
theorem domain_56 (ρ : Env) : Value.Defined (v56 ρ) ↔ d56 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := True
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d57 (ρ : Env) : Prop := ∃ x y, (v56 ρ) = some x ∧ (v13 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_57 (ρ : Env) : Value.Defined (v57 ρ) ↔ d57 ρ :=
  Functions.leN.defined (v56 ρ) (v13 ρ)

def d33 (ρ : Env) : Prop := True
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d58 (ρ : Env) : Prop := (v57 ρ) = some false ∨ ((v57 ρ) = some true ∧ (d33 ρ))
theorem domain_58 (ρ : Env) : Value.Defined (v58 ρ) ↔ d58 ρ :=
  (Value.defined_and (v57 ρ) (v33 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_33 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n58 ↔ (d58 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_58 ρ))).trans (domain_58 ρ)
#qsym_check_axioms definedness
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_57 (ρ : Env) : Value.Defined (v57 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v56 ρ) (v13 ρ) (total_56 ρ) (total_13 ρ)
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_58 (ρ : Env) : Value.Defined (v58 ρ) :=
  Value.defined_and_total (v57 ρ) (v33 ρ) (total_57 ρ) (total_33 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n58 := Eq.mpr (congrArg Value.Defined (eval_58 ρ)) (total_58 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_33 ρ)) (Value.refines_refl (v33 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v33 ρ) := (total_33 ρ)
def d33 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n13 : Expr .natural := (.nat (10))
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n30 : Expr .natural := (.varN 2)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 2)
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
def n68 : Expr .bool := (.leN n30 n13)
noncomputable def v68 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v30 ρ) (v13 ρ)
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q68 (ρ : Env) : Domain.Correct (v68 ρ) (v33 ρ) :=
  Domain.total2 Functions.leN (x := (v30 ρ)) (y := (v13 ρ)) (dx := (v33 ρ)) (dy := (v33 ρ)) (fun _ _ => True.intro) (q30 ρ) (q13 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n68) (Expr.eval ρ Certificate.n33) :=
  Domain.simplify (q68 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n33) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n68 ↔ (Expr.eval ρ Certificate.n33) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n33 : Expr .bool := (.bool true)
def n73 : Expr .bool := (.not n33)
def n74 : Expr .bool := (.or n73 n33)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v73 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v33 ρ)
noncomputable def v74 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v73 ρ) (v33 ρ)
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_74 (ρ : Env) : (Expr.eval ρ n74) = (v74 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v74 ρ) (v33 ρ) :=
  (Generated.r_bool_or_right_true (v73 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n74) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_74 ρ) (eval_33 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n74) : (Expr.eval ρ n74) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d33 (ρ : Env) : Prop := True
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d73 (ρ : Env) : Prop := (d33 ρ)
theorem domain_73 (ρ : Env) : Value.Defined (v73 ρ) ↔ d73 ρ :=
  (Value.defined_not (v33 ρ)).trans (domain_33 ρ)

def d74 (ρ : Env) : Prop := (v73 ρ) = some true ∨ ((v73 ρ) = some false ∧ (d33 ρ))
theorem domain_74 (ρ : Env) : Value.Defined (v74 ρ) ↔ d74 ρ :=
  (Value.defined_or (v73 ρ) (v33 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_33 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n74 ↔ (d74 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_74 ρ))).trans (domain_74 ρ)
#qsym_check_axioms definedness
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_73 (ρ : Env) : Value.Defined (v73 ρ) :=
  (Value.defined_not (v33 ρ)).mpr (total_33 ρ)
theorem total_74 (ρ : Env) : Value.Defined (v74 ρ) :=
  Value.defined_or_total (v73 ρ) (v33 ρ) (total_73 ρ) (total_33 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n74 := Eq.mpr (congrArg Value.Defined (eval_74 ρ)) (total_74 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n13 : Expr .natural := (.nat (10))
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n30 : Expr .natural := (.varN 2)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 2)
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
def n68 : Expr .bool := (.leN n30 n13)
noncomputable def v68 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v30 ρ) (v13 ρ)
def n72 : Expr .bool := (.and n33 n68)
noncomputable def v72 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v33 ρ) (v68 ρ)
def n73 : Expr .bool := (.not n33)
noncomputable def v73 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v33 ρ)
def n74 : Expr .bool := (.or n73 n33)
noncomputable def v74 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v73 ρ) (v33 ρ)
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q68 (ρ : Env) : Domain.Correct (v68 ρ) (v33 ρ) :=
  Domain.total2 Functions.leN (x := (v30 ρ)) (y := (v13 ρ)) (dx := (v33 ρ)) (dy := (v33 ρ)) (fun _ _ => True.intro) (q30 ρ) (q13 ρ)
theorem q72 (ρ : Env) : Domain.Correct (v72 ρ) (v74 ρ) :=
  Domain.and (p := (v33 ρ)) (q := (v68 ρ)) (dp := (v33 ρ)) (dq := (v33 ρ)) (q33 ρ) (q68 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n72) (Expr.eval ρ Certificate.n33) :=
  Domain.simplify (q72 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n33) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n72 ↔ (Expr.eval ρ Certificate.n33) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .natural := (.nat (10))
def n30 : Expr .natural := (.varN 2)
def n33 : Expr .bool := (.bool true)
def n68 : Expr .bool := (.leN n30 n13)
def n72 : Expr .bool := (.and n33 n68)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 2)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v68 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v30 ρ) (v13 ρ)
noncomputable def v72 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v33 ρ) (v68 ρ)
theorem eval_68 (ρ : Env) : (Expr.eval ρ n68) = (v68 ρ) := rfl
theorem eval_72 (ρ : Env) : (Expr.eval ρ n72) = (v72 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v72 ρ) (v68 ρ) :=
  (Generated.r_bool_and_left_true (v68 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n72) (Expr.eval ρ n68) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_72 ρ) (eval_68 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n72) : (Expr.eval ρ n72) = (Expr.eval ρ n68) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d33 (ρ : Env) : Prop := True
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d30 (ρ : Env) : Prop := True
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := True
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d68 (ρ : Env) : Prop := ∃ x y, (v30 ρ) = some x ∧ (v13 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_68 (ρ : Env) : Value.Defined (v68 ρ) ↔ d68 ρ :=
  Functions.leN.defined (v30 ρ) (v13 ρ)

def d72 (ρ : Env) : Prop := (v33 ρ) = some false ∨ ((v33 ρ) = some true ∧ (d68 ρ))
theorem domain_72 (ρ : Env) : Value.Defined (v72 ρ) ↔ d72 ρ :=
  (Value.defined_and (v33 ρ) (v68 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_68 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n72 ↔ (d72 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_72 ρ))).trans (domain_72 ρ)
#qsym_check_axioms definedness
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_68 (ρ : Env) : Value.Defined (v68 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v30 ρ) (v13 ρ) (total_30 ρ) (total_13 ρ)
theorem total_72 (ρ : Env) : Value.Defined (v72 ρ) :=
  Value.defined_and_total (v33 ρ) (v68 ρ) (total_33 ρ) (total_68 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n72 := Eq.mpr (congrArg Value.Defined (eval_72 ρ)) (total_72 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (0))
def n13 : Expr .natural := (.nat (10))
def n30 : Expr .natural := (.varN 2)
def n33 : Expr .bool := (.bool true)
def n53 : Expr .natural := (.varN 8)
def n54 : Expr .bool := (.leN n53 n13)
def n56 : Expr .natural := (.varN 9)
def n57 : Expr .bool := (.leN n56 n13)
def n58 : Expr .bool := (.and n57 n33)
def n68 : Expr .bool := (.leN n30 n13)
def n72 : Expr .bool := (.and n33 n68)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: c0
abbrev c2 : List Binding.Ty := (.scalar .natural) :: c1
abbrev c3 : List Binding.Ty := (.scalar .natural) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c2 (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.subN.apply (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t2 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .integer) := .unary Functions.castNZ.apply (t0 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Functions.nonzeroZ.apply (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n3
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t9 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n13
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .binary Functions.leN.apply (t0 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t14 γ) (t4 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t14 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t16 γ) (t6 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t12 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t11 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c1 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t21 γ))
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .unary Binding.inputDomain (t22 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n30
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Binding.memberValue (t23 γ) (t24 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .var .here
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n13
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Functions.leN.apply (t26 γ) (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n3
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Binding.guardValue (t28 γ) (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t30 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .unary Binding.inputDomain (t31 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.definedValue (t30 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t33 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.holdsValue (t28 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.definedValue (t29 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t35 γ) (t36 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .scalar n33
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t35 γ) (t38 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t39 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t38 γ) (t28 γ)
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t41 γ) (t38 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t42 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t28 γ) (t38 γ)
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t44 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t28 γ)
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Binding.memberValue (t46 γ) (t24 γ)
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n13
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Functions.leN.apply (t24 γ) (t48 γ)
noncomputable def t51 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.holdsValue (t49 γ)
noncomputable def t52 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .seq (t24 γ) (t51 γ)
noncomputable def t53 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n68
noncomputable def t54 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.holdsValue (t53 γ)
noncomputable def t55 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n72
noncomputable def t56 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n33
noncomputable def t57 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Binding.guardValue (t56 γ) (t53 γ)
noncomputable def t58 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .seq (t24 γ) (t53 γ)
noncomputable def rec22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t11 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t12 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.branch (.constant (fun x => (t14 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t3 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))) (.branch (.constant (fun x => (t16 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t5 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0)))) (.constant (fun _ => some 0))))
theorem fixed22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = some (FixedPoint.value (rec22 γ ξ ρ).functional) := Recursion.fixed_program (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem unroll22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (Binding.Expr.app (.lam (t21 γ)) (t22 γ)).eval ξ ρ := Recursion.program_unfold (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem solve22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t31 γ).eval ξ ρ :=
  Eq.trans (fixed22 γ ξ ρ) (congrArg some (Recursion.solve_nat_cutoff (rec22 γ ξ ρ) ((n3.eval ξ).getD 0) ((n13.eval ξ).getD 0) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _)))).symm)))
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 γ))
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t31 γ) := .ofEq (fun ξ ρ => solve22 γ ξ ρ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .refl (t27 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p3 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .refl (t29 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p5 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .lam (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t31 γ) := .trans (p2 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t31 γ) := .trans (p1 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t32 γ) := .unary (a := (.arrow (.scalar .natural) (.scalar .natural))) (b := (.set (.scalar .natural))) Binding.inputDomain (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t34 γ) := .domainLam (t30 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p7 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t37 γ) := .definedGuard (t28 γ) (t29 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .unary (a := (.scalar .bool)) (b := (.scalar .bool)) Binding.holdsValue (p5 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p6 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .scalarDomain n3 n33 QSym.BindingScalar0.DomainCertificate.domain_correct
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .refl (t38 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p17 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p16 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p15 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t39 γ) := .trans (p14 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t39 γ) := .trans (p13 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t40 γ) := .set (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t43 γ) := .setPointwise (fun ξ ρ x => (congrArg₂ Value.and (Binding.holdsDomain (n54.eval ({ ξ with natural := fun i => if i = 8 then x else ξ.natural i })) (n33.eval ({ ξ with natural := fun i => if i = 8 then x else ξ.natural i })) (QSym.BindingScalar1.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 8 then x else ξ.natural i }))) rfl))
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p18 γ) (p5 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t28 γ) := .ofEq (fun _ _ => rfl)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t28 γ) := .trans (p27 γ) (p5 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t28 γ) := .trans (p26 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t44 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p29 γ) (p18 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t45 γ) := .set (p30 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .setPointwise (fun ξ ρ x => (Binding.preserveDomain (n58.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (n57.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (n33.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (QSym.BindingScalar2.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (QSym.BindingScalar2.ValueCertificate.refinement ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i }))))
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .set (p5 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .trans (p32 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t46 γ) := .trans (p31 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t46 γ) := .trans (p25 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t46 γ) := .trans (p24 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t46 γ) := .trans (p12 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t46 γ) := .trans (p11 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t47 γ) := .binary (a := (.set (.scalar .natural))) (b := (.scalar .natural)) (c := (.scalar .bool)) Binding.memberValue (p39 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t52 γ) := .memberSet (t28 γ) (t24 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t48 γ) := .refl (t48 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t49 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p40 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t53 γ) := .refl (t53 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t53 γ) := .trans (p45 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t53 γ) := .trans (p44 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t54 γ) := .unary (a := (.scalar .bool)) (b := (.scalar .bool)) Binding.holdsValue (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .scalarHolds n68 n33 QSym.BindingScalar3.DomainCertificate.domain_correct
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t55 γ) := .refl (t55 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t57 γ) := .scalarSimplify n72 n33 n68 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t56 γ) := .refl (t56 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t57 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Binding.guardValue (p53 γ) (p46 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t53 γ) := .guardTrue (t53 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t53 γ) := .trans (p55 γ) (p46 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t53 γ) := .trans (p54 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t53 γ) := .trans (p52 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t53 γ) := .trans (p51 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t53 γ) := .trans (p50 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t53 γ) := .trans (p49 γ) (p60 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t58 γ) := .seq (p40 γ) (p61 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t53 γ) := .seqScalar n30 (t53 γ) (fun _ => ⟨_, rfl⟩)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t53 γ) := .trans (p63 γ) (p46 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .trans (p62 γ) (p64 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t53 γ) := .trans (p42 γ) (p65 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t53 γ) := .trans (p41 γ) (p66 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t53 γ) := (p67 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t25 γ).eval ξ ρ = (t53 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t25 γ).eval ξ ρ) ↔ Value.Defined ((t53 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t25 γ).eval ξ ρ = n68.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .natural := (.nat (10))
def n30 : Expr .natural := (.varN 2)
def n68 : Expr .bool := (.leN n30 n13)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 2)
noncomputable def v68 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v30 ρ) (v13 ρ)
theorem eval_68 (ρ : Env) : (Expr.eval ρ n68) = (v68 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n68) (Expr.eval ρ n68) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_68 ρ) (eval_68 ρ)) (Value.refines_refl (v68 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n68) : (Expr.eval ρ n68) = (Expr.eval ρ n68) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d30 (ρ : Env) : Prop := True
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := True
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d68 (ρ : Env) : Prop := ∃ x y, (v30 ρ) = some x ∧ (v13 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_68 (ρ : Env) : Value.Defined (v68 ρ) ↔ d68 ρ :=
  Functions.leN.defined (v30 ρ) (v13 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n68 ↔ (d68 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_68 ρ))).trans (domain_68 ρ)
#qsym_check_axioms definedness
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_68 (ρ : Env) : Value.Defined (v68 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v30 ρ) (v13 ρ) (total_30 ρ) (total_13 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n68 := Eq.mpr (congrArg Value.Defined (eval_68 ρ)) (total_68 ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t25 γ).eval ξ ρ) (FunctionScalar.n68.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n68.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t25 γ).eval ξ ρ)) : ((BindingCertificate.t25 γ).eval ξ ρ) = (FunctionScalar.n68.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
