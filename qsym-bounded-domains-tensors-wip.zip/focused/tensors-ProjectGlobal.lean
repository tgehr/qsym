import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (0))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.pair (.scalar .real) (.vector (.scalar .natural) 1)) := .constant (some (γ (.pair (.scalar .real) (.vector (.scalar .natural) 1)) 0))
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .unary (fun x => x.map Prod.snd) (t0 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Tensor.getValue (t2 γ) (t3 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .unary (a := (.pair (.scalar .real) (.vector (.scalar .natural) 1))) (b := (.vector (.scalar .natural) 1)) (fun x => x.map Prod.snd) (p0 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.vector (.scalar .natural) 1)) (b := (.scalar .natural)) (c := (.scalar .natural)) Tensor.getValue (p1 γ) (p2 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := (p3 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t4 γ).eval ξ ρ = (t4 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t4 γ).eval ξ ρ) ↔ Value.Defined ((t4 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
