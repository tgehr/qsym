import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n12 : Expr .natural := (.mulN n0 n4)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v13 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v4 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q0 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n12) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q12 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n12 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n4 : Expr .natural := (.nat (5))
def n12 : Expr .natural := (.mulN n0 n4)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v12 ρ) (v4 ρ) :=
  (Generated.r_natural_one_mul (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.mulN.defined (v0 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (domain_12 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v4 ρ) (total_0 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_12 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n14 : Expr .natural := (.mulN n1 n5)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v5 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v13 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v5 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q1 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n5 : Expr .natural := (.nat (6))
def n14 : Expr .natural := (.mulN n1 n5)
def n15 : Expr .natural := (.nat (12))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v5 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (12)
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_14 ρ) (eval_15 ρ)) (Numeric.sound ρ n14 n15 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d14 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.mulN.defined (v1 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (domain_14 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v5 ρ) (total_1 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_14 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n6 : Expr .natural := (.nat (0))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n15 : Expr .natural := (.nat (12))
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (12)
def n16 : Expr .natural := (.addN n15 n6)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v15 ρ) (v6 ρ)
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v13 ρ) :=
  Domain.total2 Functions.addN (x := (v15 ρ)) (y := (v6 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q15 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n16) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q16 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n16 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n6 : Expr .natural := (.nat (0))
def n15 : Expr .natural := (.nat (12))
def n16 : Expr .natural := (.addN n15 n6)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (12)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v15 ρ) (v6 ρ)
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v16 ρ) (v15 ρ) :=
  (Generated.r_natural_add_zero (v15 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d15 (ρ : Env) : Prop := True
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d16 (ρ : Env) : Prop := ∃ x y, (v15 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  Functions.addN.defined (v15 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (domain_16 ρ)
#qsym_check_axioms definedness
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v15 ρ) (v6 ρ) (total_15 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_16 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n15 : Expr .natural := (.nat (12))
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (12)
def n17 : Expr .natural := (.addN n4 n15)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v15 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v13 ρ) :=
  Domain.total2 Functions.addN (x := (v4 ρ)) (y := (v15 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q4 ρ) (q15 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n17) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q17 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n17 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n4 : Expr .natural := (.nat (5))
def n15 : Expr .natural := (.nat (12))
def n17 : Expr .natural := (.addN n4 n15)
def n18 : Expr .natural := (.nat (17))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (12)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v15 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := some (17)
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v17 ρ) (v18 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_18 ρ)) (Numeric.sound ρ n17 n18 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n18) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_18 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n18) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d15 (ρ : Env) : Prop := True
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d17 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v15 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  Functions.addN.defined (v4 ρ) (v15 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (domain_17 ρ)
#qsym_check_axioms definedness
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v4 ρ) (v15 ρ) (total_4 ρ) (total_15 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_17 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n2 : Expr .natural := (.nat (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n19 : Expr .natural := (.mulN n2 n4)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v4 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q19 (ρ : Env) : Domain.Correct (v19 ρ) (v13 ρ) :=
  Domain.total2 Functions.mulN (x := (v2 ρ)) (y := (v4 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q2 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n19) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q19 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n19 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (3))
def n4 : Expr .natural := (.nat (5))
def n19 : Expr .natural := (.mulN n2 n4)
def n20 : Expr .natural := (.nat (15))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v4 ρ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (15)
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v19 ρ) (v20 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (Numeric.sound ρ n19 n20 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n19) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n19) : (Expr.eval ρ n19) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d19 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_19 (ρ : Env) : Value.Defined (v19 ρ) ↔ d19 ρ :=
  Functions.mulN.defined (v2 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n19 ↔ (d19 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_19 ρ))).trans (domain_19 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_19 (ρ : Env) : Value.Defined (v19 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v2 ρ) (v4 ρ) (total_2 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n19 := Eq.mpr (congrArg Value.Defined (eval_19 ρ)) (total_19 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n21 : Expr .natural := (.mulN n3 n5)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v5 ρ)
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q21 (ρ : Env) : Domain.Correct (v21 ρ) (v13 ρ) :=
  Domain.total2 Functions.mulN (x := (v3 ρ)) (y := (v5 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q3 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n21) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q21 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n21 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n3 : Expr .natural := (.nat (4))
def n5 : Expr .natural := (.nat (6))
def n21 : Expr .natural := (.mulN n3 n5)
def n22 : Expr .natural := (.nat (24))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v5 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := some (24)
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v21 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_21 ρ) (eval_22 ρ)) (Numeric.sound ρ n21 n22 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n21) (Expr.eval ρ n22) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_21 ρ) (eval_22 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n21) : (Expr.eval ρ n21) = (Expr.eval ρ n22) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d21 (ρ : Env) : Prop := ∃ x y, (v3 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_21 (ρ : Env) : Value.Defined (v21 ρ) ↔ d21 ρ :=
  Functions.mulN.defined (v3 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n21 ↔ (d21 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_21 ρ))).trans (domain_21 ρ)
#qsym_check_axioms definedness
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_21 (ρ : Env) : Value.Defined (v21 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v3 ρ) (v5 ρ) (total_3 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n21 := Eq.mpr (congrArg Value.Defined (eval_21 ρ)) (total_21 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n6 : Expr .natural := (.nat (0))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n22 : Expr .natural := (.nat (24))
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := some (24)
def n23 : Expr .natural := (.addN n22 n6)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v22 ρ) (v6 ρ)
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v13 ρ) :=
  Domain.total2 Functions.addN (x := (v22 ρ)) (y := (v6 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q22 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n23) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q23 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n23 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n6 : Expr .natural := (.nat (0))
def n22 : Expr .natural := (.nat (24))
def n23 : Expr .natural := (.addN n22 n6)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := some (24)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v22 ρ) (v6 ρ)
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v23 ρ) (v22 ρ) :=
  (Generated.r_natural_add_zero (v22 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n23) (Expr.eval ρ n22) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_23 ρ) (eval_22 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n23) : (Expr.eval ρ n23) = (Expr.eval ρ n22) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d22 (ρ : Env) : Prop := True
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d23 (ρ : Env) : Prop := ∃ x y, (v22 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  Functions.addN.defined (v22 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n23 ↔ (d23 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_23 ρ))).trans (domain_23 ρ)
#qsym_check_axioms definedness
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  ⟨_, rfl⟩
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v22 ρ) (v6 ρ) (total_22 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n23 := Eq.mpr (congrArg Value.Defined (eval_23 ρ)) (total_23 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_13 ρ)) (Value.refines_refl (v13 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v13 ρ) := (total_13 ρ)
def d13 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n13 : Expr .bool := (.bool true)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .natural := (.nat (15))
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (15)
def n22 : Expr .natural := (.nat (24))
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := some (24)
def n24 : Expr .natural := (.addN n20 n22)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v20 ρ) (v22 ρ)
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v13 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v13 ρ) :=
  Domain.total2 Functions.addN (x := (v20 ρ)) (y := (v22 ρ)) (dx := (v13 ρ)) (dy := (v13 ρ)) (fun _ _ => True.intro) (q20 ρ) (q22 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n24) (Expr.eval ρ Certificate.n13) :=
  Domain.simplify (q24 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n13) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n24 ↔ (Expr.eval ρ Certificate.n13) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n20 : Expr .natural := (.nat (15))
def n22 : Expr .natural := (.nat (24))
def n24 : Expr .natural := (.addN n20 n22)
def n25 : Expr .natural := (.nat (39))
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (15)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := some (24)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v20 ρ) (v22 ρ)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := some (39)
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v24 ρ) (v25 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_24 ρ) (eval_25 ρ)) (Numeric.sound ρ n24 n25 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n24) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_24 ρ) (eval_25 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n24) : (Expr.eval ρ n24) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d20 (ρ : Env) : Prop := True
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d22 (ρ : Env) : Prop := True
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d24 (ρ : Env) : Prop := ∃ x y, (v20 ρ) = some x ∧ (v22 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_24 (ρ : Env) : Value.Defined (v24 ρ) ↔ d24 ρ :=
  Functions.addN.defined (v20 ρ) (v22 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n24 ↔ (d24 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_24 ρ))).trans (domain_24 ρ)
#qsym_check_axioms definedness
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v20 ρ) (v22 ρ) (total_20 ρ) (total_22 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n24 := Eq.mpr (congrArg Value.Defined (eval_24 ρ)) (total_24 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (3))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (5))
def n5 : Expr .natural := (.nat (6))
def n6 : Expr .natural := (.nat (0))
def n12 : Expr .natural := (.mulN n0 n4)
def n13 : Expr .bool := (.bool true)
def n14 : Expr .natural := (.mulN n1 n5)
def n15 : Expr .natural := (.nat (12))
def n16 : Expr .natural := (.addN n15 n6)
def n17 : Expr .natural := (.addN n4 n15)
def n18 : Expr .natural := (.nat (17))
def n19 : Expr .natural := (.mulN n2 n4)
def n20 : Expr .natural := (.nat (15))
def n21 : Expr .natural := (.mulN n3 n5)
def n22 : Expr .natural := (.nat (24))
def n23 : Expr .natural := (.addN n22 n6)
def n24 : Expr .natural := (.addN n20 n22)
def n25 : Expr .natural := (.nat (39))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t6 γ) (t2 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t5 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 0) := .constant Tensor.nilValue
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t8 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t4 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n5
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t13 γ) (t2 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t12 γ) (t14 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary (Tensor.matvecValue Functions.addN.apply Functions.mulN.apply 0 2 2) (t11 γ) (t15 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n6
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t1 γ) (t13 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t18 γ) (t17 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t12 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t20 γ) (t19 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t6 γ) (t13 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t22 γ) (t17 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t5 γ) (t12 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t24 γ) (t23 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t25 γ) (t2 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t21 γ) (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n12
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n13
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t29 γ) (t12 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n14
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n15
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t29 γ) (t32 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t32 γ) (t17 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n16
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t12 γ) (t32 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n17
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n18
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t29 γ) (t38 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n19
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n20
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t29 γ) (t41 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n21
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n22
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t29 γ) (t44 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t44 γ) (t17 γ)
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n23
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t41 γ) (t44 γ)
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n24
noncomputable def t50 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n25
noncomputable def t51 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t29 γ) (t50 γ)
noncomputable def t52 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t50 γ) (t2 γ)
noncomputable def t53 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t38 γ) (t52 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p6 γ) (p2 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p5 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p8 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p4 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .refl (t13 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p13 γ) (p2 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p12 γ) (p14 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 2)) (Tensor.matvecValue Functions.addN.apply Functions.mulN.apply 0 2 2) (p11 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t27 γ) := .ofEq (fun ξ ρ => rfl)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p12 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t28 γ) := .ofEq (fun _ _ => rfl)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .refl (t28 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t30 γ) := .scalarSimplify n12 n13 n4 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .refl (t29 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p22 γ) (p12 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t12 γ) := .guardTrue (t12 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t12 γ) := .trans (p24 γ) (p12 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t12 γ) := .trans (p23 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t12 γ) := .trans (p21 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t12 γ) := .trans (p20 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t12 γ) := .trans (p19 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t12 γ) := .trans (p18 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p1 γ) (p13 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t31 γ) := .ofEq (fun _ _ => rfl)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .refl (t31 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t33 γ) := .scalarSimplify n14 n13 n15 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .refl (t32 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p22 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t32 γ) := .guardTrue (t32 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t32 γ) := .trans (p37 γ) (p35 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t32 γ) := .trans (p36 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t32 γ) := .trans (p34 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t32 γ) := .trans (p33 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t32 γ) := .trans (p32 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t32 γ) := .trans (p31 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t34 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p43 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t35 γ) := .ofEq (fun _ _ => rfl)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .refl (t35 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t33 γ) := .scalarSimplify n16 n13 n15 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t32 γ) := .trans (p48 γ) (p39 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t32 γ) := .trans (p47 γ) (p49 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t32 γ) := .trans (p46 γ) (p50 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t32 γ) := .trans (p45 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t36 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p30 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t37 γ) := .ofEq (fun _ _ => rfl)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .refl (t37 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t39 γ) := .scalarSimplify n17 n13 n18 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .refl (t38 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p22 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .guardTrue (t38 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .trans (p59 γ) (p57 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t38 γ) := .trans (p58 γ) (p60 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t38 γ) := .trans (p56 γ) (p61 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t38 γ) := .trans (p55 γ) (p62 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p54 γ) (p63 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t38 γ) := .trans (p53 γ) (p64 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p5 γ) (p12 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t40 γ) := .ofEq (fun _ _ => rfl)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .refl (t40 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t42 γ) := .scalarSimplify n19 n13 n20 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .refl (t41 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p22 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .guardTrue (t41 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .trans (p72 γ) (p70 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .trans (p71 γ) (p73 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t41 γ) := .trans (p69 γ) (p74 γ)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t41 γ) := .trans (p68 γ) (p75 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t41 γ) := .trans (p67 γ) (p76 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t41 γ) := .trans (p66 γ) (p77 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p6 γ) (p13 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t43 γ) := .ofEq (fun _ _ => rfl)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t43 γ) := .refl (t43 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t45 γ) := .scalarSimplify n21 n13 n22 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t44 γ) := .refl (t44 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t45 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p22 γ) (p83 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t44 γ) := .guardTrue (t44 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t44 γ) := .trans (p85 γ) (p83 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t44 γ) := .trans (p84 γ) (p86 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t44 γ) := .trans (p82 γ) (p87 γ)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t44 γ) := .trans (p81 γ) (p88 γ)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t44 γ) := .trans (p80 γ) (p89 γ)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t44 γ) := .trans (p79 γ) (p90 γ)
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t46 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p91 γ) (p44 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t47 γ) := .ofEq (fun _ _ => rfl)
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t47 γ) := .refl (t47 γ)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t45 γ) := .scalarSimplify n23 n13 n22 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t44 γ) := .trans (p95 γ) (p87 γ)
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t44 γ) := .trans (p94 γ) (p96 γ)
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t44 γ) := .trans (p93 γ) (p97 γ)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t44 γ) := .trans (p92 γ) (p98 γ)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t48 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p78 γ) (p99 γ)
theorem p101 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t49 γ) := .ofEq (fun _ _ => rfl)
theorem p102 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t49 γ) := .refl (t49 γ)
theorem p103 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t51 γ) := .scalarSimplify n24 n13 n25 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p104 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t50 γ) := .refl (t50 γ)
theorem p105 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t51 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p22 γ) (p104 γ)
theorem p106 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t50 γ) := .guardTrue (t50 γ)
theorem p107 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t50 γ) := .trans (p106 γ) (p104 γ)
theorem p108 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t50 γ) := .trans (p105 γ) (p107 γ)
theorem p109 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t50 γ) := .trans (p103 γ) (p108 γ)
theorem p110 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t50 γ) := .trans (p102 γ) (p109 γ)
theorem p111 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t50 γ) := .trans (p101 γ) (p110 γ)
theorem p112 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t50 γ) := .trans (p100 γ) (p111 γ)
theorem p113 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p112 γ) (p2 γ)
theorem p114 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t53 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p65 γ) (p113 γ)
theorem p115 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t53 γ) := .trans (p17 γ) (p114 γ)
theorem p116 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t53 γ) := .trans (p16 γ) (p115 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t53 γ) := (p116 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t16 γ).eval ξ ρ = (t53 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t16 γ).eval ξ ρ) ↔ Value.Defined ((t53 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
