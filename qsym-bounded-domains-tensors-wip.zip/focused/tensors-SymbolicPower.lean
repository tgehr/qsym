import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.varN 0)
abbrev c0 (δ : ℕ → ℕ) : List Binding.Ty := []
noncomputable def t0 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.vector (.vector (.scalar .real) (δ 1)) (δ 1)) := .constant (some (γ (.vector (.vector (.scalar .real) (δ 1)) (δ 1)) 0))
noncomputable def t1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.scalar .natural) := .scalar n0
noncomputable def t2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.vector (.vector (.scalar .real) (δ 1)) (δ 1)) := .binary (Tensor.matrixPowerValue Value.add Value.mul ((0 : ℤ) : ℝ) ((1 : ℤ) : ℝ) (δ 1)) (t0 δ γ) (t1 δ γ)
theorem p0 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t0 δ γ) (t0 δ γ) := .refl (t0 δ γ)
theorem p1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t1 δ γ) (t1 δ γ) := .refl (t1 δ γ)
theorem p2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t2 δ γ) (t2 δ γ) := .binary (a := (.vector (.vector (.scalar .real) (δ 1)) (δ 1))) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .real) (δ 1)) (δ 1))) (Tensor.matrixPowerValue Value.add Value.mul ((0 : ℤ) : ℝ) ((1 : ℤ) : ℝ) (δ 1)) (p0 δ γ) (p1 δ γ)
theorem reduction (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t2 δ γ) (t2 δ γ) := (p2 δ γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : (t2 ξ.natural γ).eval ξ ρ = (t2 ξ.natural γ).eval ξ ρ := Binding.Reduction.sound (reduction ξ.natural γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : Value.Defined ((t2 ξ.natural γ).eval ξ ρ) ↔ Value.Defined ((t2 ξ.natural γ).eval ξ ρ) := Binding.Reduction.defined (reduction ξ.natural γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
