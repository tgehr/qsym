import QSym.Refinement
import QSym.AxiomCheck
namespace QSym.Generated
theorem r_bool_false (v_p : Option (Ty.denote .bool))
    (hp0 : Value.Refines (Value.not v_p) (some true)) :
    Value.Refines v_p (some false) := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_bool_false

theorem r_embed_NZ_nonzero (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.nonzeroZ.apply (Functions.castNZ.apply v_x)) (Functions.nonzeroN.apply v_x) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_embed_NZ_nonzero

theorem r_natural_le_self (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.leN.apply v_x v_x) (some true) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_le_self

theorem r_natural_literal_lt_left (v_x : Option (Ty.denote .natural)) (v_a : Option (Ty.denote .natural)) (v_b : Option (Ty.denote .natural))
    (hp0 : Value.Refines (Value.not (Functions.nonzeroZ.apply (Functions.addZ.apply (Functions.castNZ.apply v_b) (Functions.mulZ.apply (some ((-1) : ℤ)) (Functions.castNZ.apply (Functions.addN.apply v_a (some ((1) : ℕ)))))))) (some true))
    (hp1 : Value.Defined v_b) :
    Value.Refines (Functions.ltN.apply v_a v_x) (Functions.leN.apply v_b v_x) := by
  cases v_x <;> cases v_a <;> cases v_b
  all_goals qsym_rule

#qsym_check_axioms r_natural_literal_lt_left

theorem r_natural_mask_zero (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.mask v_p (some ((0) : ℕ))) (some ((0) : ℕ)) := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_natural_mask_zero

theorem r_natural_nonnegative (v_n : Option (Ty.denote .natural)) :
    Value.Refines (Functions.leN.apply (some ((0) : ℕ)) v_n) (some true) := by
  cases v_n
  all_goals qsym_rule

#qsym_check_axioms r_natural_nonnegative

theorem r_natural_nonpositive_zero (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.leN.apply v_x (some ((0) : ℕ))) (Value.not (Functions.nonzeroZ.apply (Functions.castNZ.apply v_x))) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_nonpositive_zero

theorem r_natural_not_le (v_x : Option (Ty.denote .natural)) (v_y : Option (Ty.denote .natural)) :
    Value.Refines (Value.not (Functions.leN.apply v_x v_y)) (Functions.ltN.apply v_y v_x) := by
  cases v_x <;> cases v_y
  all_goals qsym_rule

#qsym_check_axioms r_natural_not_le

theorem r_natural_one_le (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.leN.apply (some ((1) : ℕ)) v_x) (Functions.nonzeroZ.apply (Functions.castNZ.apply v_x)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_one_le

theorem r_natural_zero_add (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.addN.apply (some ((0) : ℕ)) v_x) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_zero_add
end QSym.Generated
