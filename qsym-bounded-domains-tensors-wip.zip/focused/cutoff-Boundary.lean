import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_33 ρ)) (Value.refines_refl (v33 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v33 ρ) := (total_33 ρ)
def d33 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n14 : Expr .natural := (.nat (10))
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
def n51 : Expr .bool := (.leN n14 n14)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v14 ρ) (v14 ρ)
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v33 ρ) :=
  Domain.total2 Functions.leN (x := (v14 ρ)) (y := (v14 ρ)) (dx := (v33 ρ)) (dy := (v33 ρ)) (fun _ _ => True.intro) (q14 ρ) (q14 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n51) (Expr.eval ρ Certificate.n33) :=
  Domain.simplify (q51 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n33) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n51 ↔ (Expr.eval ρ Certificate.n33) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n14 : Expr .natural := (.nat (10))
def n33 : Expr .bool := (.bool true)
def n51 : Expr .bool := (.leN n14 n14)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v51 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v14 ρ) (v14 ρ)
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v51 ρ) (v33 ρ) :=
  (Generated.r_natural_le_self (v14 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n51) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_51 ρ) (eval_33 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n51) : (Expr.eval ρ n51) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d14 (ρ : Env) : Prop := True
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d51 (ρ : Env) : Prop := ∃ x y, (v14 ρ) = some x ∧ (v14 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_51 (ρ : Env) : Value.Defined (v51 ρ) ↔ d51 ρ :=
  Functions.leN.defined (v14 ρ) (v14 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n51 ↔ (d51 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_51 ρ))).trans (domain_51 ρ)
#qsym_check_axioms definedness
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  ⟨_, rfl⟩
theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v14 ρ) (v14 ρ) (total_14 ρ) (total_14 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n51 := Eq.mpr (congrArg Value.Defined (eval_51 ρ)) (total_51 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n10 : Expr .natural := (.nat (5))
def n14 : Expr .natural := (.nat (10))
def n33 : Expr .bool := (.bool true)
def n51 : Expr .bool := (.leN n14 n14)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: c0
abbrev c2 : List Binding.Ty := (.scalar .natural) :: c1
abbrev c3 : List Binding.Ty := (.scalar .natural) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c2 (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.subN.apply (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t2 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .integer) := .unary Functions.castNZ.apply (t0 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Functions.nonzeroZ.apply (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n10
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t9 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n14
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .binary Functions.leN.apply (t0 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t14 γ) (t4 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t14 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t16 γ) (t6 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t12 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t11 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c1 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t21 γ))
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n14
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .app (t22 γ) (t23 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .var .here
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n14
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Functions.leN.apply (t25 γ) (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n10
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Binding.guardValue (t27 γ) (t28 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .app (t30 γ) (t23 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Functions.leN.apply (t23 γ) (t23 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n10
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t32 γ) (t33 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .seq (t23 γ) (t34 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n51
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n33
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Binding.guardValue (t37 γ) (t37 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t37 γ) (t33 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .seq (t23 γ) (t33 γ)
noncomputable def rec22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t11 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t12 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.branch (.constant (fun x => (t14 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t3 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))) (.branch (.constant (fun x => (t16 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t5 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0)))) (.constant (fun _ => some 0))))
theorem fixed22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = some (FixedPoint.value (rec22 γ ξ ρ).functional) := Recursion.fixed_program (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem unroll22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (Binding.Expr.app (.lam (t21 γ)) (t22 γ)).eval ξ ρ := Recursion.program_unfold (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem solve22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t30 γ).eval ξ ρ :=
  Eq.trans (fixed22 γ ξ ρ) (congrArg some (Recursion.solve_nat_cutoff (rec22 γ ξ ρ) ((n10.eval ξ).getD 0) ((n14.eval ξ).getD 0) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _)))).symm)))
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 γ))
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t30 γ) := .ofEq (fun ξ ρ => solve22 γ ξ ρ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .refl (t25 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p3 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .refl (t28 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p5 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .lam (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t30 γ) := .trans (p2 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t30 γ) := .trans (p1 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t31 γ) := .app (p10 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t35 γ) := .beta (t29 γ) (t23 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p11 γ) (p11 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t36 γ) := .ofEq (fun _ _ => rfl)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .refl (t36 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .scalarSimplify n51 n33 n33 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .refl (t37 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Binding.guardValue (p18 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t37 γ) := .guardTrue (t37 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t37 γ) := .trans (p20 γ) (p18 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t37 γ) := .trans (p19 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t37 γ) := .trans (p17 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t37 γ) := .trans (p16 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t37 γ) := .trans (p15 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t37 γ) := .trans (p14 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .refl (t33 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p26 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t33 γ) := .guardTrue (t33 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t33 γ) := .trans (p29 γ) (p27 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t33 γ) := .trans (p28 γ) (p30 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t40 γ) := .seq (p11 γ) (p31 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t33 γ) := .seqScalar n14 (t33 γ) (fun _ => ⟨_, rfl⟩)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t33 γ) := .trans (p33 γ) (p27 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t33 γ) := .trans (p32 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t33 γ) := .trans (p13 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t33 γ) := .trans (p12 γ) (p36 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t33 γ) := (p37 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t24 γ).eval ξ ρ = (t33 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t24 γ).eval ξ ρ) ↔ Value.Defined ((t33 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t24 γ).eval ξ ρ = n10.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n10 : Expr .natural := (.nat (5))
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (5)
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_10 ρ)) (Value.refines_refl (v10 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v10 ρ) := (total_10 ρ)
def d10 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t24 γ).eval ξ ρ) (FunctionScalar.n10.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n10.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t24 γ).eval ξ ρ)) : ((BindingCertificate.t24 γ).eval ξ ρ) = (FunctionScalar.n10.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
