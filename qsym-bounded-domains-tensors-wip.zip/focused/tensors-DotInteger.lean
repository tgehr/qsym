import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .integer := (.int (-1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .integer) := some (-1)
def n5 : Expr .integer := (.int (3))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .integer) := some (3)
def n14 : Expr .integer := (.mulZ n0 n5)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .integer) := Functions.mulZ.apply (v0 ρ) (v5 ρ)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulZ (x := (v0 ρ)) (y := (v5 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .integer := (.int (-1))
def n5 : Expr .integer := (.int (3))
def n14 : Expr .integer := (.mulZ n0 n5)
def n16 : Expr .integer := (.int (-3))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .integer) := some (-1)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .integer) := some (3)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .integer) := Functions.mulZ.apply (v0 ρ) (v5 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .integer) := some (-3)
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_14 ρ) (eval_16 ρ)) (Numeric.sound ρ n14 n16 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_16 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d14 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulZ.domain x y
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.mulZ.defined (v0 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (domain_14 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.mulZ.total (fun _ _ => True.intro) (v0 ρ) (v5 ρ) (total_0 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_14 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n4 : Expr .integer := (.castNZ n1)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
def n6 : Expr .integer := (.int (-4))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .integer) := some (-4)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n18 : Expr .integer := (.mulZ n4 n6)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .integer) := Functions.mulZ.apply (v4 ρ) (v6 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v17 ρ) :=
  Domain.total1 Functions.castNZ (x := (v1 ρ)) (d := (v17 ρ)) (fun _ => True.intro) (q1 ρ)
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulZ (x := (v4 ρ)) (y := (v6 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q4 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n18) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q18 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n18 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n4 : Expr .integer := (.castNZ n1)
def n6 : Expr .integer := (.int (-4))
def n7 : Expr .integer := (.int (2))
def n18 : Expr .integer := (.mulZ n4 n6)
def n19 : Expr .integer := (.mulZ n7 n6)
def n20 : Expr .integer := (.int (-8))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .integer) := some (-4)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := some (2)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .integer) := Functions.mulZ.apply (v4 ρ) (v6 ρ)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .integer) := Functions.mulZ.apply (v7 ρ) (v6 ρ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .integer) := some (-8)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v4 ρ) (v7 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_4 ρ) (eval_7 ρ)) (Numeric.sound ρ n4 n7 rfl)

theorem p1 (ρ : Env) : Value.Refines (v18 ρ) (v19 ρ) :=
  Value.refines_function2 Functions.mulZ (p0 ρ) (Value.refines_refl (v6 ρ))

theorem p2 (ρ : Env) : Value.Refines (v19 ρ) (v20 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (Numeric.sound ρ n19 n20 rfl)

theorem p3 (ρ : Env) : Value.Refines (v18 ρ) (v20 ρ) :=
  (p1 ρ).trans (p2 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n18) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_18 ρ) (eval_20 ρ)) (p3 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n18) : (Expr.eval ρ n18) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := ∃ x, (v1 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  Functions.castNZ.defined (v1 ρ)

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d18 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.mulZ.domain x y
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  Functions.mulZ.defined (v4 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n18 ↔ (d18 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_18 ρ))).trans (domain_18 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v1 ρ) (total_1 ρ)
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  Functions.mulZ.total (fun _ _ => True.intro) (v4 ρ) (v6 ρ) (total_4 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n18 := Eq.mpr (congrArg Value.Defined (eval_18 ρ)) (total_18 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n8 : Expr .integer := (.int (0))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .integer) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .integer := (.int (-8))
noncomputable def v20 (ρ : Env) : Option (Ty.denote .integer) := some (-8)
def n21 : Expr .integer := (.addZ n20 n8)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .integer) := Functions.addZ.apply (v20 ρ) (v8 ρ)
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q21 (ρ : Env) : Domain.Correct (v21 ρ) (v17 ρ) :=
  Domain.total2 Functions.addZ (x := (v20 ρ)) (y := (v8 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q20 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n21) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q21 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n21 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .integer := (.int (0))
def n20 : Expr .integer := (.int (-8))
def n21 : Expr .integer := (.addZ n20 n8)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .integer) := some (0)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .integer) := some (-8)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .integer) := Functions.addZ.apply (v20 ρ) (v8 ρ)
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v21 ρ) (v20 ρ) :=
  (Generated.r_integer_add_zero (v20 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n21) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_21 ρ) (eval_20 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n21) : (Expr.eval ρ n21) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d20 (ρ : Env) : Prop := True
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d21 (ρ : Env) : Prop := ∃ x y, (v20 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.addZ.domain x y
theorem domain_21 (ρ : Env) : Value.Defined (v21 ρ) ↔ d21 ρ :=
  Functions.addZ.defined (v20 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n21 ↔ (d21 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_21 ρ))).trans (domain_21 ρ)
#qsym_check_axioms definedness
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_21 (ρ : Env) : Value.Defined (v21 ρ) :=
  Functions.addZ.total (fun _ _ => True.intro) (v20 ρ) (v8 ρ) (total_20 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n21 := Eq.mpr (congrArg Value.Defined (eval_21 ρ)) (total_21 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n16 : Expr .integer := (.int (-3))
noncomputable def v16 (ρ : Env) : Option (Ty.denote .integer) := some (-3)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .integer := (.int (-8))
noncomputable def v20 (ρ : Env) : Option (Ty.denote .integer) := some (-8)
def n22 : Expr .integer := (.addZ n16 n20)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .integer) := Functions.addZ.apply (v16 ρ) (v20 ρ)
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v17 ρ) :=
  Domain.total2 Functions.addZ (x := (v16 ρ)) (y := (v20 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q16 ρ) (q20 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n22) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q22 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n22 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .integer := (.int (-3))
def n20 : Expr .integer := (.int (-8))
def n22 : Expr .integer := (.addZ n16 n20)
def n23 : Expr .integer := (.int (-11))
noncomputable def v16 (ρ : Env) : Option (Ty.denote .integer) := some (-3)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .integer) := some (-8)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .integer) := Functions.addZ.apply (v16 ρ) (v20 ρ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .integer) := some (-11)
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v22 ρ) (v23 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_23 ρ)) (Numeric.sound ρ n22 n23 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n22) (Expr.eval ρ n23) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_22 ρ) (eval_23 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n22) : (Expr.eval ρ n22) = (Expr.eval ρ n23) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d16 (ρ : Env) : Prop := True
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d20 (ρ : Env) : Prop := True
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d22 (ρ : Env) : Prop := ∃ x y, (v16 ρ) = some x ∧ (v20 ρ) = some y ∧ Functions.addZ.domain x y
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  Functions.addZ.defined (v16 ρ) (v20 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n22 ↔ (d22 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_22 ρ))).trans (domain_22 ρ)
#qsym_check_axioms definedness
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  Functions.addZ.total (fun _ _ => True.intro) (v16 ρ) (v20 ρ) (total_16 ρ) (total_20 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n22 := Eq.mpr (congrArg Value.Defined (eval_22 ρ)) (total_22 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .integer := (.int (-1))
def n1 : Expr .natural := (.nat (2))
def n4 : Expr .integer := (.castNZ n1)
def n5 : Expr .integer := (.int (3))
def n6 : Expr .integer := (.int (-4))
def n8 : Expr .integer := (.int (0))
def n14 : Expr .integer := (.mulZ n0 n5)
def n16 : Expr .integer := (.int (-3))
def n17 : Expr .bool := (.bool true)
def n18 : Expr .integer := (.mulZ n4 n6)
def n20 : Expr .integer := (.int (-8))
def n21 : Expr .integer := (.addZ n20 n8)
def n22 : Expr .integer := (.addZ n16 n20)
def n23 : Expr .integer := (.int (-11))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n0
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n4
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .integer) 0) := .constant Tensor.nilValue
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .integer) 1) := .binary Tensor.consValue (t2 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .integer) 2) := .binary Tensor.consValue (t0 γ) (t4 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n5
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n6
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .integer) 1) := .binary Tensor.consValue (t7 γ) (t3 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .integer) 2) := .binary Tensor.consValue (t6 γ) (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary (Tensor.dotValue Functions.addZ.apply Functions.mulZ.apply id 0 2) (t5 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n8
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Functions.mulZ.apply (t2 γ) (t7 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Functions.addZ.apply (t12 γ) (t11 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Functions.mulZ.apply (t0 γ) (t6 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Functions.addZ.apply (t14 γ) (t13 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n14
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n17
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n16
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Binding.guardValue (t17 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n18
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n20
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Binding.guardValue (t17 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Functions.addZ.apply (t21 γ) (t11 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n21
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Functions.addZ.apply (t18 γ) (t21 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n22
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .scalar n23
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .integer) := .binary Binding.guardValue (t17 γ) (t27 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .integer)) (b := (.vector (.scalar .integer) 0)) (c := (.vector (.scalar .integer) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.scalar .integer)) (b := (.vector (.scalar .integer) 1)) (c := (.vector (.scalar .integer) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .integer)) (b := (.vector (.scalar .integer) 0)) (c := (.vector (.scalar .integer) 1)) Tensor.consValue (p6 γ) (p2 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .binary (a := (.scalar .integer)) (b := (.vector (.scalar .integer) 1)) (c := (.vector (.scalar .integer) 2)) Tensor.consValue (p5 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.vector (.scalar .integer) 2)) (b := (.vector (.scalar .integer) 2)) (c := (.scalar .integer)) (Tensor.dotValue Functions.addZ.apply Functions.mulZ.apply id 0 2) (p4 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t15 γ) := .ofEq (fun ξ ρ => (Eq.mpr (congrArg (fun w0 : Option ((.scalar .integer) : Binding.Ty).denote => ((Tensor.dotValue Functions.addZ.apply Functions.mulZ.apply id 0 2) (Tensor.consValue ((t0 γ).eval ξ ρ) (Tensor.consValue w0 ((t3 γ).eval ξ ρ))) (Tensor.consValue ((t6 γ).eval ξ ρ) (Tensor.consValue ((t7 γ).eval ξ ρ) ((t3 γ).eval ξ ρ)))) = (Functions.addZ.apply (Functions.mulZ.apply ((t0 γ).eval ξ ρ) ((t6 γ).eval ξ ρ)) (Functions.addZ.apply (Functions.mulZ.apply w0 ((t7 γ).eval ξ ρ)) ((t11 γ).eval ξ ρ)))) (show n4.eval ξ = some (Functions.castNZ.value ((n1.eval ξ).getD 0)) from Eq.trans (congrArg Functions.castNZ.apply (show n1.eval ξ = some ((n1.eval ξ).getD 0) from rfl)) (Tensor.apply_some Functions.castNZ ((n1.eval ξ).getD 0) True.intro))) rfl))
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .integer)) (b := (.scalar .integer)) (c := (.scalar .integer)) Functions.mulZ.apply (p0 γ) (p5 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t16 γ) := .ofEq (fun _ _ => rfl)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t19 γ) := .scalarSimplify n14 n17 n16 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .refl (t18 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .integer)) (c := (.scalar .integer)) Binding.guardValue (p15 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t18 γ) := .guardTrue (t18 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t18 γ) := .trans (p18 γ) (p16 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t18 γ) := .trans (p17 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t18 γ) := .trans (p14 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t18 γ) := .trans (p13 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t18 γ) := .trans (p12 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t18 γ) := .trans (p11 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.scalar .integer)) (b := (.scalar .integer)) (c := (.scalar .integer)) Functions.mulZ.apply (p1 γ) (p6 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t20 γ) := .ofEq (fun _ _ => rfl)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t22 γ) := .scalarSimplify n18 n17 n20 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .integer)) (c := (.scalar .integer)) Binding.guardValue (p15 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .guardTrue (t21 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .trans (p31 γ) (p29 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .trans (p30 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t21 γ) := .trans (p28 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t21 γ) := .trans (p27 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t21 γ) := .trans (p26 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t21 γ) := .trans (p25 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t23 γ) := .binary (a := (.scalar .integer)) (b := (.scalar .integer)) (c := (.scalar .integer)) Functions.addZ.apply (p37 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t24 γ) := .ofEq (fun _ _ => rfl)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t22 γ) := .scalarSimplify n21 n17 n20 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t21 γ) := .trans (p42 γ) (p33 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t21 γ) := .trans (p41 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t21 γ) := .trans (p40 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t21 γ) := .trans (p39 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t25 γ) := .binary (a := (.scalar .integer)) (b := (.scalar .integer)) (c := (.scalar .integer)) Functions.addZ.apply (p24 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t26 γ) := .ofEq (fun _ _ => rfl)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t28 γ) := .scalarSimplify n22 n17 n23 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .refl (t27 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .integer)) (c := (.scalar .integer)) Binding.guardValue (p15 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .guardTrue (t27 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p53 γ) (p51 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p52 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t27 γ) := .trans (p50 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t27 γ) := .trans (p49 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t27 γ) := .trans (p48 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t27 γ) := .trans (p47 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t27 γ) := .trans (p10 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t27 γ) := .trans (p9 γ) (p60 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t27 γ) := (p61 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t10 γ).eval ξ ρ = (t27 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t10 γ).eval ξ ρ) ↔ Value.Defined ((t27 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t10 γ).eval ξ ρ = n23.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n23 : Expr .integer := (.int (-11))
noncomputable def v23 (ρ : Env) : Option (Ty.denote .integer) := some (-11)
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n23) (Expr.eval ρ n23) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_23 ρ) (eval_23 ρ)) (Value.refines_refl (v23 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n23) : (Expr.eval ρ n23) = (Expr.eval ρ n23) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v23 ρ) := (total_23 ρ)
def d23 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n23 ↔ (d23 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_23 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n23 := Eq.mpr (congrArg Value.Defined (eval_23 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t10 γ).eval ξ ρ) (FunctionScalar.n23.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n23.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t10 γ).eval ξ ρ)) : ((BindingCertificate.t10 γ).eval ξ ρ) = (FunctionScalar.n23.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
