import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n6 : Expr .natural := (.nat (7))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
def n15 : Expr .natural := (.mulN n0 n6)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v6 ρ)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v16 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v6 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q0 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n15) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q15 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n15 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n6 : Expr .natural := (.nat (7))
def n15 : Expr .natural := (.mulN n0 n6)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v6 ρ)
theorem eval_6 (ρ : Env) : (Expr.eval ρ n6) = (v6 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v15 ρ) (v6 ρ) :=
  (Generated.r_natural_one_mul (v6 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n6) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_6 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n6) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d15 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  Functions.mulN.defined (v0 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (domain_15 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v6 ρ) (total_0 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_15 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n7 : Expr .natural := (.nat (8))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n17 : Expr .natural := (.mulN n1 n7)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v7 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v16 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v7 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q1 ρ) (q7 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n17) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q17 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n17 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n7 : Expr .natural := (.nat (8))
def n17 : Expr .natural := (.mulN n1 n7)
def n18 : Expr .natural := (.nat (16))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v7 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := some (16)
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v17 ρ) (v18 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_18 ρ)) (Numeric.sound ρ n17 n18 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n18) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_18 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n18) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d17 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v7 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  Functions.mulN.defined (v1 ρ) (v7 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (domain_17 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v7 ρ) (total_1 ρ) (total_7 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_17 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n2 : Expr .natural := (.nat (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n8 : Expr .natural := (.nat (9))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (9)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n19 : Expr .natural := (.mulN n2 n8)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v8 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q19 (ρ : Env) : Domain.Correct (v19 ρ) (v16 ρ) :=
  Domain.total2 Functions.mulN (x := (v2 ρ)) (y := (v8 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q2 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n19) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q19 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n19 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (3))
def n8 : Expr .natural := (.nat (9))
def n19 : Expr .natural := (.mulN n2 n8)
def n20 : Expr .natural := (.nat (27))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (9)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v8 ρ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (27)
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v19 ρ) (v20 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (Numeric.sound ρ n19 n20 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n19) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n19) : (Expr.eval ρ n19) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d19 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_19 (ρ : Env) : Value.Defined (v19 ρ) ↔ d19 ρ :=
  Functions.mulN.defined (v2 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n19 ↔ (d19 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_19 ρ))).trans (domain_19 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_19 (ρ : Env) : Value.Defined (v19 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v2 ρ) (v8 ρ) (total_2 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n19 := Eq.mpr (congrArg Value.Defined (eval_19 ρ)) (total_19 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n9 : Expr .natural := (.nat (0))
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .natural := (.nat (27))
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (27)
def n21 : Expr .natural := (.addN n20 n9)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v20 ρ) (v9 ρ)
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q21 (ρ : Env) : Domain.Correct (v21 ρ) (v16 ρ) :=
  Domain.total2 Functions.addN (x := (v20 ρ)) (y := (v9 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q20 ρ) (q9 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n21) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q21 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n21 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n9 : Expr .natural := (.nat (0))
def n20 : Expr .natural := (.nat (27))
def n21 : Expr .natural := (.addN n20 n9)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (27)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v20 ρ) (v9 ρ)
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v21 ρ) (v20 ρ) :=
  (Generated.r_natural_add_zero (v20 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n21) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_21 ρ) (eval_20 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n21) : (Expr.eval ρ n21) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d20 (ρ : Env) : Prop := True
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d9 (ρ : Env) : Prop := True
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d21 (ρ : Env) : Prop := ∃ x y, (v20 ρ) = some x ∧ (v9 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_21 (ρ : Env) : Value.Defined (v21 ρ) ↔ d21 ρ :=
  Functions.addN.defined (v20 ρ) (v9 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n21 ↔ (d21 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_21 ρ))).trans (domain_21 ρ)
#qsym_check_axioms definedness
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_21 (ρ : Env) : Value.Defined (v21 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v20 ρ) (v9 ρ) (total_20 ρ) (total_9 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n21 := Eq.mpr (congrArg Value.Defined (eval_21 ρ)) (total_21 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n18 : Expr .natural := (.nat (16))
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := some (16)
def n20 : Expr .natural := (.nat (27))
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (27)
def n22 : Expr .natural := (.addN n18 n20)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v18 ρ) (v20 ρ)
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v16 ρ) :=
  Domain.total2 Functions.addN (x := (v18 ρ)) (y := (v20 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q18 ρ) (q20 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n22) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q22 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n22 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n18 : Expr .natural := (.nat (16))
def n20 : Expr .natural := (.nat (27))
def n22 : Expr .natural := (.addN n18 n20)
def n23 : Expr .natural := (.nat (43))
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := some (16)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (27)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v18 ρ) (v20 ρ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (43)
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v22 ρ) (v23 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_23 ρ)) (Numeric.sound ρ n22 n23 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n22) (Expr.eval ρ n23) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_22 ρ) (eval_23 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n22) : (Expr.eval ρ n22) = (Expr.eval ρ n23) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d18 (ρ : Env) : Prop := True
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d20 (ρ : Env) : Prop := True
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d22 (ρ : Env) : Prop := ∃ x y, (v18 ρ) = some x ∧ (v20 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  Functions.addN.defined (v18 ρ) (v20 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n22 ↔ (d22 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_22 ρ))).trans (domain_22 ρ)
#qsym_check_axioms definedness
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  ⟨_, rfl⟩
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v18 ρ) (v20 ρ) (total_18 ρ) (total_20 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n22 := Eq.mpr (congrArg Value.Defined (eval_22 ρ)) (total_22 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n6 : Expr .natural := (.nat (7))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .natural := (.nat (43))
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (43)
def n24 : Expr .natural := (.addN n6 n23)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v6 ρ) (v23 ρ)
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v16 ρ) :=
  Domain.total2 Functions.addN (x := (v6 ρ)) (y := (v23 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q6 ρ) (q23 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n24) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q24 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n24 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n6 : Expr .natural := (.nat (7))
def n23 : Expr .natural := (.nat (43))
def n24 : Expr .natural := (.addN n6 n23)
def n25 : Expr .natural := (.nat (50))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (43)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v6 ρ) (v23 ρ)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := some (50)
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v24 ρ) (v25 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_24 ρ) (eval_25 ρ)) (Numeric.sound ρ n24 n25 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n24) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_24 ρ) (eval_25 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n24) : (Expr.eval ρ n24) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d23 (ρ : Env) : Prop := True
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d24 (ρ : Env) : Prop := ∃ x y, (v6 ρ) = some x ∧ (v23 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_24 (ρ : Env) : Value.Defined (v24 ρ) ↔ d24 ρ :=
  Functions.addN.defined (v6 ρ) (v23 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n24 ↔ (d24 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_24 ρ))).trans (domain_24 ρ)
#qsym_check_axioms definedness
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v6 ρ) (v23 ρ) (total_6 ρ) (total_23 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n24 := Eq.mpr (congrArg Value.Defined (eval_24 ρ)) (total_24 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n6 : Expr .natural := (.nat (7))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n26 : Expr .natural := (.mulN n3 n6)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v6 ρ)
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q26 (ρ : Env) : Domain.Correct (v26 ρ) (v16 ρ) :=
  Domain.total2 Functions.mulN (x := (v3 ρ)) (y := (v6 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q3 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n26) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q26 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n26 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n3 : Expr .natural := (.nat (4))
def n6 : Expr .natural := (.nat (7))
def n26 : Expr .natural := (.mulN n3 n6)
def n27 : Expr .natural := (.nat (28))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v6 ρ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := some (28)
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v26 ρ) (v27 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_26 ρ) (eval_27 ρ)) (Numeric.sound ρ n26 n27 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n26) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_26 ρ) (eval_27 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n26) : (Expr.eval ρ n26) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d26 (ρ : Env) : Prop := ∃ x y, (v3 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_26 (ρ : Env) : Value.Defined (v26 ρ) ↔ d26 ρ :=
  Functions.mulN.defined (v3 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n26 ↔ (d26 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_26 ρ))).trans (domain_26 ρ)
#qsym_check_axioms definedness
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v3 ρ) (v6 ρ) (total_3 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n26 := Eq.mpr (congrArg Value.Defined (eval_26 ρ)) (total_26 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n7 : Expr .natural := (.nat (8))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n28 : Expr .natural := (.mulN n4 n7)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v4 ρ) (v7 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q28 (ρ : Env) : Domain.Correct (v28 ρ) (v16 ρ) :=
  Domain.total2 Functions.mulN (x := (v4 ρ)) (y := (v7 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q4 ρ) (q7 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n28) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q28 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n28 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n4 : Expr .natural := (.nat (5))
def n7 : Expr .natural := (.nat (8))
def n28 : Expr .natural := (.mulN n4 n7)
def n29 : Expr .natural := (.nat (40))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v4 ρ) (v7 ρ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := some (40)
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v28 ρ) (v29 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_28 ρ) (eval_29 ρ)) (Numeric.sound ρ n28 n29 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n28) (Expr.eval ρ n29) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_28 ρ) (eval_29 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n28) : (Expr.eval ρ n28) = (Expr.eval ρ n29) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d28 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v7 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_28 (ρ : Env) : Value.Defined (v28 ρ) ↔ d28 ρ :=
  Functions.mulN.defined (v4 ρ) (v7 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n28 ↔ (d28 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_28 ρ))).trans (domain_28 ρ)
#qsym_check_axioms definedness
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_28 (ρ : Env) : Value.Defined (v28 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v4 ρ) (v7 ρ) (total_4 ρ) (total_7 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n28 := Eq.mpr (congrArg Value.Defined (eval_28 ρ)) (total_28 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.Certificate

namespace QSym.BindingScalar8.DomainCertificate
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n8 : Expr .natural := (.nat (9))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (9)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n30 : Expr .natural := (.mulN n5 n8)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v5 ρ) (v8 ρ)
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v16 ρ) :=
  Domain.total2 Functions.mulN (x := (v5 ρ)) (y := (v8 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q5 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n30) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q30 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n30 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar8.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n5 : Expr .natural := (.nat (6))
def n8 : Expr .natural := (.nat (9))
def n30 : Expr .natural := (.mulN n5 n8)
def n31 : Expr .natural := (.nat (54))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (9)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v5 ρ) (v8 ρ)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := some (54)
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v30 ρ) (v31 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_30 ρ) (eval_31 ρ)) (Numeric.sound ρ n30 n31 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n30) (Expr.eval ρ n31) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_30 ρ) (eval_31 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n30) : (Expr.eval ρ n30) = (Expr.eval ρ n31) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d30 (ρ : Env) : Prop := ∃ x y, (v5 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  Functions.mulN.defined (v5 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n30 ↔ (d30 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_30 ρ))).trans (domain_30 ρ)
#qsym_check_axioms definedness
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v5 ρ) (v8 ρ) (total_5 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n30 := Eq.mpr (congrArg Value.Defined (eval_30 ρ)) (total_30 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.Certificate

namespace QSym.BindingScalar9.DomainCertificate
def n9 : Expr .natural := (.nat (0))
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n31 : Expr .natural := (.nat (54))
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := some (54)
def n32 : Expr .natural := (.addN n31 n9)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v31 ρ) (v9 ρ)
theorem q31 (ρ : Env) : Domain.Correct (v31 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v16 ρ) :=
  Domain.total2 Functions.addN (x := (v31 ρ)) (y := (v9 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q31 ρ) (q9 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n32) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q32 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n32 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar9.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n9 : Expr .natural := (.nat (0))
def n31 : Expr .natural := (.nat (54))
def n32 : Expr .natural := (.addN n31 n9)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := some (54)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v31 ρ) (v9 ρ)
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v32 ρ) (v31 ρ) :=
  (Generated.r_natural_add_zero (v31 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n32) (Expr.eval ρ n31) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_32 ρ) (eval_31 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n32) : (Expr.eval ρ n32) = (Expr.eval ρ n31) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d31 (ρ : Env) : Prop := True
theorem domain_31 (ρ : Env) : Value.Defined (v31 ρ) ↔ d31 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d9 (ρ : Env) : Prop := True
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d32 (ρ : Env) : Prop := ∃ x y, (v31 ρ) = some x ∧ (v9 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  Functions.addN.defined (v31 ρ) (v9 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n32 ↔ (d32 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_32 ρ))).trans (domain_32 ρ)
#qsym_check_axioms definedness
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  ⟨_, rfl⟩
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v31 ρ) (v9 ρ) (total_31 ρ) (total_9 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n32 := Eq.mpr (congrArg Value.Defined (eval_32 ρ)) (total_32 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.Certificate

namespace QSym.BindingScalar10.DomainCertificate
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n29 : Expr .natural := (.nat (40))
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := some (40)
def n31 : Expr .natural := (.nat (54))
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := some (54)
def n33 : Expr .natural := (.addN n29 n31)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v29 ρ) (v31 ρ)
theorem q29 (ρ : Env) : Domain.Correct (v29 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q31 (ρ : Env) : Domain.Correct (v31 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v16 ρ) :=
  Domain.total2 Functions.addN (x := (v29 ρ)) (y := (v31 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q29 ρ) (q31 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n33) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q33 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n33 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar10.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n29 : Expr .natural := (.nat (40))
def n31 : Expr .natural := (.nat (54))
def n33 : Expr .natural := (.addN n29 n31)
def n34 : Expr .natural := (.nat (94))
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := some (40)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := some (54)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v29 ρ) (v31 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := some (94)
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_34 (ρ : Env) : (Expr.eval ρ n34) = (v34 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v33 ρ) (v34 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_33 ρ) (eval_34 ρ)) (Numeric.sound ρ n33 n34 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n34) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_34 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n34) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d29 (ρ : Env) : Prop := True
theorem domain_29 (ρ : Env) : Value.Defined (v29 ρ) ↔ d29 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d31 (ρ : Env) : Prop := True
theorem domain_31 (ρ : Env) : Value.Defined (v31 ρ) ↔ d31 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d33 (ρ : Env) : Prop := ∃ x y, (v29 ρ) = some x ∧ (v31 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  Functions.addN.defined (v29 ρ) (v31 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (domain_33 ρ)
#qsym_check_axioms definedness
theorem total_29 (ρ : Env) : Value.Defined (v29 ρ) :=
  ⟨_, rfl⟩
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  ⟨_, rfl⟩
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v29 ρ) (v31 ρ) (total_29 ρ) (total_31 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_33 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n16) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_16 ρ)) (Value.refines_refl (v16 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n16) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v16 ρ) := (total_16 ρ)
def d16 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.Certificate

namespace QSym.BindingScalar11.DomainCertificate
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n27 : Expr .natural := (.nat (28))
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := some (28)
def n34 : Expr .natural := (.nat (94))
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := some (94)
def n35 : Expr .natural := (.addN n27 n34)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v27 ρ) (v34 ρ)
theorem q27 (ρ : Env) : Domain.Correct (v27 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q34 (ρ : Env) : Domain.Correct (v34 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q35 (ρ : Env) : Domain.Correct (v35 ρ) (v16 ρ) :=
  Domain.total2 Functions.addN (x := (v27 ρ)) (y := (v34 ρ)) (dx := (v16 ρ)) (dy := (v16 ρ)) (fun _ _ => True.intro) (q27 ρ) (q34 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n35) (Expr.eval ρ Certificate.n16) :=
  Domain.simplify (q35 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n16) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n35 ↔ (Expr.eval ρ Certificate.n16) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar11.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n27 : Expr .natural := (.nat (28))
def n34 : Expr .natural := (.nat (94))
def n35 : Expr .natural := (.addN n27 n34)
def n36 : Expr .natural := (.nat (122))
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := some (28)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := some (94)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v27 ρ) (v34 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (122)
theorem eval_35 (ρ : Env) : (Expr.eval ρ n35) = (v35 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v35 ρ) (v36 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_35 ρ) (eval_36 ρ)) (Numeric.sound ρ n35 n36 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n35) (Expr.eval ρ n36) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_35 ρ) (eval_36 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n35) : (Expr.eval ρ n35) = (Expr.eval ρ n36) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d27 (ρ : Env) : Prop := True
theorem domain_27 (ρ : Env) : Value.Defined (v27 ρ) ↔ d27 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d34 (ρ : Env) : Prop := True
theorem domain_34 (ρ : Env) : Value.Defined (v34 ρ) ↔ d34 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d35 (ρ : Env) : Prop := ∃ x y, (v27 ρ) = some x ∧ (v34 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_35 (ρ : Env) : Value.Defined (v35 ρ) ↔ d35 ρ :=
  Functions.addN.defined (v27 ρ) (v34 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n35 ↔ (d35 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_35 ρ))).trans (domain_35 ρ)
#qsym_check_axioms definedness
theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_34 (ρ : Env) : Value.Defined (v34 ρ) :=
  ⟨_, rfl⟩
theorem total_35 (ρ : Env) : Value.Defined (v35 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v27 ρ) (v34 ρ) (total_27 ρ) (total_34 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n35 := Eq.mpr (congrArg Value.Defined (eval_35 ρ)) (total_35 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (3))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (5))
def n5 : Expr .natural := (.nat (6))
def n6 : Expr .natural := (.nat (7))
def n7 : Expr .natural := (.nat (8))
def n8 : Expr .natural := (.nat (9))
def n9 : Expr .natural := (.nat (0))
def n15 : Expr .natural := (.mulN n0 n6)
def n16 : Expr .bool := (.bool true)
def n17 : Expr .natural := (.mulN n1 n7)
def n18 : Expr .natural := (.nat (16))
def n19 : Expr .natural := (.mulN n2 n8)
def n20 : Expr .natural := (.nat (27))
def n21 : Expr .natural := (.addN n20 n9)
def n22 : Expr .natural := (.addN n18 n20)
def n23 : Expr .natural := (.nat (43))
def n24 : Expr .natural := (.addN n6 n23)
def n25 : Expr .natural := (.nat (50))
def n26 : Expr .natural := (.mulN n3 n6)
def n27 : Expr .natural := (.nat (28))
def n28 : Expr .natural := (.mulN n4 n7)
def n29 : Expr .natural := (.nat (40))
def n30 : Expr .natural := (.mulN n5 n8)
def n31 : Expr .natural := (.nat (54))
def n32 : Expr .natural := (.addN n31 n9)
def n33 : Expr .natural := (.addN n29 n31)
def n34 : Expr .natural := (.nat (94))
def n35 : Expr .natural := (.addN n27 n34)
def n36 : Expr .natural := (.nat (122))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t2 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t1 γ) (t4 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t0 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n5
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t9 γ) (t3 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t8 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t7 γ) (t11 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 3) 0) := .constant Tensor.nilValue
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 3) 1) := .binary Tensor.consValue (t12 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 3) 2) := .binary Tensor.consValue (t6 γ) (t14 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n6
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n7
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n8
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t18 γ) (t3 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t17 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t16 γ) (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary (Tensor.matvecValue Functions.addN.apply Functions.mulN.apply 0 2 3) (t15 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n9
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t2 γ) (t18 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t24 γ) (t23 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t1 γ) (t17 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t26 γ) (t25 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t16 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t28 γ) (t27 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t9 γ) (t18 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t30 γ) (t23 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t8 γ) (t17 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t32 γ) (t31 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t7 γ) (t16 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t34 γ) (t33 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t35 γ) (t3 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t29 γ) (t36 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n15
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n16
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t16 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n17
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n18
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t42 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n19
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n20
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t45 γ)
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t45 γ) (t23 γ)
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n21
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t42 γ) (t45 γ)
noncomputable def t50 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n22
noncomputable def t51 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n23
noncomputable def t52 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t51 γ)
noncomputable def t53 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t16 γ) (t51 γ)
noncomputable def t54 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n24
noncomputable def t55 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n25
noncomputable def t56 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t55 γ)
noncomputable def t57 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n26
noncomputable def t58 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n27
noncomputable def t59 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t58 γ)
noncomputable def t60 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n28
noncomputable def t61 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n29
noncomputable def t62 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t61 γ)
noncomputable def t63 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n30
noncomputable def t64 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n31
noncomputable def t65 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t64 γ)
noncomputable def t66 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t64 γ) (t23 γ)
noncomputable def t67 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n32
noncomputable def t68 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t61 γ) (t64 γ)
noncomputable def t69 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n33
noncomputable def t70 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n34
noncomputable def t71 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t70 γ)
noncomputable def t72 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t58 γ) (t70 γ)
noncomputable def t73 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n35
noncomputable def t74 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n36
noncomputable def t75 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t74 γ)
noncomputable def t76 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t74 γ) (t3 γ)
noncomputable def t77 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t55 γ) (t76 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p2 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p1 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p0 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .refl (t8 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p9 γ) (p3 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p8 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p7 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .refl (t13 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.vector (.scalar .natural) 3)) (b := (.vector (.vector (.scalar .natural) 3) 0)) (c := (.vector (.vector (.scalar .natural) 3) 1)) Tensor.consValue (p12 γ) (p13 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.vector (.scalar .natural) 3)) (b := (.vector (.vector (.scalar .natural) 3) 1)) (c := (.vector (.vector (.scalar .natural) 3) 2)) Tensor.consValue (p6 γ) (p14 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .refl (t18 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p18 γ) (p3 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p17 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p16 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.vector (.vector (.scalar .natural) 3) 2)) (b := (.vector (.scalar .natural) 3)) (c := (.vector (.scalar .natural) 2)) (Tensor.matvecValue Functions.addN.apply Functions.mulN.apply 0 2 3) (p15 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t37 γ) := .ofEq (fun ξ ρ => rfl)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p16 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t38 γ) := .ofEq (fun _ _ => rfl)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .refl (t38 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t40 γ) := .scalarSimplify n15 n16 n6 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .refl (t39 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p16 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t16 γ) := .guardTrue (t16 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t16 γ) := .trans (p30 γ) (p16 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t16 γ) := .trans (p29 γ) (p31 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t16 γ) := .trans (p27 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t16 γ) := .trans (p26 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t16 γ) := .trans (p25 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t16 γ) := .trans (p24 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p1 γ) (p17 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t41 γ) := .ofEq (fun _ _ => rfl)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .refl (t41 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t43 γ) := .scalarSimplify n17 n16 n18 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .refl (t42 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t43 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .guardTrue (t42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .trans (p43 γ) (p41 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .trans (p42 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t42 γ) := .trans (p40 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t42 γ) := .trans (p39 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t42 γ) := .trans (p38 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t42 γ) := .trans (p37 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p2 γ) (p18 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t44 γ) := .ofEq (fun _ _ => rfl)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t44 γ) := .refl (t44 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t46 γ) := .scalarSimplify n19 n16 n20 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t45 γ) := .refl (t45 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t45 γ) := .guardTrue (t45 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t45 γ) := .trans (p56 γ) (p54 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t45 γ) := .trans (p55 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t45 γ) := .trans (p53 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t45 γ) := .trans (p52 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t45 γ) := .trans (p51 γ) (p60 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t45 γ) := .trans (p50 γ) (p61 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t47 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p62 γ) (p63 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t48 γ) := .ofEq (fun _ _ => rfl)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t48 γ) := .refl (t48 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t46 γ) := .scalarSimplify n21 n16 n20 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t45 γ) := .trans (p67 γ) (p58 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t45 γ) := .trans (p66 γ) (p68 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t45 γ) := .trans (p65 γ) (p69 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t45 γ) := .trans (p64 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t49 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p49 γ) (p71 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t50 γ) := .ofEq (fun _ _ => rfl)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t50 γ) := .refl (t50 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t52 γ) := .scalarSimplify n22 n16 n23 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t51 γ) := .refl (t51 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t52 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p76 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t51 γ) := .guardTrue (t51 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t51 γ) := .trans (p78 γ) (p76 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t51 γ) := .trans (p77 γ) (p79 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t51 γ) := .trans (p75 γ) (p80 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t51 γ) := .trans (p74 γ) (p81 γ)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t51 γ) := .trans (p73 γ) (p82 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t51 γ) := .trans (p72 γ) (p83 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t53 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p36 γ) (p84 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t54 γ) := .ofEq (fun _ _ => rfl)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t54 γ) := .refl (t54 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t56 γ) := .scalarSimplify n24 n16 n25 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t55 γ) := .refl (t55 γ)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t56 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p89 γ)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t55 γ) := .guardTrue (t55 γ)
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t55 γ) := .trans (p91 γ) (p89 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t55 γ) := .trans (p90 γ) (p92 γ)
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .trans (p88 γ) (p93 γ)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .trans (p87 γ) (p94 γ)
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t55 γ) := .trans (p86 γ) (p95 γ)
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t55 γ) := .trans (p85 γ) (p96 γ)
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t34 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p7 γ) (p16 γ)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t57 γ) := .ofEq (fun _ _ => rfl)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t57 γ) := .refl (t57 γ)
theorem p101 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t59 γ) := .scalarSimplify n26 n16 n27 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p102 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t58 γ) := .refl (t58 γ)
theorem p103 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t59 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p102 γ)
theorem p104 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t58 γ) := .guardTrue (t58 γ)
theorem p105 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t58 γ) := .trans (p104 γ) (p102 γ)
theorem p106 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t58 γ) := .trans (p103 γ) (p105 γ)
theorem p107 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t58 γ) := .trans (p101 γ) (p106 γ)
theorem p108 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t58 γ) := .trans (p100 γ) (p107 γ)
theorem p109 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t58 γ) := .trans (p99 γ) (p108 γ)
theorem p110 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t58 γ) := .trans (p98 γ) (p109 γ)
theorem p111 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p8 γ) (p17 γ)
theorem p112 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t60 γ) := .ofEq (fun _ _ => rfl)
theorem p113 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t60 γ) := .refl (t60 γ)
theorem p114 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t62 γ) := .scalarSimplify n28 n16 n29 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p115 (γ : Binding.Globals) : Binding.Reduction (t61 γ) (t61 γ) := .refl (t61 γ)
theorem p116 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t62 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p115 γ)
theorem p117 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t61 γ) := .guardTrue (t61 γ)
theorem p118 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t61 γ) := .trans (p117 γ) (p115 γ)
theorem p119 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t61 γ) := .trans (p116 γ) (p118 γ)
theorem p120 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t61 γ) := .trans (p114 γ) (p119 γ)
theorem p121 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t61 γ) := .trans (p113 γ) (p120 γ)
theorem p122 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t61 γ) := .trans (p112 γ) (p121 γ)
theorem p123 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t61 γ) := .trans (p111 γ) (p122 γ)
theorem p124 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p9 γ) (p18 γ)
theorem p125 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t63 γ) := .ofEq (fun _ _ => rfl)
theorem p126 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t63 γ) := .refl (t63 γ)
theorem p127 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t65 γ) := .scalarSimplify n30 n16 n31 QSym.BindingScalar8.DomainCertificate.domain_correct QSym.BindingScalar8.ValueCertificate.refinement
theorem p128 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t64 γ) := .refl (t64 γ)
theorem p129 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t65 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p128 γ)
theorem p130 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t64 γ) := .guardTrue (t64 γ)
theorem p131 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t64 γ) := .trans (p130 γ) (p128 γ)
theorem p132 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t64 γ) := .trans (p129 γ) (p131 γ)
theorem p133 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t64 γ) := .trans (p127 γ) (p132 γ)
theorem p134 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t64 γ) := .trans (p126 γ) (p133 γ)
theorem p135 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t64 γ) := .trans (p125 γ) (p134 γ)
theorem p136 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t64 γ) := .trans (p124 γ) (p135 γ)
theorem p137 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t66 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p136 γ) (p63 γ)
theorem p138 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t67 γ) := .ofEq (fun _ _ => rfl)
theorem p139 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t67 γ) := .refl (t67 γ)
theorem p140 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t65 γ) := .scalarSimplify n32 n16 n31 QSym.BindingScalar9.DomainCertificate.domain_correct QSym.BindingScalar9.ValueCertificate.refinement
theorem p141 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t64 γ) := .trans (p140 γ) (p132 γ)
theorem p142 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t64 γ) := .trans (p139 γ) (p141 γ)
theorem p143 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t64 γ) := .trans (p138 γ) (p142 γ)
theorem p144 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t64 γ) := .trans (p137 γ) (p143 γ)
theorem p145 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t68 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p123 γ) (p144 γ)
theorem p146 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t69 γ) := .ofEq (fun _ _ => rfl)
theorem p147 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t69 γ) := .refl (t69 γ)
theorem p148 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t71 γ) := .scalarSimplify n33 n16 n34 QSym.BindingScalar10.DomainCertificate.domain_correct QSym.BindingScalar10.ValueCertificate.refinement
theorem p149 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t70 γ) := .refl (t70 γ)
theorem p150 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t71 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p149 γ)
theorem p151 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t70 γ) := .guardTrue (t70 γ)
theorem p152 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t70 γ) := .trans (p151 γ) (p149 γ)
theorem p153 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t70 γ) := .trans (p150 γ) (p152 γ)
theorem p154 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .trans (p148 γ) (p153 γ)
theorem p155 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .trans (p147 γ) (p154 γ)
theorem p156 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t70 γ) := .trans (p146 γ) (p155 γ)
theorem p157 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t70 γ) := .trans (p145 γ) (p156 γ)
theorem p158 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t72 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p110 γ) (p157 γ)
theorem p159 (γ : Binding.Globals) : Binding.Reduction (t72 γ) (t73 γ) := .ofEq (fun _ _ => rfl)
theorem p160 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t73 γ) := .refl (t73 γ)
theorem p161 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t75 γ) := .scalarSimplify n35 n16 n36 QSym.BindingScalar11.DomainCertificate.domain_correct QSym.BindingScalar11.ValueCertificate.refinement
theorem p162 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t74 γ) := .refl (t74 γ)
theorem p163 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t75 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p162 γ)
theorem p164 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t74 γ) := .guardTrue (t74 γ)
theorem p165 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t74 γ) := .trans (p164 γ) (p162 γ)
theorem p166 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t74 γ) := .trans (p163 γ) (p165 γ)
theorem p167 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t74 γ) := .trans (p161 γ) (p166 γ)
theorem p168 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t74 γ) := .trans (p160 γ) (p167 γ)
theorem p169 (γ : Binding.Globals) : Binding.Reduction (t72 γ) (t74 γ) := .trans (p159 γ) (p168 γ)
theorem p170 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t74 γ) := .trans (p158 γ) (p169 γ)
theorem p171 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t76 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p170 γ) (p3 γ)
theorem p172 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t77 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p97 γ) (p171 γ)
theorem p173 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t77 γ) := .trans (p23 γ) (p172 γ)
theorem p174 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t77 γ) := .trans (p22 γ) (p173 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t77 γ) := (p174 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t77 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t22 γ).eval ξ ρ) ↔ Value.Defined ((t77 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
