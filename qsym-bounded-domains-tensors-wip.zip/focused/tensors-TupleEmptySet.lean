import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .bool := (.bool true)
def n1 : Expr .bool := (.bool false)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.pair (.scalar .real) (.vector (.scalar .natural) 1)) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c1 (.scalar .bool) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.set (.pair (.scalar .real) (.vector (.scalar .natural) 1))) := .set (t0 γ)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c1 (.scalar .bool) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.set (.pair (.scalar .real) (.vector (.scalar .natural) 1))) := .set (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Binding.equalValue (t1 γ) (t3 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n1
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .set (p0 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .set (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.set (.pair (.scalar .real) (.vector (.scalar .natural) 1)))) (b := (.set (.pair (.scalar .real) (.vector (.scalar .natural) 1)))) (c := (.scalar .bool)) Binding.equalValue (p1 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t6 γ) := .equalUnivEmpty (a := (.pair (.scalar .real) (.vector (.scalar .natural) 1))) (0, (fun _ => 0))
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t6 γ) := .trans (p5 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t6 γ) := .trans (p4 γ) (p7 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t6 γ) := (p8 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t4 γ).eval ξ ρ = (t6 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t4 γ).eval ξ ρ) ↔ Value.Defined ((t6 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t4 γ).eval ξ ρ = n1.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .bool := (.bool false)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n1) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_1 ρ) (eval_1 ρ)) (Value.refines_refl (v1 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n1) : (Expr.eval ρ n1) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v1 ρ) := (total_1 ρ)
def d1 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n1 ↔ (d1 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_1 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n1 := Eq.mpr (congrArg Value.Defined (eval_1 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t4 γ).eval ξ ρ) (FunctionScalar.n1.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n1.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t4 γ).eval ξ ρ)) : ((BindingCertificate.t4 γ).eval ξ ρ) = (FunctionScalar.n1.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
