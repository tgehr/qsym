import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n2 : Expr .natural := (.nat (0))
def n4 : Expr .bool := (.bool true)
def n5 : Expr .bool := (.leN n0 n2)
def n6 : Expr .integer := (.castNZ n0)
def n14 : Expr .integer := (.int (1))
def n15 : Expr .bool := (.nonzeroZ n14)
def n17 : Expr .bool := (.bool false)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v5 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v0 ρ) (v2 ρ)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroZ.apply (v6 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v7 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroZ.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v4 ρ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some false
noncomputable def v18 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v16 ρ)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v17 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_5 (ρ : Env) : (Expr.eval ρ n5) = (v5 ρ) := rfl
theorem eval_6 (ρ : Env) : (Expr.eval ρ n6) = (v6 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v5 ρ) (v8 ρ) :=
  (Generated.r_natural_nonpositive_zero (v0 ρ))

theorem p1 (ρ : Env) : Value.Refines (v6 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_6 ρ) (eval_14 ρ)) (Numeric.sound ρ n6 n14 rfl)

theorem p2 (ρ : Env) : Value.Refines (v7 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.nonzeroZ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v15 ρ) (v4 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_4 ρ)) (Numeric.sound ρ n15 n4 rfl)

theorem p4 (ρ : Env) : Value.Refines (v7 ρ) (v4 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v8 ρ) (v16 ρ) :=
  Value.refines_not (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v16 ρ) (v17 ρ) :=
  (Generated.r_bool_not_true)

theorem p7 (ρ : Env) : Value.Refines (v18 ρ) (v19 ρ) :=
  Value.refines_not (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v19 ρ) (v4 ρ) :=
  (Generated.r_bool_not_false)

theorem p9 (ρ : Env) : Value.Refines (v18 ρ) (v4 ρ) :=
  (p7 ρ).trans (p8 ρ)

theorem p10 (ρ : Env) : Value.Refines (v16 ρ) (v17 ρ) :=
  (Generated.r_bool_false (v16 ρ) (p9 ρ))

theorem p11 (ρ : Env) : Value.Refines (v8 ρ) (v17 ρ) :=
  (p5 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v5 ρ) (v17 ρ) :=
  (p0 ρ).trans (p11 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n5) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_5 ρ) (eval_17 ρ)) (p12 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n5) : (Expr.eval ρ n5) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v2 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  Functions.leN.defined (v0 ρ) (v2 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n5 ↔ (d5 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_5 ρ))).trans (domain_5 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v0 ρ) (v2 ρ) (total_0 ρ) (total_2 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n5 := Eq.mpr (congrArg Value.Defined (eval_5 ρ)) (total_5 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n2 : Expr .natural := (.nat (0))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n3 : Expr .natural := (.subN n2 n0)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := Functions.subN.apply (v2 ρ) (v0 ρ)
def n4 : Expr .bool := (.bool true)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .bool) := some true
def n5 : Expr .bool := (.leN n0 n2)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v0 ρ) (v2 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v4 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v4 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v5 ρ) :=
  Domain.partial2 Functions.subN (x := (v2 ρ)) (y := (v0 ρ)) (dx := (v4 ρ)) (dy := (v4 ρ)) (p := (v5 ρ)) (Domain.test_subN (v2 ρ) (v0 ρ)) (q2 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n3) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q3 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n3 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (0))
def n3 : Expr .natural := (.subN n2 n0)
def n17 : Expr .bool := (.bool false)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Tensor.getValue (t4 γ) (t6 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .constant none
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n17
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.scalar .natural)) (c := (.scalar .natural)) Tensor.getValue (p4 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t9 γ) := Tensor.getScalarUndefined (t4 γ) n3 QSym.BindingScalar0.DomainCertificate.domain_correct
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t9 γ) := .trans (p7 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t9 γ) := .trans (p6 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t10 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t11 γ) := .ofEq (fun _ _ => rfl)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t11 γ) := .trans (p12 γ) (p13 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t11 γ) := .trans (p11 γ) (p14 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t11 γ) := (p15 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t8 γ).eval ξ ρ = (t11 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t8 γ).eval ξ ρ) ↔ Value.Defined ((t11 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t8 γ).eval ξ ρ = n17.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool false)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t8 γ).eval ξ ρ) (FunctionScalar.n17.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n17.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t8 γ).eval ξ ρ)) : ((BindingCertificate.t8 γ).eval ξ ρ) = (FunctionScalar.n17.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
