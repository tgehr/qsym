import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n11 : Expr .bool := (.bool true)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n11) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_11 ρ) (eval_11 ρ)) (Value.refines_refl (v11 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n11) : (Expr.eval ρ n11) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v11 ρ) := (total_11 ρ)
def d11 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n11 ↔ (d11 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_11 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n11 := Eq.mpr (congrArg Value.Defined (eval_11 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n10 : Expr .natural := (.addN n0 n3)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v3 ρ)
def n11 : Expr .bool := (.bool true)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v11 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v11 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v11 ρ) :=
  Domain.total2 Functions.addN (x := (v0 ρ)) (y := (v3 ρ)) (dx := (v11 ρ)) (dy := (v11 ρ)) (fun _ _ => True.intro) (q0 ρ) (q3 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n10) (Expr.eval ρ Certificate.n11) :=
  Domain.simplify (q10 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n11) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n10 ↔ (Expr.eval ρ Certificate.n11) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (5))
def n10 : Expr .natural := (.addN n0 n3)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v3 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v10 ρ) (v4 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_10 ρ) (eval_4 ρ)) (Numeric.sound ρ n10 n4 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d10 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v3 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.addN.defined (v0 ρ) (v3 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (domain_10 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v0 ρ) (v3 ρ) (total_0 ρ) (total_3 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_10 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n11 : Expr .bool := (.bool true)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n11) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_11 ρ) (eval_11 ρ)) (Value.refines_refl (v11 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n11) : (Expr.eval ρ n11) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v11 ρ) := (total_11 ρ)
def d11 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n11 ↔ (d11 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_11 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n11 := Eq.mpr (congrArg Value.Defined (eval_11 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n11 : Expr .bool := (.bool true)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .bool) := some true
def n12 : Expr .natural := (.addN n1 n4)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v4 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v11 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v11 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v11 ρ) :=
  Domain.total2 Functions.addN (x := (v1 ρ)) (y := (v4 ρ)) (dx := (v11 ρ)) (dy := (v11 ρ)) (fun _ _ => True.intro) (q1 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n12) (Expr.eval ρ Certificate.n11) :=
  Domain.simplify (q12 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n11) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n12 ↔ (Expr.eval ρ Certificate.n11) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n4 : Expr .natural := (.nat (5))
def n12 : Expr .natural := (.addN n1 n4)
def n13 : Expr .natural := (.nat (7))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v4 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (7)
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v12 ρ) (v13 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_12 ρ) (eval_13 ρ)) (Numeric.sound ρ n12 n13 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n13) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_13 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n13) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.addN.defined (v1 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (domain_12 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v1 ρ) (v4 ρ) (total_1 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_12 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n11 : Expr .bool := (.bool true)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n11) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_11 ρ) (eval_11 ρ)) (Value.refines_refl (v11 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n11) : (Expr.eval ρ n11) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v11 ρ) := (total_11 ρ)
def d11 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n11 ↔ (d11 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_11 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n11 := Eq.mpr (congrArg Value.Defined (eval_11 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n2 : Expr .natural := (.nat (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n11 : Expr .bool := (.bool true)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .bool) := some true
def n14 : Expr .natural := (.addN n2 n5)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v2 ρ) (v5 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v11 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v11 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v11 ρ) :=
  Domain.total2 Functions.addN (x := (v2 ρ)) (y := (v5 ρ)) (dx := (v11 ρ)) (dy := (v11 ρ)) (fun _ _ => True.intro) (q2 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n11) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n11) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n11) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (3))
def n5 : Expr .natural := (.nat (6))
def n14 : Expr .natural := (.addN n2 n5)
def n15 : Expr .natural := (.nat (9))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v2 ρ) (v5 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := some (9)
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_14 ρ) (eval_15 ρ)) (Numeric.sound ρ n14 n15 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d14 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.addN.defined (v2 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (domain_14 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v2 ρ) (v5 ρ) (total_2 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_14 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (3))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (5))
def n5 : Expr .natural := (.nat (6))
def n10 : Expr .natural := (.addN n0 n3)
def n11 : Expr .bool := (.bool true)
def n12 : Expr .natural := (.addN n1 n4)
def n13 : Expr .natural := (.nat (7))
def n14 : Expr .natural := (.addN n2 n5)
def n15 : Expr .natural := (.nat (9))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t2 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t1 γ) (t4 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t0 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n5
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t9 γ) (t3 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t8 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t7 γ) (t11 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary (Tensor.zipValue Functions.addN.apply 3) (t6 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t7 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t1 γ) (t8 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t2 γ) (t9 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t16 γ) (t3 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t15 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t14 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n10
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n11
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t21 γ) (t8 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n12
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n13
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t21 γ) (t24 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n14
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n15
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t21 γ) (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t27 γ) (t3 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t24 γ) (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 3) := .binary Tensor.consValue (t8 γ) (t30 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p2 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p1 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p0 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .refl (t8 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p9 γ) (p3 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p8 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p7 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.vector (.scalar .natural) 3)) (b := (.vector (.scalar .natural) 3)) (c := (.vector (.scalar .natural) 3)) (Tensor.zipValue Functions.addN.apply 3) (p6 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t19 γ) := .ofEq (fun ξ ρ => rfl)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p0 γ) (p7 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t20 γ) := .ofEq (fun _ _ => rfl)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t22 γ) := .scalarSimplify n10 n11 n4 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p8 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t8 γ) := .guardTrue (t8 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t8 γ) := .trans (p21 γ) (p8 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t8 γ) := .trans (p20 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t8 γ) := .trans (p18 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t8 γ) := .trans (p17 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t8 γ) := .trans (p16 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t8 γ) := .trans (p15 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p1 γ) (p8 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t23 γ) := .ofEq (fun _ _ => rfl)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t25 γ) := .scalarSimplify n12 n11 n13 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t24 γ) := .guardTrue (t24 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t24 γ) := .trans (p34 γ) (p32 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t24 γ) := .trans (p33 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t24 γ) := .trans (p31 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t24 γ) := .trans (p30 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t24 γ) := .trans (p29 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t24 γ) := .trans (p28 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p2 γ) (p9 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t26 γ) := .ofEq (fun _ _ => rfl)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t28 γ) := .scalarSimplify n14 n11 n15 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .refl (t27 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .guardTrue (t27 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p47 γ) (p45 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p46 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t27 γ) := .trans (p44 γ) (p49 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t27 γ) := .trans (p43 γ) (p50 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t27 γ) := .trans (p42 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t27 γ) := .trans (p41 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t29 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p53 γ) (p3 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t30 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p40 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t31 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 3)) Tensor.consValue (p27 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t31 γ) := .trans (p14 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t31 γ) := .trans (p13 γ) (p57 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t31 γ) := (p58 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t13 γ).eval ξ ρ = (t31 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t13 γ).eval ξ ρ) ↔ Value.Defined ((t31 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
