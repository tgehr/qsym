import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (3))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (0))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t6 γ) (t2 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t5 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 0) := .constant Tensor.nilValue
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t8 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t4 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t11 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t12 γ) (t2 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t14 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t0 γ) (t2 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t12 γ) (t16 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t17 γ) (t9 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t15 γ) (t18 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p6 γ) (p2 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p5 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p8 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p4 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p11 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t19 γ) := .ofEq (fun ξ ρ => rfl)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p12 γ) (p2 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p0 γ) (p2 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p12 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p18 γ) (p9 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p16 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t19 γ) := .trans (p14 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t19 γ) := .trans (p13 γ) (p21 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t19 γ) := (p22 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t13 γ).eval ξ ρ = (t19 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t13 γ).eval ξ ρ) ↔ Value.Defined ((t19 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
