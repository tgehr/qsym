import QSym.Refinement
import QSym.AxiomCheck
namespace QSym.Generated
theorem r_complex_pow_one (v_x : Option (Ty.denote .complex)) :
    Value.Refines (v_x.map (fun x => x ^ (1))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_complex_pow_one

theorem r_complex_pow_split (v_x : Option (Ty.denote .complex)) (v_m : Nat) (v_n : Nat) :
    Value.Refines (v_x.map (fun x => x ^ (v_m + v_n))) (Value.mul (v_x.map (fun x => x ^ v_m)) (v_x.map (fun x => x ^ v_n))) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_complex_pow_split

theorem r_embed_NZ_mask (v_p : Option (Ty.denote .bool)) (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Value.mask v_p (Functions.castNZ.apply v_x)) (Functions.castNZ.apply (Value.mask v_p v_x)) := by
  cases v_p <;> cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_embed_NZ_mask

theorem r_embed_QR_mask (v_p : Option (Ty.denote .bool)) (v_x : Option (Ty.denote .rational)) :
    Value.Refines (Value.mask v_p (Functions.castQR.apply v_x)) (Functions.castQR.apply (Value.mask v_p v_x)) := by
  cases v_p <;> cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_embed_QR_mask

theorem r_embed_RC_mask (v_p : Option (Ty.denote .bool)) (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.mask v_p (Functions.castRC.apply v_x)) (Functions.castRC.apply (Value.mask v_p v_x)) := by
  cases v_p <;> cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_embed_RC_mask

theorem r_embed_ZQ_mask (v_p : Option (Ty.denote .bool)) (v_x : Option (Ty.denote .integer)) :
    Value.Refines (Value.mask v_p (Functions.castZQ.apply v_x)) (Functions.castZQ.apply (Value.mask v_p v_x)) := by
  cases v_p <;> cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_embed_ZQ_mask

theorem r_integer_add_zero (v_x : Option (Ty.denote .integer)) :
    Value.Refines (Functions.addZ.apply v_x (some ((0) : ℤ))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_integer_add_zero

theorem r_integer_literal_lt_left (v_x : Option (Ty.denote .integer)) (v_a : Option (Ty.denote .integer)) (v_b : Option (Ty.denote .integer))
    (hp0 : Value.Refines (Value.not (Functions.nonzeroZ.apply (Functions.addZ.apply v_b (Functions.mulZ.apply (some ((-1) : ℤ)) (Functions.addZ.apply v_a (some ((1) : ℤ))))))) (some true))
    (hp1 : Value.Defined v_b) :
    Value.Refines (Functions.ltZ.apply v_a v_x) (Functions.leZ.apply v_b v_x) := by
  cases v_x <;> cases v_a <;> cases v_b
  all_goals qsym_rule

#qsym_check_axioms r_integer_literal_lt_left

theorem r_integer_mask_zero (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.mask v_p (some ((0) : ℤ))) (some ((0) : ℤ)) := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_integer_mask_zero

theorem r_integer_mul_one (v_x : Option (Ty.denote .integer)) :
    Value.Refines (Functions.mulZ.apply v_x (some ((1) : ℤ))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_integer_mul_one

theorem r_integer_not_le (v_x : Option (Ty.denote .integer)) (v_y : Option (Ty.denote .integer)) :
    Value.Refines (Value.not (Functions.leZ.apply v_x v_y)) (Functions.ltZ.apply v_y v_x) := by
  cases v_x <;> cases v_y
  all_goals qsym_rule

#qsym_check_axioms r_integer_not_le

theorem r_integer_zero_add (v_x : Option (Ty.denote .integer)) :
    Value.Refines (Functions.addZ.apply (some ((0) : ℤ)) v_x) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_integer_zero_add

theorem r_natural_literal_lt_right (v_x : Option (Ty.denote .natural)) (v_a : Option (Ty.denote .natural)) (v_b : Option (Ty.denote .natural))
    (hp0 : Value.Refines (Value.not (Functions.nonzeroZ.apply (Functions.addZ.apply (Functions.castNZ.apply v_a) (Functions.mulZ.apply (some ((-1) : ℤ)) (Functions.castNZ.apply (Functions.addN.apply v_b (some ((1) : ℕ)))))))) (some true))
    (hp1 : Value.Defined v_b) :
    Value.Refines (Functions.ltN.apply v_x v_a) (Functions.leN.apply v_x v_b) := by
  cases v_x <;> cases v_a <;> cases v_b
  all_goals qsym_rule

#qsym_check_axioms r_natural_literal_lt_right

theorem r_natural_mul_one (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.mulN.apply v_x (some ((1) : ℕ))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_mul_one

theorem r_natural_not_lt (v_x : Option (Ty.denote .natural)) (v_y : Option (Ty.denote .natural)) :
    Value.Refines (Value.not (Functions.ltN.apply v_x v_y)) (Functions.leN.apply v_y v_x) := by
  cases v_x <;> cases v_y
  all_goals qsym_rule

#qsym_check_axioms r_natural_not_lt

theorem r_rational_add_zero (v_x : Option (Ty.denote .rational)) :
    Value.Refines (Functions.addQ.apply v_x (some (((0) : ℚ) / (1)))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_rational_add_zero

theorem r_real_sqrt_exact (v_x : Option (Ty.denote .real)) (v_y : Option (Ty.denote .real))
    (hp0 : Value.Refines (Value.not (Value.nonzero (Value.add (v_y.map (fun x => x ^ (2))) (Value.mul (some (((-1) : Int) : ℝ)) v_x)))) (some true))
    (hp1 : Value.Refines (Value.le (some (((0) : Int) : ℝ)) v_y) (some true))
    (hp2 : Value.Defined v_y) :
    Value.Refines (Functions.sqrtR.apply v_x) v_y := by
  cases v_x <;> cases v_y
  all_goals qsym_rule

#qsym_check_axioms r_real_sqrt_exact
end QSym.Generated
