import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n3 : Expr .natural := (.nat (0))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n29 : Expr .natural := (.varN 7)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 7)
def n30 : Expr .bool := (.leN n29 n3)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v29 ρ) (v3 ρ)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q29 (ρ : Env) : Domain.Correct (v29 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v39 ρ) :=
  Domain.total2 Functions.leN (x := (v29 ρ)) (y := (v3 ρ)) (dx := (v39 ρ)) (dy := (v39 ρ)) (fun _ _ => True.intro) (q29 ρ) (q3 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n30) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q30 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n30 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n3 : Expr .natural := (.nat (0))
def n29 : Expr .natural := (.varN 7)
def n30 : Expr .bool := (.leN n29 n3)
def n38 : Expr .bool := (.nonzeroN n29)
def n40 : Expr .bool := (.not n38)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 7)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v29 ρ) (v3 ρ)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v29 ρ)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroZ.apply (v31 ρ)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v32 ρ)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroN.apply (v29 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v38 ρ)
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v30 ρ) (v33 ρ) :=
  (Generated.r_natural_nonpositive_zero (v29 ρ))

theorem p1 (ρ : Env) : Value.Refines (v32 ρ) (v38 ρ) :=
  (Generated.r_embed_NZ_nonzero (v29 ρ))

theorem p2 (ρ : Env) : Value.Refines (v33 ρ) (v40 ρ) :=
  Value.refines_not (p1 ρ)

theorem p4 (ρ : Env) : Value.Refines (v30 ρ) (v40 ρ) :=
  (p0 ρ).trans (p2 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n30) (Expr.eval ρ n40) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_30 ρ) (eval_40 ρ)) (p4 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n30) : (Expr.eval ρ n30) = (Expr.eval ρ n40) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d29 (ρ : Env) : Prop := True
theorem domain_29 (ρ : Env) : Value.Defined (v29 ρ) ↔ d29 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d30 (ρ : Env) : Prop := ∃ x y, (v29 ρ) = some x ∧ (v3 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  Functions.leN.defined (v29 ρ) (v3 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n30 ↔ (d30 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_30 ρ))).trans (domain_30 ρ)
#qsym_check_axioms definedness
theorem total_29 (ρ : Env) : Value.Defined (v29 ρ) :=
  ⟨_, rfl⟩
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v29 ρ) (v3 ρ) (total_29 ρ) (total_3 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n30 := Eq.mpr (congrArg Value.Defined (eval_30 ρ)) (total_30 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n3 : Expr .natural := (.nat (0))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v39 ρ) :=
  Domain.leaf _
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n3) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q3 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n3 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n49 : Expr .natural := (.varN 9)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 9)
def n50 : Expr .bool := (.nonzeroN n49)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroN.apply (v49 ρ)
def n51 : Expr .bool := (.not n50)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v50 ρ)
theorem q49 (ρ : Env) : Domain.Correct (v49 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q50 (ρ : Env) : Domain.Correct (v50 ρ) (v39 ρ) :=
  Domain.total1 Functions.nonzeroN (x := (v49 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q49 ρ)
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v39 ρ) :=
  Domain.transport (x := (v50 ρ)) (d := (v39 ρ)) (Value.defined_not (v50 ρ)) (q50 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n51) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q51 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n51 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
def n53 : Expr .natural := (.varN 10)
def n54 : Expr .bool := (.nonzeroN n53)
def n55 : Expr .bool := (.not n54)
def n57 : Expr .bool := (.not n55)
def n58 : Expr .bool := (.or n57 n39)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v53 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 10)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroN.apply (v53 ρ)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v54 ρ)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v55 ρ)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v57 ρ) (v39 ρ)
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl
theorem eval_58 (ρ : Env) : (Expr.eval ρ n58) = (v58 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v58 ρ) (v39 ρ) :=
  (Generated.r_bool_or_right_true (v57 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n58) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_58 ρ) (eval_39 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n58) : (Expr.eval ρ n58) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d53 (ρ : Env) : Prop := True
theorem domain_53 (ρ : Env) : Value.Defined (v53 ρ) ↔ d53 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d54 (ρ : Env) : Prop := ∃ x, (v53 ρ) = some x ∧ Functions.nonzeroN.domain x
theorem domain_54 (ρ : Env) : Value.Defined (v54 ρ) ↔ d54 ρ :=
  Functions.nonzeroN.defined (v53 ρ)

def d55 (ρ : Env) : Prop := (d54 ρ)
theorem domain_55 (ρ : Env) : Value.Defined (v55 ρ) ↔ d55 ρ :=
  (Value.defined_not (v54 ρ)).trans (domain_54 ρ)

def d57 (ρ : Env) : Prop := (d55 ρ)
theorem domain_57 (ρ : Env) : Value.Defined (v57 ρ) ↔ d57 ρ :=
  (Value.defined_not (v55 ρ)).trans (domain_55 ρ)

def d39 (ρ : Env) : Prop := True
theorem domain_39 (ρ : Env) : Value.Defined (v39 ρ) ↔ d39 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d58 (ρ : Env) : Prop := (v57 ρ) = some true ∨ ((v57 ρ) = some false ∧ (d39 ρ))
theorem domain_58 (ρ : Env) : Value.Defined (v58 ρ) ↔ d58 ρ :=
  (Value.defined_or (v57 ρ) (v39 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_39 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n58 ↔ (d58 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_58 ρ))).trans (domain_58 ρ)
#qsym_check_axioms definedness
theorem total_53 (ρ : Env) : Value.Defined (v53 ρ) :=
  ⟨_, rfl⟩
theorem total_54 (ρ : Env) : Value.Defined (v54 ρ) :=
  Functions.nonzeroN.total (fun _ => True.intro) (v53 ρ) (total_53 ρ)
theorem total_55 (ρ : Env) : Value.Defined (v55 ρ) :=
  (Value.defined_not (v54 ρ)).mpr (total_54 ρ)
theorem total_57 (ρ : Env) : Value.Defined (v57 ρ) :=
  (Value.defined_not (v55 ρ)).mpr (total_55 ρ)
theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_58 (ρ : Env) : Value.Defined (v58 ρ) :=
  Value.defined_or_total (v57 ρ) (v39 ρ) (total_57 ρ) (total_39 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n58 := Eq.mpr (congrArg Value.Defined (eval_58 ρ)) (total_58 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n53 : Expr .natural := (.varN 10)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 10)
def n54 : Expr .bool := (.nonzeroN n53)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroN.apply (v53 ρ)
def n55 : Expr .bool := (.not n54)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v54 ρ)
def n56 : Expr .bool := (.and n55 n39)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v55 ρ) (v39 ρ)
def n57 : Expr .bool := (.not n55)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v55 ρ)
def n58 : Expr .bool := (.or n57 n39)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v57 ρ) (v39 ρ)
theorem q53 (ρ : Env) : Domain.Correct (v53 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q54 (ρ : Env) : Domain.Correct (v54 ρ) (v39 ρ) :=
  Domain.total1 Functions.nonzeroN (x := (v53 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q53 ρ)
theorem q55 (ρ : Env) : Domain.Correct (v55 ρ) (v39 ρ) :=
  Domain.transport (x := (v54 ρ)) (d := (v39 ρ)) (Value.defined_not (v54 ρ)) (q54 ρ)
theorem q39 (ρ : Env) : Domain.Correct (v39 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q56 (ρ : Env) : Domain.Correct (v56 ρ) (v58 ρ) :=
  Domain.and (p := (v55 ρ)) (q := (v39 ρ)) (dp := (v39 ρ)) (dq := (v39 ρ)) (q55 ρ) (q39 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n56) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q56 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n56 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
def n53 : Expr .natural := (.varN 10)
def n54 : Expr .bool := (.nonzeroN n53)
def n55 : Expr .bool := (.not n54)
def n56 : Expr .bool := (.and n55 n39)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v53 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 10)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroN.apply (v53 ρ)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v54 ρ)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v55 ρ) (v39 ρ)
theorem eval_55 (ρ : Env) : (Expr.eval ρ n55) = (v55 ρ) := rfl
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v56 ρ) (v55 ρ) :=
  (Generated.r_bool_and_right_true (v55 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n56) (Expr.eval ρ n55) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_56 ρ) (eval_55 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n56) : (Expr.eval ρ n56) = (Expr.eval ρ n55) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d53 (ρ : Env) : Prop := True
theorem domain_53 (ρ : Env) : Value.Defined (v53 ρ) ↔ d53 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d54 (ρ : Env) : Prop := ∃ x, (v53 ρ) = some x ∧ Functions.nonzeroN.domain x
theorem domain_54 (ρ : Env) : Value.Defined (v54 ρ) ↔ d54 ρ :=
  Functions.nonzeroN.defined (v53 ρ)

def d55 (ρ : Env) : Prop := (d54 ρ)
theorem domain_55 (ρ : Env) : Value.Defined (v55 ρ) ↔ d55 ρ :=
  (Value.defined_not (v54 ρ)).trans (domain_54 ρ)

def d39 (ρ : Env) : Prop := True
theorem domain_39 (ρ : Env) : Value.Defined (v39 ρ) ↔ d39 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d56 (ρ : Env) : Prop := (v55 ρ) = some false ∨ ((v55 ρ) = some true ∧ (d39 ρ))
theorem domain_56 (ρ : Env) : Value.Defined (v56 ρ) ↔ d56 ρ :=
  (Value.defined_and (v55 ρ) (v39 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_39 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n56 ↔ (d56 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_56 ρ))).trans (domain_56 ρ)
#qsym_check_axioms definedness
theorem total_53 (ρ : Env) : Value.Defined (v53 ρ) :=
  ⟨_, rfl⟩
theorem total_54 (ρ : Env) : Value.Defined (v54 ρ) :=
  Functions.nonzeroN.total (fun _ => True.intro) (v53 ρ) (total_53 ρ)
theorem total_55 (ρ : Env) : Value.Defined (v55 ρ) :=
  (Value.defined_not (v54 ρ)).mpr (total_54 ρ)
theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  Value.defined_and_total (v55 ρ) (v39 ρ) (total_55 ρ) (total_39 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n56 := Eq.mpr (congrArg Value.Defined (eval_56 ρ)) (total_56 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (0))
def n29 : Expr .natural := (.varN 7)
def n30 : Expr .bool := (.leN n29 n3)
def n38 : Expr .bool := (.nonzeroN n29)
def n39 : Expr .bool := (.bool true)
def n40 : Expr .bool := (.not n38)
def n49 : Expr .natural := (.varN 9)
def n50 : Expr .bool := (.nonzeroN n49)
def n51 : Expr .bool := (.not n50)
def n53 : Expr .natural := (.varN 10)
def n54 : Expr .bool := (.nonzeroN n53)
def n55 : Expr .bool := (.not n54)
def n56 : Expr .bool := (.and n55 n39)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: c0
abbrev c2 : List Binding.Ty := (.scalar .natural) :: c1
abbrev c3 : List Binding.Ty := (.scalar .natural) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c2 (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.subN.apply (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t2 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .integer) := .unary Functions.castNZ.apply (t0 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Functions.nonzeroZ.apply (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n3
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t9 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .binary Functions.leN.apply (t0 γ) (t10 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t13 γ) (t4 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t13 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t15 γ) (t6 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t14 γ) (t16 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t12 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t11 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c1 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t20 γ))
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .unary Binding.inputDomain (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .var .here
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n3
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Functions.leN.apply (t23 γ) (t24 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Binding.guardValue (t25 γ) (t24 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Functions.nonzeroN.apply (t23 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Value.not (t28 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Binding.guardValue (t29 γ) (t24 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t30 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .unary Binding.inputDomain (t31 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.definedValue (t30 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t33 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.holdsValue (t29 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.definedValue (t24 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t35 γ) (t36 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .scalar n39
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t35 γ) (t38 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t39 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t38 γ) (t29 γ)
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t41 γ) (t38 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t42 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t29 γ) (t38 γ)
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t44 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t29 γ)
noncomputable def rec21 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t11 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t12 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.branch (.constant (fun x => (t13 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t3 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))) (.branch (.constant (fun x => (t15 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t5 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0)))) (.constant (fun _ => some 0))))
theorem fixed21 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t21 γ).eval ξ ρ = some (FixedPoint.value (rec21 γ ξ ρ).functional) := Recursion.fixed_program (rec21 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem unroll21 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t21 γ).eval ξ ρ = (Binding.Expr.app (.lam (t20 γ)) (t21 γ)).eval ξ ρ := Recursion.program_unfold (rec21 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem solve21 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t21 γ).eval ξ ρ = (t27 γ).eval ξ ρ :=
  Eq.trans (fixed21 γ ξ ρ) (congrArg some (Recursion.solve_nat_cutoff (rec21 γ ξ ρ) ((n3.eval ξ).getD 0) ((n3.eval ξ).getD 0) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _)))).symm)))
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 γ))
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t27 γ) := .ofEq (fun ξ ρ => solve21 γ ξ ρ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p3 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p5 γ) (p4 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .lam (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t31 γ) := .lamPointwise (fun ξ ρ x => (congrArg₂ Binding.guardValue (Binding.preserveDomain (n30.eval ({ ξ with natural := fun i => if i = 7 then x else ξ.natural i })) (n40.eval ({ ξ with natural := fun i => if i = 7 then x else ξ.natural i })) (n39.eval ({ ξ with natural := fun i => if i = 7 then x else ξ.natural i })) (QSym.BindingScalar0.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 7 then x else ξ.natural i })) (QSym.BindingScalar0.ValueCertificate.refinement ({ ξ with natural := fun i => if i = 7 then x else ξ.natural i }))) rfl))
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Functions.nonzeroN.apply (p3 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .unary (a := (.scalar .bool)) (b := (.scalar .bool)) Value.not (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p10 γ) (p4 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .lam (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t31 γ) := .trans (p8 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t31 γ) := .trans (p7 γ) (p13 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t31 γ) := .trans (p2 γ) (p14 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t31 γ) := .trans (p1 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t32 γ) := .unary (a := (.arrow (.scalar .natural) (.scalar .natural))) (b := (.set (.scalar .natural))) Binding.inputDomain (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t34 γ) := .domainLam (t30 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p11 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t37 γ) := .definedGuard (t29 γ) (t24 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .unary (a := (.scalar .bool)) (b := (.scalar .bool)) Binding.holdsValue (p10 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p4 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .scalarDomain n3 n39 QSym.BindingScalar1.DomainCertificate.domain_correct
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .refl (t38 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p23 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t38 γ) := .trans (p22 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p21 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t39 γ) := .trans (p20 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t39 γ) := .trans (p19 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t40 γ) := .set (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t43 γ) := .setPointwise (fun ξ ρ x => (congrArg₂ Value.and (Binding.holdsDomain (n51.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (n39.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (QSym.BindingScalar2.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i }))) rfl))
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p24 γ) (p10 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t29 γ) := .ofEq (fun _ _ => rfl)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t29 γ) := .trans (p33 γ) (p10 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t29 γ) := .trans (p32 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t44 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p35 γ) (p24 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t45 γ) := .set (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .setPointwise (fun ξ ρ x => (Binding.preserveDomain (n56.eval ({ ξ with natural := fun i => if i = 10 then x else ξ.natural i })) (n55.eval ({ ξ with natural := fun i => if i = 10 then x else ξ.natural i })) (n39.eval ({ ξ with natural := fun i => if i = 10 then x else ξ.natural i })) (QSym.BindingScalar3.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 10 then x else ξ.natural i })) (QSym.BindingScalar3.ValueCertificate.refinement ({ ξ with natural := fun i => if i = 10 then x else ξ.natural i }))))
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .set (p10 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .trans (p38 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t46 γ) := .trans (p37 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t46 γ) := .trans (p31 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t46 γ) := .trans (p30 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t46 γ) := .trans (p18 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t46 γ) := .trans (p17 γ) (p44 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t46 γ) := (p45 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t46 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t22 γ).eval ξ ρ) ↔ Value.Defined ((t46 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
