import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_20 ρ)) (Value.refines_refl (v20 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v20 ρ) := (total_20 ρ)
def d20 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .real := (.real (3))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some ((3 : Int) : ℝ)
def n8 : Expr .real := (.mulR n0 n0)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v0 ρ)
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v20 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v20 ρ) :=
  Domain.strict2 (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v20 ρ)) (dy := (v20 ρ)) (Value.defined_mul (v0 ρ) (v0 ρ)) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n8) (Expr.eval ρ Certificate.n20) :=
  Domain.simplify (q8 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n20) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n8 ↔ (Expr.eval ρ Certificate.n20) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .real := (.real (3))
def n8 : Expr .real := (.mulR n0 n0)
def b9 : Region (Expr .real) := .item n0 (.twice .one)
def n9 : Expr .real := Expr.productR b9
def n15 : Expr .real := (.real (9))
def n16 : Expr .natural := (.nat (9))
def n17 : Expr .integer := (.castNZ n16)
def n18 : Expr .rational := (.castZQ n17)
def n19 : Expr .real := (.castQR n18)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some ((3 : Int) : ℝ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v0 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v0 ρ) (v0 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v0 ρ)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 1)) (v0 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v12 ρ) (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v12 ρ) (v12 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := some ((9 : Int) : ℝ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := some (9)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v16 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v17 ρ)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v18 ρ)
theorem eval_8 (ρ : Env) : (Expr.eval ρ n8) = (v8 ρ) := rfl
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v8 ρ) (v9 ρ) :=
  Value.refines_refl (v8 ρ)

theorem p1 (ρ : Env) : Value.Refines (v9 ρ) (v11 ρ) :=
  Value.refines_repeat_mul (.twice .one) 2 (Positive.toNat_twice .one 1 Positive.toNat_one) (x := (v0 ρ)) (y := (v0 ρ)) (Value.refines_refl (v0 ρ))

theorem p2 (ρ : Env) : Value.Refines (v11 ρ) (v14 ρ) :=
  (Generated.r_real_pow_split (v0 ρ) 1 1)

theorem p3 (ρ : Env) : Value.Refines (v14 ρ) (v13 ρ) :=
  Value.refines_refl (v14 ρ)

theorem p4 (ρ : Env) : Value.Refines (v11 ρ) (v13 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v12 ρ) (v0 ρ) :=
  (Generated.r_real_pow_one (v0 ρ))

theorem p6 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Value.refines_refl (v13 ρ)

theorem p7 (ρ : Env) : Value.Refines (v14 ρ) (v8 ρ) :=
  Value.refines_mul (p5 ρ) (p5 ρ)

theorem p8 (ρ : Env) : Value.Refines (v13 ρ) (v8 ρ) :=
  (p6 ρ).trans (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v8 ρ) (v9 ρ) :=
  Value.refines_refl (v8 ρ)

theorem p10 (ρ : Env) : Value.Refines (v13 ρ) (v9 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v11 ρ) (v9 ρ) :=
  (p4 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_9 ρ) (eval_15 ρ)) (Numeric.sound ρ n9 n15 rfl)

theorem p13 (ρ : Env) : Value.Refines (v11 ρ) (v15 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem p14 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  (p1 ρ).trans (p13 ρ)

theorem p15 (ρ : Env) : Value.Refines (v8 ρ) (v15 ρ) :=
  (p0 ρ).trans (p14 ρ)

theorem p16 (ρ : Env) : Value.Refines (v15 ρ) (v19 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_19 ρ)) (Numeric.sound ρ n15 n19 rfl)

theorem p17 (ρ : Env) : Value.Refines (v8 ρ) (v19 ρ) :=
  (p15 ρ).trans (p16 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n8) (Expr.eval ρ n19) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_8 ρ) (eval_19 ρ)) (p17 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n8) : (Expr.eval ρ n8) = (Expr.eval ρ n19) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  (Value.defined_mul (v0 ρ) (v0 ρ)).mpr ⟨(total_0 ρ), (total_0 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v8 ρ) := (total_8 ρ)
def d8 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n8 ↔ (d8 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_8 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n8 := Eq.mpr (congrArg Value.Defined (eval_8 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_20 ρ)) (Value.refines_refl (v20 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v20 ρ) := (total_20 ρ)
def d20 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .real := (.real (4))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some ((4 : Int) : ℝ)
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
def n25 : Expr .real := (.mulR n1 n1)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v1 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v20 ρ) :=
  Domain.leaf _
theorem q25 (ρ : Env) : Domain.Correct (v25 ρ) (v20 ρ) :=
  Domain.strict2 (x := (v1 ρ)) (y := (v1 ρ)) (dx := (v20 ρ)) (dy := (v20 ρ)) (Value.defined_mul (v1 ρ) (v1 ρ)) (q1 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n25) (Expr.eval ρ Certificate.n20) :=
  Domain.simplify (q25 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n20) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n25 ↔ (Expr.eval ρ Certificate.n20) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .real := (.real (4))
def n25 : Expr .real := (.mulR n1 n1)
def b26 : Region (Expr .real) := .item n1 (.twice .one)
def n26 : Expr .real := Expr.productR b26
def n31 : Expr .real := (.real (16))
def n32 : Expr .natural := (.nat (16))
def n33 : Expr .integer := (.castNZ n32)
def n34 : Expr .rational := (.castZQ n33)
def n35 : Expr .real := (.castQR n34)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some ((4 : Int) : ℝ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v1 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v1 ρ) (v1 ρ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 2)) (v1 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .real) := (Option.map (fun (x : Ty.denote .real) => x ^ 1)) (v1 ρ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v28 ρ) (v28 ρ)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .real) := Value.mul (v28 ρ) (v28 ρ)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .real) := some ((16 : Int) : ℝ)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := some (16)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v32 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v33 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v34 ρ)
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl
theorem eval_35 (ρ : Env) : (Expr.eval ρ n35) = (v35 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v25 ρ) (v26 ρ) :=
  Value.refines_refl (v25 ρ)

theorem p1 (ρ : Env) : Value.Refines (v26 ρ) (v27 ρ) :=
  Value.refines_repeat_mul (.twice .one) 2 (Positive.toNat_twice .one 1 Positive.toNat_one) (x := (v1 ρ)) (y := (v1 ρ)) (Value.refines_refl (v1 ρ))

theorem p2 (ρ : Env) : Value.Refines (v27 ρ) (v30 ρ) :=
  (Generated.r_real_pow_split (v1 ρ) 1 1)

theorem p3 (ρ : Env) : Value.Refines (v30 ρ) (v29 ρ) :=
  Value.refines_refl (v30 ρ)

theorem p4 (ρ : Env) : Value.Refines (v27 ρ) (v29 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v28 ρ) (v1 ρ) :=
  (Generated.r_real_pow_one (v1 ρ))

theorem p6 (ρ : Env) : Value.Refines (v29 ρ) (v30 ρ) :=
  Value.refines_refl (v29 ρ)

theorem p7 (ρ : Env) : Value.Refines (v30 ρ) (v25 ρ) :=
  Value.refines_mul (p5 ρ) (p5 ρ)

theorem p8 (ρ : Env) : Value.Refines (v29 ρ) (v25 ρ) :=
  (p6 ρ).trans (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v25 ρ) (v26 ρ) :=
  Value.refines_refl (v25 ρ)

theorem p10 (ρ : Env) : Value.Refines (v29 ρ) (v26 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v27 ρ) (v26 ρ) :=
  (p4 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v26 ρ) (v31 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_26 ρ) (eval_31 ρ)) (Numeric.sound ρ n26 n31 rfl)

theorem p13 (ρ : Env) : Value.Refines (v27 ρ) (v31 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem p14 (ρ : Env) : Value.Refines (v26 ρ) (v31 ρ) :=
  (p1 ρ).trans (p13 ρ)

theorem p15 (ρ : Env) : Value.Refines (v25 ρ) (v31 ρ) :=
  (p0 ρ).trans (p14 ρ)

theorem p16 (ρ : Env) : Value.Refines (v31 ρ) (v35 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_31 ρ) (eval_35 ρ)) (Numeric.sound ρ n31 n35 rfl)

theorem p17 (ρ : Env) : Value.Refines (v25 ρ) (v35 ρ) :=
  (p15 ρ).trans (p16 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n35) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_35 ρ)) (p17 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n35) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  (Value.defined_mul (v1 ρ) (v1 ρ)).mpr ⟨(total_1 ρ), (total_1 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_20 ρ)) (Value.refines_refl (v20 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v20 ρ) := (total_20 ρ)
def d20 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n2 : Expr .real := (.real (0))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
def n32 : Expr .natural := (.nat (16))
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := some (16)
def n33 : Expr .integer := (.castNZ n32)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v32 ρ)
def n34 : Expr .rational := (.castZQ n33)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v33 ρ)
def n35 : Expr .real := (.castQR n34)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v34 ρ)
def n40 : Expr .real := (.addR n35 n2)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .real) := Value.add (v35 ρ) (v2 ρ)
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v20 ρ) :=
  Domain.leaf _
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v20 ρ) :=
  Domain.total1 Functions.castNZ (x := (v32 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q32 ρ)
theorem q34 (ρ : Env) : Domain.Correct (v34 ρ) (v20 ρ) :=
  Domain.total1 Functions.castZQ (x := (v33 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q33 ρ)
theorem q35 (ρ : Env) : Domain.Correct (v35 ρ) (v20 ρ) :=
  Domain.total1 Functions.castQR (x := (v34 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q34 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v20 ρ) :=
  Domain.leaf _
theorem q40 (ρ : Env) : Domain.Correct (v40 ρ) (v20 ρ) :=
  Domain.strict2 (x := (v35 ρ)) (y := (v2 ρ)) (dx := (v20 ρ)) (dy := (v20 ρ)) (Value.defined_add (v35 ρ) (v2 ρ)) (q35 ρ) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n40) (Expr.eval ρ Certificate.n20) :=
  Domain.simplify (q40 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n20) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n40 ↔ (Expr.eval ρ Certificate.n20) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .real := (.real (0))
def n31 : Expr .real := (.real (16))
def n32 : Expr .natural := (.nat (16))
def n33 : Expr .integer := (.castNZ n32)
def n34 : Expr .rational := (.castZQ n33)
def n35 : Expr .real := (.castQR n34)
def n36 : Expr .integer := (.int (16))
def n37 : Expr .rational := (.castZQ n36)
def n38 : Expr .rational := (.rat ((16) / (1) : ℚ))
def n39 : Expr .real := (.castQR n38)
def n40 : Expr .real := (.addR n35 n2)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .real) := some ((16 : Int) : ℝ)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := some (16)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v32 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v33 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v34 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .integer) := some (16)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v36 ρ)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .rational) := some ((16) / (1) : ℚ)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v38 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .real) := Value.add (v35 ρ) (v2 ρ)
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_35 (ρ : Env) : (Expr.eval ρ n35) = (v35 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v40 ρ) (v35 ρ) :=
  let ac2 : Replay.Tree := .unit
  let ac35 : Replay.Tree := (.leaf 0)
  let ac40 : Replay.Tree := (.node ac35 ac2)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addR (fun i => ([(v35 ρ)] : List (Option (Ty.denote .real))).getD i none) ac40 ac35 rfl)

theorem p1 (ρ : Env) : Value.Refines (v33 ρ) (v36 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_33 ρ) (eval_36 ρ)) (Numeric.sound ρ n33 n36 rfl)

theorem p2 (ρ : Env) : Value.Refines (v34 ρ) (v37 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v37 ρ) (v38 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_37 ρ) (eval_38 ρ)) (Numeric.sound ρ n37 n38 rfl)

theorem p4 (ρ : Env) : Value.Refines (v34 ρ) (v38 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v35 ρ) (v39 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v39 ρ) (v31 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_39 ρ) (eval_31 ρ)) (Numeric.sound ρ n39 n31 rfl)

theorem p7 (ρ : Env) : Value.Refines (v35 ρ) (v31 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v40 ρ) (v31 ρ) :=
  (p0 ρ).trans (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v31 ρ) (v35 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_31 ρ) (eval_35 ρ)) (Numeric.sound ρ n31 n35 rfl)

theorem p10 (ρ : Env) : Value.Refines (v40 ρ) (v35 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n40) (Expr.eval ρ n35) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_40 ρ) (eval_35 ρ)) (p10 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n40) : (Expr.eval ρ n40) = (Expr.eval ρ n35) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d32 (ρ : Env) : Prop := True
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d33 (ρ : Env) : Prop := ∃ x, (v32 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  Functions.castNZ.defined (v32 ρ)

def d34 (ρ : Env) : Prop := ∃ x, (v33 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_34 (ρ : Env) : Value.Defined (v34 ρ) ↔ d34 ρ :=
  Functions.castZQ.defined (v33 ρ)

def d35 (ρ : Env) : Prop := ∃ x, (v34 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_35 (ρ : Env) : Value.Defined (v35 ρ) ↔ d35 ρ :=
  Functions.castQR.defined (v34 ρ)

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d40 (ρ : Env) : Prop := (d35 ρ) ∧ (d2 ρ)
theorem domain_40 (ρ : Env) : Value.Defined (v40 ρ) ↔ d40 ρ :=
  (Value.defined_add (v35 ρ) (v2 ρ)).trans (and_congr (domain_35 ρ) (domain_2 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n40 ↔ (d40 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_40 ρ))).trans (domain_40 ρ)
#qsym_check_axioms definedness
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  ⟨_, rfl⟩
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v32 ρ) (total_32 ρ)
theorem total_34 (ρ : Env) : Value.Defined (v34 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v33 ρ) (total_33 ρ)
theorem total_35 (ρ : Env) : Value.Defined (v35 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v34 ρ) (total_34 ρ)
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_40 (ρ : Env) : Value.Defined (v40 ρ) :=
  (Value.defined_add (v35 ρ) (v2 ρ)).mpr ⟨(total_35 ρ), (total_2 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n40 := Eq.mpr (congrArg Value.Defined (eval_40 ρ)) (total_40 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_20 ρ)) (Value.refines_refl (v20 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v20 ρ) := (total_20 ρ)
def d20 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n16 : Expr .natural := (.nat (9))
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := some (9)
def n17 : Expr .integer := (.castNZ n16)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v16 ρ)
def n18 : Expr .rational := (.castZQ n17)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v17 ρ)
def n19 : Expr .real := (.castQR n18)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v18 ρ)
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
def n32 : Expr .natural := (.nat (16))
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := some (16)
def n33 : Expr .integer := (.castNZ n32)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v32 ρ)
def n34 : Expr .rational := (.castZQ n33)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v33 ρ)
def n35 : Expr .real := (.castQR n34)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v34 ρ)
def n41 : Expr .real := (.addR n19 n35)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .real) := Value.add (v19 ρ) (v35 ρ)
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v20 ρ) :=
  Domain.leaf _
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v20 ρ) :=
  Domain.total1 Functions.castNZ (x := (v16 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q16 ρ)
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v20 ρ) :=
  Domain.total1 Functions.castZQ (x := (v17 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q17 ρ)
theorem q19 (ρ : Env) : Domain.Correct (v19 ρ) (v20 ρ) :=
  Domain.total1 Functions.castQR (x := (v18 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q18 ρ)
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v20 ρ) :=
  Domain.leaf _
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v20 ρ) :=
  Domain.total1 Functions.castNZ (x := (v32 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q32 ρ)
theorem q34 (ρ : Env) : Domain.Correct (v34 ρ) (v20 ρ) :=
  Domain.total1 Functions.castZQ (x := (v33 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q33 ρ)
theorem q35 (ρ : Env) : Domain.Correct (v35 ρ) (v20 ρ) :=
  Domain.total1 Functions.castQR (x := (v34 ρ)) (d := (v20 ρ)) (fun _ => True.intro) (q34 ρ)
theorem q41 (ρ : Env) : Domain.Correct (v41 ρ) (v20 ρ) :=
  Domain.strict2 (x := (v19 ρ)) (y := (v35 ρ)) (dx := (v20 ρ)) (dy := (v20 ρ)) (Value.defined_add (v19 ρ) (v35 ρ)) (q19 ρ) (q35 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n41) (Expr.eval ρ Certificate.n20) :=
  Domain.simplify (q41 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n20) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n41 ↔ (Expr.eval ρ Certificate.n20) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .real := (.real (9))
def n16 : Expr .natural := (.nat (9))
def n17 : Expr .integer := (.castNZ n16)
def n18 : Expr .rational := (.castZQ n17)
def n19 : Expr .real := (.castQR n18)
def n21 : Expr .integer := (.int (9))
def n22 : Expr .rational := (.castZQ n21)
def n23 : Expr .rational := (.rat ((9) / (1) : ℚ))
def n24 : Expr .real := (.castQR n23)
def n31 : Expr .real := (.real (16))
def n32 : Expr .natural := (.nat (16))
def n33 : Expr .integer := (.castNZ n32)
def n34 : Expr .rational := (.castZQ n33)
def n35 : Expr .real := (.castQR n34)
def n36 : Expr .integer := (.int (16))
def n37 : Expr .rational := (.castZQ n36)
def n38 : Expr .rational := (.rat ((16) / (1) : ℚ))
def n39 : Expr .real := (.castQR n38)
def n41 : Expr .real := (.addR n19 n35)
def b44 : Region (Expr .real) := .join (.item n15 .one) (.item n31 .one)
def n44 : Expr .real := Expr.sumR b44
def n45 : Expr .real := (.real (25))
def n46 : Expr .natural := (.nat (25))
def n47 : Expr .integer := (.castNZ n46)
def n48 : Expr .rational := (.castZQ n47)
def n49 : Expr .real := (.castQR n48)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := some ((9 : Int) : ℝ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := some (9)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v16 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v17 ρ)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v18 ρ)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .integer) := some (9)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v21 ρ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .rational) := some ((9) / (1) : ℚ)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v23 ρ)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .real) := some ((16 : Int) : ℝ)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := some (16)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v32 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v33 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v34 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .integer) := some (16)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v36 ρ)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .rational) := some ((16) / (1) : ℚ)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v38 ρ)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .real) := Value.add (v19 ρ) (v35 ρ)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .real) := Value.add (v19 ρ) (v35 ρ)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .real) := Value.add (v15 ρ) (v31 ρ)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .real) := Value.add (v15 ρ) (v31 ρ)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .real) := some ((25 : Int) : ℝ)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (25)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v46 ρ)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v47 ρ)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v48 ρ)
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl
theorem eval_41 (ρ : Env) : (Expr.eval ρ n41) = (v41 ρ) := rfl
theorem eval_44 (ρ : Env) : (Expr.eval ρ n44) = (v44 ρ) := rfl
theorem eval_45 (ρ : Env) : (Expr.eval ρ n45) = (v45 ρ) := rfl
theorem eval_46 (ρ : Env) : (Expr.eval ρ n46) = (v46 ρ) := rfl
theorem eval_49 (ρ : Env) : (Expr.eval ρ n49) = (v49 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v41 ρ) (v42 ρ) :=
  Value.refines_refl (v41 ρ)

theorem p1 (ρ : Env) : Value.Refines (v17 ρ) (v21 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_21 ρ)) (Numeric.sound ρ n17 n21 rfl)

theorem p2 (ρ : Env) : Value.Refines (v18 ρ) (v22 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v22 ρ) (v23 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_23 ρ)) (Numeric.sound ρ n22 n23 rfl)

theorem p4 (ρ : Env) : Value.Refines (v18 ρ) (v23 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v19 ρ) (v24 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v24 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_24 ρ) (eval_15 ρ)) (Numeric.sound ρ n24 n15 rfl)

theorem p7 (ρ : Env) : Value.Refines (v19 ρ) (v15 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v33 ρ) (v36 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_33 ρ) (eval_36 ρ)) (Numeric.sound ρ n33 n36 rfl)

theorem p9 (ρ : Env) : Value.Refines (v34 ρ) (v37 ρ) :=
  Value.refines_function1 Functions.castZQ (p8 ρ)

theorem p10 (ρ : Env) : Value.Refines (v37 ρ) (v38 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_37 ρ) (eval_38 ρ)) (Numeric.sound ρ n37 n38 rfl)

theorem p11 (ρ : Env) : Value.Refines (v34 ρ) (v38 ρ) :=
  (p9 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v35 ρ) (v39 ρ) :=
  Value.refines_function1 Functions.castQR (p11 ρ)

theorem p13 (ρ : Env) : Value.Refines (v39 ρ) (v31 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_39 ρ) (eval_31 ρ)) (Numeric.sound ρ n39 n31 rfl)

theorem p14 (ρ : Env) : Value.Refines (v35 ρ) (v31 ρ) :=
  (p12 ρ).trans (p13 ρ)

theorem p15 (ρ : Env) : Value.Refines (v42 ρ) (v41 ρ) :=
  Value.refines_refl (v42 ρ)

theorem p16 (ρ : Env) : Value.Refines (v41 ρ) (v43 ρ) :=
  Value.refines_add (p7 ρ) (p14 ρ)

theorem p17 (ρ : Env) : Value.Refines (v42 ρ) (v43 ρ) :=
  (p15 ρ).trans (p16 ρ)

theorem p18 (ρ : Env) : Value.Refines (v43 ρ) (v44 ρ) :=
  Value.refines_refl (v43 ρ)

theorem p19 (ρ : Env) : Value.Refines (v42 ρ) (v44 ρ) :=
  (p17 ρ).trans (p18 ρ)

theorem p20 (ρ : Env) : Value.Refines (v44 ρ) (v45 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_44 ρ) (eval_45 ρ)) (Numeric.sound ρ n44 n45 rfl)

theorem p21 (ρ : Env) : Value.Refines (v42 ρ) (v45 ρ) :=
  (p19 ρ).trans (p20 ρ)

theorem p22 (ρ : Env) : Value.Refines (v41 ρ) (v45 ρ) :=
  (p0 ρ).trans (p21 ρ)

theorem p23 (ρ : Env) : Value.Refines (v45 ρ) (v49 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_45 ρ) (eval_49 ρ)) (Numeric.sound ρ n45 n49 rfl)

theorem p24 (ρ : Env) : Value.Refines (v41 ρ) (v49 ρ) :=
  (p22 ρ).trans (p23 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n41) (Expr.eval ρ n49) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_41 ρ) (eval_49 ρ)) (p24 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n41) : (Expr.eval ρ n41) = (Expr.eval ρ n49) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d16 (ρ : Env) : Prop := True
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d17 (ρ : Env) : Prop := ∃ x, (v16 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  Functions.castNZ.defined (v16 ρ)

def d18 (ρ : Env) : Prop := ∃ x, (v17 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  Functions.castZQ.defined (v17 ρ)

def d19 (ρ : Env) : Prop := ∃ x, (v18 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_19 (ρ : Env) : Value.Defined (v19 ρ) ↔ d19 ρ :=
  Functions.castQR.defined (v18 ρ)

def d32 (ρ : Env) : Prop := True
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d33 (ρ : Env) : Prop := ∃ x, (v32 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  Functions.castNZ.defined (v32 ρ)

def d34 (ρ : Env) : Prop := ∃ x, (v33 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_34 (ρ : Env) : Value.Defined (v34 ρ) ↔ d34 ρ :=
  Functions.castZQ.defined (v33 ρ)

def d35 (ρ : Env) : Prop := ∃ x, (v34 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_35 (ρ : Env) : Value.Defined (v35 ρ) ↔ d35 ρ :=
  Functions.castQR.defined (v34 ρ)

def d41 (ρ : Env) : Prop := (d19 ρ) ∧ (d35 ρ)
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  (Value.defined_add (v19 ρ) (v35 ρ)).trans (and_congr (domain_19 ρ) (domain_35 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n41 ↔ (d41 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_41 ρ))).trans (domain_41 ρ)
#qsym_check_axioms definedness
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v16 ρ) (total_16 ρ)
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v17 ρ) (total_17 ρ)
theorem total_19 (ρ : Env) : Value.Defined (v19 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v18 ρ) (total_18 ρ)
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  ⟨_, rfl⟩
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v32 ρ) (total_32 ρ)
theorem total_34 (ρ : Env) : Value.Defined (v34 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v33 ρ) (total_33 ρ)
theorem total_35 (ρ : Env) : Value.Defined (v35 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v34 ρ) (total_34 ρ)
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  (Value.defined_add (v19 ρ) (v35 ρ)).mpr ⟨(total_19 ρ), (total_35 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n41 := Eq.mpr (congrArg Value.Defined (eval_41 ρ)) (total_41 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_20 ρ)) (Value.refines_refl (v20 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v20 ρ) := (total_20 ρ)
def d20 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n0 : Expr .real := (.real (3))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some ((3 : Int) : ℝ)
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v20 ρ) :=
  Domain.leaf _
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n0) (Expr.eval ρ Certificate.n20) :=
  Domain.simplify (q0 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n20) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n0 ↔ (Expr.eval ρ Certificate.n20) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_20 ρ)) (Value.refines_refl (v20 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v20 ρ) := (total_20 ρ)
def d20 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n1 : Expr .real := (.real (4))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .real) := some ((4 : Int) : ℝ)
def n20 : Expr .bool := (.bool true)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v20 ρ) :=
  Domain.leaf _
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n1) (Expr.eval ρ Certificate.n20) :=
  Domain.simplify (q1 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n20) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n1 ↔ (Expr.eval ρ Certificate.n20) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
namespace QSym.BindingCertificate
def n0 : Expr .real := (.real (3))
def n1 : Expr .real := (.real (4))
def n2 : Expr .real := (.real (0))
def n8 : Expr .real := (.mulR n0 n0)
def n16 : Expr .natural := (.nat (9))
def n17 : Expr .integer := (.castNZ n16)
def n18 : Expr .rational := (.castZQ n17)
def n19 : Expr .real := (.castQR n18)
def n20 : Expr .bool := (.bool true)
def n25 : Expr .real := (.mulR n1 n1)
def n32 : Expr .natural := (.nat (16))
def n33 : Expr .integer := (.castNZ n32)
def n34 : Expr .rational := (.castZQ n33)
def n35 : Expr .real := (.castQR n34)
def n40 : Expr .real := (.addR n35 n2)
def n41 : Expr .real := (.addR n19 n35)
def n46 : Expr .natural := (.nat (25))
def n47 : Expr .integer := (.castNZ n46)
def n48 : Expr .rational := (.castZQ n47)
def n49 : Expr .real := (.castQR n48)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.vector (.scalar .real) 2) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c1 (.vector (.scalar .real) 2) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c1 (.scalar .real) := .binary (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (t0 γ) (t0 γ)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.vector (.scalar .real) 2) (.scalar .real)) := .lam (t1 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n0
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n1
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 0) := .constant Tensor.nilValue
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 1) := .binary Tensor.consValue (t4 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary Tensor.consValue (t3 γ) (t6 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .app (t2 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (t7 γ) (t7 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .seq (t7 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n2
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.mul (t4 γ) (t4 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t12 γ) (t11 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.mul (t3 γ) (t3 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t14 γ) (t13 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n8
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n20
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n19
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t17 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n25
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n35
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t17 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t21 γ) (t11 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n40
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Value.add (t18 γ) (t21 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n41
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n49
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t17 γ) (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .seq (t7 γ) (t27 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t7 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary Binding.guardValue (t30 γ) (t27 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t3 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t6 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Value.and (t32 γ) (t33 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t4 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t5 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Value.and (t35 γ) (t36 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Value.and (t17 γ) (t17 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .binary (a := (.vector (.scalar .real) 2)) (b := (.vector (.scalar .real) 2)) (c := (.scalar .real)) (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (p0 γ) (p0 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .lam (p1 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .refl (t4 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 1)) Tensor.consValue (p4 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 1)) (c := (.vector (.scalar .real) 2)) Tensor.consValue (p3 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .app (p2 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t10 γ) := .beta (t1 γ) (t7 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .binary (a := (.vector (.scalar .real) 2)) (b := (.vector (.scalar .real) 2)) (c := (.scalar .real)) (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (p7 γ) (p7 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t15 γ) := .ofEq (fun ξ ρ => rfl)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.mul (p3 γ) (p3 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t16 γ) := .ofEq (fun _ _ => rfl)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t19 γ) := .scalarSimplify n8 n20 n19 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .refl (t18 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p16 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t18 γ) := .guardTrue (t18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t18 γ) := .trans (p19 γ) (p17 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t18 γ) := .trans (p18 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t18 γ) := .trans (p15 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t18 γ) := .trans (p14 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t18 γ) := .trans (p13 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t18 γ) := .trans (p12 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.mul (p4 γ) (p4 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t20 γ) := .ofEq (fun _ _ => rfl)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t22 γ) := .scalarSimplify n25 n20 n35 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p16 γ) (p30 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .guardTrue (t21 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .trans (p32 γ) (p30 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .trans (p31 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t21 γ) := .trans (p29 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t21 γ) := .trans (p28 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t21 γ) := .trans (p27 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t21 γ) := .trans (p26 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t23 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.add (p38 γ) (p39 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t24 γ) := .ofEq (fun _ _ => rfl)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t22 γ) := .scalarSimplify n40 n20 n35 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t21 γ) := .trans (p43 γ) (p34 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t21 γ) := .trans (p42 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t21 γ) := .trans (p41 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t21 γ) := .trans (p40 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t25 γ) := .binary (a := (.scalar .real)) (b := (.scalar .real)) (c := (.scalar .real)) Value.add (p25 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t26 γ) := .ofEq (fun _ _ => rfl)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t28 γ) := .scalarSimplify n41 n20 n49 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .refl (t27 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p16 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .guardTrue (t27 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p54 γ) (p52 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p53 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t27 γ) := .trans (p51 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t27 γ) := .trans (p50 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t27 γ) := .trans (p49 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t27 γ) := .trans (p48 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t27 γ) := .trans (p11 γ) (p60 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t27 γ) := .trans (p10 γ) (p61 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t29 γ) := .seq (p7 γ) (p62 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t31 γ) := .seqGuard (t7 γ) (t27 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .unary (a := (.vector (.scalar .real) 2)) (b := (.scalar .bool)) Binding.definedValue (p7 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t34 γ) := .ofEq (fun ξ ρ => Tensor.defined_cons ((t3 γ).eval ξ ρ) ((t6 γ).eval ξ ρ))
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .unary (a := (.scalar .real)) (b := (.scalar .bool)) Binding.definedValue (p3 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t17 γ) := .scalarDomain n0 n20 QSym.BindingScalar4.DomainCertificate.domain_correct
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t17 γ) := .trans (p68 γ) (p16 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t17 γ) := .trans (p67 γ) (p69 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .unary (a := (.vector (.scalar .real) 1)) (b := (.scalar .bool)) Binding.definedValue (p6 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t37 γ) := .ofEq (fun ξ ρ => Tensor.defined_cons ((t4 γ).eval ξ ρ) ((t5 γ).eval ξ ρ))
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .unary (a := (.scalar .real)) (b := (.scalar .bool)) Binding.definedValue (p4 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t17 γ) := .scalarDomain n1 n20 QSym.BindingScalar5.DomainCertificate.domain_correct
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t17 γ) := .trans (p74 γ) (p16 γ)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t17 γ) := .trans (p73 γ) (p75 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .unary (a := (.vector (.scalar .real) 0)) (b := (.scalar .bool)) Binding.definedValue (p5 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t17 γ) := .ofEq (fun ξ ρ => rfl)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t17 γ) := .trans (p78 γ) (p16 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t17 γ) := .trans (p77 γ) (p79 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t38 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p76 γ) (p80 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t17 γ) := .ofEq (fun _ _ => rfl)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t17 γ) := .trans (p82 γ) (p16 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t17 γ) := .trans (p81 γ) (p83 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t17 γ) := .trans (p72 γ) (p84 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t17 γ) := .trans (p71 γ) (p85 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t38 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p70 γ) (p86 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t17 γ) := .ofEq (fun _ _ => rfl)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t17 γ) := .trans (p88 γ) (p16 γ)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t17 γ) := .trans (p87 γ) (p89 γ)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t17 γ) := .trans (p66 γ) (p90 γ)
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t17 γ) := .trans (p65 γ) (p91 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t28 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .real)) (c := (.scalar .real)) Binding.guardValue (p92 γ) (p52 γ)
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .guardTrue (t27 γ)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p94 γ) (p52 γ)
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t27 γ) := .trans (p93 γ) (p95 γ)
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t27 γ) := .trans (p64 γ) (p96 γ)
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t27 γ) := .trans (p63 γ) (p97 γ)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t27 γ) := .trans (p9 γ) (p98 γ)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t27 γ) := .trans (p8 γ) (p99 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t27 γ) := (p100 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t8 γ).eval ξ ρ = (t27 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t8 γ).eval ξ ρ) ↔ Value.Defined ((t27 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t8 γ).eval ξ ρ = n49.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n46 : Expr .natural := (.nat (25))
def n47 : Expr .integer := (.castNZ n46)
def n48 : Expr .rational := (.castZQ n47)
def n49 : Expr .real := (.castQR n48)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (25)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v46 ρ)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v47 ρ)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v48 ρ)
theorem eval_46 (ρ : Env) : (Expr.eval ρ n46) = (v46 ρ) := rfl
theorem eval_49 (ρ : Env) : (Expr.eval ρ n49) = (v49 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n49) (Expr.eval ρ n49) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_49 ρ) (eval_49 ρ)) (Value.refines_refl (v49 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n49) : (Expr.eval ρ n49) = (Expr.eval ρ n49) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d46 (ρ : Env) : Prop := True
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d47 (ρ : Env) : Prop := ∃ x, (v46 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_47 (ρ : Env) : Value.Defined (v47 ρ) ↔ d47 ρ :=
  Functions.castNZ.defined (v46 ρ)

def d48 (ρ : Env) : Prop := ∃ x, (v47 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_48 (ρ : Env) : Value.Defined (v48 ρ) ↔ d48 ρ :=
  Functions.castZQ.defined (v47 ρ)

def d49 (ρ : Env) : Prop := ∃ x, (v48 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_49 (ρ : Env) : Value.Defined (v49 ρ) ↔ d49 ρ :=
  Functions.castQR.defined (v48 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n49 ↔ (d49 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_49 ρ))).trans (domain_49 ρ)
#qsym_check_axioms definedness
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  ⟨_, rfl⟩
theorem total_47 (ρ : Env) : Value.Defined (v47 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v46 ρ) (total_46 ρ)
theorem total_48 (ρ : Env) : Value.Defined (v48 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v47 ρ) (total_47 ρ)
theorem total_49 (ρ : Env) : Value.Defined (v49 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v48 ρ) (total_48 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n49 := Eq.mpr (congrArg Value.Defined (eval_49 ρ)) (total_49 ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t8 γ).eval ξ ρ) (FunctionScalar.n49.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n49.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t8 γ).eval ξ ρ)) : ((BindingCertificate.t8 γ).eval ξ ρ) = (FunctionScalar.n49.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
