import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n11 : Expr .natural := (.mulN n0 n0)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v0 ρ)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n11) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q11 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n11 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n11 : Expr .natural := (.mulN n0 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v0 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v11 ρ) (v0 ρ) :=
  (Generated.r_natural_mul_one (v0 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n11) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_11 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n11) : (Expr.eval ρ n11) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d11 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  Functions.mulN.defined (v0 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n11 ↔ (d11 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_11 ρ))).trans (domain_11 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v0 ρ) (total_0 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n11 := Eq.mpr (congrArg Value.Defined (eval_11 ρ)) (total_11 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n13 : Expr .natural := (.mulN n0 n1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v1 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q0 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n13) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q13 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n13 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n13 : Expr .natural := (.mulN n0 n1)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v13 ρ) (v1 ρ) :=
  (Generated.r_natural_one_mul (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.mulN.defined (v0 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (domain_13 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v1 ρ) (total_0 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_13 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n10 : Expr .natural := (.addN n1 n1)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v1 ρ)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v1 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q1 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n10) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q10 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n10 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n10 : Expr .natural := (.addN n1 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v10 ρ) (v1 ρ) :=
  (Generated.r_natural_add_zero (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n10) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_10 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n10) : (Expr.eval ρ n10) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d10 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.addN.defined (v1 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n10 ↔ (d10 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_10 ρ))).trans (domain_10 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v1 ρ) (v1 ρ) (total_1 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n10 := Eq.mpr (congrArg Value.Defined (eval_10 ρ)) (total_10 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n14 : Expr .natural := (.addN n0 n1)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v1 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v0 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q0 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n14 : Expr .natural := (.addN n0 n1)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v1 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v0 ρ) :=
  (Generated.r_natural_add_zero (v0 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d14 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.addN.defined (v0 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (domain_14 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v0 ρ) (v1 ρ) (total_0 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_14 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n15 : Expr .natural := (.addN n1 n0)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v0 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v1 ρ)) (y := (v0 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q1 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n15) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q15 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n15 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n15 : Expr .natural := (.addN n1 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v0 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v15 ρ) (v0 ρ) :=
  (Generated.r_natural_zero_add (v0 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d15 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  Functions.addN.defined (v1 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (domain_15 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v1 ρ) (v0 ρ) (total_1 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_15 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n8 : Expr .natural := (.mulN n1 n1)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v1 ρ)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q1 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n8) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q8 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n8 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n8 : Expr .natural := (.mulN n1 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_8 (ρ : Env) : (Expr.eval ρ n8) = (v8 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v8 ρ) (v1 ρ) :=
  (Generated.r_natural_mul_zero (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n8) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_8 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n8) : (Expr.eval ρ n8) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.mulN.defined (v1 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n8 ↔ (d8 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_8 ρ))).trans (domain_8 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v1 ρ) (total_1 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n8 := Eq.mpr (congrArg Value.Defined (eval_8 ρ)) (total_8 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n16 : Expr .natural := (.mulN n1 n0)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v0 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v0 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q1 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n16) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q16 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n16 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n16 : Expr .natural := (.mulN n1 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v0 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v16 ρ) (v1 ρ) :=
  (Generated.r_natural_mul_one (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d16 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  Functions.mulN.defined (v1 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (domain_16 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v0 ρ) (total_1 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_16 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n17 : Expr .natural := (.addN n0 n0)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v0 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n17) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q17 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n17 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n5 : Expr .natural := (.nat (2))
def n17 : Expr .natural := (.addN n0 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v0 ρ)
theorem eval_5 (ρ : Env) : (Expr.eval ρ n5) = (v5 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v17 ρ) (v5 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_5 ρ)) (Numeric.sound ρ n17 n5 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n5) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_5 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n5) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d17 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  Functions.addN.defined (v0 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (domain_17 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v0 ρ) (v0 ρ) (total_0 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_17 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.Certificate

namespace QSym.BindingScalar8.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n5 : Expr .natural := (.nat (2))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n18 : Expr .natural := (.mulN n0 n5)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v5 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v5 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q0 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n18) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q18 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n18 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar8.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n5 : Expr .natural := (.nat (2))
def n18 : Expr .natural := (.mulN n0 n5)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v5 ρ)
theorem eval_5 (ρ : Env) : (Expr.eval ρ n5) = (v5 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v18 ρ) (v5 ρ) :=
  (Generated.r_natural_one_mul (v5 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n18) (Expr.eval ρ n5) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_18 ρ) (eval_5 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n18) : (Expr.eval ρ n18) = (Expr.eval ρ n5) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d18 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  Functions.mulN.defined (v0 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n18 ↔ (d18 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_18 ρ))).trans (domain_18 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v5 ρ) (total_0 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n18 := Eq.mpr (congrArg Value.Defined (eval_18 ρ)) (total_18 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.Certificate

namespace QSym.BindingScalar9.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n5 : Expr .natural := (.nat (2))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n19 : Expr .natural := (.addN n5 n0)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v5 ρ) (v0 ρ)
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q19 (ρ : Env) : Domain.Correct (v19 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v5 ρ)) (y := (v0 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q5 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n19) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q19 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n19 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar9.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n4 : Expr .natural := (.nat (3))
def n5 : Expr .natural := (.nat (2))
def n19 : Expr .natural := (.addN n5 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v5 ρ) (v0 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v19 ρ) (v4 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_4 ρ)) (Numeric.sound ρ n19 n4 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n19) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_19 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n19) : (Expr.eval ρ n19) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d19 (ρ : Env) : Prop := ∃ x y, (v5 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_19 (ρ : Env) : Value.Defined (v19 ρ) ↔ d19 ρ :=
  Functions.addN.defined (v5 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n19 ↔ (d19 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_19 ρ))).trans (domain_19 ρ)
#qsym_check_axioms definedness
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_19 (ρ : Env) : Value.Defined (v19 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v5 ρ) (v0 ρ) (total_5 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n19 := Eq.mpr (congrArg Value.Defined (eval_19 ρ)) (total_19 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.Certificate

namespace QSym.BindingScalar10.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n5 : Expr .natural := (.nat (2))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .natural := (.addN n5 n1)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v5 ρ) (v1 ρ)
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v5 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q5 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n20) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q20 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n20 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar10.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n5 : Expr .natural := (.nat (2))
def n20 : Expr .natural := (.addN n5 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v5 ρ) (v1 ρ)
theorem eval_5 (ρ : Env) : (Expr.eval ρ n5) = (v5 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v20 ρ) (v5 ρ) :=
  (Generated.r_natural_add_zero (v5 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n5) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_5 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n5) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d20 (ρ : Env) : Prop := ∃ x y, (v5 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  Functions.addN.defined (v5 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (domain_20 ρ)
#qsym_check_axioms definedness
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v5 ρ) (v1 ρ) (total_5 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_20 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.Certificate

namespace QSym.BindingScalar11.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n4 : Expr .natural := (.nat (3))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n21 : Expr .natural := (.mulN n0 n4)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q21 (ρ : Env) : Domain.Correct (v21 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v4 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q0 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n21) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q21 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n21 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar11.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n4 : Expr .natural := (.nat (3))
def n21 : Expr .natural := (.mulN n0 n4)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v21 ρ) (v4 ρ) :=
  (Generated.r_natural_one_mul (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n21) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_21 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n21) : (Expr.eval ρ n21) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d21 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_21 (ρ : Env) : Value.Defined (v21 ρ) ↔ d21 ρ :=
  Functions.mulN.defined (v0 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n21 ↔ (d21 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_21 ρ))).trans (domain_21 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_21 (ρ : Env) : Value.Defined (v21 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v4 ρ) (total_0 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n21 := Eq.mpr (congrArg Value.Defined (eval_21 ρ)) (total_21 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar12.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar12.Certificate

namespace QSym.BindingScalar12.DomainCertificate
def n4 : Expr .natural := (.nat (3))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n5 : Expr .natural := (.nat (2))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n22 : Expr .natural := (.addN n4 n5)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v5 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v4 ρ)) (y := (v5 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q4 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n22) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q22 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n22 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar12.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar12.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (5))
def n4 : Expr .natural := (.nat (3))
def n5 : Expr .natural := (.nat (2))
def n22 : Expr .natural := (.addN n4 n5)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v5 ρ)
theorem eval_2 (ρ : Env) : (Expr.eval ρ n2) = (v2 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v22 ρ) (v2 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_2 ρ)) (Numeric.sound ρ n22 n2 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n22) (Expr.eval ρ n2) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_22 ρ) (eval_2 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n22) : (Expr.eval ρ n22) = (Expr.eval ρ n2) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d22 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  Functions.addN.defined (v4 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n22 ↔ (d22 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_22 ρ))).trans (domain_22 ρ)
#qsym_check_axioms definedness
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v4 ρ) (v5 ρ) (total_4 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n22 := Eq.mpr (congrArg Value.Defined (eval_22 ρ)) (total_22 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar12.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar13.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar13.Certificate

namespace QSym.BindingScalar13.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n5 : Expr .natural := (.nat (2))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .natural := (.mulN n1 n5)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v5 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v5 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q1 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n23) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q23 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n23 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar13.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar13.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n5 : Expr .natural := (.nat (2))
def n23 : Expr .natural := (.mulN n1 n5)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v5 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v23 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v5 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n23) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_23 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n23) : (Expr.eval ρ n23) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d23 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  Functions.mulN.defined (v1 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n23 ↔ (d23 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_23 ρ))).trans (domain_23 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v5 ρ) (total_1 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n23 := Eq.mpr (congrArg Value.Defined (eval_23 ρ)) (total_23 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar13.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar14.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar14.Certificate

namespace QSym.BindingScalar14.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n4 : Expr .natural := (.nat (3))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n24 : Expr .natural := (.addN n4 n1)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v1 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v4 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q4 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n24) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q24 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n24 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar14.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar14.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n4 : Expr .natural := (.nat (3))
def n24 : Expr .natural := (.addN n4 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v1 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v24 ρ) (v4 ρ) :=
  (Generated.r_natural_add_zero (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n24) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_24 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n24) : (Expr.eval ρ n24) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d24 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_24 (ρ : Env) : Value.Defined (v24 ρ) ↔ d24 ρ :=
  Functions.addN.defined (v4 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n24 ↔ (d24 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_24 ρ))).trans (domain_24 ρ)
#qsym_check_axioms definedness
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v4 ρ) (v1 ρ) (total_4 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n24 := Eq.mpr (congrArg Value.Defined (eval_24 ρ)) (total_24 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar14.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar15.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar15.Certificate

namespace QSym.BindingScalar15.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n2 : Expr .natural := (.nat (5))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n25 : Expr .natural := (.mulN n0 n2)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v2 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q25 (ρ : Env) : Domain.Correct (v25 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v2 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q0 ρ) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n25) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q25 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n25 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar15.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar15.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n2 : Expr .natural := (.nat (5))
def n25 : Expr .natural := (.mulN n0 n2)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v2 ρ)
theorem eval_2 (ρ : Env) : (Expr.eval ρ n2) = (v2 ρ) := rfl
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v25 ρ) (v2 ρ) :=
  (Generated.r_natural_one_mul (v2 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n2) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_2 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n2) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d25 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v2 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_25 (ρ : Env) : Value.Defined (v25 ρ) ↔ d25 ρ :=
  Functions.mulN.defined (v0 ρ) (v2 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (domain_25 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v2 ρ) (total_0 ρ) (total_2 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_25 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar15.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar16.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar16.Certificate

namespace QSym.BindingScalar16.DomainCertificate
def n2 : Expr .natural := (.nat (5))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n4 : Expr .natural := (.nat (3))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n26 : Expr .natural := (.addN n2 n4)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v2 ρ) (v4 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q26 (ρ : Env) : Domain.Correct (v26 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v2 ρ)) (y := (v4 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q2 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n26) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q26 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n26 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar16.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar16.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (5))
def n4 : Expr .natural := (.nat (3))
def n26 : Expr .natural := (.addN n2 n4)
def n27 : Expr .natural := (.nat (8))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v2 ρ) (v4 ρ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := some (8)
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v26 ρ) (v27 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_26 ρ) (eval_27 ρ)) (Numeric.sound ρ n26 n27 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n26) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_26 ρ) (eval_27 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n26) : (Expr.eval ρ n26) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d26 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_26 (ρ : Env) : Value.Defined (v26 ρ) ↔ d26 ρ :=
  Functions.addN.defined (v2 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n26 ↔ (d26 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_26 ρ))).trans (domain_26 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v2 ρ) (v4 ρ) (total_2 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n26 := Eq.mpr (congrArg Value.Defined (eval_26 ρ)) (total_26 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar16.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar17.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar17.Certificate

namespace QSym.BindingScalar17.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n4 : Expr .natural := (.nat (3))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n28 : Expr .natural := (.mulN n1 n4)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v4 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q28 (ρ : Env) : Domain.Correct (v28 ρ) (v12 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v4 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q1 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n28) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q28 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n28 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar17.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar17.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n4 : Expr .natural := (.nat (3))
def n28 : Expr .natural := (.mulN n1 n4)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v4 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v28 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n28) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_28 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n28) : (Expr.eval ρ n28) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d28 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_28 (ρ : Env) : Value.Defined (v28 ρ) ↔ d28 ρ :=
  Functions.mulN.defined (v1 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n28 ↔ (d28 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_28 ρ))).trans (domain_28 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_28 (ρ : Env) : Value.Defined (v28 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v4 ρ) (total_1 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n28 := Eq.mpr (congrArg Value.Defined (eval_28 ρ)) (total_28 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar17.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar18.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n12) (Expr.eval ρ n12) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_12 ρ) (eval_12 ρ)) (Value.refines_refl (v12 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n12) : (Expr.eval ρ n12) = (Expr.eval ρ n12) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v12 ρ) := (total_12 ρ)
def d12 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n12 ↔ (d12 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_12 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n12 := Eq.mpr (congrArg Value.Defined (eval_12 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar18.Certificate

namespace QSym.BindingScalar18.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n2 : Expr .natural := (.nat (5))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n12 : Expr .bool := (.bool true)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .bool) := some true
def n29 : Expr .natural := (.addN n2 n1)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v2 ρ) (v1 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v12 ρ) :=
  Domain.leaf _
theorem q29 (ρ : Env) : Domain.Correct (v29 ρ) (v12 ρ) :=
  Domain.total2 Functions.addN (x := (v2 ρ)) (y := (v1 ρ)) (dx := (v12 ρ)) (dy := (v12 ρ)) (fun _ _ => True.intro) (q2 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n29) (Expr.eval ρ Certificate.n12) :=
  Domain.simplify (q29 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n12) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n29 ↔ (Expr.eval ρ Certificate.n12) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar18.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar18.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n2 : Expr .natural := (.nat (5))
def n29 : Expr .natural := (.addN n2 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v2 ρ) (v1 ρ)
theorem eval_2 (ρ : Env) : (Expr.eval ρ n2) = (v2 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v29 ρ) (v2 ρ) :=
  (Generated.r_natural_add_zero (v2 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n29) (Expr.eval ρ n2) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_29 ρ) (eval_2 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n29) : (Expr.eval ρ n29) = (Expr.eval ρ n2) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d29 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_29 (ρ : Env) : Value.Defined (v29 ρ) ↔ d29 ρ :=
  Functions.addN.defined (v2 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n29 ↔ (d29 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_29 ρ))).trans (domain_29 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_29 (ρ : Env) : Value.Defined (v29 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v2 ρ) (v1 ρ) (total_2 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n29 := Eq.mpr (congrArg Value.Defined (eval_29 ρ)) (total_29 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar18.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n2 : Expr .natural := (.nat (5))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (3))
def n5 : Expr .natural := (.nat (2))
def n8 : Expr .natural := (.mulN n1 n1)
def n10 : Expr .natural := (.addN n1 n1)
def n11 : Expr .natural := (.mulN n0 n0)
def n12 : Expr .bool := (.bool true)
def n13 : Expr .natural := (.mulN n0 n1)
def n14 : Expr .natural := (.addN n0 n1)
def n15 : Expr .natural := (.addN n1 n0)
def n16 : Expr .natural := (.mulN n1 n0)
def n17 : Expr .natural := (.addN n0 n0)
def n18 : Expr .natural := (.mulN n0 n5)
def n19 : Expr .natural := (.addN n5 n0)
def n20 : Expr .natural := (.addN n5 n1)
def n21 : Expr .natural := (.mulN n0 n4)
def n22 : Expr .natural := (.addN n4 n5)
def n23 : Expr .natural := (.mulN n1 n5)
def n24 : Expr .natural := (.addN n4 n1)
def n25 : Expr .natural := (.mulN n0 n2)
def n26 : Expr .natural := (.addN n2 n4)
def n27 : Expr .natural := (.nat (8))
def n28 : Expr .natural := (.mulN n1 n4)
def n29 : Expr .natural := (.addN n2 n1)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t0 γ) (t1 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t4 γ) (t1 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 0) := .constant Tensor.nilValue
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t6 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t3 γ) (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t15 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t16 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n5
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t0 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t4 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t23 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t4 γ) (t2 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t25 γ) (t7 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t6 γ) (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t4 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t29 γ) (t4 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t0 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t31 γ) (t30 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t31 γ) (t4 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t29 γ) (t33 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t34 γ) (t1 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t32 γ) (t35 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t4 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t37 γ) (t4 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t31 γ) (t38 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t0 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t40 γ) (t4 γ)
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t29 γ) (t41 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t42 γ) (t1 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t39 γ) (t43 γ)
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t44 γ) (t7 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t36 γ) (t45 γ)
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n11
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n12
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t48 γ) (t0 γ)
noncomputable def t50 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n13
noncomputable def t51 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t48 γ) (t4 γ)
noncomputable def t52 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t4 γ) (t4 γ)
noncomputable def t53 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n10
noncomputable def t54 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t4 γ)
noncomputable def t55 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n14
noncomputable def t56 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t4 γ) (t0 γ)
noncomputable def t57 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n15
noncomputable def t58 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n8
noncomputable def t59 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n16
noncomputable def t60 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t9 γ)
noncomputable def t61 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t31 γ) (t33 γ)
noncomputable def t62 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t32 γ) (t1 γ)
noncomputable def t63 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t61 γ) (t62 γ)
noncomputable def t64 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t31 γ) (t41 γ)
noncomputable def t65 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t39 γ) (t1 γ)
noncomputable def t66 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t64 γ) (t65 γ)
noncomputable def t67 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t66 γ) (t7 γ)
noncomputable def t68 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t63 γ) (t67 γ)
noncomputable def t69 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t0 γ)
noncomputable def t70 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n17
noncomputable def t71 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t48 γ) (t18 γ)
noncomputable def t72 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t18 γ) (t2 γ)
noncomputable def t73 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t3 γ) (t7 γ)
noncomputable def t74 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t72 γ) (t73 γ)
noncomputable def t75 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t74 γ)
noncomputable def t76 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t18 γ)
noncomputable def t77 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t76 γ) (t33 γ)
noncomputable def t78 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t61 γ) (t1 γ)
noncomputable def t79 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t77 γ) (t78 γ)
noncomputable def t80 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t76 γ) (t41 γ)
noncomputable def t81 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t64 γ) (t1 γ)
noncomputable def t82 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t80 γ) (t81 γ)
noncomputable def t83 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t82 γ) (t7 γ)
noncomputable def t84 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t79 γ) (t83 γ)
noncomputable def t85 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n18
noncomputable def t86 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t18 γ) (t0 γ)
noncomputable def t87 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n19
noncomputable def t88 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t48 γ) (t15 γ)
noncomputable def t89 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t18 γ) (t1 γ)
noncomputable def t90 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t15 γ) (t89 γ)
noncomputable def t91 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t18 γ) (t4 γ)
noncomputable def t92 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n20
noncomputable def t93 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t72 γ) (t7 γ)
noncomputable def t94 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t90 γ) (t93 γ)
noncomputable def t95 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t94 γ)
noncomputable def t96 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t76 γ) (t4 γ)
noncomputable def t97 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t15 γ)
noncomputable def t98 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t97 γ) (t96 γ)
noncomputable def t99 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t77 γ) (t1 γ)
noncomputable def t100 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t98 γ) (t99 γ)
noncomputable def t101 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t18 γ)
noncomputable def t102 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t101 γ) (t4 γ)
noncomputable def t103 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t97 γ) (t102 γ)
noncomputable def t104 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t80 γ) (t1 γ)
noncomputable def t105 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t103 γ) (t104 γ)
noncomputable def t106 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t105 γ) (t7 γ)
noncomputable def t107 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t100 γ) (t106 γ)
noncomputable def t108 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n21
noncomputable def t109 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t18 γ)
noncomputable def t110 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n22
noncomputable def t111 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t48 γ) (t10 γ)
noncomputable def t112 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t15 γ) (t1 γ)
noncomputable def t113 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t10 γ) (t112 γ)
noncomputable def t114 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n23
noncomputable def t115 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t4 γ)
noncomputable def t116 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n24
noncomputable def t117 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t90 γ) (t7 γ)
noncomputable def t118 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t113 γ) (t117 γ)
noncomputable def t119 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t118 γ)
noncomputable def t120 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t97 γ) (t4 γ)
noncomputable def t121 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t10 γ)
noncomputable def t122 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t121 γ) (t120 γ)
noncomputable def t123 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t98 γ) (t1 γ)
noncomputable def t124 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t122 γ) (t123 γ)
noncomputable def t125 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t15 γ)
noncomputable def t126 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t125 γ) (t4 γ)
noncomputable def t127 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t121 γ) (t126 γ)
noncomputable def t128 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t103 γ) (t1 γ)
noncomputable def t129 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t127 γ) (t128 γ)
noncomputable def t130 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t129 γ) (t7 γ)
noncomputable def t131 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t124 γ) (t130 γ)
noncomputable def t132 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n25
noncomputable def t133 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t10 γ) (t15 γ)
noncomputable def t134 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n26
noncomputable def t135 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n27
noncomputable def t136 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t48 γ) (t135 γ)
noncomputable def t137 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t10 γ) (t1 γ)
noncomputable def t138 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t135 γ) (t137 γ)
noncomputable def t139 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n28
noncomputable def t140 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t10 γ) (t4 γ)
noncomputable def t141 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n29
noncomputable def t142 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t113 γ) (t7 γ)
noncomputable def t143 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t138 γ) (t142 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p0 γ) (p1 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .refl (t4 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p4 γ) (p1 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p6 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p3 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .refl (t10 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t14 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 4)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p13 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t17 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 3)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .refl (t15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t20 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 2)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .refl (t18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t22 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 1)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p0 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t24 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 0)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p4 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t27 γ) := .ofEq (fun ξ ρ => rfl)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p4 γ) (p2 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p26 γ) (p7 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p6 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t27 γ) := .trans (p25 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t27 γ) := .trans (p24 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t28 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p30 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t46 γ) := .ofEq (fun ξ ρ => rfl)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p0 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t47 γ) := .ofEq (fun _ _ => rfl)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t47 γ) := .refl (t47 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t49 γ) := .scalarSimplify n11 n12 n0 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t48 γ) := .refl (t48 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t49 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p37 γ) (p0 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t0 γ) := .guardTrue (t0 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t0 γ) := .trans (p39 γ) (p0 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t0 γ) := .trans (p38 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t0 γ) := .trans (p36 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t0 γ) := .trans (p35 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t0 γ) := .trans (p34 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t0 γ) := .trans (p33 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p4 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t50 γ) := .ofEq (fun _ _ => rfl)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t50 γ) := .refl (t50 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t51 γ) := .scalarSimplify n13 n12 n1 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t51 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p37 γ) (p4 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t4 γ) := .guardTrue (t4 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t4 γ) := .trans (p51 γ) (p4 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t4 γ) := .trans (p50 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t4 γ) := .trans (p49 γ) (p53 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t4 γ) := .trans (p48 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t4 γ) := .trans (p47 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t4 γ) := .trans (p46 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p57 γ) (p4 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t53 γ) := .refl (t53 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t51 γ) := .scalarSimplify n10 n12 n1 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t4 γ) := .trans (p61 γ) (p53 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t4 γ) := .trans (p60 γ) (p62 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t4 γ) := .trans (p59 γ) (p63 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t4 γ) := .trans (p58 γ) (p64 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t54 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p45 γ) (p65 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .ofEq (fun _ _ => rfl)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t55 γ) := .refl (t55 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t49 γ) := .scalarSimplify n14 n12 n0 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t0 γ) := .trans (p69 γ) (p41 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t0 γ) := .trans (p68 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t0 γ) := .trans (p67 γ) (p71 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t0 γ) := .trans (p66 γ) (p72 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t54 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p45 γ) (p4 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .ofEq (fun _ _ => rfl)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t0 γ) := .trans (p75 γ) (p71 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t0 γ) := .trans (p74 γ) (p76 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t56 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p57 γ) (p77 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t57 γ) := .ofEq (fun _ _ => rfl)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t57 γ) := .refl (t57 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t49 γ) := .scalarSimplify n15 n12 n0 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t0 γ) := .trans (p81 γ) (p41 γ)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t0 γ) := .trans (p80 γ) (p82 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t0 γ) := .trans (p79 γ) (p83 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t0 γ) := .trans (p78 γ) (p84 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p85 γ) (p1 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p73 γ) (p86 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p4 γ)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t58 γ) := .ofEq (fun _ _ => rfl)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t58 γ) := .refl (t58 γ)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t51 γ) := .scalarSimplify n8 n12 n1 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t4 γ) := .trans (p91 γ) (p53 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t4 γ) := .trans (p90 γ) (p92 γ)
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t4 γ) := .trans (p89 γ) (p93 γ)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t4 γ) := .trans (p88 γ) (p94 γ)
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p95 γ) (p4 γ)
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t4 γ) := .trans (p97 γ) (p63 γ)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t4 γ) := .trans (p96 γ) (p98 γ)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t54 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p45 γ) (p99 γ)
theorem p101 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .ofEq (fun _ _ => rfl)
theorem p102 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t0 γ) := .trans (p101 γ) (p71 γ)
theorem p103 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t0 γ) := .trans (p100 γ) (p102 γ)
theorem p104 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p0 γ)
theorem p105 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t59 γ) := .ofEq (fun _ _ => rfl)
theorem p106 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t59 γ) := .refl (t59 γ)
theorem p107 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t51 γ) := .scalarSimplify n16 n12 n1 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p108 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t4 γ) := .trans (p107 γ) (p53 γ)
theorem p109 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t4 γ) := .trans (p106 γ) (p108 γ)
theorem p110 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t4 γ) := .trans (p105 γ) (p109 γ)
theorem p111 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t4 γ) := .trans (p104 γ) (p110 γ)
theorem p112 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p111 γ) (p4 γ)
theorem p113 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p114 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t4 γ) := .trans (p113 γ) (p63 γ)
theorem p115 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t4 γ) := .trans (p112 γ) (p114 γ)
theorem p116 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p57 γ) (p115 γ)
theorem p117 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p118 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t4 γ) := .trans (p117 γ) (p63 γ)
theorem p119 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t4 γ) := .trans (p116 γ) (p118 γ)
theorem p120 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t5 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p119 γ) (p1 γ)
theorem p121 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t6 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p103 γ) (p120 γ)
theorem p122 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t8 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p121 γ) (p7 γ)
theorem p123 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t9 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p87 γ) (p122 γ)
theorem p124 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t9 γ) := .trans (p32 γ) (p123 γ)
theorem p125 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t9 γ) := .trans (p31 γ) (p124 γ)
theorem p126 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t9 γ) := .trans (p23 γ) (p125 γ)
theorem p127 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t9 γ) := .trans (p22 γ) (p126 γ)
theorem p128 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t60 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p127 γ)
theorem p129 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t68 γ) := .ofEq (fun ξ ρ => rfl)
theorem p130 (γ : Binding.Globals) : Binding.Reduction (t61 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p45 γ) (p77 γ)
theorem p131 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p132 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t70 γ) := .refl (t70 γ)
theorem p133 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t71 γ) := .scalarSimplify n17 n12 n5 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p134 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t71 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p37 γ) (p19 γ)
theorem p135 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t18 γ) := .guardTrue (t18 γ)
theorem p136 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t18 γ) := .trans (p135 γ) (p19 γ)
theorem p137 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t18 γ) := .trans (p134 γ) (p136 γ)
theorem p138 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t18 γ) := .trans (p133 γ) (p137 γ)
theorem p139 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t18 γ) := .trans (p132 γ) (p138 γ)
theorem p140 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t18 γ) := .trans (p131 γ) (p139 γ)
theorem p141 (γ : Binding.Globals) : Binding.Reduction (t61 γ) (t18 γ) := .trans (p130 γ) (p140 γ)
theorem p142 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p73 γ) (p1 γ)
theorem p143 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t72 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p141 γ) (p142 γ)
theorem p144 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t54 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p45 γ) (p115 γ)
theorem p145 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .ofEq (fun _ _ => rfl)
theorem p146 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t0 γ) := .trans (p145 γ) (p71 γ)
theorem p147 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t0 γ) := .trans (p144 γ) (p146 γ)
theorem p148 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p103 γ) (p1 γ)
theorem p149 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p147 γ) (p148 γ)
theorem p150 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t73 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p149 γ) (p7 γ)
theorem p151 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t74 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p143 γ) (p150 γ)
theorem p152 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t74 γ) := .trans (p129 γ) (p151 γ)
theorem p153 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t74 γ) := .trans (p128 γ) (p152 γ)
theorem p154 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t74 γ) := .trans (p21 γ) (p153 γ)
theorem p155 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t74 γ) := .trans (p20 γ) (p154 γ)
theorem p156 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t75 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p155 γ)
theorem p157 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t84 γ) := .ofEq (fun ξ ρ => rfl)
theorem p158 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t76 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p19 γ)
theorem p159 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t85 γ) := .ofEq (fun _ _ => rfl)
theorem p160 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t85 γ) := .refl (t85 γ)
theorem p161 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t71 γ) := .scalarSimplify n18 n12 n5 QSym.BindingScalar8.DomainCertificate.domain_correct QSym.BindingScalar8.ValueCertificate.refinement
theorem p162 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t18 γ) := .trans (p161 γ) (p137 γ)
theorem p163 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t18 γ) := .trans (p160 γ) (p162 γ)
theorem p164 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t18 γ) := .trans (p159 γ) (p163 γ)
theorem p165 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t18 γ) := .trans (p158 γ) (p164 γ)
theorem p166 (γ : Binding.Globals) : Binding.Reduction (t77 γ) (t86 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p165 γ) (p77 γ)
theorem p167 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t87 γ) := .ofEq (fun _ _ => rfl)
theorem p168 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t87 γ) := .refl (t87 γ)
theorem p169 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t88 γ) := .scalarSimplify n19 n12 n4 QSym.BindingScalar9.DomainCertificate.domain_correct QSym.BindingScalar9.ValueCertificate.refinement
theorem p170 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t88 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p37 γ) (p16 γ)
theorem p171 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t15 γ) := .guardTrue (t15 γ)
theorem p172 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t15 γ) := .trans (p171 γ) (p16 γ)
theorem p173 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t15 γ) := .trans (p170 γ) (p172 γ)
theorem p174 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t15 γ) := .trans (p169 γ) (p173 γ)
theorem p175 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t15 γ) := .trans (p168 γ) (p174 γ)
theorem p176 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t15 γ) := .trans (p167 γ) (p175 γ)
theorem p177 (γ : Binding.Globals) : Binding.Reduction (t77 γ) (t15 γ) := .trans (p166 γ) (p176 γ)
theorem p178 (γ : Binding.Globals) : Binding.Reduction (t78 γ) (t89 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p141 γ) (p1 γ)
theorem p179 (γ : Binding.Globals) : Binding.Reduction (t79 γ) (t90 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p177 γ) (p178 γ)
theorem p180 (γ : Binding.Globals) : Binding.Reduction (t80 γ) (t91 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p165 γ) (p115 γ)
theorem p181 (γ : Binding.Globals) : Binding.Reduction (t91 γ) (t92 γ) := .ofEq (fun _ _ => rfl)
theorem p182 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t92 γ) := .refl (t92 γ)
theorem p183 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t71 γ) := .scalarSimplify n20 n12 n5 QSym.BindingScalar10.DomainCertificate.domain_correct QSym.BindingScalar10.ValueCertificate.refinement
theorem p184 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t18 γ) := .trans (p183 γ) (p137 γ)
theorem p185 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t18 γ) := .trans (p182 γ) (p184 γ)
theorem p186 (γ : Binding.Globals) : Binding.Reduction (t91 γ) (t18 γ) := .trans (p181 γ) (p185 γ)
theorem p187 (γ : Binding.Globals) : Binding.Reduction (t80 γ) (t18 γ) := .trans (p180 γ) (p186 γ)
theorem p188 (γ : Binding.Globals) : Binding.Reduction (t81 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p147 γ) (p1 γ)
theorem p189 (γ : Binding.Globals) : Binding.Reduction (t82 γ) (t72 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p187 γ) (p188 γ)
theorem p190 (γ : Binding.Globals) : Binding.Reduction (t83 γ) (t93 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p189 γ) (p7 γ)
theorem p191 (γ : Binding.Globals) : Binding.Reduction (t84 γ) (t94 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p179 γ) (p190 γ)
theorem p192 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t94 γ) := .trans (p157 γ) (p191 γ)
theorem p193 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t94 γ) := .trans (p156 γ) (p192 γ)
theorem p194 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t94 γ) := .trans (p18 γ) (p193 γ)
theorem p195 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t94 γ) := .trans (p17 γ) (p194 γ)
theorem p196 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t95 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p195 γ)
theorem p197 (γ : Binding.Globals) : Binding.Reduction (t95 γ) (t107 γ) := .ofEq (fun ξ ρ => rfl)
theorem p198 (γ : Binding.Globals) : Binding.Reduction (t97 γ) (t97 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p16 γ)
theorem p199 (γ : Binding.Globals) : Binding.Reduction (t97 γ) (t108 γ) := .ofEq (fun _ _ => rfl)
theorem p200 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t108 γ) := .refl (t108 γ)
theorem p201 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t88 γ) := .scalarSimplify n21 n12 n4 QSym.BindingScalar11.DomainCertificate.domain_correct QSym.BindingScalar11.ValueCertificate.refinement
theorem p202 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t15 γ) := .trans (p201 γ) (p173 γ)
theorem p203 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t15 γ) := .trans (p200 γ) (p202 γ)
theorem p204 (γ : Binding.Globals) : Binding.Reduction (t97 γ) (t15 γ) := .trans (p199 γ) (p203 γ)
theorem p205 (γ : Binding.Globals) : Binding.Reduction (t97 γ) (t15 γ) := .trans (p198 γ) (p204 γ)
theorem p206 (γ : Binding.Globals) : Binding.Reduction (t96 γ) (t91 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p165 γ) (p4 γ)
theorem p207 (γ : Binding.Globals) : Binding.Reduction (t91 γ) (t92 γ) := .ofEq (fun _ _ => rfl)
theorem p208 (γ : Binding.Globals) : Binding.Reduction (t91 γ) (t18 γ) := .trans (p207 γ) (p185 γ)
theorem p209 (γ : Binding.Globals) : Binding.Reduction (t96 γ) (t18 γ) := .trans (p206 γ) (p208 γ)
theorem p210 (γ : Binding.Globals) : Binding.Reduction (t98 γ) (t109 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p205 γ) (p209 γ)
theorem p211 (γ : Binding.Globals) : Binding.Reduction (t109 γ) (t110 γ) := .ofEq (fun _ _ => rfl)
theorem p212 (γ : Binding.Globals) : Binding.Reduction (t110 γ) (t110 γ) := .refl (t110 γ)
theorem p213 (γ : Binding.Globals) : Binding.Reduction (t110 γ) (t111 γ) := .scalarSimplify n22 n12 n2 QSym.BindingScalar12.DomainCertificate.domain_correct QSym.BindingScalar12.ValueCertificate.refinement
theorem p214 (γ : Binding.Globals) : Binding.Reduction (t111 γ) (t111 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p37 γ) (p10 γ)
theorem p215 (γ : Binding.Globals) : Binding.Reduction (t111 γ) (t10 γ) := .guardTrue (t10 γ)
theorem p216 (γ : Binding.Globals) : Binding.Reduction (t111 γ) (t10 γ) := .trans (p215 γ) (p10 γ)
theorem p217 (γ : Binding.Globals) : Binding.Reduction (t111 γ) (t10 γ) := .trans (p214 γ) (p216 γ)
theorem p218 (γ : Binding.Globals) : Binding.Reduction (t110 γ) (t10 γ) := .trans (p213 γ) (p217 γ)
theorem p219 (γ : Binding.Globals) : Binding.Reduction (t110 γ) (t10 γ) := .trans (p212 γ) (p218 γ)
theorem p220 (γ : Binding.Globals) : Binding.Reduction (t109 γ) (t10 γ) := .trans (p211 γ) (p219 γ)
theorem p221 (γ : Binding.Globals) : Binding.Reduction (t98 γ) (t10 γ) := .trans (p210 γ) (p220 γ)
theorem p222 (γ : Binding.Globals) : Binding.Reduction (t99 γ) (t112 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p177 γ) (p1 γ)
theorem p223 (γ : Binding.Globals) : Binding.Reduction (t100 γ) (t113 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p221 γ) (p222 γ)
theorem p224 (γ : Binding.Globals) : Binding.Reduction (t101 γ) (t101 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p19 γ)
theorem p225 (γ : Binding.Globals) : Binding.Reduction (t101 γ) (t114 γ) := .ofEq (fun _ _ => rfl)
theorem p226 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t114 γ) := .refl (t114 γ)
theorem p227 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t51 γ) := .scalarSimplify n23 n12 n1 QSym.BindingScalar13.DomainCertificate.domain_correct QSym.BindingScalar13.ValueCertificate.refinement
theorem p228 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t4 γ) := .trans (p227 γ) (p53 γ)
theorem p229 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t4 γ) := .trans (p226 γ) (p228 γ)
theorem p230 (γ : Binding.Globals) : Binding.Reduction (t101 γ) (t4 γ) := .trans (p225 γ) (p229 γ)
theorem p231 (γ : Binding.Globals) : Binding.Reduction (t101 γ) (t4 γ) := .trans (p224 γ) (p230 γ)
theorem p232 (γ : Binding.Globals) : Binding.Reduction (t102 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p231 γ) (p4 γ)
theorem p233 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p234 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t4 γ) := .trans (p233 γ) (p63 γ)
theorem p235 (γ : Binding.Globals) : Binding.Reduction (t102 γ) (t4 γ) := .trans (p232 γ) (p234 γ)
theorem p236 (γ : Binding.Globals) : Binding.Reduction (t103 γ) (t115 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p205 γ) (p235 γ)
theorem p237 (γ : Binding.Globals) : Binding.Reduction (t115 γ) (t116 γ) := .ofEq (fun _ _ => rfl)
theorem p238 (γ : Binding.Globals) : Binding.Reduction (t116 γ) (t116 γ) := .refl (t116 γ)
theorem p239 (γ : Binding.Globals) : Binding.Reduction (t116 γ) (t88 γ) := .scalarSimplify n24 n12 n4 QSym.BindingScalar14.DomainCertificate.domain_correct QSym.BindingScalar14.ValueCertificate.refinement
theorem p240 (γ : Binding.Globals) : Binding.Reduction (t116 γ) (t15 γ) := .trans (p239 γ) (p173 γ)
theorem p241 (γ : Binding.Globals) : Binding.Reduction (t116 γ) (t15 γ) := .trans (p238 γ) (p240 γ)
theorem p242 (γ : Binding.Globals) : Binding.Reduction (t115 γ) (t15 γ) := .trans (p237 γ) (p241 γ)
theorem p243 (γ : Binding.Globals) : Binding.Reduction (t103 γ) (t15 γ) := .trans (p236 γ) (p242 γ)
theorem p244 (γ : Binding.Globals) : Binding.Reduction (t104 γ) (t89 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p187 γ) (p1 γ)
theorem p245 (γ : Binding.Globals) : Binding.Reduction (t105 γ) (t90 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p243 γ) (p244 γ)
theorem p246 (γ : Binding.Globals) : Binding.Reduction (t106 γ) (t117 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p245 γ) (p7 γ)
theorem p247 (γ : Binding.Globals) : Binding.Reduction (t107 γ) (t118 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p223 γ) (p246 γ)
theorem p248 (γ : Binding.Globals) : Binding.Reduction (t95 γ) (t118 γ) := .trans (p197 γ) (p247 γ)
theorem p249 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t118 γ) := .trans (p196 γ) (p248 γ)
theorem p250 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t118 γ) := .trans (p15 γ) (p249 γ)
theorem p251 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t118 γ) := .trans (p14 γ) (p250 γ)
theorem p252 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t119 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p251 γ)
theorem p253 (γ : Binding.Globals) : Binding.Reduction (t119 γ) (t131 γ) := .ofEq (fun ξ ρ => rfl)
theorem p254 (γ : Binding.Globals) : Binding.Reduction (t121 γ) (t121 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p10 γ)
theorem p255 (γ : Binding.Globals) : Binding.Reduction (t121 γ) (t132 γ) := .ofEq (fun _ _ => rfl)
theorem p256 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t132 γ) := .refl (t132 γ)
theorem p257 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t111 γ) := .scalarSimplify n25 n12 n2 QSym.BindingScalar15.DomainCertificate.domain_correct QSym.BindingScalar15.ValueCertificate.refinement
theorem p258 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t10 γ) := .trans (p257 γ) (p217 γ)
theorem p259 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t10 γ) := .trans (p256 γ) (p258 γ)
theorem p260 (γ : Binding.Globals) : Binding.Reduction (t121 γ) (t10 γ) := .trans (p255 γ) (p259 γ)
theorem p261 (γ : Binding.Globals) : Binding.Reduction (t121 γ) (t10 γ) := .trans (p254 γ) (p260 γ)
theorem p262 (γ : Binding.Globals) : Binding.Reduction (t120 γ) (t115 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p205 γ) (p4 γ)
theorem p263 (γ : Binding.Globals) : Binding.Reduction (t115 γ) (t116 γ) := .ofEq (fun _ _ => rfl)
theorem p264 (γ : Binding.Globals) : Binding.Reduction (t115 γ) (t15 γ) := .trans (p263 γ) (p241 γ)
theorem p265 (γ : Binding.Globals) : Binding.Reduction (t120 γ) (t15 γ) := .trans (p262 γ) (p264 γ)
theorem p266 (γ : Binding.Globals) : Binding.Reduction (t122 γ) (t133 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p261 γ) (p265 γ)
theorem p267 (γ : Binding.Globals) : Binding.Reduction (t133 γ) (t134 γ) := .ofEq (fun _ _ => rfl)
theorem p268 (γ : Binding.Globals) : Binding.Reduction (t134 γ) (t134 γ) := .refl (t134 γ)
theorem p269 (γ : Binding.Globals) : Binding.Reduction (t134 γ) (t136 γ) := .scalarSimplify n26 n12 n27 QSym.BindingScalar16.DomainCertificate.domain_correct QSym.BindingScalar16.ValueCertificate.refinement
theorem p270 (γ : Binding.Globals) : Binding.Reduction (t135 γ) (t135 γ) := .refl (t135 γ)
theorem p271 (γ : Binding.Globals) : Binding.Reduction (t136 γ) (t136 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p37 γ) (p270 γ)
theorem p272 (γ : Binding.Globals) : Binding.Reduction (t136 γ) (t135 γ) := .guardTrue (t135 γ)
theorem p273 (γ : Binding.Globals) : Binding.Reduction (t136 γ) (t135 γ) := .trans (p272 γ) (p270 γ)
theorem p274 (γ : Binding.Globals) : Binding.Reduction (t136 γ) (t135 γ) := .trans (p271 γ) (p273 γ)
theorem p275 (γ : Binding.Globals) : Binding.Reduction (t134 γ) (t135 γ) := .trans (p269 γ) (p274 γ)
theorem p276 (γ : Binding.Globals) : Binding.Reduction (t134 γ) (t135 γ) := .trans (p268 γ) (p275 γ)
theorem p277 (γ : Binding.Globals) : Binding.Reduction (t133 γ) (t135 γ) := .trans (p267 γ) (p276 γ)
theorem p278 (γ : Binding.Globals) : Binding.Reduction (t122 γ) (t135 γ) := .trans (p266 γ) (p277 γ)
theorem p279 (γ : Binding.Globals) : Binding.Reduction (t123 γ) (t137 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p221 γ) (p1 γ)
theorem p280 (γ : Binding.Globals) : Binding.Reduction (t124 γ) (t138 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p278 γ) (p279 γ)
theorem p281 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t125 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p16 γ)
theorem p282 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t139 γ) := .ofEq (fun _ _ => rfl)
theorem p283 (γ : Binding.Globals) : Binding.Reduction (t139 γ) (t139 γ) := .refl (t139 γ)
theorem p284 (γ : Binding.Globals) : Binding.Reduction (t139 γ) (t51 γ) := .scalarSimplify n28 n12 n1 QSym.BindingScalar17.DomainCertificate.domain_correct QSym.BindingScalar17.ValueCertificate.refinement
theorem p285 (γ : Binding.Globals) : Binding.Reduction (t139 γ) (t4 γ) := .trans (p284 γ) (p53 γ)
theorem p286 (γ : Binding.Globals) : Binding.Reduction (t139 γ) (t4 γ) := .trans (p283 γ) (p285 γ)
theorem p287 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t4 γ) := .trans (p282 γ) (p286 γ)
theorem p288 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t4 γ) := .trans (p281 γ) (p287 γ)
theorem p289 (γ : Binding.Globals) : Binding.Reduction (t126 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p288 γ) (p4 γ)
theorem p290 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p291 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t4 γ) := .trans (p290 γ) (p63 γ)
theorem p292 (γ : Binding.Globals) : Binding.Reduction (t126 γ) (t4 γ) := .trans (p289 γ) (p291 γ)
theorem p293 (γ : Binding.Globals) : Binding.Reduction (t127 γ) (t140 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p261 γ) (p292 γ)
theorem p294 (γ : Binding.Globals) : Binding.Reduction (t140 γ) (t141 γ) := .ofEq (fun _ _ => rfl)
theorem p295 (γ : Binding.Globals) : Binding.Reduction (t141 γ) (t141 γ) := .refl (t141 γ)
theorem p296 (γ : Binding.Globals) : Binding.Reduction (t141 γ) (t111 γ) := .scalarSimplify n29 n12 n2 QSym.BindingScalar18.DomainCertificate.domain_correct QSym.BindingScalar18.ValueCertificate.refinement
theorem p297 (γ : Binding.Globals) : Binding.Reduction (t141 γ) (t10 γ) := .trans (p296 γ) (p217 γ)
theorem p298 (γ : Binding.Globals) : Binding.Reduction (t141 γ) (t10 γ) := .trans (p295 γ) (p297 γ)
theorem p299 (γ : Binding.Globals) : Binding.Reduction (t140 γ) (t10 γ) := .trans (p294 γ) (p298 γ)
theorem p300 (γ : Binding.Globals) : Binding.Reduction (t127 γ) (t10 γ) := .trans (p293 γ) (p299 γ)
theorem p301 (γ : Binding.Globals) : Binding.Reduction (t128 γ) (t112 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p243 γ) (p1 γ)
theorem p302 (γ : Binding.Globals) : Binding.Reduction (t129 γ) (t113 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p300 γ) (p301 γ)
theorem p303 (γ : Binding.Globals) : Binding.Reduction (t130 γ) (t142 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p302 γ) (p7 γ)
theorem p304 (γ : Binding.Globals) : Binding.Reduction (t131 γ) (t143 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p280 γ) (p303 γ)
theorem p305 (γ : Binding.Globals) : Binding.Reduction (t119 γ) (t143 γ) := .trans (p253 γ) (p304 γ)
theorem p306 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t143 γ) := .trans (p252 γ) (p305 γ)
theorem p307 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t143 γ) := .trans (p12 γ) (p306 γ)
theorem p308 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t143 γ) := .trans (p11 γ) (p307 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t143 γ) := (p308 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t11 γ).eval ξ ρ = (t143 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t11 γ).eval ξ ρ) ↔ Value.Defined ((t143 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
