import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .complex := (.complex (0) (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n11 : Expr .complex := (.complex (1) (0))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n24 : Expr .complex := (.mulC n0 n11)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v11 ρ)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v0 ρ)) (y := (v11 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_mul (v0 ρ) (v11 ρ)) (q0 ρ) (q11 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n24) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q24 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n24 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .complex := (.complex (0) (1))
def n11 : Expr .complex := (.complex (1) (0))
def n24 : Expr .complex := (.mulC n0 n11)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v11 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v24 ρ) (v0 ρ) :=
  let ac0 : Replay.Tree := (.leaf 0)
  let ac11 : Replay.Tree := .unit
  let ac24 : Replay.Tree := (.node ac0 ac11)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v0 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac24 ac0 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n24) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_24 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n24) : (Expr.eval ρ n24) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  (Value.defined_mul (v0 ρ) (v11 ρ)).mpr ⟨(total_0 ρ), (total_11 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v24 ρ) := (total_24 ρ)
def d24 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n24 ↔ (d24 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_24 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n24 := Eq.mpr (congrArg Value.Defined (eval_24 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n0 : Expr .complex := (.complex (0) (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n1 : Expr .natural := (.nat (1))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .integer := (.castNZ n1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
def n8 : Expr .rational := (.castZQ n7)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
def n9 : Expr .real := (.castQR n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
def n10 : Expr .complex := (.castRC n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
def n26 : Expr .complex := (.mulC n10 n0)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v10 ρ) (v0 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v25 ρ) :=
  Domain.total1 Functions.castNZ (x := (v1 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q1 ρ)
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v25 ρ) :=
  Domain.total1 Functions.castZQ (x := (v7 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q7 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v25 ρ) :=
  Domain.total1 Functions.castQR (x := (v8 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v25 ρ) :=
  Domain.total1 Functions.castRC (x := (v9 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q26 (ρ : Env) : Domain.Correct (v26 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v10 ρ)) (y := (v0 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_mul (v10 ρ) (v0 ρ)) (q10 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n26) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q26 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n26 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .complex := (.complex (0) (1))
def n1 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n1)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n12 : Expr .integer := (.int (1))
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n15 : Expr .real := (.castQR n14)
def n16 : Expr .real := (.real (1))
def n17 : Expr .complex := (.castRC n16)
def n26 : Expr .complex := (.mulC n10 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v16 ρ)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v11 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v10 ρ) (v0 ρ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v10 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v10 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v26 ρ) (v27 ρ) :=
  let ac0 : Replay.Tree := (.leaf 0)
  let ac10 : Replay.Tree := (.leaf 1)
  let ac26 : Replay.Tree := (.node ac10 ac0)
  let ac27 : Replay.Tree := (.node ac0 ac10)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v0 ρ),(v10 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac26 ac27 rfl)

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_7 ρ) (eval_12 ρ)) (Numeric.sound ρ n7 n12 rfl)

theorem p2 (ρ : Env) : Value.Refines (v8 ρ) (v13 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem p4 (ρ : Env) : Value.Refines (v8 ρ) (v14 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (Numeric.sound ρ n15 n16 rfl)

theorem p7 (ρ : Env) : Value.Refines (v9 ρ) (v16 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v10 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v17 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_11 ρ)) (Numeric.sound ρ n17 n11 rfl)

theorem p10 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v27 ρ) (v28 ρ) :=
  Value.refines_refl (v27 ρ)

theorem p12 (ρ : Env) : Value.Refines (v28 ρ) (v24 ρ) :=
  Value.refines_mul (Value.refines_refl (v0 ρ)) (p10 ρ)

theorem p13 (ρ : Env) : Value.Refines (v27 ρ) (v24 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem p14 (ρ : Env) : Value.Refines (v24 ρ) (v0 ρ) :=
  let ac0 : Replay.Tree := (.leaf 0)
  let ac11 : Replay.Tree := .unit
  let ac24 : Replay.Tree := (.node ac0 ac11)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v0 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac24 ac0 rfl)

theorem p15 (ρ : Env) : Value.Refines (v27 ρ) (v0 ρ) :=
  (p13 ρ).trans (p14 ρ)

theorem p16 (ρ : Env) : Value.Refines (v26 ρ) (v0 ρ) :=
  (p0 ρ).trans (p15 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n26) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_26 ρ) (eval_0 ρ)) (p16 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n26) : (Expr.eval ρ n26) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := ∃ x, (v1 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.castNZ.defined (v1 ρ)

def d8 (ρ : Env) : Prop := ∃ x, (v7 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castZQ.defined (v7 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castQR.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castRC.defined (v9 ρ)

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d26 (ρ : Env) : Prop := (d10 ρ) ∧ (d0 ρ)
theorem domain_26 (ρ : Env) : Value.Defined (v26 ρ) ↔ d26 ρ :=
  (Value.defined_mul (v10 ρ) (v0 ρ)).trans (and_congr (domain_10 ρ) (domain_0 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n26 ↔ (d26 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_26 ρ))).trans (domain_26 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v1 ρ) (total_1 ρ)
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v7 ρ) (total_7 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  (Value.defined_mul (v10 ρ) (v0 ρ)).mpr ⟨(total_10 ρ), (total_0 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n26 := Eq.mpr (congrArg Value.Defined (eval_26 ρ)) (total_26 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n0 : Expr .complex := (.complex (0) (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n18 : Expr .complex := (.complex (0) (0))
noncomputable def v18 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
def n29 : Expr .complex := (.addC n0 n18)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v0 ρ) (v18 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q29 (ρ : Env) : Domain.Correct (v29 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v0 ρ)) (y := (v18 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_add (v0 ρ) (v18 ρ)) (q0 ρ) (q18 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n29) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q29 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n29 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .complex := (.complex (0) (1))
def n18 : Expr .complex := (.complex (0) (0))
def n29 : Expr .complex := (.addC n0 n18)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v0 ρ) (v18 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v29 ρ) (v0 ρ) :=
  let ac0 : Replay.Tree := (.leaf 0)
  let ac18 : Replay.Tree := .unit
  let ac29 : Replay.Tree := (.node ac0 ac18)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addC (fun i => ([(v0 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac29 ac0 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n29) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_29 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n29) : (Expr.eval ρ n29) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  ⟨_, rfl⟩
theorem total_29 (ρ : Env) : Value.Defined (v29 ρ) :=
  (Value.defined_add (v0 ρ) (v18 ρ)).mpr ⟨(total_0 ρ), (total_18 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v29 ρ) := (total_29 ρ)
def d29 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n29 ↔ (d29 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_29 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n29 := Eq.mpr (congrArg Value.Defined (eval_29 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n0 : Expr .complex := (.complex (0) (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
def n30 : Expr .complex := (.addC n0 n0)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v0 ρ) (v0 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_add (v0 ρ) (v0 ρ)) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n30) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q30 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n30 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .complex := (.complex (0) (1))
def n30 : Expr .complex := (.addC n0 n0)
def n32 : Expr .complex := (.complex (2) (0))
def b34 : Region (Expr .complex) := .join (.item n0 .one) (.item n32 .one)
def n34 : Expr .complex := Expr.productC b34
def n35 : Expr .complex := (.complex (0) (2))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v0 ρ) (v0 ρ)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v0 ρ) (v0 ρ)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v32 ρ) (v0 ρ)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v32 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((2 : Int) : ℂ) * Complex.I)
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl
theorem eval_34 (ρ : Env) : (Expr.eval ρ n34) = (v34 ρ) := rfl
theorem eval_35 (ρ : Env) : (Expr.eval ρ n35) = (v35 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v30 ρ) (v31 ρ) :=
  Value.refines_refl (v30 ρ)

theorem p1 (ρ : Env) : Value.Refines (v31 ρ) (v33 ρ) :=
  Value.refines_repeat_addC (.twice .one) 2 (Positive.toNat_twice .one 1 Positive.toNat_one) (x := (v0 ρ)) (y := (v0 ρ)) (Value.refines_refl (v0 ρ))

theorem p2 (ρ : Env) : Value.Refines (v33 ρ) (v34 ρ) :=
  let ac0 : Replay.Tree := (.leaf 0)
  let ac32 : Replay.Tree := (.leaf 1)
  let ac33 : Replay.Tree := (.node ac32 ac0)
  let ac34 : Replay.Tree := (.node ac0 ac32)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v0 ρ),(v32 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac33 ac34 rfl)

theorem p3 (ρ : Env) : Value.Refines (v31 ρ) (v34 ρ) :=
  (p1 ρ).trans (p2 ρ)

theorem p4 (ρ : Env) : Value.Refines (v34 ρ) (v35 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_34 ρ) (eval_35 ρ)) (Numeric.sound ρ n34 n35 rfl)

theorem p5 (ρ : Env) : Value.Refines (v31 ρ) (v35 ρ) :=
  (p3 ρ).trans (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v30 ρ) (v35 ρ) :=
  (p0 ρ).trans (p5 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n30) (Expr.eval ρ n35) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_30 ρ) (eval_35 ρ)) (p6 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n30) : (Expr.eval ρ n30) = (Expr.eval ρ n35) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  (Value.defined_add (v0 ρ) (v0 ρ)).mpr ⟨(total_0 ρ), (total_0 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v30 ρ) := (total_30 ρ)
def d30 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n30 ↔ (d30 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_30 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n30 := Eq.mpr (congrArg Value.Defined (eval_30 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n1 : Expr .natural := (.nat (1))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .integer := (.castNZ n1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
def n8 : Expr .rational := (.castZQ n7)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
def n9 : Expr .real := (.castQR n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
def n10 : Expr .complex := (.castRC n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
def n11 : Expr .complex := (.complex (1) (0))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
def n36 : Expr .complex := (.mulC n10 n11)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v10 ρ) (v11 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v25 ρ) :=
  Domain.total1 Functions.castNZ (x := (v1 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q1 ρ)
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v25 ρ) :=
  Domain.total1 Functions.castZQ (x := (v7 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q7 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v25 ρ) :=
  Domain.total1 Functions.castQR (x := (v8 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v25 ρ) :=
  Domain.total1 Functions.castRC (x := (v9 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q36 (ρ : Env) : Domain.Correct (v36 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v10 ρ)) (y := (v11 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_mul (v10 ρ) (v11 ρ)) (q10 ρ) (q11 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n36) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q36 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n36 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n1)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n12 : Expr .integer := (.int (1))
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n15 : Expr .real := (.castQR n14)
def n16 : Expr .real := (.real (1))
def n17 : Expr .complex := (.castRC n16)
def n36 : Expr .complex := (.mulC n10 n11)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v16 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v10 ρ) (v11 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v36 ρ) (v10 ρ) :=
  let ac10 : Replay.Tree := (.leaf 0)
  let ac11 : Replay.Tree := .unit
  let ac36 : Replay.Tree := (.node ac10 ac11)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v10 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac36 ac10 rfl)

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_7 ρ) (eval_12 ρ)) (Numeric.sound ρ n7 n12 rfl)

theorem p2 (ρ : Env) : Value.Refines (v8 ρ) (v13 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem p4 (ρ : Env) : Value.Refines (v8 ρ) (v14 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (Numeric.sound ρ n15 n16 rfl)

theorem p7 (ρ : Env) : Value.Refines (v9 ρ) (v16 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v10 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v17 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_11 ρ)) (Numeric.sound ρ n17 n11 rfl)

theorem p10 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v36 ρ) (v11 ρ) :=
  (p0 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v11 ρ) (v10 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_11 ρ) (eval_10 ρ)) (Numeric.sound ρ n11 n10 rfl)

theorem p13 (ρ : Env) : Value.Refines (v36 ρ) (v10 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n36) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_36 ρ) (eval_10 ρ)) (p13 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n36) : (Expr.eval ρ n36) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := ∃ x, (v1 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.castNZ.defined (v1 ρ)

def d8 (ρ : Env) : Prop := ∃ x, (v7 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castZQ.defined (v7 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castQR.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castRC.defined (v9 ρ)

def d11 (ρ : Env) : Prop := True
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d36 (ρ : Env) : Prop := (d10 ρ) ∧ (d11 ρ)
theorem domain_36 (ρ : Env) : Value.Defined (v36 ρ) ↔ d36 ρ :=
  (Value.defined_mul (v10 ρ) (v11 ρ)).trans (and_congr (domain_10 ρ) (domain_11 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n36 ↔ (d36 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_36 ρ))).trans (domain_36 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v1 ρ) (total_1 ρ)
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v7 ρ) (total_7 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_36 (ρ : Env) : Value.Defined (v36 ρ) :=
  (Value.defined_mul (v10 ρ) (v11 ρ)).mpr ⟨(total_10 ρ), (total_11 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n36 := Eq.mpr (congrArg Value.Defined (eval_36 ρ)) (total_36 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n0 : Expr .complex := (.complex (0) (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
def n37 : Expr .complex := (.mulC n0 n0)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v0 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q37 (ρ : Env) : Domain.Correct (v37 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_mul (v0 ρ) (v0 ρ)) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n37) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q37 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n37 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .complex := (.complex (0) (1))
def n37 : Expr .complex := (.mulC n0 n0)
def b38 : Region (Expr .complex) := .item n0 (.twice .one)
def n38 : Expr .complex := Expr.productC b38
def n43 : Expr .complex := (.complex (-1) (0))
def n44 : Expr .integer := (.int (-1))
def n45 : Expr .rational := (.castZQ n44)
def n46 : Expr .real := (.castQR n45)
def n47 : Expr .complex := (.castRC n46)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v0 ρ)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v0 ρ) (v0 ρ)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .complex) := (Option.map (fun (x : Ty.denote .complex) => x ^ 2)) (v0 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .complex) := (Option.map (fun (x : Ty.denote .complex) => x ^ 1)) (v0 ρ)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v40 ρ) (v40 ρ)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v40 ρ) (v40 ρ)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .complex) := some (((-1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .integer) := some (-1)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v44 ρ)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v45 ρ)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v46 ρ)
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl
theorem eval_43 (ρ : Env) : (Expr.eval ρ n43) = (v43 ρ) := rfl
theorem eval_44 (ρ : Env) : (Expr.eval ρ n44) = (v44 ρ) := rfl
theorem eval_47 (ρ : Env) : (Expr.eval ρ n47) = (v47 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v37 ρ) (v38 ρ) :=
  Value.refines_refl (v37 ρ)

theorem p1 (ρ : Env) : Value.Refines (v38 ρ) (v39 ρ) :=
  Value.refines_repeat_mul (.twice .one) 2 (Positive.toNat_twice .one 1 Positive.toNat_one) (x := (v0 ρ)) (y := (v0 ρ)) (Value.refines_refl (v0 ρ))

theorem p2 (ρ : Env) : Value.Refines (v39 ρ) (v42 ρ) :=
  (Generated.r_complex_pow_split (v0 ρ) 1 1)

theorem p3 (ρ : Env) : Value.Refines (v42 ρ) (v41 ρ) :=
  Value.refines_refl (v42 ρ)

theorem p4 (ρ : Env) : Value.Refines (v39 ρ) (v41 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v40 ρ) (v0 ρ) :=
  (Generated.r_complex_pow_one (v0 ρ))

theorem p6 (ρ : Env) : Value.Refines (v41 ρ) (v42 ρ) :=
  Value.refines_refl (v41 ρ)

theorem p7 (ρ : Env) : Value.Refines (v42 ρ) (v37 ρ) :=
  Value.refines_mul (p5 ρ) (p5 ρ)

theorem p8 (ρ : Env) : Value.Refines (v41 ρ) (v37 ρ) :=
  (p6 ρ).trans (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v37 ρ) (v38 ρ) :=
  Value.refines_refl (v37 ρ)

theorem p10 (ρ : Env) : Value.Refines (v41 ρ) (v38 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v39 ρ) (v38 ρ) :=
  (p4 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v38 ρ) (v43 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_38 ρ) (eval_43 ρ)) (Numeric.sound ρ n38 n43 rfl)

theorem p13 (ρ : Env) : Value.Refines (v39 ρ) (v43 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem p14 (ρ : Env) : Value.Refines (v38 ρ) (v43 ρ) :=
  (p1 ρ).trans (p13 ρ)

theorem p15 (ρ : Env) : Value.Refines (v37 ρ) (v43 ρ) :=
  (p0 ρ).trans (p14 ρ)

theorem p16 (ρ : Env) : Value.Refines (v43 ρ) (v47 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_43 ρ) (eval_47 ρ)) (Numeric.sound ρ n43 n47 rfl)

theorem p17 (ρ : Env) : Value.Refines (v37 ρ) (v47 ρ) :=
  (p15 ρ).trans (p16 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n37) (Expr.eval ρ n47) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_37 ρ) (eval_47 ρ)) (p17 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n37) : (Expr.eval ρ n37) = (Expr.eval ρ n47) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  (Value.defined_mul (v0 ρ) (v0 ρ)).mpr ⟨(total_0 ρ), (total_0 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v37 ρ) := (total_37 ρ)
def d37 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n37 ↔ (d37 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_37 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n37 := Eq.mpr (congrArg Value.Defined (eval_37 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n18 : Expr .complex := (.complex (0) (0))
noncomputable def v18 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
def n44 : Expr .integer := (.int (-1))
noncomputable def v44 (ρ : Env) : Option (Ty.denote .integer) := some (-1)
def n45 : Expr .rational := (.castZQ n44)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v44 ρ)
def n46 : Expr .real := (.castQR n45)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v45 ρ)
def n47 : Expr .complex := (.castRC n46)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v46 ρ)
def n52 : Expr .complex := (.addC n47 n18)
noncomputable def v52 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v47 ρ) (v18 ρ)
theorem q44 (ρ : Env) : Domain.Correct (v44 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q45 (ρ : Env) : Domain.Correct (v45 ρ) (v25 ρ) :=
  Domain.total1 Functions.castZQ (x := (v44 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q44 ρ)
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v25 ρ) :=
  Domain.total1 Functions.castQR (x := (v45 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q45 ρ)
theorem q47 (ρ : Env) : Domain.Correct (v47 ρ) (v25 ρ) :=
  Domain.total1 Functions.castRC (x := (v46 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q46 ρ)
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q52 (ρ : Env) : Domain.Correct (v52 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v47 ρ)) (y := (v18 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_add (v47 ρ) (v18 ρ)) (q47 ρ) (q18 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n52) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q52 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n52 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n18 : Expr .complex := (.complex (0) (0))
def n43 : Expr .complex := (.complex (-1) (0))
def n44 : Expr .integer := (.int (-1))
def n45 : Expr .rational := (.castZQ n44)
def n46 : Expr .real := (.castQR n45)
def n47 : Expr .complex := (.castRC n46)
def n48 : Expr .rational := (.rat ((-1) / (1) : ℚ))
def n49 : Expr .real := (.castQR n48)
def n50 : Expr .real := (.real (-1))
def n51 : Expr .complex := (.castRC n50)
def n52 : Expr .complex := (.addC n47 n18)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .complex) := some (((-1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .integer) := some (-1)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v44 ρ)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v45 ρ)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v46 ρ)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .rational) := some ((-1) / (1) : ℚ)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v48 ρ)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .real) := some ((-1 : Int) : ℝ)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v50 ρ)
noncomputable def v52 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v47 ρ) (v18 ρ)
theorem eval_43 (ρ : Env) : (Expr.eval ρ n43) = (v43 ρ) := rfl
theorem eval_44 (ρ : Env) : (Expr.eval ρ n44) = (v44 ρ) := rfl
theorem eval_45 (ρ : Env) : (Expr.eval ρ n45) = (v45 ρ) := rfl
theorem eval_47 (ρ : Env) : (Expr.eval ρ n47) = (v47 ρ) := rfl
theorem eval_48 (ρ : Env) : (Expr.eval ρ n48) = (v48 ρ) := rfl
theorem eval_49 (ρ : Env) : (Expr.eval ρ n49) = (v49 ρ) := rfl
theorem eval_50 (ρ : Env) : (Expr.eval ρ n50) = (v50 ρ) := rfl
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl
theorem eval_52 (ρ : Env) : (Expr.eval ρ n52) = (v52 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v52 ρ) (v47 ρ) :=
  let ac18 : Replay.Tree := .unit
  let ac47 : Replay.Tree := (.leaf 0)
  let ac52 : Replay.Tree := (.node ac47 ac18)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addC (fun i => ([(v47 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac52 ac47 rfl)

theorem p1 (ρ : Env) : Value.Refines (v45 ρ) (v48 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_45 ρ) (eval_48 ρ)) (Numeric.sound ρ n45 n48 rfl)

theorem p2 (ρ : Env) : Value.Refines (v46 ρ) (v49 ρ) :=
  Value.refines_function1 Functions.castQR (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v49 ρ) (v50 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_49 ρ) (eval_50 ρ)) (Numeric.sound ρ n49 n50 rfl)

theorem p4 (ρ : Env) : Value.Refines (v46 ρ) (v50 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v47 ρ) (v51 ρ) :=
  Value.refines_function1 Functions.castRC (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v51 ρ) (v43 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_51 ρ) (eval_43 ρ)) (Numeric.sound ρ n51 n43 rfl)

theorem p7 (ρ : Env) : Value.Refines (v47 ρ) (v43 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v52 ρ) (v43 ρ) :=
  (p0 ρ).trans (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v43 ρ) (v47 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_43 ρ) (eval_47 ρ)) (Numeric.sound ρ n43 n47 rfl)

theorem p10 (ρ : Env) : Value.Refines (v52 ρ) (v47 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n52) (Expr.eval ρ n47) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_52 ρ) (eval_47 ρ)) (p10 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n52) : (Expr.eval ρ n52) = (Expr.eval ρ n47) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d44 (ρ : Env) : Prop := True
theorem domain_44 (ρ : Env) : Value.Defined (v44 ρ) ↔ d44 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d45 (ρ : Env) : Prop := ∃ x, (v44 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_45 (ρ : Env) : Value.Defined (v45 ρ) ↔ d45 ρ :=
  Functions.castZQ.defined (v44 ρ)

def d46 (ρ : Env) : Prop := ∃ x, (v45 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  Functions.castQR.defined (v45 ρ)

def d47 (ρ : Env) : Prop := ∃ x, (v46 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_47 (ρ : Env) : Value.Defined (v47 ρ) ↔ d47 ρ :=
  Functions.castRC.defined (v46 ρ)

def d18 (ρ : Env) : Prop := True
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d52 (ρ : Env) : Prop := (d47 ρ) ∧ (d18 ρ)
theorem domain_52 (ρ : Env) : Value.Defined (v52 ρ) ↔ d52 ρ :=
  (Value.defined_add (v47 ρ) (v18 ρ)).trans (and_congr (domain_47 ρ) (domain_18 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n52 ↔ (d52 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_52 ρ))).trans (domain_52 ρ)
#qsym_check_axioms definedness
theorem total_44 (ρ : Env) : Value.Defined (v44 ρ) :=
  ⟨_, rfl⟩
theorem total_45 (ρ : Env) : Value.Defined (v45 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v44 ρ) (total_44 ρ)
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v45 ρ) (total_45 ρ)
theorem total_47 (ρ : Env) : Value.Defined (v47 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v46 ρ) (total_46 ρ)
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  ⟨_, rfl⟩
theorem total_52 (ρ : Env) : Value.Defined (v52 ρ) :=
  (Value.defined_add (v47 ρ) (v18 ρ)).mpr ⟨(total_47 ρ), (total_18 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n52 := Eq.mpr (congrArg Value.Defined (eval_52 ρ)) (total_52 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n25) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_25 ρ)) (Value.refines_refl (v25 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n25) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v25 ρ) := (total_25 ρ)
def d25 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n1 : Expr .natural := (.nat (1))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .integer := (.castNZ n1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
def n8 : Expr .rational := (.castZQ n7)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
def n9 : Expr .real := (.castQR n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
def n10 : Expr .complex := (.castRC n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
def n25 : Expr .bool := (.bool true)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .bool) := some true
def n44 : Expr .integer := (.int (-1))
noncomputable def v44 (ρ : Env) : Option (Ty.denote .integer) := some (-1)
def n45 : Expr .rational := (.castZQ n44)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v44 ρ)
def n46 : Expr .real := (.castQR n45)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v45 ρ)
def n47 : Expr .complex := (.castRC n46)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v46 ρ)
def n53 : Expr .complex := (.addC n10 n47)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v47 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v25 ρ) :=
  Domain.total1 Functions.castNZ (x := (v1 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q1 ρ)
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v25 ρ) :=
  Domain.total1 Functions.castZQ (x := (v7 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q7 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v25 ρ) :=
  Domain.total1 Functions.castQR (x := (v8 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v25 ρ) :=
  Domain.total1 Functions.castRC (x := (v9 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q44 (ρ : Env) : Domain.Correct (v44 ρ) (v25 ρ) :=
  Domain.leaf _
theorem q45 (ρ : Env) : Domain.Correct (v45 ρ) (v25 ρ) :=
  Domain.total1 Functions.castZQ (x := (v44 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q44 ρ)
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v25 ρ) :=
  Domain.total1 Functions.castQR (x := (v45 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q45 ρ)
theorem q47 (ρ : Env) : Domain.Correct (v47 ρ) (v25 ρ) :=
  Domain.total1 Functions.castRC (x := (v46 ρ)) (d := (v25 ρ)) (fun _ => True.intro) (q46 ρ)
theorem q53 (ρ : Env) : Domain.Correct (v53 ρ) (v25 ρ) :=
  Domain.strict2 (x := (v10 ρ)) (y := (v47 ρ)) (dx := (v25 ρ)) (dy := (v25 ρ)) (Value.defined_add (v10 ρ) (v47 ρ)) (q10 ρ) (q47 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n53) (Expr.eval ρ Certificate.n25) :=
  Domain.simplify (q53 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n25) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n53 ↔ (Expr.eval ρ Certificate.n25) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n1)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n12 : Expr .integer := (.int (1))
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n15 : Expr .real := (.castQR n14)
def n16 : Expr .real := (.real (1))
def n17 : Expr .complex := (.castRC n16)
def n18 : Expr .complex := (.complex (0) (0))
def n43 : Expr .complex := (.complex (-1) (0))
def n44 : Expr .integer := (.int (-1))
def n45 : Expr .rational := (.castZQ n44)
def n46 : Expr .real := (.castQR n45)
def n47 : Expr .complex := (.castRC n46)
def n48 : Expr .rational := (.rat ((-1) / (1) : ℚ))
def n49 : Expr .real := (.castQR n48)
def n50 : Expr .real := (.real (-1))
def n51 : Expr .complex := (.castRC n50)
def n53 : Expr .complex := (.addC n10 n47)
def b56 : Region (Expr .complex) := .join (.item n11 .one) (.item n43 .one)
def n56 : Expr .complex := Expr.sumC b56
def n57 : Expr .natural := (.nat (0))
def n58 : Expr .integer := (.castNZ n57)
def n59 : Expr .rational := (.castZQ n58)
def n60 : Expr .real := (.castQR n59)
def n61 : Expr .complex := (.castRC n60)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v7 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v16 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .complex) := some (((-1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .integer) := some (-1)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v44 ρ)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v45 ρ)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v46 ρ)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .rational) := some ((-1) / (1) : ℚ)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v48 ρ)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .real) := some ((-1 : Int) : ℝ)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v50 ρ)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v47 ρ)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v10 ρ) (v47 ρ)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v11 ρ) (v43 ρ)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v11 ρ) (v43 ρ)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v57 ρ)
noncomputable def v59 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v58 ρ)
noncomputable def v60 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v59 ρ)
noncomputable def v61 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v60 ρ)
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl
theorem eval_43 (ρ : Env) : (Expr.eval ρ n43) = (v43 ρ) := rfl
theorem eval_45 (ρ : Env) : (Expr.eval ρ n45) = (v45 ρ) := rfl
theorem eval_48 (ρ : Env) : (Expr.eval ρ n48) = (v48 ρ) := rfl
theorem eval_49 (ρ : Env) : (Expr.eval ρ n49) = (v49 ρ) := rfl
theorem eval_50 (ρ : Env) : (Expr.eval ρ n50) = (v50 ρ) := rfl
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl
theorem eval_53 (ρ : Env) : (Expr.eval ρ n53) = (v53 ρ) := rfl
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl
theorem eval_57 (ρ : Env) : (Expr.eval ρ n57) = (v57 ρ) := rfl
theorem eval_61 (ρ : Env) : (Expr.eval ρ n61) = (v61 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v53 ρ) (v54 ρ) :=
  Value.refines_refl (v53 ρ)

theorem p1 (ρ : Env) : Value.Refines (v7 ρ) (v12 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_7 ρ) (eval_12 ρ)) (Numeric.sound ρ n7 n12 rfl)

theorem p2 (ρ : Env) : Value.Refines (v8 ρ) (v13 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_13 ρ) (eval_14 ρ)) (Numeric.sound ρ n13 n14 rfl)

theorem p4 (ρ : Env) : Value.Refines (v8 ρ) (v14 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v9 ρ) (v15 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v15 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_15 ρ) (eval_16 ρ)) (Numeric.sound ρ n15 n16 rfl)

theorem p7 (ρ : Env) : Value.Refines (v9 ρ) (v16 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v10 ρ) (v17 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v17 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_11 ρ)) (Numeric.sound ρ n17 n11 rfl)

theorem p10 (ρ : Env) : Value.Refines (v10 ρ) (v11 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v45 ρ) (v48 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_45 ρ) (eval_48 ρ)) (Numeric.sound ρ n45 n48 rfl)

theorem p12 (ρ : Env) : Value.Refines (v46 ρ) (v49 ρ) :=
  Value.refines_function1 Functions.castQR (p11 ρ)

theorem p13 (ρ : Env) : Value.Refines (v49 ρ) (v50 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_49 ρ) (eval_50 ρ)) (Numeric.sound ρ n49 n50 rfl)

theorem p14 (ρ : Env) : Value.Refines (v46 ρ) (v50 ρ) :=
  (p12 ρ).trans (p13 ρ)

theorem p15 (ρ : Env) : Value.Refines (v47 ρ) (v51 ρ) :=
  Value.refines_function1 Functions.castRC (p14 ρ)

theorem p16 (ρ : Env) : Value.Refines (v51 ρ) (v43 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_51 ρ) (eval_43 ρ)) (Numeric.sound ρ n51 n43 rfl)

theorem p17 (ρ : Env) : Value.Refines (v47 ρ) (v43 ρ) :=
  (p15 ρ).trans (p16 ρ)

theorem p18 (ρ : Env) : Value.Refines (v54 ρ) (v53 ρ) :=
  Value.refines_refl (v54 ρ)

theorem p19 (ρ : Env) : Value.Refines (v53 ρ) (v55 ρ) :=
  Value.refines_add (p10 ρ) (p17 ρ)

theorem p20 (ρ : Env) : Value.Refines (v54 ρ) (v55 ρ) :=
  (p18 ρ).trans (p19 ρ)

theorem p21 (ρ : Env) : Value.Refines (v55 ρ) (v56 ρ) :=
  Value.refines_refl (v55 ρ)

theorem p22 (ρ : Env) : Value.Refines (v54 ρ) (v56 ρ) :=
  (p20 ρ).trans (p21 ρ)

theorem p23 (ρ : Env) : Value.Refines (v56 ρ) (v18 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_56 ρ) (eval_18 ρ)) (Numeric.sound ρ n56 n18 rfl)

theorem p24 (ρ : Env) : Value.Refines (v54 ρ) (v18 ρ) :=
  (p22 ρ).trans (p23 ρ)

theorem p25 (ρ : Env) : Value.Refines (v53 ρ) (v18 ρ) :=
  (p0 ρ).trans (p24 ρ)

theorem p26 (ρ : Env) : Value.Refines (v18 ρ) (v61 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_18 ρ) (eval_61 ρ)) (Numeric.sound ρ n18 n61 rfl)

theorem p27 (ρ : Env) : Value.Refines (v53 ρ) (v61 ρ) :=
  (p25 ρ).trans (p26 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n53) (Expr.eval ρ n61) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_53 ρ) (eval_61 ρ)) (p27 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n53) : (Expr.eval ρ n53) = (Expr.eval ρ n61) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := ∃ x, (v1 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.castNZ.defined (v1 ρ)

def d8 (ρ : Env) : Prop := ∃ x, (v7 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castZQ.defined (v7 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castQR.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castRC.defined (v9 ρ)

def d44 (ρ : Env) : Prop := True
theorem domain_44 (ρ : Env) : Value.Defined (v44 ρ) ↔ d44 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d45 (ρ : Env) : Prop := ∃ x, (v44 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_45 (ρ : Env) : Value.Defined (v45 ρ) ↔ d45 ρ :=
  Functions.castZQ.defined (v44 ρ)

def d46 (ρ : Env) : Prop := ∃ x, (v45 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  Functions.castQR.defined (v45 ρ)

def d47 (ρ : Env) : Prop := ∃ x, (v46 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_47 (ρ : Env) : Value.Defined (v47 ρ) ↔ d47 ρ :=
  Functions.castRC.defined (v46 ρ)

def d53 (ρ : Env) : Prop := (d10 ρ) ∧ (d47 ρ)
theorem domain_53 (ρ : Env) : Value.Defined (v53 ρ) ↔ d53 ρ :=
  (Value.defined_add (v10 ρ) (v47 ρ)).trans (and_congr (domain_10 ρ) (domain_47 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n53 ↔ (d53 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_53 ρ))).trans (domain_53 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v1 ρ) (total_1 ρ)
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v7 ρ) (total_7 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_44 (ρ : Env) : Value.Defined (v44 ρ) :=
  ⟨_, rfl⟩
theorem total_45 (ρ : Env) : Value.Defined (v45 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v44 ρ) (total_44 ρ)
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v45 ρ) (total_45 ρ)
theorem total_47 (ρ : Env) : Value.Defined (v47 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v46 ρ) (total_46 ρ)
theorem total_53 (ρ : Env) : Value.Defined (v53 ρ) :=
  (Value.defined_add (v10 ρ) (v47 ρ)).mpr ⟨(total_10 ρ), (total_47 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n53 := Eq.mpr (congrArg Value.Defined (eval_53 ρ)) (total_53 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .complex := (.complex (0) (1))
def n1 : Expr .natural := (.nat (1))
def n7 : Expr .integer := (.castNZ n1)
def n8 : Expr .rational := (.castZQ n7)
def n9 : Expr .real := (.castQR n8)
def n10 : Expr .complex := (.castRC n9)
def n11 : Expr .complex := (.complex (1) (0))
def n18 : Expr .complex := (.complex (0) (0))
def n24 : Expr .complex := (.mulC n0 n11)
def n25 : Expr .bool := (.bool true)
def n26 : Expr .complex := (.mulC n10 n0)
def n29 : Expr .complex := (.addC n0 n18)
def n30 : Expr .complex := (.addC n0 n0)
def n35 : Expr .complex := (.complex (0) (2))
def n36 : Expr .complex := (.mulC n10 n11)
def n37 : Expr .complex := (.mulC n0 n0)
def n44 : Expr .integer := (.int (-1))
def n45 : Expr .rational := (.castZQ n44)
def n46 : Expr .real := (.castQR n45)
def n47 : Expr .complex := (.castRC n46)
def n52 : Expr .complex := (.addC n47 n18)
def n53 : Expr .complex := (.addC n10 n47)
def n57 : Expr .natural := (.nat (0))
def n58 : Expr .integer := (.castNZ n57)
def n59 : Expr .rational := (.castZQ n58)
def n60 : Expr .real := (.castQR n59)
def n61 : Expr .complex := (.castRC n60)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n0
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n10
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 0) := .constant Tensor.nilValue
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t5 γ) (t6 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t0 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t0 γ) (t6 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t5 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .complex) 2) 0) := .constant Tensor.nilValue
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .complex) 2) 1) := .binary Tensor.consValue (t10 γ) (t11 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .complex) 2) 2) := .binary Tensor.consValue (t8 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n11
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t14 γ) (t9 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary (Tensor.matvecValue Value.add Value.mul (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 2 2) (t13 γ) (t15 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n18
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t5 γ) (t0 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t18 γ) (t17 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t0 γ) (t14 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t20 γ) (t19 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t0 γ) (t0 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t22 γ) (t17 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t5 γ) (t14 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t24 γ) (t23 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t25 γ) (t6 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t21 γ) (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n24
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n25
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t29 γ) (t0 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n26
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t0 γ) (t17 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n29
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t0 γ) (t0 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n30
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n35
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t29 γ) (t36 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n36
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t29 γ) (t5 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n37
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n47
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t29 γ) (t41 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t41 γ) (t17 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n52
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t5 γ) (t41 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n53
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n61
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t29 γ) (t47 γ)
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t47 γ) (t6 γ)
noncomputable def t50 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t36 γ) (t49 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p0 γ) (p2 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p1 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.vector (.scalar .complex) 2)) (b := (.vector (.vector (.scalar .complex) 2) 0)) (c := (.vector (.vector (.scalar .complex) 2) 1)) Tensor.consValue (p6 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.vector (.scalar .complex) 2)) (b := (.vector (.vector (.scalar .complex) 2) 1)) (c := (.vector (.vector (.scalar .complex) 2) 2)) Tensor.consValue (p4 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .refl (t14 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p10 γ) (p5 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .binary (a := (.vector (.vector (.scalar .complex) 2) 2)) (b := (.vector (.scalar .complex) 2)) (c := (.vector (.scalar .complex) 2)) (Tensor.matvecValue Value.add Value.mul (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 2 2) (p9 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t27 γ) := .ofEq (fun ξ ρ => (Eq.mpr (congrArg (fun w0 : Option ((.scalar .complex) : Binding.Ty).denote => ((Tensor.matvecValue Value.add Value.mul (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 2 2) (Tensor.consValue (Tensor.consValue ((t0 γ).eval ξ ρ) (Tensor.consValue w0 ((t6 γ).eval ξ ρ))) (Tensor.consValue (Tensor.consValue w0 (Tensor.consValue ((t0 γ).eval ξ ρ) ((t6 γ).eval ξ ρ))) ((t11 γ).eval ξ ρ))) (Tensor.consValue ((t14 γ).eval ξ ρ) (Tensor.consValue ((t0 γ).eval ξ ρ) ((t6 γ).eval ξ ρ)))) = (Tensor.consValue (Value.add (Value.mul ((t0 γ).eval ξ ρ) ((t14 γ).eval ξ ρ)) (Value.add (Value.mul w0 ((t0 γ).eval ξ ρ)) ((t17 γ).eval ξ ρ))) (Tensor.consValue (Value.add (Value.mul w0 ((t14 γ).eval ξ ρ)) (Value.add (Value.mul ((t0 γ).eval ξ ρ) ((t0 γ).eval ξ ρ)) ((t17 γ).eval ξ ρ))) ((t6 γ).eval ξ ρ)))) (show n10.eval ξ = some (Functions.castRC.value (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0))))) from Eq.trans (congrArg Functions.castRC.apply (show n9.eval ξ = some (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0)))) from Eq.trans (congrArg Functions.castQR.apply (show n8.eval ξ = some (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0))) from Eq.trans (congrArg Functions.castZQ.apply (show n7.eval ξ = some (Functions.castNZ.value ((n1.eval ξ).getD 0)) from Eq.trans (congrArg Functions.castNZ.apply (show n1.eval ξ = some ((n1.eval ξ).getD 0) from rfl)) (Tensor.apply_some Functions.castNZ ((n1.eval ξ).getD 0) True.intro))) (Tensor.apply_some Functions.castZQ (Functions.castNZ.value ((n1.eval ξ).getD 0)) True.intro))) (Tensor.apply_some Functions.castQR (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0))) True.intro))) (Tensor.apply_some Functions.castRC (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0)))) True.intro))) rfl))
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p0 γ) (p10 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t28 γ) := .ofEq (fun _ _ => rfl)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .refl (t28 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t30 γ) := .scalarSimplify n24 n25 n0 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .refl (t29 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p0 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t0 γ) := .guardTrue (t0 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t0 γ) := .trans (p20 γ) (p0 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t0 γ) := .trans (p19 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t0 γ) := .trans (p17 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t0 γ) := .trans (p16 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t0 γ) := .trans (p15 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t0 γ) := .trans (p14 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p1 γ) (p0 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t31 γ) := .ofEq (fun _ _ => rfl)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .refl (t31 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t30 γ) := .scalarSimplify n26 n25 n0 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t0 γ) := .trans (p30 γ) (p22 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t0 γ) := .trans (p29 γ) (p31 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t0 γ) := .trans (p28 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t0 γ) := .trans (p27 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t32 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p34 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t33 γ) := .ofEq (fun _ _ => rfl)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .refl (t33 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t30 γ) := .scalarSimplify n29 n25 n0 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t0 γ) := .trans (p39 γ) (p22 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t0 γ) := .trans (p38 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t0 γ) := .trans (p37 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t0 γ) := .trans (p36 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t34 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p26 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t35 γ) := .ofEq (fun _ _ => rfl)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .refl (t35 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t37 γ) := .scalarSimplify n30 n25 n35 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .refl (t36 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t36 γ) := .guardTrue (t36 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t36 γ) := .trans (p50 γ) (p48 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t36 γ) := .trans (p49 γ) (p51 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t36 γ) := .trans (p47 γ) (p52 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t36 γ) := .trans (p46 γ) (p53 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t36 γ) := .trans (p45 γ) (p54 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t36 γ) := .trans (p44 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p1 γ) (p10 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t38 γ) := .ofEq (fun _ _ => rfl)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .refl (t38 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t39 γ) := .scalarSimplify n36 n25 n10 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p1 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t5 γ) := .guardTrue (t5 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t5 γ) := .trans (p62 γ) (p1 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t5 γ) := .trans (p61 γ) (p63 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t5 γ) := .trans (p60 γ) (p64 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t5 γ) := .trans (p59 γ) (p65 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t5 γ) := .trans (p58 γ) (p66 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t5 γ) := .trans (p57 γ) (p67 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p0 γ) (p0 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t40 γ) := .ofEq (fun _ _ => rfl)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .refl (t40 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t42 γ) := .scalarSimplify n37 n25 n47 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .refl (t41 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p73 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .guardTrue (t41 γ)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .trans (p75 γ) (p73 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .trans (p74 γ) (p76 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t41 γ) := .trans (p72 γ) (p77 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t41 γ) := .trans (p71 γ) (p78 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t41 γ) := .trans (p70 γ) (p79 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t41 γ) := .trans (p69 γ) (p80 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t43 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p81 γ) (p35 γ)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t44 γ) := .ofEq (fun _ _ => rfl)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t44 γ) := .refl (t44 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t42 γ) := .scalarSimplify n52 n25 n47 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t41 γ) := .trans (p85 γ) (p77 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t41 γ) := .trans (p84 γ) (p86 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t41 γ) := .trans (p83 γ) (p87 γ)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t41 γ) := .trans (p82 γ) (p88 γ)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t45 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p68 γ) (p89 γ)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .ofEq (fun _ _ => rfl)
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .refl (t46 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t48 γ) := .scalarSimplify n53 n25 n61 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t47 γ) := .refl (t47 γ)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t48 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p94 γ)
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t47 γ) := .guardTrue (t47 γ)
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t47 γ) := .trans (p96 γ) (p94 γ)
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t47 γ) := .trans (p95 γ) (p97 γ)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t47 γ) := .trans (p93 γ) (p98 γ)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t47 γ) := .trans (p92 γ) (p99 γ)
theorem p101 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t47 γ) := .trans (p91 γ) (p100 γ)
theorem p102 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t47 γ) := .trans (p90 γ) (p101 γ)
theorem p103 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t49 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p102 γ) (p2 γ)
theorem p104 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t50 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p56 γ) (p103 γ)
theorem p105 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t50 γ) := .trans (p13 γ) (p104 γ)
theorem p106 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t50 γ) := .trans (p12 γ) (p105 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t50 γ) := (p106 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t16 γ).eval ξ ρ = (t50 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t16 γ).eval ξ ρ) ↔ Value.Defined ((t50 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
