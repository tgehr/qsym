import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (0))
def n13 : Expr .natural := (.nat (10))
abbrev c0 (δ : ℕ → ℕ) : List Binding.Ty := []
abbrev c1 (δ : ℕ → ℕ) : List Binding.Ty := (.vector (.scalar .real) (δ 0)) :: (c0 δ)
abbrev c2 (δ : ℕ → ℕ) : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: (c1 δ)
abbrev c3 (δ : ℕ → ℕ) : List Binding.Ty := (.scalar .natural) :: (c2 δ)
abbrev c4 (δ : ℕ → ℕ) : List Binding.Ty := (.scalar .natural) :: (c1 δ)
noncomputable def t0 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .var .here
noncomputable def t1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .scalar n1
noncomputable def t3 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Functions.subN.apply (t0 δ γ) (t2 δ γ)
noncomputable def t4 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .app (t1 δ γ) (t3 δ γ)
noncomputable def t5 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Functions.addN.apply (t0 δ γ) (t2 δ γ)
noncomputable def t6 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .app (t1 δ γ) (t5 δ γ)
noncomputable def t7 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .integer) := .unary Functions.castNZ.apply (t0 δ γ)
noncomputable def t8 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .bool) := .unary Functions.nonzeroZ.apply (t7 δ γ)
noncomputable def t9 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .bool) := .unary Value.not (t8 δ γ)
noncomputable def t10 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .scalar n3
noncomputable def t11 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Value.mask (t9 δ γ) (t10 δ γ)
noncomputable def t12 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .bool) := .unary Value.not (t9 δ γ)
noncomputable def t13 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .scalar n13
noncomputable def t14 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .bool) := .binary Functions.leN.apply (t0 δ γ) (t13 δ γ)
noncomputable def t15 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Value.mask (t14 δ γ) (t4 δ γ)
noncomputable def t16 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .bool) := .unary Value.not (t14 δ γ)
noncomputable def t17 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Value.mask (t16 δ γ) (t6 δ γ)
noncomputable def t18 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Functions.addN.apply (t15 δ γ) (t17 δ γ)
noncomputable def t19 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Value.mask (t12 δ γ) (t18 δ γ)
noncomputable def t20 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c3 δ) (.scalar .natural) := .binary Functions.addN.apply (t11 δ γ) (t19 δ γ)
noncomputable def t21 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c2 δ) (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t20 δ γ)
noncomputable def t22 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c1 δ) (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t21 δ γ))
noncomputable def t23 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.arrow (.vector (.scalar .real) (δ 0)) (.arrow (.scalar .natural) (.scalar .natural))) := .lam (t22 δ γ)
noncomputable def t24 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c4 δ) (.scalar .natural) := .var .here
noncomputable def t25 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c4 δ) (.scalar .natural) := .scalar n13
noncomputable def t26 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c4 δ) (.scalar .bool) := .binary Functions.leN.apply (t24 δ γ) (t25 δ γ)
noncomputable def t27 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c4 δ) (.scalar .natural) := .scalar n3
noncomputable def t28 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c4 δ) (.scalar .natural) := .binary Binding.guardValue (t26 δ γ) (t27 δ γ)
noncomputable def t29 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c1 δ) (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t28 δ γ)
noncomputable def t30 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.arrow (.vector (.scalar .real) (δ 0)) (.arrow (.scalar .natural) (.scalar .natural))) := .lam (t29 δ γ)
noncomputable def rec22 (δ : ℕ → ℕ) (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c1 δ)) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t11 δ γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t12 δ γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.branch (.constant (fun x => (t14 δ γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t3 δ γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))) (.branch (.constant (fun x => (t16 δ γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t5 δ γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0)))) (.constant (fun _ => some 0))))
theorem fixed22 (δ : ℕ → ℕ) (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c1 δ)) : (t22 δ γ).eval ξ ρ = some (FixedPoint.value (rec22 δ γ ξ ρ).functional) := Recursion.fixed_program (rec22 δ γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem unroll22 (δ : ℕ → ℕ) (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c1 δ)) : (t22 δ γ).eval ξ ρ = (Binding.Expr.app (.lam (t21 δ γ)) (t22 δ γ)).eval ξ ρ := Recursion.program_unfold (rec22 δ γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem solve22 (δ : ℕ → ℕ) (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c1 δ)) : (t22 δ γ).eval ξ ρ = (t29 δ γ).eval ξ ρ :=
  Eq.trans (fixed22 δ γ ξ ρ) (congrArg some (Recursion.solve_nat_cutoff (rec22 δ γ ξ ρ) ((n3.eval ξ).getD 0) ((n13.eval ξ).getD 0) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _)))).symm)))
theorem p0 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t21 δ γ) (t21 δ γ) := .refl (t21 δ γ)
theorem p1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t22 δ γ) (t22 δ γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 δ γ))
theorem p2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t22 δ γ) (t29 δ γ) := .ofEq (fun ξ ρ => solve22 δ γ ξ ρ)
theorem p3 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t24 δ γ) (t24 δ γ) := .refl (t24 δ γ)
theorem p4 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t25 δ γ) (t25 δ γ) := .refl (t25 δ γ)
theorem p5 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t26 δ γ) (t26 δ γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p3 δ γ) (p4 δ γ)
theorem p6 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t27 δ γ) (t27 δ γ) := .refl (t27 δ γ)
theorem p7 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t28 δ γ) (t28 δ γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p5 δ γ) (p6 δ γ)
theorem p8 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t29 δ γ) (t29 δ γ) := .lam (p7 δ γ)
theorem p9 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t22 δ γ) (t29 δ γ) := .trans (p2 δ γ) (p8 δ γ)
theorem p10 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t22 δ γ) (t29 δ γ) := .trans (p1 δ γ) (p9 δ γ)
theorem p11 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t23 δ γ) (t30 δ γ) := .lam (p10 δ γ)
theorem reduction (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t23 δ γ) (t30 δ γ) := (p11 δ γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : (t23 ξ.natural γ).eval ξ ρ = (t30 ξ.natural γ).eval ξ ρ := Binding.Reduction.sound (reduction ξ.natural γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : Value.Defined ((t23 ξ.natural γ).eval ξ ρ) ↔ Value.Defined ((t30 ξ.natural γ).eval ξ ρ) := Binding.Reduction.defined (reduction ξ.natural γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
