import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .real := (.real (0))
def n17 : Expr .bool := (.nonzeroR n2)
def n18 : Expr .bool := (.bool false)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := Value.nonzero (v2 ρ)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v17 ρ) (v18 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_18 ρ)) (Numeric.sound ρ n17 n18 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n18) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_18 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n18) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  (Value.defined_nonzero (v2 ρ)).mpr (total_2 ρ)
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n2 : Expr .real := (.real (0))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
def n3 : Expr .real := (.invR n2)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .real) := Value.inv (v2 ρ)
def n16 : Expr .bool := (.bool true)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .bool) := some true
def n17 : Expr .bool := (.nonzeroR n2)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := Value.nonzero (v2 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v16 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v17 ρ) :=
  Domain.inverse (x := (v2 ρ)) (d := (v16 ρ)) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n3) (Expr.eval ρ Certificate.n18) :=
  Domain.simplify (q3 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n18) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n3 ↔ (Expr.eval ρ Certificate.n18) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
namespace QSym.BindingCertificate
def n1 : Expr .real := (.real (1))
def n2 : Expr .real := (.real (0))
def n3 : Expr .real := (.invR n2)
def n18 : Expr .bool := (.bool false)
abbrev c0 : List Binding.Ty := []
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n3
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n1
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 0) := .constant Tensor.nilValue
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 1) := .binary Tensor.consValue (t3 γ) (t4 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary Tensor.consValue (t2 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t6 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t2 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t5 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Value.and (t8 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n18
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Value.and (t11 γ) (t9 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .refl (t4 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 1)) (c := (.vector (.scalar .real) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .unary (a := (.vector (.scalar .real) 2)) (b := (.scalar .bool)) Binding.definedValue (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t10 γ) := .ofEq (fun ξ ρ => Tensor.defined_cons ((t2 γ).eval ξ ρ) ((t5 γ).eval ξ ρ))
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .unary (a := (.scalar .real)) (b := (.scalar .bool)) Binding.definedValue (p0 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t11 γ) := .scalarDomain n3 n18 QSym.BindingScalar0.DomainCertificate.domain_correct
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t11 γ) := .trans (p8 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t11 γ) := .trans (p7 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t12 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p11 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t11 γ) := .ofEq (fun _ _ => rfl)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t11 γ) := .trans (p14 γ) (p9 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t11 γ) := .trans (p13 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t11 γ) := .trans (p6 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t11 γ) := .trans (p5 γ) (p17 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t11 γ) := (p18 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t7 γ).eval ξ ρ = (t11 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t7 γ).eval ξ ρ) ↔ Value.Defined ((t11 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t7 γ).eval ξ ρ = n18.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n18 : Expr .bool := (.bool false)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n18) (Expr.eval ρ n18) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_18 ρ) (eval_18 ρ)) (Value.refines_refl (v18 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n18) : (Expr.eval ρ n18) = (Expr.eval ρ n18) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v18 ρ) := (total_18 ρ)
def d18 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n18 ↔ (d18 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_18 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n18 := Eq.mpr (congrArg Value.Defined (eval_18 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t7 γ).eval ξ ρ) (FunctionScalar.n18.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n18.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t7 γ).eval ξ ρ)) : ((BindingCertificate.t7 γ).eval ξ ρ) = (FunctionScalar.n18.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
