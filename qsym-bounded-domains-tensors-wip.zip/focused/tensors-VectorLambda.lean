import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.vector (.scalar .real) 2) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c1 (.vector (.scalar .real) 2) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c1 (.scalar .real) := .binary (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (t0 γ) (t0 γ)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.vector (.scalar .real) 2) (.scalar .real)) := .lam (t1 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .binary (a := (.vector (.scalar .real) 2)) (b := (.vector (.scalar .real) 2)) (c := (.scalar .real)) (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 2) (p0 γ) (p0 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .lam (p1 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := (p2 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t2 γ).eval ξ ρ = (t2 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t2 γ).eval ξ ρ) ↔ Value.Defined ((t2 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
