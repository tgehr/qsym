import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n5 : Expr .integer := (.castNZ n0)
def n6 : Expr .rational := (.castZQ n5)
def n7 : Expr .real := (.castQR n6)
def n15 : Expr .bool := (.bool false)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .constant none
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n7
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 0) := .constant Tensor.nilValue
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 1) := .binary Tensor.consValue (t4 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary Tensor.consValue (t0 γ) (t6 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t0 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t6 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Value.and (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n15
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Value.and (t12 γ) (t10 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .refl (t4 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 1)) (c := (.vector (.scalar .real) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .unary (a := (.vector (.scalar .real) 2)) (b := (.scalar .bool)) Binding.definedValue (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t11 γ) := .ofEq (fun ξ ρ => Tensor.defined_cons ((t0 γ).eval ξ ρ) ((t6 γ).eval ξ ρ))
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .unary (a := (.scalar .real)) (b := (.scalar .bool)) Binding.definedValue (p0 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t12 γ) := .ofEq (fun _ _ => rfl)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t12 γ) := .trans (p8 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t12 γ) := .trans (p7 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .refl (t10 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t13 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p11 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t12 γ) := .ofEq (fun _ _ => rfl)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t12 γ) := .trans (p14 γ) (p9 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t12 γ) := .trans (p13 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t12 γ) := .trans (p6 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t12 γ) := .trans (p5 γ) (p17 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t12 γ) := (p18 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t8 γ).eval ξ ρ = (t12 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t8 γ).eval ξ ρ) ↔ Value.Defined ((t12 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t8 γ).eval ξ ρ = n15.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool false)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t8 γ).eval ξ ρ) (FunctionScalar.n15.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n15.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t8 γ).eval ξ ρ)) : ((BindingCertificate.t8 γ).eval ξ ρ) = (FunctionScalar.n15.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
