import QSym.Refinement
import QSym.AxiomCheck
namespace QSym.Generated
theorem r_bool_and_left_false (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.and (some false) v_p) (some false) := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_bool_and_left_false


theorem r_bool_and_left_true (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.and (some true) v_p) v_p := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_bool_and_left_true


theorem r_bool_and_right_true (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.and v_p (some true)) v_p := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_bool_and_right_true


theorem r_bool_and_same (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.and v_p v_p) v_p := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_bool_and_same


theorem r_bool_and_swap (v_p : Option (Ty.denote .bool)) (v_q : Option (Ty.denote .bool))
    (hp0 : Value.Defined v_q) :
    Value.Refines (Value.and v_p v_q) (Value.and v_q v_p) := by
  cases v_p <;> cases v_q
  all_goals qsym_rule

#qsym_check_axioms r_bool_and_swap


theorem r_bool_not_false :
    Value.Refines (Value.not (some false)) (some true) := by
  all_goals qsym_rule

#qsym_check_axioms r_bool_not_false


theorem r_bool_not_not (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.not (Value.not v_p)) v_p := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_bool_not_not


theorem r_bool_not_true :
    Value.Refines (Value.not (some true)) (some false) := by
  all_goals qsym_rule

#qsym_check_axioms r_bool_not_true


theorem r_bool_or_right_true (v_p : Option (Ty.denote .bool)) :
    Value.Refines (Value.or v_p (some true)) (some true) := by
  cases v_p
  all_goals qsym_rule

#qsym_check_axioms r_bool_or_right_true


theorem r_complex_add_assoc (v_x : Option (Ty.denote .complex)) (v_y : Option (Ty.denote .complex)) (v_z : Option (Ty.denote .complex)) :
    (Value.add (Value.add v_x v_y) v_z) = (Value.add v_x (Value.add v_y v_z)) := by
  cases v_x <;> cases v_y <;> cases v_z
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_complex_add_assoc


theorem r_complex_add_comm (v_x : Option (Ty.denote .complex)) (v_y : Option (Ty.denote .complex)) :
    (Value.add v_x v_y) = (Value.add v_y v_x) := by
  cases v_x <;> cases v_y
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_complex_add_comm


theorem r_complex_add_unit (v_x : Option (Ty.denote .complex)) :
    (Value.add v_x (some ((((0) : Int) : ℂ) + (((0) : Int) : ℂ) * Complex.I))) = v_x := by
  cases v_x
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_complex_add_unit


theorem r_complex_div_self (v_x : Option (Ty.denote .complex)) :
    Value.Refines (Value.mul v_x (Value.inv v_x)) (some ((((1) : Int) : ℂ) + (((0) : Int) : ℂ) * Complex.I)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_complex_div_self


theorem r_complex_mul_assoc (v_x : Option (Ty.denote .complex)) (v_y : Option (Ty.denote .complex)) (v_z : Option (Ty.denote .complex)) :
    (Value.mul (Value.mul v_x v_y) v_z) = (Value.mul v_x (Value.mul v_y v_z)) := by
  cases v_x <;> cases v_y <;> cases v_z
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_complex_mul_assoc


theorem r_complex_mul_comm (v_x : Option (Ty.denote .complex)) (v_y : Option (Ty.denote .complex)) :
    (Value.mul v_x v_y) = (Value.mul v_y v_x) := by
  cases v_x <;> cases v_y
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_complex_mul_comm


theorem r_complex_mul_unit (v_x : Option (Ty.denote .complex)) :
    (Value.mul v_x (some ((((1) : Int) : ℂ) + (((0) : Int) : ℂ) * Complex.I))) = v_x := by
  cases v_x
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_complex_mul_unit


theorem r_natural_add_zero (v_x : Option (Ty.denote .natural)) :
    Value.Refines (Functions.addN.apply v_x (some ((0) : ℕ))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_natural_add_zero


theorem r_natural_substitute (v_x : Option (Ty.denote .natural)) (v_y : Option (Ty.denote .natural))
    (hp0 : Value.Refines (Value.not (Functions.nonzeroZ.apply (Functions.addZ.apply (Functions.castNZ.apply v_x) (Functions.mulZ.apply (some ((-1) : ℤ)) (Functions.castNZ.apply v_y))))) (some true))
    (hp1 : Value.Defined v_y) :
    Value.Refines v_x v_y := by
  cases v_x <;> cases v_y
  all_goals qsym_rule

#qsym_check_axioms r_natural_substitute


theorem r_real_add_assoc (v_x : Option (Ty.denote .real)) (v_y : Option (Ty.denote .real)) (v_z : Option (Ty.denote .real)) :
    (Value.add (Value.add v_x v_y) v_z) = (Value.add v_x (Value.add v_y v_z)) := by
  cases v_x <;> cases v_y <;> cases v_z
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_real_add_assoc


theorem r_real_add_comm (v_x : Option (Ty.denote .real)) (v_y : Option (Ty.denote .real)) :
    (Value.add v_x v_y) = (Value.add v_y v_x) := by
  cases v_x <;> cases v_y
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_real_add_comm


theorem r_real_add_unit (v_x : Option (Ty.denote .real)) :
    (Value.add v_x (some (((0) : Int) : ℝ))) = v_x := by
  cases v_x
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_real_add_unit


theorem r_real_collect (v_a : Option (Ty.denote .real)) (v_b : Option (Ty.denote .real)) (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.add (Value.mul v_a v_x) (Value.mul v_b v_x)) (Value.mul (Value.add v_a v_b) v_x) := by
  cases v_a <;> cases v_b <;> cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_collect


theorem r_real_distribute (v_x : Option (Ty.denote .real)) (v_y : Option (Ty.denote .real)) (v_z : Option (Ty.denote .real)) :
    Value.Refines (Value.mul v_x (Value.add v_y v_z)) (Value.add (Value.mul v_x v_y) (Value.mul v_x v_z)) := by
  cases v_x <;> cases v_y <;> cases v_z
  all_goals qsym_rule

#qsym_check_axioms r_real_distribute


theorem r_real_div_self (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.mul v_x (Value.inv v_x)) (some (((1) : Int) : ℝ)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_div_self


theorem r_real_inverse_positive (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.lt (some (((0) : Int) : ℝ)) (Value.inv v_x)) (Value.lt (some (((0) : Int) : ℝ)) v_x) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_inverse_positive


theorem r_real_lt_self (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.lt v_x v_x) (some false) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_lt_self


theorem r_real_mask_true (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.mask (some true) v_x) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_mask_true


theorem r_real_mul_assoc (v_x : Option (Ty.denote .real)) (v_y : Option (Ty.denote .real)) (v_z : Option (Ty.denote .real)) :
    (Value.mul (Value.mul v_x v_y) v_z) = (Value.mul v_x (Value.mul v_y v_z)) := by
  cases v_x <;> cases v_y <;> cases v_z
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_real_mul_assoc


theorem r_real_mul_comm (v_x : Option (Ty.denote .real)) (v_y : Option (Ty.denote .real)) :
    (Value.mul v_x v_y) = (Value.mul v_y v_x) := by
  cases v_x <;> cases v_y
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_real_mul_comm


theorem r_real_mul_unit (v_x : Option (Ty.denote .real)) :
    (Value.mul v_x (some (((1) : Int) : ℝ))) = v_x := by
  cases v_x
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_real_mul_unit


theorem r_real_mul_zero (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.mul v_x (some (((0) : Int) : ℝ))) (some (((0) : Int) : ℝ)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_mul_zero


theorem r_real_nonzero_scale (v_p : Option (Ty.denote .real)) (v_x : Option (Ty.denote .real)) (v_a : Option (Ty.denote .real))
    (hp0 : Value.Refines (Value.not (Value.nonzero (Value.add v_p (Value.mul (some (((-1) : Int) : ℝ)) (Value.mul v_a v_x))))) (some true))
    (hp1 : Value.Refines (Value.nonzero v_a) (some true))
    (hp2 : Value.Defined v_a)
    (hp3 : Value.Defined v_x) :
    Value.Refines (Value.nonzero v_p) (Value.nonzero v_x) := by
  cases v_p <;> cases v_x <;> cases v_a
  all_goals qsym_rule

#qsym_check_axioms r_real_nonzero_scale


theorem r_real_positive_nonnegative (v_x : Option (Ty.denote .real))
    (hp0 : Value.Refines (Value.lt (some (((0) : Int) : ℝ)) v_x) (some true)) :
    Value.Refines (Value.le (some (((0) : Int) : ℝ)) v_x) (some true) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_positive_nonnegative


theorem r_real_positive_nonnegative_test (v_x : Option (Ty.denote .real))
    (hp0 : Value.Refines (Value.le (some (((0) : Int) : ℝ)) v_x) (some true)) :
    Value.Refines (Value.lt (some (((0) : Int) : ℝ)) v_x) (Value.nonzero v_x) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_positive_nonnegative_test


theorem r_real_pow_one (v_x : Option (Ty.denote .real)) :
    Value.Refines (v_x.map (fun x => x ^ (1))) v_x := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_pow_one


theorem r_real_pow_split (v_x : Option (Ty.denote .real)) (v_m : Nat) (v_n : Nat) :
    Value.Refines (v_x.map (fun x => x ^ (v_m + v_n))) (Value.mul (v_x.map (fun x => x ^ v_m)) (v_x.map (fun x => x ^ v_n))) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_pow_split


theorem r_real_solve_affine (v_x : Option (Ty.denote .real)) (v_a : Option (Ty.denote .real)) (v_b : Option (Ty.denote .real))
    (hp0 : Value.Refines (Value.not (Value.nonzero (Value.add (Value.mul v_a v_x) v_b))) (some true))
    (hp1 : Value.Refines (Value.nonzero v_a) (some true))
    (hp2 : Value.Defined v_a)
    (hp3 : Value.Defined v_b) :
    Value.Refines v_x (Value.mul (Value.mul (some (((-1) : Int) : ℝ)) v_b) (Value.inv v_a)) := by
  cases v_x <;> cases v_a <;> cases v_b
  all_goals qsym_rule

#qsym_check_axioms r_real_solve_affine


theorem r_real_zero_mul (v_x : Option (Ty.denote .real)) :
    Value.Refines (Value.mul (some (((0) : Int) : ℝ)) v_x) (some (((0) : Int) : ℝ)) := by
  cases v_x
  all_goals qsym_rule

#qsym_check_axioms r_real_zero_mul


end QSym.Generated
