import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n32 : Expr .bool := (.bool true)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n32) (Expr.eval ρ n32) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_32 ρ) (eval_32 ρ)) (Value.refines_refl (v32 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n32) : (Expr.eval ρ n32) = (Expr.eval ρ n32) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v32 ρ) := (total_32 ρ)
def d32 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n32 ↔ (d32 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_32 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n32 := Eq.mpr (congrArg Value.Defined (eval_32 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n3 : Expr .natural := (.nat (0))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n32 : Expr .bool := (.bool true)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v32 ρ) :=
  Domain.leaf _
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n3) (Expr.eval ρ Certificate.n32) :=
  Domain.simplify (q3 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n32) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n3 ↔ (Expr.eval ρ Certificate.n32) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n32 : Expr .bool := (.bool true)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n32) (Expr.eval ρ n32) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_32 ρ) (eval_32 ρ)) (Value.refines_refl (v32 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n32) : (Expr.eval ρ n32) = (Expr.eval ρ n32) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v32 ρ) := (total_32 ρ)
def d32 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n32 ↔ (d32 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_32 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n32 := Eq.mpr (congrArg Value.Defined (eval_32 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n13 : Expr .natural := (.nat (10))
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n32 : Expr .bool := (.bool true)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := some true
def n52 : Expr .natural := (.varN 8)
noncomputable def v52 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 8)
def n53 : Expr .bool := (.leN n52 n13)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v52 ρ) (v13 ρ)
theorem q52 (ρ : Env) : Domain.Correct (v52 ρ) (v32 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v32 ρ) :=
  Domain.leaf _
theorem q53 (ρ : Env) : Domain.Correct (v53 ρ) (v32 ρ) :=
  Domain.total2 Functions.leN (x := (v52 ρ)) (y := (v13 ρ)) (dx := (v32 ρ)) (dy := (v32 ρ)) (fun _ _ => True.intro) (q52 ρ) (q13 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n53) (Expr.eval ρ Certificate.n32) :=
  Domain.simplify (q53 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n32) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n53 ↔ (Expr.eval ρ Certificate.n32) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .natural := (.nat (10))
def n32 : Expr .bool := (.bool true)
def n55 : Expr .natural := (.varN 9)
def n56 : Expr .bool := (.leN n55 n13)
def n58 : Expr .bool := (.not n56)
def n61 : Expr .bool := (.or n58 n32)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v55 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 9)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v55 ρ) (v13 ρ)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v56 ρ)
noncomputable def v61 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v58 ρ) (v32 ρ)
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl
theorem eval_61 (ρ : Env) : (Expr.eval ρ n61) = (v61 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v61 ρ) (v32 ρ) :=
  (Generated.r_bool_or_right_true (v58 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n61) (Expr.eval ρ n32) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_61 ρ) (eval_32 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n61) : (Expr.eval ρ n61) = (Expr.eval ρ n32) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d55 (ρ : Env) : Prop := True
theorem domain_55 (ρ : Env) : Value.Defined (v55 ρ) ↔ d55 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := True
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d56 (ρ : Env) : Prop := ∃ x y, (v55 ρ) = some x ∧ (v13 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_56 (ρ : Env) : Value.Defined (v56 ρ) ↔ d56 ρ :=
  Functions.leN.defined (v55 ρ) (v13 ρ)

def d58 (ρ : Env) : Prop := (d56 ρ)
theorem domain_58 (ρ : Env) : Value.Defined (v58 ρ) ↔ d58 ρ :=
  (Value.defined_not (v56 ρ)).trans (domain_56 ρ)

def d32 (ρ : Env) : Prop := True
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d61 (ρ : Env) : Prop := (v58 ρ) = some true ∨ ((v58 ρ) = some false ∧ (d32 ρ))
theorem domain_61 (ρ : Env) : Value.Defined (v61 ρ) ↔ d61 ρ :=
  (Value.defined_or (v58 ρ) (v32 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_32 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n61 ↔ (d61 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_61 ρ))).trans (domain_61 ρ)
#qsym_check_axioms definedness
theorem total_55 (ρ : Env) : Value.Defined (v55 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v55 ρ) (v13 ρ) (total_55 ρ) (total_13 ρ)
theorem total_58 (ρ : Env) : Value.Defined (v58 ρ) :=
  (Value.defined_not (v56 ρ)).mpr (total_56 ρ)
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  ⟨_, rfl⟩
theorem total_61 (ρ : Env) : Value.Defined (v61 ρ) :=
  Value.defined_or_total (v58 ρ) (v32 ρ) (total_58 ρ) (total_32 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n61 := Eq.mpr (congrArg Value.Defined (eval_61 ρ)) (total_61 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n13 : Expr .natural := (.nat (10))
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
def n32 : Expr .bool := (.bool true)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := some true
def n55 : Expr .natural := (.varN 9)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 9)
def n56 : Expr .bool := (.leN n55 n13)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v55 ρ) (v13 ρ)
def n57 : Expr .bool := (.and n56 n32)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v56 ρ) (v32 ρ)
def n58 : Expr .bool := (.not n56)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v56 ρ)
def n61 : Expr .bool := (.or n58 n32)
noncomputable def v61 (ρ : Env) : Option (Ty.denote .bool) := Value.or (v58 ρ) (v32 ρ)
theorem q55 (ρ : Env) : Domain.Correct (v55 ρ) (v32 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v32 ρ) :=
  Domain.leaf _
theorem q56 (ρ : Env) : Domain.Correct (v56 ρ) (v32 ρ) :=
  Domain.total2 Functions.leN (x := (v55 ρ)) (y := (v13 ρ)) (dx := (v32 ρ)) (dy := (v32 ρ)) (fun _ _ => True.intro) (q55 ρ) (q13 ρ)
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v32 ρ) :=
  Domain.leaf _
theorem q57 (ρ : Env) : Domain.Correct (v57 ρ) (v61 ρ) :=
  Domain.and (p := (v56 ρ)) (q := (v32 ρ)) (dp := (v32 ρ)) (dq := (v32 ρ)) (q56 ρ) (q32 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n57) (Expr.eval ρ Certificate.n32) :=
  Domain.simplify (q57 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n32) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n57 ↔ (Expr.eval ρ Certificate.n32) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n13 : Expr .natural := (.nat (10))
def n32 : Expr .bool := (.bool true)
def n55 : Expr .natural := (.varN 9)
def n56 : Expr .bool := (.leN n55 n13)
def n57 : Expr .bool := (.and n56 n32)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := some (10)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v55 (ρ : Env) : Option (Ty.denote .natural) := some (ρ.natural 9)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v55 ρ) (v13 ρ)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Value.and (v56 ρ) (v32 ρ)
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl
theorem eval_57 (ρ : Env) : (Expr.eval ρ n57) = (v57 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v57 ρ) (v56 ρ) :=
  (Generated.r_bool_and_right_true (v56 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n57) (Expr.eval ρ n56) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_57 ρ) (eval_56 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n57) : (Expr.eval ρ n57) = (Expr.eval ρ n56) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d55 (ρ : Env) : Prop := True
theorem domain_55 (ρ : Env) : Value.Defined (v55 ρ) ↔ d55 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := True
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d56 (ρ : Env) : Prop := ∃ x y, (v55 ρ) = some x ∧ (v13 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_56 (ρ : Env) : Value.Defined (v56 ρ) ↔ d56 ρ :=
  Functions.leN.defined (v55 ρ) (v13 ρ)

def d32 (ρ : Env) : Prop := True
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d57 (ρ : Env) : Prop := (v56 ρ) = some false ∨ ((v56 ρ) = some true ∧ (d32 ρ))
theorem domain_57 (ρ : Env) : Value.Defined (v57 ρ) ↔ d57 ρ :=
  (Value.defined_and (v56 ρ) (v32 ρ)).trans (or_congr Iff.rfl (and_congr Iff.rfl (domain_32 ρ)))

theorem definedness (ρ : Env) : Expr.Defined ρ n57 ↔ (d57 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_57 ρ))).trans (domain_57 ρ)
#qsym_check_axioms definedness
theorem total_55 (ρ : Env) : Value.Defined (v55 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  ⟨_, rfl⟩
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v55 ρ) (v13 ρ) (total_55 ρ) (total_13 ρ)
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  ⟨_, rfl⟩
theorem total_57 (ρ : Env) : Value.Defined (v57 ρ) :=
  Value.defined_and_total (v56 ρ) (v32 ρ) (total_56 ρ) (total_32 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n57 := Eq.mpr (congrArg Value.Defined (eval_57 ρ)) (total_57 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (0))
def n13 : Expr .natural := (.nat (10))
def n32 : Expr .bool := (.bool true)
def n52 : Expr .natural := (.varN 8)
def n53 : Expr .bool := (.leN n52 n13)
def n55 : Expr .natural := (.varN 9)
def n56 : Expr .bool := (.leN n55 n13)
def n57 : Expr .bool := (.and n56 n32)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: c0
abbrev c2 : List Binding.Ty := (.scalar .natural) :: c1
abbrev c3 : List Binding.Ty := (.scalar .natural) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c2 (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.subN.apply (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t2 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .integer) := .unary Functions.castNZ.apply (t0 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Functions.nonzeroZ.apply (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n3
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t9 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n13
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .binary Functions.leN.apply (t0 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t14 γ) (t4 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t14 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t16 γ) (t6 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t12 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t11 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c1 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t21 γ))
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .unary Binding.inputDomain (t22 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .var .here
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n13
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Functions.leN.apply (t24 γ) (t25 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n3
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Binding.guardValue (t26 γ) (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t28 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .unary Binding.inputDomain (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.definedValue (t28 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t31 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.holdsValue (t26 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .unary Binding.definedValue (t27 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t33 γ) (t34 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .scalar n32
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t33 γ) (t36 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t37 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t36 γ) (t26 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t39 γ) (t36 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t40 γ)
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Value.and (t26 γ) (t36 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t42 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.set (.scalar .natural)) := .set (t26 γ)
noncomputable def rec22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t11 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t12 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.branch (.constant (fun x => (t14 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t3 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))) (.branch (.constant (fun x => (t16 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t5 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0)))) (.constant (fun _ => some 0))))
theorem fixed22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = some (FixedPoint.value (rec22 γ ξ ρ).functional) := Recursion.fixed_program (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem unroll22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (Binding.Expr.app (.lam (t21 γ)) (t22 γ)).eval ξ ρ := Recursion.program_unfold (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem solve22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t29 γ).eval ξ ρ :=
  Eq.trans (fixed22 γ ξ ρ) (congrArg some (Recursion.solve_nat_cutoff (rec22 γ ξ ρ) ((n3.eval ξ).getD 0) ((n13.eval ξ).getD 0) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _)))).symm)))
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 γ))
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t29 γ) := .ofEq (fun ξ ρ => solve22 γ ξ ρ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .refl (t24 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .refl (t25 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p3 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .refl (t27 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p5 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .lam (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t29 γ) := .trans (p2 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t29 γ) := .trans (p1 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t30 γ) := .unary (a := (.arrow (.scalar .natural) (.scalar .natural))) (b := (.set (.scalar .natural))) Binding.inputDomain (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t32 γ) := .domainLam (t28 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p7 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t35 γ) := .definedGuard (t26 γ) (t27 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .unary (a := (.scalar .bool)) (b := (.scalar .bool)) Binding.holdsValue (p5 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t34 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p6 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t36 γ) := .scalarDomain n3 n32 QSym.BindingScalar0.DomainCertificate.domain_correct
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .refl (t36 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t36 γ) := .trans (p17 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t36 γ) := .trans (p16 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t37 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p15 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t37 γ) := .trans (p14 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t37 γ) := .trans (p13 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t38 γ) := .set (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t41 γ) := .setPointwise (fun ξ ρ x => (congrArg₂ Value.and (Binding.holdsDomain (n53.eval ({ ξ with natural := fun i => if i = 8 then x else ξ.natural i })) (n32.eval ({ ξ with natural := fun i => if i = 8 then x else ξ.natural i })) (QSym.BindingScalar1.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 8 then x else ξ.natural i }))) rfl))
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p18 γ) (p5 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t26 γ) := .ofEq (fun _ _ => rfl)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t26 γ) := .trans (p27 γ) (p5 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t26 γ) := .trans (p26 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t42 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .bool)) (c := (.scalar .bool)) Value.and (p29 γ) (p18 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t43 γ) := .set (p30 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t44 γ) := .setPointwise (fun ξ ρ x => (Binding.preserveDomain (n57.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (n56.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (n32.eval ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (QSym.BindingScalar2.DomainCertificate.domain_correct ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i })) (QSym.BindingScalar2.ValueCertificate.refinement ({ ξ with natural := fun i => if i = 9 then x else ξ.natural i }))))
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t44 γ) := .set (p5 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t44 γ) := .trans (p32 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t44 γ) := .trans (p31 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t44 γ) := .trans (p25 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t44 γ) := .trans (p24 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t44 γ) := .trans (p12 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t44 γ) := .trans (p11 γ) (p38 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t44 γ) := (p39 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t23 γ).eval ξ ρ = (t44 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t23 γ).eval ξ ρ) ↔ Value.Defined ((t44 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
