import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n16 : Expr .natural := (.mulN n0 n0)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v0 ρ)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n16) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q16 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n16 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n16 : Expr .natural := (.mulN n0 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v0 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v16 ρ) (v0 ρ) :=
  (Generated.r_natural_mul_one (v0 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d16 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  Functions.mulN.defined (v0 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (domain_16 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v0 ρ) (total_0 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_16 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n18 : Expr .natural := (.mulN n0 n1)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v1 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n18) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q18 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n18 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n18 : Expr .natural := (.mulN n0 n1)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v18 ρ) (v1 ρ) :=
  (Generated.r_natural_one_mul (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n18) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_18 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n18) : (Expr.eval ρ n18) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d18 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  Functions.mulN.defined (v0 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n18 ↔ (d18 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_18 ρ))).trans (domain_18 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v1 ρ) (total_0 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n18 := Eq.mpr (congrArg Value.Defined (eval_18 ρ)) (total_18 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n15 : Expr .natural := (.addN n1 n1)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v1 ρ)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v1 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n15) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q15 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n15 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n15 : Expr .natural := (.addN n1 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v15 ρ) (v1 ρ) :=
  (Generated.r_natural_add_zero (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d15 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  Functions.addN.defined (v1 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (domain_15 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v1 ρ) (v1 ρ) (total_1 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_15 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n19 : Expr .natural := (.addN n0 n1)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v1 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q19 (ρ : Env) : Domain.Correct (v19 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v0 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n19) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q19 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n19 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n19 : Expr .natural := (.addN n0 n1)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v1 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v19 ρ) (v0 ρ) :=
  (Generated.r_natural_add_zero (v0 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n19) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_19 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n19) : (Expr.eval ρ n19) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d19 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_19 (ρ : Env) : Value.Defined (v19 ρ) ↔ d19 ρ :=
  Functions.addN.defined (v0 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n19 ↔ (d19 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_19 ρ))).trans (domain_19 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_19 (ρ : Env) : Value.Defined (v19 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v0 ρ) (v1 ρ) (total_0 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n19 := Eq.mpr (congrArg Value.Defined (eval_19 ρ)) (total_19 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n20 : Expr .natural := (.addN n1 n0)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v0 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q20 (ρ : Env) : Domain.Correct (v20 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v1 ρ)) (y := (v0 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n20) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q20 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n20 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n20 : Expr .natural := (.addN n1 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v1 ρ) (v0 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v20 ρ) (v0 ρ) :=
  (Generated.r_natural_zero_add (v0 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n20) (Expr.eval ρ n0) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_20 ρ) (eval_0 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n20) : (Expr.eval ρ n20) = (Expr.eval ρ n0) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d20 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_20 (ρ : Env) : Value.Defined (v20 ρ) ↔ d20 ρ :=
  Functions.addN.defined (v1 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n20 ↔ (d20 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_20 ρ))).trans (domain_20 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_20 (ρ : Env) : Value.Defined (v20 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v1 ρ) (v0 ρ) (total_1 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n20 := Eq.mpr (congrArg Value.Defined (eval_20 ρ)) (total_20 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n13 : Expr .natural := (.mulN n1 n1)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v1 ρ)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n13) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q13 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n13 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n13 : Expr .natural := (.mulN n1 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v13 ρ) (v1 ρ) :=
  (Generated.r_natural_mul_zero (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d13 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.mulN.defined (v1 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (domain_13 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v1 ρ) (total_1 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n13 := Eq.mpr (congrArg Value.Defined (eval_13 ρ)) (total_13 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n21 : Expr .natural := (.mulN n1 n0)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v0 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q21 (ρ : Env) : Domain.Correct (v21 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v0 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n21) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q21 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n21 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n21 : Expr .natural := (.mulN n1 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v0 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v21 ρ) (v1 ρ) :=
  (Generated.r_natural_mul_one (v1 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n21) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_21 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n21) : (Expr.eval ρ n21) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d21 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_21 (ρ : Env) : Value.Defined (v21 ρ) ↔ d21 ρ :=
  Functions.mulN.defined (v1 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n21 ↔ (d21 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_21 ρ))).trans (domain_21 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_21 (ρ : Env) : Value.Defined (v21 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v0 ρ) (total_1 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n21 := Eq.mpr (congrArg Value.Defined (eval_21 ρ)) (total_21 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n22 : Expr .natural := (.addN n0 n0)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v0 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v0 ρ)) (y := (v0 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n22) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q22 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n22 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n10 : Expr .natural := (.nat (2))
def n22 : Expr .natural := (.addN n0 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v0 ρ) (v0 ρ)
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v22 ρ) (v10 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_10 ρ)) (Numeric.sound ρ n22 n10 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n22) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_22 ρ) (eval_10 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n22) : (Expr.eval ρ n22) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d22 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  Functions.addN.defined (v0 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n22 ↔ (d22 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_22 ρ))).trans (domain_22 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v0 ρ) (v0 ρ) (total_0 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n22 := Eq.mpr (congrArg Value.Defined (eval_22 ρ)) (total_22 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.Certificate

namespace QSym.BindingScalar8.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n10 : Expr .natural := (.nat (2))
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .natural := (.mulN n0 n10)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v10 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v10 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q10 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n23) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q23 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n23 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar8.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n10 : Expr .natural := (.nat (2))
def n23 : Expr .natural := (.mulN n0 n10)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v10 ρ)
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v23 ρ) (v10 ρ) :=
  (Generated.r_natural_one_mul (v10 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n23) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_23 ρ) (eval_10 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n23) : (Expr.eval ρ n23) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d10 (ρ : Env) : Prop := True
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d23 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v10 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  Functions.mulN.defined (v0 ρ) (v10 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n23 ↔ (d23 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_23 ρ))).trans (domain_23 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v10 ρ) (total_0 ρ) (total_10 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n23 := Eq.mpr (congrArg Value.Defined (eval_23 ρ)) (total_23 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.Certificate

namespace QSym.BindingScalar9.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n10 : Expr .natural := (.nat (2))
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n24 : Expr .natural := (.addN n10 n0)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v10 ρ) (v0 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v10 ρ)) (y := (v0 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q10 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n24) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q24 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n24 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar9.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n9 : Expr .natural := (.nat (3))
def n10 : Expr .natural := (.nat (2))
def n24 : Expr .natural := (.addN n10 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v10 ρ) (v0 ρ)
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v24 ρ) (v9 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_24 ρ) (eval_9 ρ)) (Numeric.sound ρ n24 n9 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n24) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_24 ρ) (eval_9 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n24) : (Expr.eval ρ n24) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d10 (ρ : Env) : Prop := True
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d24 (ρ : Env) : Prop := ∃ x y, (v10 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_24 (ρ : Env) : Value.Defined (v24 ρ) ↔ d24 ρ :=
  Functions.addN.defined (v10 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n24 ↔ (d24 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_24 ρ))).trans (domain_24 ρ)
#qsym_check_axioms definedness
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v10 ρ) (v0 ρ) (total_10 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n24 := Eq.mpr (congrArg Value.Defined (eval_24 ρ)) (total_24 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.Certificate

namespace QSym.BindingScalar10.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n10 : Expr .natural := (.nat (2))
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n25 : Expr .natural := (.addN n10 n1)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v10 ρ) (v1 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q25 (ρ : Env) : Domain.Correct (v25 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v10 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q10 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n25) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q25 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n25 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar10.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n10 : Expr .natural := (.nat (2))
def n25 : Expr .natural := (.addN n10 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v10 ρ) (v1 ρ)
theorem eval_10 (ρ : Env) : (Expr.eval ρ n10) = (v10 ρ) := rfl
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v25 ρ) (v10 ρ) :=
  (Generated.r_natural_add_zero (v10 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n10) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_10 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n10) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d10 (ρ : Env) : Prop := True
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d25 (ρ : Env) : Prop := ∃ x y, (v10 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_25 (ρ : Env) : Value.Defined (v25 ρ) ↔ d25 ρ :=
  Functions.addN.defined (v10 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (domain_25 ρ)
#qsym_check_axioms definedness
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v10 ρ) (v1 ρ) (total_10 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_25 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.Certificate

namespace QSym.BindingScalar11.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n9 : Expr .natural := (.nat (3))
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n26 : Expr .natural := (.mulN n0 n9)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v9 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q26 (ρ : Env) : Domain.Correct (v26 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v9 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q9 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n26) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q26 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n26 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar11.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n9 : Expr .natural := (.nat (3))
def n26 : Expr .natural := (.mulN n0 n9)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v9 ρ)
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v26 ρ) (v9 ρ) :=
  (Generated.r_natural_one_mul (v9 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n26) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_26 ρ) (eval_9 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n26) : (Expr.eval ρ n26) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d9 (ρ : Env) : Prop := True
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d26 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v9 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_26 (ρ : Env) : Value.Defined (v26 ρ) ↔ d26 ρ :=
  Functions.mulN.defined (v0 ρ) (v9 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n26 ↔ (d26 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_26 ρ))).trans (domain_26 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v9 ρ) (total_0 ρ) (total_9 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n26 := Eq.mpr (congrArg Value.Defined (eval_26 ρ)) (total_26 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar12.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar12.Certificate

namespace QSym.BindingScalar12.DomainCertificate
def n9 : Expr .natural := (.nat (3))
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n10 : Expr .natural := (.nat (2))
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n27 : Expr .natural := (.addN n9 n10)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v9 ρ) (v10 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q27 (ρ : Env) : Domain.Correct (v27 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v9 ρ)) (y := (v10 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q9 ρ) (q10 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n27) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q27 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n27 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar12.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar12.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n7 : Expr .natural := (.nat (5))
def n9 : Expr .natural := (.nat (3))
def n10 : Expr .natural := (.nat (2))
def n27 : Expr .natural := (.addN n9 n10)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v9 ρ) (v10 ρ)
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v27 ρ) (v7 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_27 ρ) (eval_7 ρ)) (Numeric.sound ρ n27 n7 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n7) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_7 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n7) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d9 (ρ : Env) : Prop := True
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d10 (ρ : Env) : Prop := True
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d27 (ρ : Env) : Prop := ∃ x y, (v9 ρ) = some x ∧ (v10 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_27 (ρ : Env) : Value.Defined (v27 ρ) ↔ d27 ρ :=
  Functions.addN.defined (v9 ρ) (v10 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (domain_27 ρ)
#qsym_check_axioms definedness
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v9 ρ) (v10 ρ) (total_9 ρ) (total_10 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_27 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar12.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar13.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar13.Certificate

namespace QSym.BindingScalar13.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n10 : Expr .natural := (.nat (2))
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n28 : Expr .natural := (.mulN n1 n10)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v10 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q28 (ρ : Env) : Domain.Correct (v28 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v10 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q10 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n28) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q28 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n28 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar13.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar13.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n10 : Expr .natural := (.nat (2))
def n28 : Expr .natural := (.mulN n1 n10)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v10 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v28 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v10 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n28) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_28 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n28) : (Expr.eval ρ n28) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d10 (ρ : Env) : Prop := True
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d28 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v10 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_28 (ρ : Env) : Value.Defined (v28 ρ) ↔ d28 ρ :=
  Functions.mulN.defined (v1 ρ) (v10 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n28 ↔ (d28 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_28 ρ))).trans (domain_28 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  ⟨_, rfl⟩
theorem total_28 (ρ : Env) : Value.Defined (v28 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v10 ρ) (total_1 ρ) (total_10 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n28 := Eq.mpr (congrArg Value.Defined (eval_28 ρ)) (total_28 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar13.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar14.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar14.Certificate

namespace QSym.BindingScalar14.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n9 : Expr .natural := (.nat (3))
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n29 : Expr .natural := (.addN n9 n1)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v9 ρ) (v1 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q29 (ρ : Env) : Domain.Correct (v29 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v9 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q9 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n29) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q29 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n29 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar14.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar14.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n9 : Expr .natural := (.nat (3))
def n29 : Expr .natural := (.addN n9 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v9 ρ) (v1 ρ)
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v29 ρ) (v9 ρ) :=
  (Generated.r_natural_add_zero (v9 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n29) (Expr.eval ρ n9) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_29 ρ) (eval_9 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n29) : (Expr.eval ρ n29) = (Expr.eval ρ n9) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d9 (ρ : Env) : Prop := True
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d29 (ρ : Env) : Prop := ∃ x y, (v9 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_29 (ρ : Env) : Value.Defined (v29 ρ) ↔ d29 ρ :=
  Functions.addN.defined (v9 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n29 ↔ (d29 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_29 ρ))).trans (domain_29 ρ)
#qsym_check_axioms definedness
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_29 (ρ : Env) : Value.Defined (v29 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v9 ρ) (v1 ρ) (total_9 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n29 := Eq.mpr (congrArg Value.Defined (eval_29 ρ)) (total_29 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar14.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar15.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar15.Certificate

namespace QSym.BindingScalar15.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n7 : Expr .natural := (.nat (5))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n30 : Expr .natural := (.mulN n0 n7)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v7 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v7 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q7 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n30) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q30 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n30 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar15.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar15.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n7 : Expr .natural := (.nat (5))
def n30 : Expr .natural := (.mulN n0 n7)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v7 ρ)
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v30 ρ) (v7 ρ) :=
  (Generated.r_natural_one_mul (v7 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n30) (Expr.eval ρ n7) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_30 ρ) (eval_7 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n30) : (Expr.eval ρ n30) = (Expr.eval ρ n7) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d30 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v7 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  Functions.mulN.defined (v0 ρ) (v7 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n30 ↔ (d30 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_30 ρ))).trans (domain_30 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v7 ρ) (total_0 ρ) (total_7 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n30 := Eq.mpr (congrArg Value.Defined (eval_30 ρ)) (total_30 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar15.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar16.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar16.Certificate

namespace QSym.BindingScalar16.DomainCertificate
def n7 : Expr .natural := (.nat (5))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n9 : Expr .natural := (.nat (3))
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n31 : Expr .natural := (.addN n7 n9)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v7 ρ) (v9 ρ)
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q31 (ρ : Env) : Domain.Correct (v31 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v7 ρ)) (y := (v9 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q7 ρ) (q9 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n31) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q31 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n31 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar16.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar16.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n4 : Expr .natural := (.nat (8))
def n7 : Expr .natural := (.nat (5))
def n9 : Expr .natural := (.nat (3))
def n31 : Expr .natural := (.addN n7 n9)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v7 ρ) (v9 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v31 ρ) (v4 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_31 ρ) (eval_4 ρ)) (Numeric.sound ρ n31 n4 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n31) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_31 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n31) : (Expr.eval ρ n31) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d9 (ρ : Env) : Prop := True
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d31 (ρ : Env) : Prop := ∃ x y, (v7 ρ) = some x ∧ (v9 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_31 (ρ : Env) : Value.Defined (v31 ρ) ↔ d31 ρ :=
  Functions.addN.defined (v7 ρ) (v9 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n31 ↔ (d31 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_31 ρ))).trans (domain_31 ρ)
#qsym_check_axioms definedness
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v7 ρ) (v9 ρ) (total_7 ρ) (total_9 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n31 := Eq.mpr (congrArg Value.Defined (eval_31 ρ)) (total_31 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar16.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar17.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar17.Certificate

namespace QSym.BindingScalar17.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n9 : Expr .natural := (.nat (3))
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n32 : Expr .natural := (.mulN n1 n9)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v9 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v9 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q9 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n32) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q32 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n32 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar17.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar17.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n9 : Expr .natural := (.nat (3))
def n32 : Expr .natural := (.mulN n1 n9)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v9 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v32 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v9 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n32) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_32 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n32) : (Expr.eval ρ n32) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d9 (ρ : Env) : Prop := True
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d32 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v9 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  Functions.mulN.defined (v1 ρ) (v9 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n32 ↔ (d32 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_32 ρ))).trans (domain_32 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  ⟨_, rfl⟩
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v9 ρ) (total_1 ρ) (total_9 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n32 := Eq.mpr (congrArg Value.Defined (eval_32 ρ)) (total_32 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar17.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar18.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar18.Certificate

namespace QSym.BindingScalar18.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n7 : Expr .natural := (.nat (5))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n33 : Expr .natural := (.addN n7 n1)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v7 ρ) (v1 ρ)
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q33 (ρ : Env) : Domain.Correct (v33 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v7 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q7 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n33) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q33 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n33 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar18.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar18.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n7 : Expr .natural := (.nat (5))
def n33 : Expr .natural := (.addN n7 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v7 ρ) (v1 ρ)
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v33 ρ) (v7 ρ) :=
  (Generated.r_natural_add_zero (v7 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n33) (Expr.eval ρ n7) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_33 ρ) (eval_7 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n33) : (Expr.eval ρ n33) = (Expr.eval ρ n7) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d33 (ρ : Env) : Prop := ∃ x y, (v7 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_33 (ρ : Env) : Value.Defined (v33 ρ) ↔ d33 ρ :=
  Functions.addN.defined (v7 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n33 ↔ (d33 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_33 ρ))).trans (domain_33 ρ)
#qsym_check_axioms definedness
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_33 (ρ : Env) : Value.Defined (v33 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v7 ρ) (v1 ρ) (total_7 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n33 := Eq.mpr (congrArg Value.Defined (eval_33 ρ)) (total_33 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar18.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar19.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar19.Certificate

namespace QSym.BindingScalar19.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n4 : Expr .natural := (.nat (8))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n34 : Expr .natural := (.mulN n0 n4)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q34 (ρ : Env) : Domain.Correct (v34 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v4 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n34) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q34 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n34 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar19.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar19.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n4 : Expr .natural := (.nat (8))
def n34 : Expr .natural := (.mulN n0 n4)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_34 (ρ : Env) : (Expr.eval ρ n34) = (v34 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v34 ρ) (v4 ρ) :=
  (Generated.r_natural_one_mul (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n34) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_34 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n34) : (Expr.eval ρ n34) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d34 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_34 (ρ : Env) : Value.Defined (v34 ρ) ↔ d34 ρ :=
  Functions.mulN.defined (v0 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n34 ↔ (d34 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_34 ρ))).trans (domain_34 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_34 (ρ : Env) : Value.Defined (v34 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v4 ρ) (total_0 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n34 := Eq.mpr (congrArg Value.Defined (eval_34 ρ)) (total_34 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar19.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar20.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar20.Certificate

namespace QSym.BindingScalar20.DomainCertificate
def n4 : Expr .natural := (.nat (8))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n7 : Expr .natural := (.nat (5))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n35 : Expr .natural := (.addN n4 n7)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v7 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q35 (ρ : Env) : Domain.Correct (v35 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v4 ρ)) (y := (v7 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q4 ρ) (q7 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n35) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q35 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n35 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar20.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar20.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n4 : Expr .natural := (.nat (8))
def n7 : Expr .natural := (.nat (5))
def n35 : Expr .natural := (.addN n4 n7)
def n36 : Expr .natural := (.nat (13))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v7 ρ)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
theorem eval_35 (ρ : Env) : (Expr.eval ρ n35) = (v35 ρ) := rfl
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v35 ρ) (v36 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_35 ρ) (eval_36 ρ)) (Numeric.sound ρ n35 n36 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n35) (Expr.eval ρ n36) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_35 ρ) (eval_36 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n35) : (Expr.eval ρ n35) = (Expr.eval ρ n36) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d35 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v7 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_35 (ρ : Env) : Value.Defined (v35 ρ) ↔ d35 ρ :=
  Functions.addN.defined (v4 ρ) (v7 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n35 ↔ (d35 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_35 ρ))).trans (domain_35 ρ)
#qsym_check_axioms definedness
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_35 (ρ : Env) : Value.Defined (v35 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v4 ρ) (v7 ρ) (total_4 ρ) (total_7 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n35 := Eq.mpr (congrArg Value.Defined (eval_35 ρ)) (total_35 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar20.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar21.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar21.Certificate

namespace QSym.BindingScalar21.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n7 : Expr .natural := (.nat (5))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n37 : Expr .natural := (.mulN n1 n7)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v7 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q37 (ρ : Env) : Domain.Correct (v37 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v7 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q7 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n37) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q37 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n37 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar21.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar21.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n7 : Expr .natural := (.nat (5))
def n37 : Expr .natural := (.mulN n1 n7)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v7 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v37 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v7 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n37) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_37 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n37) : (Expr.eval ρ n37) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d37 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v7 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_37 (ρ : Env) : Value.Defined (v37 ρ) ↔ d37 ρ :=
  Functions.mulN.defined (v1 ρ) (v7 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n37 ↔ (d37 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_37 ρ))).trans (domain_37 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v7 ρ) (total_1 ρ) (total_7 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n37 := Eq.mpr (congrArg Value.Defined (eval_37 ρ)) (total_37 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar21.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar22.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar22.Certificate

namespace QSym.BindingScalar22.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n4 : Expr .natural := (.nat (8))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n38 : Expr .natural := (.addN n4 n1)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v1 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q38 (ρ : Env) : Domain.Correct (v38 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v4 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q4 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n38) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q38 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n38 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar22.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar22.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n4 : Expr .natural := (.nat (8))
def n38 : Expr .natural := (.addN n4 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v1 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v38 ρ) (v4 ρ) :=
  (Generated.r_natural_add_zero (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n38) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_38 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n38) : (Expr.eval ρ n38) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d38 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_38 (ρ : Env) : Value.Defined (v38 ρ) ↔ d38 ρ :=
  Functions.addN.defined (v4 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n38 ↔ (d38 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_38 ρ))).trans (domain_38 ρ)
#qsym_check_axioms definedness
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_38 (ρ : Env) : Value.Defined (v38 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v4 ρ) (v1 ρ) (total_4 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n38 := Eq.mpr (congrArg Value.Defined (eval_38 ρ)) (total_38 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar22.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar23.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar23.Certificate

namespace QSym.BindingScalar23.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n36 : Expr .natural := (.nat (13))
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
def n39 : Expr .natural := (.mulN n0 n36)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v36 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q36 (ρ : Env) : Domain.Correct (v36 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q39 (ρ : Env) : Domain.Correct (v39 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v36 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q36 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n39) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q39 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n39 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar23.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar23.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n36 : Expr .natural := (.nat (13))
def n39 : Expr .natural := (.mulN n0 n36)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v36 ρ)
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v39 ρ) (v36 ρ) :=
  (Generated.r_natural_one_mul (v36 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n36) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_36 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n36) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d36 (ρ : Env) : Prop := True
theorem domain_36 (ρ : Env) : Value.Defined (v36 ρ) ↔ d36 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d39 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v36 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_39 (ρ : Env) : Value.Defined (v39 ρ) ↔ d39 ρ :=
  Functions.mulN.defined (v0 ρ) (v36 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (domain_39 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_36 (ρ : Env) : Value.Defined (v36 ρ) :=
  ⟨_, rfl⟩
theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v36 ρ) (total_0 ρ) (total_36 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_39 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar23.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar24.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar24.Certificate

namespace QSym.BindingScalar24.DomainCertificate
def n4 : Expr .natural := (.nat (8))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n36 : Expr .natural := (.nat (13))
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
def n40 : Expr .natural := (.addN n36 n4)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v36 ρ) (v4 ρ)
theorem q36 (ρ : Env) : Domain.Correct (v36 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q40 (ρ : Env) : Domain.Correct (v40 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v36 ρ)) (y := (v4 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q36 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n40) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q40 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n40 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar24.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar24.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n4 : Expr .natural := (.nat (8))
def n36 : Expr .natural := (.nat (13))
def n40 : Expr .natural := (.addN n36 n4)
def n41 : Expr .natural := (.nat (21))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v36 ρ) (v4 ρ)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl
theorem eval_41 (ρ : Env) : (Expr.eval ρ n41) = (v41 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v40 ρ) (v41 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_40 ρ) (eval_41 ρ)) (Numeric.sound ρ n40 n41 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n40) (Expr.eval ρ n41) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_40 ρ) (eval_41 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n40) : (Expr.eval ρ n40) = (Expr.eval ρ n41) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d36 (ρ : Env) : Prop := True
theorem domain_36 (ρ : Env) : Value.Defined (v36 ρ) ↔ d36 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d40 (ρ : Env) : Prop := ∃ x y, (v36 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_40 (ρ : Env) : Value.Defined (v40 ρ) ↔ d40 ρ :=
  Functions.addN.defined (v36 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n40 ↔ (d40 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_40 ρ))).trans (domain_40 ρ)
#qsym_check_axioms definedness
theorem total_36 (ρ : Env) : Value.Defined (v36 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_40 (ρ : Env) : Value.Defined (v40 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v36 ρ) (v4 ρ) (total_36 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n40 := Eq.mpr (congrArg Value.Defined (eval_40 ρ)) (total_40 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar24.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar25.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar25.Certificate

namespace QSym.BindingScalar25.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n4 : Expr .natural := (.nat (8))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n42 : Expr .natural := (.mulN n1 n4)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v4 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q42 (ρ : Env) : Domain.Correct (v42 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v4 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n42) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q42 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n42 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar25.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar25.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n4 : Expr .natural := (.nat (8))
def n42 : Expr .natural := (.mulN n1 n4)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v4 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_42 (ρ : Env) : (Expr.eval ρ n42) = (v42 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v42 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n42) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_42 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n42) : (Expr.eval ρ n42) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d42 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_42 (ρ : Env) : Value.Defined (v42 ρ) ↔ d42 ρ :=
  Functions.mulN.defined (v1 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n42 ↔ (d42 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_42 ρ))).trans (domain_42 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_42 (ρ : Env) : Value.Defined (v42 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v4 ρ) (total_1 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n42 := Eq.mpr (congrArg Value.Defined (eval_42 ρ)) (total_42 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar25.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar26.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar26.Certificate

namespace QSym.BindingScalar26.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n36 : Expr .natural := (.nat (13))
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
def n43 : Expr .natural := (.addN n36 n1)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v36 ρ) (v1 ρ)
theorem q36 (ρ : Env) : Domain.Correct (v36 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q43 (ρ : Env) : Domain.Correct (v43 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v36 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q36 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n43) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q43 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n43 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar26.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar26.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n36 : Expr .natural := (.nat (13))
def n43 : Expr .natural := (.addN n36 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v36 ρ) (v1 ρ)
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl
theorem eval_43 (ρ : Env) : (Expr.eval ρ n43) = (v43 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v43 ρ) (v36 ρ) :=
  (Generated.r_natural_add_zero (v36 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n43) (Expr.eval ρ n36) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_43 ρ) (eval_36 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n43) : (Expr.eval ρ n43) = (Expr.eval ρ n36) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d36 (ρ : Env) : Prop := True
theorem domain_36 (ρ : Env) : Value.Defined (v36 ρ) ↔ d36 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d43 (ρ : Env) : Prop := ∃ x y, (v36 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_43 (ρ : Env) : Value.Defined (v43 ρ) ↔ d43 ρ :=
  Functions.addN.defined (v36 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n43 ↔ (d43 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_43 ρ))).trans (domain_43 ρ)
#qsym_check_axioms definedness
theorem total_36 (ρ : Env) : Value.Defined (v36 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_43 (ρ : Env) : Value.Defined (v43 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v36 ρ) (v1 ρ) (total_36 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n43 := Eq.mpr (congrArg Value.Defined (eval_43 ρ)) (total_43 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar26.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar27.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar27.Certificate

namespace QSym.BindingScalar27.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n41 : Expr .natural := (.nat (21))
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
def n44 : Expr .natural := (.mulN n0 n41)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v41 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q41 (ρ : Env) : Domain.Correct (v41 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q44 (ρ : Env) : Domain.Correct (v44 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v41 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q41 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n44) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q44 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n44 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar27.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar27.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n41 : Expr .natural := (.nat (21))
def n44 : Expr .natural := (.mulN n0 n41)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v41 ρ)
theorem eval_41 (ρ : Env) : (Expr.eval ρ n41) = (v41 ρ) := rfl
theorem eval_44 (ρ : Env) : (Expr.eval ρ n44) = (v44 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v44 ρ) (v41 ρ) :=
  (Generated.r_natural_one_mul (v41 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n44) (Expr.eval ρ n41) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_44 ρ) (eval_41 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n44) : (Expr.eval ρ n44) = (Expr.eval ρ n41) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d41 (ρ : Env) : Prop := True
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d44 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v41 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_44 (ρ : Env) : Value.Defined (v44 ρ) ↔ d44 ρ :=
  Functions.mulN.defined (v0 ρ) (v41 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n44 ↔ (d44 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_44 ρ))).trans (domain_44 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  ⟨_, rfl⟩
theorem total_44 (ρ : Env) : Value.Defined (v44 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v41 ρ) (total_0 ρ) (total_41 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n44 := Eq.mpr (congrArg Value.Defined (eval_44 ρ)) (total_44 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar27.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar28.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar28.Certificate

namespace QSym.BindingScalar28.DomainCertificate
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n36 : Expr .natural := (.nat (13))
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
def n41 : Expr .natural := (.nat (21))
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
def n45 : Expr .natural := (.addN n41 n36)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v41 ρ) (v36 ρ)
theorem q41 (ρ : Env) : Domain.Correct (v41 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q36 (ρ : Env) : Domain.Correct (v36 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q45 (ρ : Env) : Domain.Correct (v45 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v41 ρ)) (y := (v36 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q41 ρ) (q36 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n45) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q45 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n45 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar28.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar28.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n36 : Expr .natural := (.nat (13))
def n41 : Expr .natural := (.nat (21))
def n45 : Expr .natural := (.addN n41 n36)
def n46 : Expr .natural := (.nat (34))
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v41 ρ) (v36 ρ)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
theorem eval_45 (ρ : Env) : (Expr.eval ρ n45) = (v45 ρ) := rfl
theorem eval_46 (ρ : Env) : (Expr.eval ρ n46) = (v46 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v45 ρ) (v46 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_45 ρ) (eval_46 ρ)) (Numeric.sound ρ n45 n46 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n45) (Expr.eval ρ n46) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_45 ρ) (eval_46 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n45) : (Expr.eval ρ n45) = (Expr.eval ρ n46) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d41 (ρ : Env) : Prop := True
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d36 (ρ : Env) : Prop := True
theorem domain_36 (ρ : Env) : Value.Defined (v36 ρ) ↔ d36 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d45 (ρ : Env) : Prop := ∃ x y, (v41 ρ) = some x ∧ (v36 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_45 (ρ : Env) : Value.Defined (v45 ρ) ↔ d45 ρ :=
  Functions.addN.defined (v41 ρ) (v36 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n45 ↔ (d45 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_45 ρ))).trans (domain_45 ρ)
#qsym_check_axioms definedness
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  ⟨_, rfl⟩
theorem total_36 (ρ : Env) : Value.Defined (v36 ρ) :=
  ⟨_, rfl⟩
theorem total_45 (ρ : Env) : Value.Defined (v45 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v41 ρ) (v36 ρ) (total_41 ρ) (total_36 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n45 := Eq.mpr (congrArg Value.Defined (eval_45 ρ)) (total_45 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar28.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar29.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar29.Certificate

namespace QSym.BindingScalar29.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n36 : Expr .natural := (.nat (13))
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
def n47 : Expr .natural := (.mulN n1 n36)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v36 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q36 (ρ : Env) : Domain.Correct (v36 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q47 (ρ : Env) : Domain.Correct (v47 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v36 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q36 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n47) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q47 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n47 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar29.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar29.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n36 : Expr .natural := (.nat (13))
def n47 : Expr .natural := (.mulN n1 n36)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := some (13)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v36 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_47 (ρ : Env) : (Expr.eval ρ n47) = (v47 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v47 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v36 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n47) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_47 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n47) : (Expr.eval ρ n47) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d36 (ρ : Env) : Prop := True
theorem domain_36 (ρ : Env) : Value.Defined (v36 ρ) ↔ d36 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d47 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v36 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_47 (ρ : Env) : Value.Defined (v47 ρ) ↔ d47 ρ :=
  Functions.mulN.defined (v1 ρ) (v36 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n47 ↔ (d47 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_47 ρ))).trans (domain_47 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_36 (ρ : Env) : Value.Defined (v36 ρ) :=
  ⟨_, rfl⟩
theorem total_47 (ρ : Env) : Value.Defined (v47 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v36 ρ) (total_1 ρ) (total_36 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n47 := Eq.mpr (congrArg Value.Defined (eval_47 ρ)) (total_47 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar29.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar30.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar30.Certificate

namespace QSym.BindingScalar30.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n41 : Expr .natural := (.nat (21))
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
def n48 : Expr .natural := (.addN n41 n1)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v41 ρ) (v1 ρ)
theorem q41 (ρ : Env) : Domain.Correct (v41 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q48 (ρ : Env) : Domain.Correct (v48 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v41 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q41 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n48) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q48 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n48 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar30.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar30.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n41 : Expr .natural := (.nat (21))
def n48 : Expr .natural := (.addN n41 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v41 ρ) (v1 ρ)
theorem eval_41 (ρ : Env) : (Expr.eval ρ n41) = (v41 ρ) := rfl
theorem eval_48 (ρ : Env) : (Expr.eval ρ n48) = (v48 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v48 ρ) (v41 ρ) :=
  (Generated.r_natural_add_zero (v41 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n48) (Expr.eval ρ n41) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_48 ρ) (eval_41 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n48) : (Expr.eval ρ n48) = (Expr.eval ρ n41) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d41 (ρ : Env) : Prop := True
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d48 (ρ : Env) : Prop := ∃ x y, (v41 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_48 (ρ : Env) : Value.Defined (v48 ρ) ↔ d48 ρ :=
  Functions.addN.defined (v41 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n48 ↔ (d48 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_48 ρ))).trans (domain_48 ρ)
#qsym_check_axioms definedness
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_48 (ρ : Env) : Value.Defined (v48 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v41 ρ) (v1 ρ) (total_41 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n48 := Eq.mpr (congrArg Value.Defined (eval_48 ρ)) (total_48 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar30.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar31.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar31.Certificate

namespace QSym.BindingScalar31.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n46 : Expr .natural := (.nat (34))
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
def n49 : Expr .natural := (.mulN n0 n46)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v46 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q49 (ρ : Env) : Domain.Correct (v49 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v46 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q46 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n49) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q49 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n49 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar31.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar31.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n46 : Expr .natural := (.nat (34))
def n49 : Expr .natural := (.mulN n0 n46)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v46 ρ)
theorem eval_46 (ρ : Env) : (Expr.eval ρ n46) = (v46 ρ) := rfl
theorem eval_49 (ρ : Env) : (Expr.eval ρ n49) = (v49 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v49 ρ) (v46 ρ) :=
  (Generated.r_natural_one_mul (v46 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n49) (Expr.eval ρ n46) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_49 ρ) (eval_46 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n49) : (Expr.eval ρ n49) = (Expr.eval ρ n46) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d46 (ρ : Env) : Prop := True
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d49 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v46 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_49 (ρ : Env) : Value.Defined (v49 ρ) ↔ d49 ρ :=
  Functions.mulN.defined (v0 ρ) (v46 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n49 ↔ (d49 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_49 ρ))).trans (domain_49 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  ⟨_, rfl⟩
theorem total_49 (ρ : Env) : Value.Defined (v49 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v46 ρ) (total_0 ρ) (total_46 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n49 := Eq.mpr (congrArg Value.Defined (eval_49 ρ)) (total_49 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar31.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar32.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar32.Certificate

namespace QSym.BindingScalar32.DomainCertificate
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n41 : Expr .natural := (.nat (21))
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
def n46 : Expr .natural := (.nat (34))
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
def n50 : Expr .natural := (.addN n46 n41)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v46 ρ) (v41 ρ)
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q41 (ρ : Env) : Domain.Correct (v41 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q50 (ρ : Env) : Domain.Correct (v50 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v46 ρ)) (y := (v41 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q46 ρ) (q41 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n50) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q50 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n50 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar32.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar32.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n41 : Expr .natural := (.nat (21))
def n46 : Expr .natural := (.nat (34))
def n50 : Expr .natural := (.addN n46 n41)
def n51 : Expr .natural := (.nat (55))
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v46 ρ) (v41 ρ)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
theorem eval_50 (ρ : Env) : (Expr.eval ρ n50) = (v50 ρ) := rfl
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v50 ρ) (v51 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_50 ρ) (eval_51 ρ)) (Numeric.sound ρ n50 n51 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n50) (Expr.eval ρ n51) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_50 ρ) (eval_51 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n50) : (Expr.eval ρ n50) = (Expr.eval ρ n51) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d46 (ρ : Env) : Prop := True
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d41 (ρ : Env) : Prop := True
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d50 (ρ : Env) : Prop := ∃ x y, (v46 ρ) = some x ∧ (v41 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_50 (ρ : Env) : Value.Defined (v50 ρ) ↔ d50 ρ :=
  Functions.addN.defined (v46 ρ) (v41 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n50 ↔ (d50 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_50 ρ))).trans (domain_50 ρ)
#qsym_check_axioms definedness
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  ⟨_, rfl⟩
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  ⟨_, rfl⟩
theorem total_50 (ρ : Env) : Value.Defined (v50 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v46 ρ) (v41 ρ) (total_46 ρ) (total_41 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n50 := Eq.mpr (congrArg Value.Defined (eval_50 ρ)) (total_50 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar32.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar33.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar33.Certificate

namespace QSym.BindingScalar33.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n41 : Expr .natural := (.nat (21))
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
def n52 : Expr .natural := (.mulN n1 n41)
noncomputable def v52 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v41 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q41 (ρ : Env) : Domain.Correct (v41 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q52 (ρ : Env) : Domain.Correct (v52 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v41 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q41 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n52) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q52 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n52 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar33.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar33.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n41 : Expr .natural := (.nat (21))
def n52 : Expr .natural := (.mulN n1 n41)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .natural) := some (21)
noncomputable def v52 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v41 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_52 (ρ : Env) : (Expr.eval ρ n52) = (v52 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v52 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v41 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n52) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_52 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n52) : (Expr.eval ρ n52) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d41 (ρ : Env) : Prop := True
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d52 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v41 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_52 (ρ : Env) : Value.Defined (v52 ρ) ↔ d52 ρ :=
  Functions.mulN.defined (v1 ρ) (v41 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n52 ↔ (d52 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_52 ρ))).trans (domain_52 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  ⟨_, rfl⟩
theorem total_52 (ρ : Env) : Value.Defined (v52 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v41 ρ) (total_1 ρ) (total_41 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n52 := Eq.mpr (congrArg Value.Defined (eval_52 ρ)) (total_52 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar33.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar34.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar34.Certificate

namespace QSym.BindingScalar34.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n46 : Expr .natural := (.nat (34))
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
def n53 : Expr .natural := (.addN n46 n1)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v46 ρ) (v1 ρ)
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q53 (ρ : Env) : Domain.Correct (v53 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v46 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q46 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n53) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q53 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n53 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar34.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar34.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n46 : Expr .natural := (.nat (34))
def n53 : Expr .natural := (.addN n46 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v46 ρ) (v1 ρ)
theorem eval_46 (ρ : Env) : (Expr.eval ρ n46) = (v46 ρ) := rfl
theorem eval_53 (ρ : Env) : (Expr.eval ρ n53) = (v53 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v53 ρ) (v46 ρ) :=
  (Generated.r_natural_add_zero (v46 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n53) (Expr.eval ρ n46) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_53 ρ) (eval_46 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n53) : (Expr.eval ρ n53) = (Expr.eval ρ n46) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d46 (ρ : Env) : Prop := True
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d53 (ρ : Env) : Prop := ∃ x y, (v46 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_53 (ρ : Env) : Value.Defined (v53 ρ) ↔ d53 ρ :=
  Functions.addN.defined (v46 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n53 ↔ (d53 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_53 ρ))).trans (domain_53 ρ)
#qsym_check_axioms definedness
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_53 (ρ : Env) : Value.Defined (v53 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v46 ρ) (v1 ρ) (total_46 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n53 := Eq.mpr (congrArg Value.Defined (eval_53 ρ)) (total_53 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar34.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar35.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar35.Certificate

namespace QSym.BindingScalar35.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n51 : Expr .natural := (.nat (55))
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
def n54 : Expr .natural := (.mulN n0 n51)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v51 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q54 (ρ : Env) : Domain.Correct (v54 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v51 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q0 ρ) (q51 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n54) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q54 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n54 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar35.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar35.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n51 : Expr .natural := (.nat (55))
def n54 : Expr .natural := (.mulN n0 n51)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v51 ρ)
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl
theorem eval_54 (ρ : Env) : (Expr.eval ρ n54) = (v54 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v54 ρ) (v51 ρ) :=
  (Generated.r_natural_one_mul (v51 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n54) (Expr.eval ρ n51) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_54 ρ) (eval_51 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n54) : (Expr.eval ρ n54) = (Expr.eval ρ n51) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d51 (ρ : Env) : Prop := True
theorem domain_51 (ρ : Env) : Value.Defined (v51 ρ) ↔ d51 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d54 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v51 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_54 (ρ : Env) : Value.Defined (v54 ρ) ↔ d54 ρ :=
  Functions.mulN.defined (v0 ρ) (v51 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n54 ↔ (d54 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_54 ρ))).trans (domain_54 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  ⟨_, rfl⟩
theorem total_54 (ρ : Env) : Value.Defined (v54 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v51 ρ) (total_0 ρ) (total_51 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n54 := Eq.mpr (congrArg Value.Defined (eval_54 ρ)) (total_54 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar35.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar36.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar36.Certificate

namespace QSym.BindingScalar36.DomainCertificate
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n46 : Expr .natural := (.nat (34))
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
def n51 : Expr .natural := (.nat (55))
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
def n55 : Expr .natural := (.addN n51 n46)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v51 ρ) (v46 ρ)
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q55 (ρ : Env) : Domain.Correct (v55 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v51 ρ)) (y := (v46 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q51 ρ) (q46 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n55) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q55 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n55 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar36.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar36.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n46 : Expr .natural := (.nat (34))
def n51 : Expr .natural := (.nat (55))
def n55 : Expr .natural := (.addN n51 n46)
def n56 : Expr .natural := (.nat (89))
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v51 ρ) (v46 ρ)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (89)
theorem eval_55 (ρ : Env) : (Expr.eval ρ n55) = (v55 ρ) := rfl
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v55 ρ) (v56 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_55 ρ) (eval_56 ρ)) (Numeric.sound ρ n55 n56 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n55) (Expr.eval ρ n56) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_55 ρ) (eval_56 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n55) : (Expr.eval ρ n55) = (Expr.eval ρ n56) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d51 (ρ : Env) : Prop := True
theorem domain_51 (ρ : Env) : Value.Defined (v51 ρ) ↔ d51 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d46 (ρ : Env) : Prop := True
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d55 (ρ : Env) : Prop := ∃ x y, (v51 ρ) = some x ∧ (v46 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_55 (ρ : Env) : Value.Defined (v55 ρ) ↔ d55 ρ :=
  Functions.addN.defined (v51 ρ) (v46 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n55 ↔ (d55 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_55 ρ))).trans (domain_55 ρ)
#qsym_check_axioms definedness
theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  ⟨_, rfl⟩
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  ⟨_, rfl⟩
theorem total_55 (ρ : Env) : Value.Defined (v55 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v51 ρ) (v46 ρ) (total_51 ρ) (total_46 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n55 := Eq.mpr (congrArg Value.Defined (eval_55 ρ)) (total_55 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar36.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar37.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar37.Certificate

namespace QSym.BindingScalar37.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n46 : Expr .natural := (.nat (34))
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
def n57 : Expr .natural := (.mulN n1 n46)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v46 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q57 (ρ : Env) : Domain.Correct (v57 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v46 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q46 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n57) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q57 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n57 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar37.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar37.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n46 : Expr .natural := (.nat (34))
def n57 : Expr .natural := (.mulN n1 n46)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v46 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_57 (ρ : Env) : (Expr.eval ρ n57) = (v57 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v57 ρ) (v1 ρ) :=
  (Generated.r_natural_zero_mul (v46 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n57) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_57 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n57) : (Expr.eval ρ n57) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d46 (ρ : Env) : Prop := True
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d57 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v46 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_57 (ρ : Env) : Value.Defined (v57 ρ) ↔ d57 ρ :=
  Functions.mulN.defined (v1 ρ) (v46 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n57 ↔ (d57 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_57 ρ))).trans (domain_57 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  ⟨_, rfl⟩
theorem total_57 (ρ : Env) : Value.Defined (v57 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v46 ρ) (total_1 ρ) (total_46 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n57 := Eq.mpr (congrArg Value.Defined (eval_57 ρ)) (total_57 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar37.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar38.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar38.Certificate

namespace QSym.BindingScalar38.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n51 : Expr .natural := (.nat (55))
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
def n58 : Expr .natural := (.addN n51 n1)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v51 ρ) (v1 ρ)
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q58 (ρ : Env) : Domain.Correct (v58 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v51 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q51 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n58) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q58 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n58 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar38.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar38.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n51 : Expr .natural := (.nat (55))
def n58 : Expr .natural := (.addN n51 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v51 ρ) (v1 ρ)
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl
theorem eval_58 (ρ : Env) : (Expr.eval ρ n58) = (v58 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v58 ρ) (v51 ρ) :=
  (Generated.r_natural_add_zero (v51 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n58) (Expr.eval ρ n51) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_58 ρ) (eval_51 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n58) : (Expr.eval ρ n58) = (Expr.eval ρ n51) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d51 (ρ : Env) : Prop := True
theorem domain_51 (ρ : Env) : Value.Defined (v51 ρ) ↔ d51 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d58 (ρ : Env) : Prop := ∃ x y, (v51 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_58 (ρ : Env) : Value.Defined (v58 ρ) ↔ d58 ρ :=
  Functions.addN.defined (v51 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n58 ↔ (d58 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_58 ρ))).trans (domain_58 ρ)
#qsym_check_axioms definedness
theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_58 (ρ : Env) : Value.Defined (v58 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v51 ρ) (v1 ρ) (total_51 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n58 := Eq.mpr (congrArg Value.Defined (eval_58 ρ)) (total_58 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar38.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar39.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar39.Certificate

namespace QSym.BindingScalar39.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n56 : Expr .natural := (.nat (89))
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (89)
def n59 : Expr .natural := (.mulN n56 n0)
noncomputable def v59 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v56 ρ) (v0 ρ)
theorem q56 (ρ : Env) : Domain.Correct (v56 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q59 (ρ : Env) : Domain.Correct (v59 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v56 ρ)) (y := (v0 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q56 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n59) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q59 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n59 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar39.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar39.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n56 : Expr .natural := (.nat (89))
def n59 : Expr .natural := (.mulN n56 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (89)
noncomputable def v59 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v56 ρ) (v0 ρ)
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl
theorem eval_59 (ρ : Env) : (Expr.eval ρ n59) = (v59 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v59 ρ) (v56 ρ) :=
  (Generated.r_natural_mul_one (v56 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n59) (Expr.eval ρ n56) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_59 ρ) (eval_56 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n59) : (Expr.eval ρ n59) = (Expr.eval ρ n56) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d56 (ρ : Env) : Prop := True
theorem domain_56 (ρ : Env) : Value.Defined (v56 ρ) ↔ d56 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d59 (ρ : Env) : Prop := ∃ x y, (v56 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_59 (ρ : Env) : Value.Defined (v59 ρ) ↔ d59 ρ :=
  Functions.mulN.defined (v56 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n59 ↔ (d59 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_59 ρ))).trans (domain_59 ρ)
#qsym_check_axioms definedness
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_59 (ρ : Env) : Value.Defined (v59 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v56 ρ) (v0 ρ) (total_56 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n59 := Eq.mpr (congrArg Value.Defined (eval_59 ρ)) (total_59 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar39.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar40.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar40.Certificate

namespace QSym.BindingScalar40.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n51 : Expr .natural := (.nat (55))
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
def n60 : Expr .natural := (.mulN n51 n1)
noncomputable def v60 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v51 ρ) (v1 ρ)
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q60 (ρ : Env) : Domain.Correct (v60 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v51 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q51 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n60) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q60 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n60 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar40.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar40.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n51 : Expr .natural := (.nat (55))
def n60 : Expr .natural := (.mulN n51 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
noncomputable def v60 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v51 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_60 (ρ : Env) : (Expr.eval ρ n60) = (v60 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v60 ρ) (v1 ρ) :=
  (Generated.r_natural_mul_zero (v51 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n60) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_60 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n60) : (Expr.eval ρ n60) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d51 (ρ : Env) : Prop := True
theorem domain_51 (ρ : Env) : Value.Defined (v51 ρ) ↔ d51 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d60 (ρ : Env) : Prop := ∃ x y, (v51 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_60 (ρ : Env) : Value.Defined (v60 ρ) ↔ d60 ρ :=
  Functions.mulN.defined (v51 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n60 ↔ (d60 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_60 ρ))).trans (domain_60 ρ)
#qsym_check_axioms definedness
theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_60 (ρ : Env) : Value.Defined (v60 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v51 ρ) (v1 ρ) (total_51 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n60 := Eq.mpr (congrArg Value.Defined (eval_60 ρ)) (total_60 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar40.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar41.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar41.Certificate

namespace QSym.BindingScalar41.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n56 : Expr .natural := (.nat (89))
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (89)
def n61 : Expr .natural := (.addN n56 n1)
noncomputable def v61 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v56 ρ) (v1 ρ)
theorem q56 (ρ : Env) : Domain.Correct (v56 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q61 (ρ : Env) : Domain.Correct (v61 ρ) (v17 ρ) :=
  Domain.total2 Functions.addN (x := (v56 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q56 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n61) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q61 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n61 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar41.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar41.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n56 : Expr .natural := (.nat (89))
def n61 : Expr .natural := (.addN n56 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .natural) := some (89)
noncomputable def v61 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v56 ρ) (v1 ρ)
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl
theorem eval_61 (ρ : Env) : (Expr.eval ρ n61) = (v61 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v61 ρ) (v56 ρ) :=
  (Generated.r_natural_add_zero (v56 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n61) (Expr.eval ρ n56) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_61 ρ) (eval_56 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n61) : (Expr.eval ρ n61) = (Expr.eval ρ n56) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d56 (ρ : Env) : Prop := True
theorem domain_56 (ρ : Env) : Value.Defined (v56 ρ) ↔ d56 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d61 (ρ : Env) : Prop := ∃ x y, (v56 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_61 (ρ : Env) : Value.Defined (v61 ρ) ↔ d61 ρ :=
  Functions.addN.defined (v56 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n61 ↔ (d61 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_61 ρ))).trans (domain_61 ρ)
#qsym_check_axioms definedness
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_61 (ρ : Env) : Value.Defined (v61 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v56 ρ) (v1 ρ) (total_56 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n61 := Eq.mpr (congrArg Value.Defined (eval_61 ρ)) (total_61 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar41.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar42.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar42.Certificate

namespace QSym.BindingScalar42.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n51 : Expr .natural := (.nat (55))
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
def n62 : Expr .natural := (.mulN n51 n0)
noncomputable def v62 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v51 ρ) (v0 ρ)
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q62 (ρ : Env) : Domain.Correct (v62 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v51 ρ)) (y := (v0 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q51 ρ) (q0 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n62) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q62 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n62 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar42.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar42.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n51 : Expr .natural := (.nat (55))
def n62 : Expr .natural := (.mulN n51 n0)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
noncomputable def v62 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v51 ρ) (v0 ρ)
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl
theorem eval_62 (ρ : Env) : (Expr.eval ρ n62) = (v62 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v62 ρ) (v51 ρ) :=
  (Generated.r_natural_mul_one (v51 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n62) (Expr.eval ρ n51) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_62 ρ) (eval_51 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n62) : (Expr.eval ρ n62) = (Expr.eval ρ n51) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d51 (ρ : Env) : Prop := True
theorem domain_51 (ρ : Env) : Value.Defined (v51 ρ) ↔ d51 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d62 (ρ : Env) : Prop := ∃ x y, (v51 ρ) = some x ∧ (v0 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_62 (ρ : Env) : Value.Defined (v62 ρ) ↔ d62 ρ :=
  Functions.mulN.defined (v51 ρ) (v0 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n62 ↔ (d62 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_62 ρ))).trans (domain_62 ρ)
#qsym_check_axioms definedness
theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  ⟨_, rfl⟩
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_62 (ρ : Env) : Value.Defined (v62 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v51 ρ) (v0 ρ) (total_51 ρ) (total_0 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n62 := Eq.mpr (congrArg Value.Defined (eval_62 ρ)) (total_62 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar42.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar43.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_17 ρ)) (Value.refines_refl (v17 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v17 ρ) := (total_17 ρ)
def d17 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar43.Certificate

namespace QSym.BindingScalar43.DomainCertificate
def n1 : Expr .natural := (.nat (0))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n17 : Expr .bool := (.bool true)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := some true
def n46 : Expr .natural := (.nat (34))
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
def n63 : Expr .natural := (.mulN n46 n1)
noncomputable def v63 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v46 ρ) (v1 ρ)
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v17 ρ) :=
  Domain.leaf _
theorem q63 (ρ : Env) : Domain.Correct (v63 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulN (x := (v46 ρ)) (y := (v1 ρ)) (dx := (v17 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q46 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n63) (Expr.eval ρ Certificate.n17) :=
  Domain.simplify (q63 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n17) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n63 ↔ (Expr.eval ρ Certificate.n17) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar43.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar43.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (0))
def n46 : Expr .natural := (.nat (34))
def n63 : Expr .natural := (.mulN n46 n1)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .natural) := some (34)
noncomputable def v63 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v46 ρ) (v1 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_63 (ρ : Env) : (Expr.eval ρ n63) = (v63 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v63 ρ) (v1 ρ) :=
  (Generated.r_natural_mul_zero (v46 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n63) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_63 ρ) (eval_1 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n63) : (Expr.eval ρ n63) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d46 (ρ : Env) : Prop := True
theorem domain_46 (ρ : Env) : Value.Defined (v46 ρ) ↔ d46 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d63 (ρ : Env) : Prop := ∃ x y, (v46 ρ) = some x ∧ (v1 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_63 (ρ : Env) : Value.Defined (v63 ρ) ↔ d63 ρ :=
  Functions.mulN.defined (v46 ρ) (v1 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n63 ↔ (d63 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_63 ρ))).trans (domain_63 ρ)
#qsym_check_axioms definedness
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  ⟨_, rfl⟩
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_63 (ρ : Env) : Value.Defined (v63 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v46 ρ) (v1 ρ) (total_46 ρ) (total_1 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n63 := Eq.mpr (congrArg Value.Defined (eval_63 ρ)) (total_63 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar43.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (0))
def n2 : Expr .natural := (.nat (10))
def n3 : Expr .natural := (.nat (9))
def n4 : Expr .natural := (.nat (8))
def n5 : Expr .natural := (.nat (7))
def n6 : Expr .natural := (.nat (6))
def n7 : Expr .natural := (.nat (5))
def n8 : Expr .natural := (.nat (4))
def n9 : Expr .natural := (.nat (3))
def n10 : Expr .natural := (.nat (2))
def n13 : Expr .natural := (.mulN n1 n1)
def n15 : Expr .natural := (.addN n1 n1)
def n16 : Expr .natural := (.mulN n0 n0)
def n17 : Expr .bool := (.bool true)
def n18 : Expr .natural := (.mulN n0 n1)
def n19 : Expr .natural := (.addN n0 n1)
def n20 : Expr .natural := (.addN n1 n0)
def n21 : Expr .natural := (.mulN n1 n0)
def n22 : Expr .natural := (.addN n0 n0)
def n23 : Expr .natural := (.mulN n0 n10)
def n24 : Expr .natural := (.addN n10 n0)
def n25 : Expr .natural := (.addN n10 n1)
def n26 : Expr .natural := (.mulN n0 n9)
def n27 : Expr .natural := (.addN n9 n10)
def n28 : Expr .natural := (.mulN n1 n10)
def n29 : Expr .natural := (.addN n9 n1)
def n30 : Expr .natural := (.mulN n0 n7)
def n31 : Expr .natural := (.addN n7 n9)
def n32 : Expr .natural := (.mulN n1 n9)
def n33 : Expr .natural := (.addN n7 n1)
def n34 : Expr .natural := (.mulN n0 n4)
def n35 : Expr .natural := (.addN n4 n7)
def n36 : Expr .natural := (.nat (13))
def n37 : Expr .natural := (.mulN n1 n7)
def n38 : Expr .natural := (.addN n4 n1)
def n39 : Expr .natural := (.mulN n0 n36)
def n40 : Expr .natural := (.addN n36 n4)
def n41 : Expr .natural := (.nat (21))
def n42 : Expr .natural := (.mulN n1 n4)
def n43 : Expr .natural := (.addN n36 n1)
def n44 : Expr .natural := (.mulN n0 n41)
def n45 : Expr .natural := (.addN n41 n36)
def n46 : Expr .natural := (.nat (34))
def n47 : Expr .natural := (.mulN n1 n36)
def n48 : Expr .natural := (.addN n41 n1)
def n49 : Expr .natural := (.mulN n0 n46)
def n50 : Expr .natural := (.addN n46 n41)
def n51 : Expr .natural := (.nat (55))
def n52 : Expr .natural := (.mulN n1 n41)
def n53 : Expr .natural := (.addN n46 n1)
def n54 : Expr .natural := (.mulN n0 n51)
def n55 : Expr .natural := (.addN n51 n46)
def n56 : Expr .natural := (.nat (89))
def n57 : Expr .natural := (.mulN n1 n46)
def n58 : Expr .natural := (.addN n51 n1)
def n59 : Expr .natural := (.mulN n56 n0)
def n60 : Expr .natural := (.mulN n51 n1)
def n61 : Expr .natural := (.addN n56 n1)
def n62 : Expr .natural := (.mulN n51 n0)
def n63 : Expr .natural := (.mulN n46 n1)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t0 γ) (t1 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t4 γ) (t1 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 0) := .constant Tensor.nilValue
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t6 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t3 γ) (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary (Tensor.matvecValue Functions.addN.apply Functions.mulN.apply 0 2 2) (t11 γ) (t6 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Tensor.getValue (t12 γ) (t0 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t14 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t15 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n5
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n6
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t23 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t24 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n7
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n8
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t30 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n9
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t32 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t33 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n10
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t35 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t36 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t0 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t38 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (t9 γ) (t4 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t40 γ)
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t4 γ) (t2 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t42 γ) (t7 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t6 γ) (t43 γ)
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t44 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t4 γ)
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t46 γ) (t4 γ)
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t0 γ)
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t48 γ) (t47 γ)
noncomputable def t50 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t48 γ) (t4 γ)
noncomputable def t51 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t46 γ) (t50 γ)
noncomputable def t52 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t51 γ) (t1 γ)
noncomputable def t53 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t49 γ) (t52 γ)
noncomputable def t54 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t4 γ)
noncomputable def t55 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t54 γ) (t4 γ)
noncomputable def t56 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t48 γ) (t55 γ)
noncomputable def t57 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t0 γ)
noncomputable def t58 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t57 γ) (t4 γ)
noncomputable def t59 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t46 γ) (t58 γ)
noncomputable def t60 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t59 γ) (t1 γ)
noncomputable def t61 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t56 γ) (t60 γ)
noncomputable def t62 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t61 γ) (t7 γ)
noncomputable def t63 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t53 γ) (t62 γ)
noncomputable def t64 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n16
noncomputable def t65 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n17
noncomputable def t66 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t0 γ)
noncomputable def t67 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n18
noncomputable def t68 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t4 γ)
noncomputable def t69 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t4 γ) (t4 γ)
noncomputable def t70 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n15
noncomputable def t71 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t4 γ)
noncomputable def t72 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n19
noncomputable def t73 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t4 γ) (t0 γ)
noncomputable def t74 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n20
noncomputable def t75 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n13
noncomputable def t76 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n21
noncomputable def t77 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t9 γ)
noncomputable def t78 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t48 γ) (t50 γ)
noncomputable def t79 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t49 γ) (t1 γ)
noncomputable def t80 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t78 γ) (t79 γ)
noncomputable def t81 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t48 γ) (t58 γ)
noncomputable def t82 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t56 γ) (t1 γ)
noncomputable def t83 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t81 γ) (t82 γ)
noncomputable def t84 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t83 γ) (t7 γ)
noncomputable def t85 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t80 γ) (t84 γ)
noncomputable def t86 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t0 γ)
noncomputable def t87 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n22
noncomputable def t88 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t35 γ)
noncomputable def t89 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t35 γ) (t2 γ)
noncomputable def t90 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t3 γ) (t7 γ)
noncomputable def t91 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t89 γ) (t90 γ)
noncomputable def t92 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t91 γ)
noncomputable def t93 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t35 γ)
noncomputable def t94 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t93 γ) (t50 γ)
noncomputable def t95 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t78 γ) (t1 γ)
noncomputable def t96 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t94 γ) (t95 γ)
noncomputable def t97 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t93 γ) (t58 γ)
noncomputable def t98 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t81 γ) (t1 γ)
noncomputable def t99 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t97 γ) (t98 γ)
noncomputable def t100 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t99 γ) (t7 γ)
noncomputable def t101 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t96 γ) (t100 γ)
noncomputable def t102 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n23
noncomputable def t103 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t35 γ) (t0 γ)
noncomputable def t104 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n24
noncomputable def t105 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t32 γ)
noncomputable def t106 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t35 γ) (t1 γ)
noncomputable def t107 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t32 γ) (t106 γ)
noncomputable def t108 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t35 γ) (t4 γ)
noncomputable def t109 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n25
noncomputable def t110 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t89 γ) (t7 γ)
noncomputable def t111 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t107 γ) (t110 γ)
noncomputable def t112 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t111 γ)
noncomputable def t113 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t93 γ) (t4 γ)
noncomputable def t114 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t32 γ)
noncomputable def t115 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t114 γ) (t113 γ)
noncomputable def t116 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t94 γ) (t1 γ)
noncomputable def t117 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t115 γ) (t116 γ)
noncomputable def t118 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t35 γ)
noncomputable def t119 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t118 γ) (t4 γ)
noncomputable def t120 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t114 γ) (t119 γ)
noncomputable def t121 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t97 γ) (t1 γ)
noncomputable def t122 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t120 γ) (t121 γ)
noncomputable def t123 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t122 γ) (t7 γ)
noncomputable def t124 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t117 γ) (t123 γ)
noncomputable def t125 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n26
noncomputable def t126 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t32 γ) (t35 γ)
noncomputable def t127 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n27
noncomputable def t128 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t26 γ)
noncomputable def t129 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t32 γ) (t1 γ)
noncomputable def t130 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t26 γ) (t129 γ)
noncomputable def t131 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n28
noncomputable def t132 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t32 γ) (t4 γ)
noncomputable def t133 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n29
noncomputable def t134 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t107 γ) (t7 γ)
noncomputable def t135 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t130 γ) (t134 γ)
noncomputable def t136 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t135 γ)
noncomputable def t137 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t114 γ) (t4 γ)
noncomputable def t138 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t26 γ)
noncomputable def t139 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t138 γ) (t137 γ)
noncomputable def t140 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t115 γ) (t1 γ)
noncomputable def t141 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t139 γ) (t140 γ)
noncomputable def t142 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t32 γ)
noncomputable def t143 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t142 γ) (t4 γ)
noncomputable def t144 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t138 γ) (t143 γ)
noncomputable def t145 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t120 γ) (t1 γ)
noncomputable def t146 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t144 γ) (t145 γ)
noncomputable def t147 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t146 γ) (t7 γ)
noncomputable def t148 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t141 γ) (t147 γ)
noncomputable def t149 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n30
noncomputable def t150 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t26 γ) (t32 γ)
noncomputable def t151 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n31
noncomputable def t152 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t17 γ)
noncomputable def t153 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t26 γ) (t1 γ)
noncomputable def t154 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t17 γ) (t153 γ)
noncomputable def t155 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n32
noncomputable def t156 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t26 γ) (t4 γ)
noncomputable def t157 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n33
noncomputable def t158 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t130 γ) (t7 γ)
noncomputable def t159 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t154 γ) (t158 γ)
noncomputable def t160 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t159 γ)
noncomputable def t161 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t138 γ) (t4 γ)
noncomputable def t162 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t17 γ)
noncomputable def t163 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t162 γ) (t161 γ)
noncomputable def t164 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t139 γ) (t1 γ)
noncomputable def t165 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t163 γ) (t164 γ)
noncomputable def t166 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t26 γ)
noncomputable def t167 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t166 γ) (t4 γ)
noncomputable def t168 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t162 γ) (t167 γ)
noncomputable def t169 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t144 γ) (t1 γ)
noncomputable def t170 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t168 γ) (t169 γ)
noncomputable def t171 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t170 γ) (t7 γ)
noncomputable def t172 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t165 γ) (t171 γ)
noncomputable def t173 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n34
noncomputable def t174 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t17 γ) (t26 γ)
noncomputable def t175 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n35
noncomputable def t176 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n36
noncomputable def t177 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t176 γ)
noncomputable def t178 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t17 γ) (t1 γ)
noncomputable def t179 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t176 γ) (t178 γ)
noncomputable def t180 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n37
noncomputable def t181 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t17 γ) (t4 γ)
noncomputable def t182 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n38
noncomputable def t183 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t154 γ) (t7 γ)
noncomputable def t184 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t179 γ) (t183 γ)
noncomputable def t185 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t184 γ)
noncomputable def t186 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t162 γ) (t4 γ)
noncomputable def t187 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t176 γ)
noncomputable def t188 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t187 γ) (t186 γ)
noncomputable def t189 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t163 γ) (t1 γ)
noncomputable def t190 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t188 γ) (t189 γ)
noncomputable def t191 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t17 γ)
noncomputable def t192 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t191 γ) (t4 γ)
noncomputable def t193 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t187 γ) (t192 γ)
noncomputable def t194 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t168 γ) (t1 γ)
noncomputable def t195 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t193 γ) (t194 γ)
noncomputable def t196 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t195 γ) (t7 γ)
noncomputable def t197 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t190 γ) (t196 γ)
noncomputable def t198 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n39
noncomputable def t199 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t176 γ) (t17 γ)
noncomputable def t200 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n40
noncomputable def t201 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n41
noncomputable def t202 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t201 γ)
noncomputable def t203 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t176 γ) (t1 γ)
noncomputable def t204 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t201 γ) (t203 γ)
noncomputable def t205 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n42
noncomputable def t206 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t176 γ) (t4 γ)
noncomputable def t207 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n43
noncomputable def t208 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t179 γ) (t7 γ)
noncomputable def t209 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t204 γ) (t208 γ)
noncomputable def t210 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t209 γ)
noncomputable def t211 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t187 γ) (t4 γ)
noncomputable def t212 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t201 γ)
noncomputable def t213 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t212 γ) (t211 γ)
noncomputable def t214 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t188 γ) (t1 γ)
noncomputable def t215 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t213 γ) (t214 γ)
noncomputable def t216 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t176 γ)
noncomputable def t217 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t216 γ) (t4 γ)
noncomputable def t218 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t212 γ) (t217 γ)
noncomputable def t219 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t193 γ) (t1 γ)
noncomputable def t220 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t218 γ) (t219 γ)
noncomputable def t221 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t220 γ) (t7 γ)
noncomputable def t222 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t215 γ) (t221 γ)
noncomputable def t223 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n44
noncomputable def t224 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t201 γ) (t176 γ)
noncomputable def t225 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n45
noncomputable def t226 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n46
noncomputable def t227 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t226 γ)
noncomputable def t228 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t201 γ) (t1 γ)
noncomputable def t229 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t226 γ) (t228 γ)
noncomputable def t230 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n47
noncomputable def t231 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t201 γ) (t4 γ)
noncomputable def t232 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n48
noncomputable def t233 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t204 γ) (t7 γ)
noncomputable def t234 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t229 γ) (t233 γ)
noncomputable def t235 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t234 γ)
noncomputable def t236 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t212 γ) (t4 γ)
noncomputable def t237 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t226 γ)
noncomputable def t238 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t237 γ) (t236 γ)
noncomputable def t239 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t213 γ) (t1 γ)
noncomputable def t240 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t238 γ) (t239 γ)
noncomputable def t241 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t201 γ)
noncomputable def t242 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t241 γ) (t4 γ)
noncomputable def t243 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t237 γ) (t242 γ)
noncomputable def t244 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t218 γ) (t1 γ)
noncomputable def t245 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t243 γ) (t244 γ)
noncomputable def t246 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t245 γ) (t7 γ)
noncomputable def t247 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t240 γ) (t246 γ)
noncomputable def t248 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n49
noncomputable def t249 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t226 γ) (t201 γ)
noncomputable def t250 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n50
noncomputable def t251 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n51
noncomputable def t252 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t251 γ)
noncomputable def t253 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t226 γ) (t1 γ)
noncomputable def t254 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t251 γ) (t253 γ)
noncomputable def t255 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n52
noncomputable def t256 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t226 γ) (t4 γ)
noncomputable def t257 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n53
noncomputable def t258 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t229 γ) (t7 γ)
noncomputable def t259 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t254 γ) (t258 γ)
noncomputable def t260 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t9 γ) (t259 γ)
noncomputable def t261 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t237 γ) (t4 γ)
noncomputable def t262 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t251 γ)
noncomputable def t263 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t262 γ) (t261 γ)
noncomputable def t264 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t238 γ) (t1 γ)
noncomputable def t265 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t263 γ) (t264 γ)
noncomputable def t266 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t4 γ) (t226 γ)
noncomputable def t267 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t266 γ) (t4 γ)
noncomputable def t268 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t262 γ) (t267 γ)
noncomputable def t269 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t243 γ) (t1 γ)
noncomputable def t270 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t268 γ) (t269 γ)
noncomputable def t271 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t270 γ) (t7 γ)
noncomputable def t272 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t265 γ) (t271 γ)
noncomputable def t273 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n54
noncomputable def t274 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t251 γ) (t226 γ)
noncomputable def t275 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n55
noncomputable def t276 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n56
noncomputable def t277 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t65 γ) (t276 γ)
noncomputable def t278 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t251 γ) (t1 γ)
noncomputable def t279 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t276 γ) (t278 γ)
noncomputable def t280 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n57
noncomputable def t281 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t251 γ) (t4 γ)
noncomputable def t282 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n58
noncomputable def t283 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t254 γ) (t7 γ)
noncomputable def t284 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t279 γ) (t283 γ)
noncomputable def t285 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary (Tensor.matvecValue Functions.addN.apply Functions.mulN.apply 0 2 2) (t284 γ) (t6 γ)
noncomputable def t286 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t251 γ) (t4 γ)
noncomputable def t287 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t286 γ) (t4 γ)
noncomputable def t288 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t276 γ) (t0 γ)
noncomputable def t289 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t288 γ) (t287 γ)
noncomputable def t290 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t226 γ) (t4 γ)
noncomputable def t291 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t290 γ) (t4 γ)
noncomputable def t292 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t251 γ) (t0 γ)
noncomputable def t293 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t292 γ) (t291 γ)
noncomputable def t294 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t293 γ) (t1 γ)
noncomputable def t295 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t289 γ) (t294 γ)
noncomputable def t296 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n59
noncomputable def t297 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n60
noncomputable def t298 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t276 γ) (t4 γ)
noncomputable def t299 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n61
noncomputable def t300 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n62
noncomputable def t301 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n63
noncomputable def t302 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Tensor.getValue (t279 γ) (t0 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p0 γ) (p1 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .refl (t4 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p4 γ) (p1 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p6 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p3 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .refl (t10 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t16 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 9)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .refl (t14 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p13 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t19 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 8)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t22 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 7)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t25 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 6)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t28 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 5)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .refl (t26 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t31 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 4)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .refl (t29 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t34 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 3)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .refl (t32 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p31 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t37 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 2)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .refl (t35 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t39 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 1)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p0 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t41 γ) := .ofEq (fun ξ ρ => Tensor.matrixPowerValue_succ Functions.addN.apply Functions.mulN.apply 0 1 2 ((t9 γ).eval ξ ρ) 0)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.scalar .natural)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matrixPowerValue Functions.addN.apply Functions.mulN.apply 0 1 2) (p9 γ) (p4 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t44 γ) := .ofEq (fun ξ ρ => rfl)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p4 γ) (p2 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t43 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p41 γ) (p7 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t44 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p6 γ) (p42 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t44 γ) := .trans (p40 γ) (p43 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t44 γ) := .trans (p39 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t45 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t63 γ) := .ofEq (fun ξ ρ => rfl)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t48 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p0 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t64 γ) := .ofEq (fun _ _ => rfl)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t64 γ) := .refl (t64 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t66 γ) := .scalarSimplify n16 n17 n0 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t65 γ) := .refl (t65 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t66 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p0 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t0 γ) := .guardTrue (t0 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t0 γ) := .trans (p54 γ) (p0 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t0 γ) := .trans (p53 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t0 γ) := .trans (p51 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t0 γ) := .trans (p50 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t0 γ) := .trans (p49 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t0 γ) := .trans (p48 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p4 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t67 γ) := .ofEq (fun _ _ => rfl)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t67 γ) := .refl (t67 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t68 γ) := .scalarSimplify n18 n17 n1 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t68 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p4 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t4 γ) := .guardTrue (t4 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t4 γ) := .trans (p66 γ) (p4 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t4 γ) := .trans (p65 γ) (p67 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t4 γ) := .trans (p64 γ) (p68 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t4 γ) := .trans (p63 γ) (p69 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t4 γ) := .trans (p62 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t4 γ) := .trans (p61 γ) (p71 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p72 γ) (p4 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t70 γ) := .refl (t70 γ)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t68 γ) := .scalarSimplify n15 n17 n1 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t4 γ) := .trans (p76 γ) (p68 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t70 γ) (t4 γ) := .trans (p75 γ) (p77 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p74 γ) (p78 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t4 γ) := .trans (p73 γ) (p79 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t71 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p60 γ) (p80 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t72 γ) := .ofEq (fun _ _ => rfl)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t72 γ) (t72 γ) := .refl (t72 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t72 γ) (t66 γ) := .scalarSimplify n19 n17 n0 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t72 γ) (t0 γ) := .trans (p84 γ) (p56 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t72 γ) (t0 γ) := .trans (p83 γ) (p85 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t0 γ) := .trans (p82 γ) (p86 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t0 γ) := .trans (p81 γ) (p87 γ)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t71 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p60 γ) (p4 γ)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t72 γ) := .ofEq (fun _ _ => rfl)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t0 γ) := .trans (p90 γ) (p86 γ)
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t0 γ) := .trans (p89 γ) (p91 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t73 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p72 γ) (p92 γ)
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t74 γ) := .ofEq (fun _ _ => rfl)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t74 γ) := .refl (t74 γ)
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t66 γ) := .scalarSimplify n20 n17 n0 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t0 γ) := .trans (p96 γ) (p56 γ)
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t0 γ) := .trans (p95 γ) (p97 γ)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t0 γ) := .trans (p94 γ) (p98 γ)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t0 γ) := .trans (p93 γ) (p99 γ)
theorem p101 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p100 γ) (p1 γ)
theorem p102 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p88 γ) (p101 γ)
theorem p103 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t54 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p4 γ)
theorem p104 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t75 γ) := .ofEq (fun _ _ => rfl)
theorem p105 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t75 γ) := .refl (t75 γ)
theorem p106 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t68 γ) := .scalarSimplify n13 n17 n1 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p107 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t4 γ) := .trans (p106 γ) (p68 γ)
theorem p108 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t4 γ) := .trans (p105 γ) (p107 γ)
theorem p109 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t4 γ) := .trans (p104 γ) (p108 γ)
theorem p110 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t4 γ) := .trans (p103 γ) (p109 γ)
theorem p111 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p110 γ) (p4 γ)
theorem p112 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p113 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p112 γ) (p78 γ)
theorem p114 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t4 γ) := .trans (p111 γ) (p113 γ)
theorem p115 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t71 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p60 γ) (p114 γ)
theorem p116 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t72 γ) := .ofEq (fun _ _ => rfl)
theorem p117 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t0 γ) := .trans (p116 γ) (p86 γ)
theorem p118 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t0 γ) := .trans (p115 γ) (p117 γ)
theorem p119 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t57 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p0 γ)
theorem p120 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t76 γ) := .ofEq (fun _ _ => rfl)
theorem p121 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t76 γ) := .refl (t76 γ)
theorem p122 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t68 γ) := .scalarSimplify n21 n17 n1 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p123 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t4 γ) := .trans (p122 γ) (p68 γ)
theorem p124 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t4 γ) := .trans (p121 γ) (p123 γ)
theorem p125 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t4 γ) := .trans (p120 γ) (p124 γ)
theorem p126 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t4 γ) := .trans (p119 γ) (p125 γ)
theorem p127 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p126 γ) (p4 γ)
theorem p128 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p129 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p128 γ) (p78 γ)
theorem p130 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t4 γ) := .trans (p127 γ) (p129 γ)
theorem p131 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p72 γ) (p130 γ)
theorem p132 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p133 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p132 γ) (p78 γ)
theorem p134 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t4 γ) := .trans (p131 γ) (p133 γ)
theorem p135 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t5 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p134 γ) (p1 γ)
theorem p136 (γ : Binding.Globals) : Binding.Reduction (t61 γ) (t6 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p118 γ) (p135 γ)
theorem p137 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t8 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p136 γ) (p7 γ)
theorem p138 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t9 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p102 γ) (p137 γ)
theorem p139 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t9 γ) := .trans (p47 γ) (p138 γ)
theorem p140 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t9 γ) := .trans (p46 γ) (p139 γ)
theorem p141 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t9 γ) := .trans (p38 γ) (p140 γ)
theorem p142 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t9 γ) := .trans (p37 γ) (p141 γ)
theorem p143 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t77 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p142 γ)
theorem p144 (γ : Binding.Globals) : Binding.Reduction (t77 γ) (t85 γ) := .ofEq (fun ξ ρ => rfl)
theorem p145 (γ : Binding.Globals) : Binding.Reduction (t78 γ) (t86 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p60 γ) (p92 γ)
theorem p146 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t87 γ) := .ofEq (fun _ _ => rfl)
theorem p147 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t87 γ) := .refl (t87 γ)
theorem p148 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t88 γ) := .scalarSimplify n22 n17 n10 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p149 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t88 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p34 γ)
theorem p150 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t35 γ) := .guardTrue (t35 γ)
theorem p151 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t35 γ) := .trans (p150 γ) (p34 γ)
theorem p152 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t35 γ) := .trans (p149 γ) (p151 γ)
theorem p153 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t35 γ) := .trans (p148 γ) (p152 γ)
theorem p154 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t35 γ) := .trans (p147 γ) (p153 γ)
theorem p155 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t35 γ) := .trans (p146 γ) (p154 γ)
theorem p156 (γ : Binding.Globals) : Binding.Reduction (t78 γ) (t35 γ) := .trans (p145 γ) (p155 γ)
theorem p157 (γ : Binding.Globals) : Binding.Reduction (t79 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p88 γ) (p1 γ)
theorem p158 (γ : Binding.Globals) : Binding.Reduction (t80 γ) (t89 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p156 γ) (p157 γ)
theorem p159 (γ : Binding.Globals) : Binding.Reduction (t81 γ) (t71 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p60 γ) (p130 γ)
theorem p160 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t72 γ) := .ofEq (fun _ _ => rfl)
theorem p161 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t0 γ) := .trans (p160 γ) (p86 γ)
theorem p162 (γ : Binding.Globals) : Binding.Reduction (t81 γ) (t0 γ) := .trans (p159 γ) (p161 γ)
theorem p163 (γ : Binding.Globals) : Binding.Reduction (t82 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p118 γ) (p1 γ)
theorem p164 (γ : Binding.Globals) : Binding.Reduction (t83 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p162 γ) (p163 γ)
theorem p165 (γ : Binding.Globals) : Binding.Reduction (t84 γ) (t90 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p164 γ) (p7 γ)
theorem p166 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t91 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p158 γ) (p165 γ)
theorem p167 (γ : Binding.Globals) : Binding.Reduction (t77 γ) (t91 γ) := .trans (p144 γ) (p166 γ)
theorem p168 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t91 γ) := .trans (p143 γ) (p167 γ)
theorem p169 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t91 γ) := .trans (p36 γ) (p168 γ)
theorem p170 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t91 γ) := .trans (p35 γ) (p169 γ)
theorem p171 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t92 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p170 γ)
theorem p172 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t101 γ) := .ofEq (fun ξ ρ => rfl)
theorem p173 (γ : Binding.Globals) : Binding.Reduction (t93 γ) (t93 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p34 γ)
theorem p174 (γ : Binding.Globals) : Binding.Reduction (t93 γ) (t102 γ) := .ofEq (fun _ _ => rfl)
theorem p175 (γ : Binding.Globals) : Binding.Reduction (t102 γ) (t102 γ) := .refl (t102 γ)
theorem p176 (γ : Binding.Globals) : Binding.Reduction (t102 γ) (t88 γ) := .scalarSimplify n23 n17 n10 QSym.BindingScalar8.DomainCertificate.domain_correct QSym.BindingScalar8.ValueCertificate.refinement
theorem p177 (γ : Binding.Globals) : Binding.Reduction (t102 γ) (t35 γ) := .trans (p176 γ) (p152 γ)
theorem p178 (γ : Binding.Globals) : Binding.Reduction (t102 γ) (t35 γ) := .trans (p175 γ) (p177 γ)
theorem p179 (γ : Binding.Globals) : Binding.Reduction (t93 γ) (t35 γ) := .trans (p174 γ) (p178 γ)
theorem p180 (γ : Binding.Globals) : Binding.Reduction (t93 γ) (t35 γ) := .trans (p173 γ) (p179 γ)
theorem p181 (γ : Binding.Globals) : Binding.Reduction (t94 γ) (t103 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p180 γ) (p92 γ)
theorem p182 (γ : Binding.Globals) : Binding.Reduction (t103 γ) (t104 γ) := .ofEq (fun _ _ => rfl)
theorem p183 (γ : Binding.Globals) : Binding.Reduction (t104 γ) (t104 γ) := .refl (t104 γ)
theorem p184 (γ : Binding.Globals) : Binding.Reduction (t104 γ) (t105 γ) := .scalarSimplify n24 n17 n9 QSym.BindingScalar9.DomainCertificate.domain_correct QSym.BindingScalar9.ValueCertificate.refinement
theorem p185 (γ : Binding.Globals) : Binding.Reduction (t105 γ) (t105 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p31 γ)
theorem p186 (γ : Binding.Globals) : Binding.Reduction (t105 γ) (t32 γ) := .guardTrue (t32 γ)
theorem p187 (γ : Binding.Globals) : Binding.Reduction (t105 γ) (t32 γ) := .trans (p186 γ) (p31 γ)
theorem p188 (γ : Binding.Globals) : Binding.Reduction (t105 γ) (t32 γ) := .trans (p185 γ) (p187 γ)
theorem p189 (γ : Binding.Globals) : Binding.Reduction (t104 γ) (t32 γ) := .trans (p184 γ) (p188 γ)
theorem p190 (γ : Binding.Globals) : Binding.Reduction (t104 γ) (t32 γ) := .trans (p183 γ) (p189 γ)
theorem p191 (γ : Binding.Globals) : Binding.Reduction (t103 γ) (t32 γ) := .trans (p182 γ) (p190 γ)
theorem p192 (γ : Binding.Globals) : Binding.Reduction (t94 γ) (t32 γ) := .trans (p181 γ) (p191 γ)
theorem p193 (γ : Binding.Globals) : Binding.Reduction (t95 γ) (t106 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p156 γ) (p1 γ)
theorem p194 (γ : Binding.Globals) : Binding.Reduction (t96 γ) (t107 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p192 γ) (p193 γ)
theorem p195 (γ : Binding.Globals) : Binding.Reduction (t97 γ) (t108 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p180 γ) (p130 γ)
theorem p196 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t109 γ) := .ofEq (fun _ _ => rfl)
theorem p197 (γ : Binding.Globals) : Binding.Reduction (t109 γ) (t109 γ) := .refl (t109 γ)
theorem p198 (γ : Binding.Globals) : Binding.Reduction (t109 γ) (t88 γ) := .scalarSimplify n25 n17 n10 QSym.BindingScalar10.DomainCertificate.domain_correct QSym.BindingScalar10.ValueCertificate.refinement
theorem p199 (γ : Binding.Globals) : Binding.Reduction (t109 γ) (t35 γ) := .trans (p198 γ) (p152 γ)
theorem p200 (γ : Binding.Globals) : Binding.Reduction (t109 γ) (t35 γ) := .trans (p197 γ) (p199 γ)
theorem p201 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t35 γ) := .trans (p196 γ) (p200 γ)
theorem p202 (γ : Binding.Globals) : Binding.Reduction (t97 γ) (t35 γ) := .trans (p195 γ) (p201 γ)
theorem p203 (γ : Binding.Globals) : Binding.Reduction (t98 γ) (t2 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p162 γ) (p1 γ)
theorem p204 (γ : Binding.Globals) : Binding.Reduction (t99 γ) (t89 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p202 γ) (p203 γ)
theorem p205 (γ : Binding.Globals) : Binding.Reduction (t100 γ) (t110 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p204 γ) (p7 γ)
theorem p206 (γ : Binding.Globals) : Binding.Reduction (t101 γ) (t111 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p194 γ) (p205 γ)
theorem p207 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t111 γ) := .trans (p172 γ) (p206 γ)
theorem p208 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t111 γ) := .trans (p171 γ) (p207 γ)
theorem p209 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t111 γ) := .trans (p33 γ) (p208 γ)
theorem p210 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t111 γ) := .trans (p32 γ) (p209 γ)
theorem p211 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t112 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p210 γ)
theorem p212 (γ : Binding.Globals) : Binding.Reduction (t112 γ) (t124 γ) := .ofEq (fun ξ ρ => rfl)
theorem p213 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t114 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p31 γ)
theorem p214 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t125 γ) := .ofEq (fun _ _ => rfl)
theorem p215 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t125 γ) := .refl (t125 γ)
theorem p216 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t105 γ) := .scalarSimplify n26 n17 n9 QSym.BindingScalar11.DomainCertificate.domain_correct QSym.BindingScalar11.ValueCertificate.refinement
theorem p217 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t32 γ) := .trans (p216 γ) (p188 γ)
theorem p218 (γ : Binding.Globals) : Binding.Reduction (t125 γ) (t32 γ) := .trans (p215 γ) (p217 γ)
theorem p219 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t32 γ) := .trans (p214 γ) (p218 γ)
theorem p220 (γ : Binding.Globals) : Binding.Reduction (t114 γ) (t32 γ) := .trans (p213 γ) (p219 γ)
theorem p221 (γ : Binding.Globals) : Binding.Reduction (t113 γ) (t108 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p180 γ) (p4 γ)
theorem p222 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t109 γ) := .ofEq (fun _ _ => rfl)
theorem p223 (γ : Binding.Globals) : Binding.Reduction (t108 γ) (t35 γ) := .trans (p222 γ) (p200 γ)
theorem p224 (γ : Binding.Globals) : Binding.Reduction (t113 γ) (t35 γ) := .trans (p221 γ) (p223 γ)
theorem p225 (γ : Binding.Globals) : Binding.Reduction (t115 γ) (t126 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p220 γ) (p224 γ)
theorem p226 (γ : Binding.Globals) : Binding.Reduction (t126 γ) (t127 γ) := .ofEq (fun _ _ => rfl)
theorem p227 (γ : Binding.Globals) : Binding.Reduction (t127 γ) (t127 γ) := .refl (t127 γ)
theorem p228 (γ : Binding.Globals) : Binding.Reduction (t127 γ) (t128 γ) := .scalarSimplify n27 n17 n7 QSym.BindingScalar12.DomainCertificate.domain_correct QSym.BindingScalar12.ValueCertificate.refinement
theorem p229 (γ : Binding.Globals) : Binding.Reduction (t128 γ) (t128 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p25 γ)
theorem p230 (γ : Binding.Globals) : Binding.Reduction (t128 γ) (t26 γ) := .guardTrue (t26 γ)
theorem p231 (γ : Binding.Globals) : Binding.Reduction (t128 γ) (t26 γ) := .trans (p230 γ) (p25 γ)
theorem p232 (γ : Binding.Globals) : Binding.Reduction (t128 γ) (t26 γ) := .trans (p229 γ) (p231 γ)
theorem p233 (γ : Binding.Globals) : Binding.Reduction (t127 γ) (t26 γ) := .trans (p228 γ) (p232 γ)
theorem p234 (γ : Binding.Globals) : Binding.Reduction (t127 γ) (t26 γ) := .trans (p227 γ) (p233 γ)
theorem p235 (γ : Binding.Globals) : Binding.Reduction (t126 γ) (t26 γ) := .trans (p226 γ) (p234 γ)
theorem p236 (γ : Binding.Globals) : Binding.Reduction (t115 γ) (t26 γ) := .trans (p225 γ) (p235 γ)
theorem p237 (γ : Binding.Globals) : Binding.Reduction (t116 γ) (t129 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p192 γ) (p1 γ)
theorem p238 (γ : Binding.Globals) : Binding.Reduction (t117 γ) (t130 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p236 γ) (p237 γ)
theorem p239 (γ : Binding.Globals) : Binding.Reduction (t118 γ) (t118 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p34 γ)
theorem p240 (γ : Binding.Globals) : Binding.Reduction (t118 γ) (t131 γ) := .ofEq (fun _ _ => rfl)
theorem p241 (γ : Binding.Globals) : Binding.Reduction (t131 γ) (t131 γ) := .refl (t131 γ)
theorem p242 (γ : Binding.Globals) : Binding.Reduction (t131 γ) (t68 γ) := .scalarSimplify n28 n17 n1 QSym.BindingScalar13.DomainCertificate.domain_correct QSym.BindingScalar13.ValueCertificate.refinement
theorem p243 (γ : Binding.Globals) : Binding.Reduction (t131 γ) (t4 γ) := .trans (p242 γ) (p68 γ)
theorem p244 (γ : Binding.Globals) : Binding.Reduction (t131 γ) (t4 γ) := .trans (p241 γ) (p243 γ)
theorem p245 (γ : Binding.Globals) : Binding.Reduction (t118 γ) (t4 γ) := .trans (p240 γ) (p244 γ)
theorem p246 (γ : Binding.Globals) : Binding.Reduction (t118 γ) (t4 γ) := .trans (p239 γ) (p245 γ)
theorem p247 (γ : Binding.Globals) : Binding.Reduction (t119 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p246 γ) (p4 γ)
theorem p248 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p249 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p248 γ) (p78 γ)
theorem p250 (γ : Binding.Globals) : Binding.Reduction (t119 γ) (t4 γ) := .trans (p247 γ) (p249 γ)
theorem p251 (γ : Binding.Globals) : Binding.Reduction (t120 γ) (t132 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p220 γ) (p250 γ)
theorem p252 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t133 γ) := .ofEq (fun _ _ => rfl)
theorem p253 (γ : Binding.Globals) : Binding.Reduction (t133 γ) (t133 γ) := .refl (t133 γ)
theorem p254 (γ : Binding.Globals) : Binding.Reduction (t133 γ) (t105 γ) := .scalarSimplify n29 n17 n9 QSym.BindingScalar14.DomainCertificate.domain_correct QSym.BindingScalar14.ValueCertificate.refinement
theorem p255 (γ : Binding.Globals) : Binding.Reduction (t133 γ) (t32 γ) := .trans (p254 γ) (p188 γ)
theorem p256 (γ : Binding.Globals) : Binding.Reduction (t133 γ) (t32 γ) := .trans (p253 γ) (p255 γ)
theorem p257 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t32 γ) := .trans (p252 γ) (p256 γ)
theorem p258 (γ : Binding.Globals) : Binding.Reduction (t120 γ) (t32 γ) := .trans (p251 γ) (p257 γ)
theorem p259 (γ : Binding.Globals) : Binding.Reduction (t121 γ) (t106 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p202 γ) (p1 γ)
theorem p260 (γ : Binding.Globals) : Binding.Reduction (t122 γ) (t107 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p258 γ) (p259 γ)
theorem p261 (γ : Binding.Globals) : Binding.Reduction (t123 γ) (t134 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p260 γ) (p7 γ)
theorem p262 (γ : Binding.Globals) : Binding.Reduction (t124 γ) (t135 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p238 γ) (p261 γ)
theorem p263 (γ : Binding.Globals) : Binding.Reduction (t112 γ) (t135 γ) := .trans (p212 γ) (p262 γ)
theorem p264 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t135 γ) := .trans (p211 γ) (p263 γ)
theorem p265 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t135 γ) := .trans (p30 γ) (p264 γ)
theorem p266 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t135 γ) := .trans (p29 γ) (p265 γ)
theorem p267 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t136 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p266 γ)
theorem p268 (γ : Binding.Globals) : Binding.Reduction (t136 γ) (t148 γ) := .ofEq (fun ξ ρ => rfl)
theorem p269 (γ : Binding.Globals) : Binding.Reduction (t138 γ) (t138 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p25 γ)
theorem p270 (γ : Binding.Globals) : Binding.Reduction (t138 γ) (t149 γ) := .ofEq (fun _ _ => rfl)
theorem p271 (γ : Binding.Globals) : Binding.Reduction (t149 γ) (t149 γ) := .refl (t149 γ)
theorem p272 (γ : Binding.Globals) : Binding.Reduction (t149 γ) (t128 γ) := .scalarSimplify n30 n17 n7 QSym.BindingScalar15.DomainCertificate.domain_correct QSym.BindingScalar15.ValueCertificate.refinement
theorem p273 (γ : Binding.Globals) : Binding.Reduction (t149 γ) (t26 γ) := .trans (p272 γ) (p232 γ)
theorem p274 (γ : Binding.Globals) : Binding.Reduction (t149 γ) (t26 γ) := .trans (p271 γ) (p273 γ)
theorem p275 (γ : Binding.Globals) : Binding.Reduction (t138 γ) (t26 γ) := .trans (p270 γ) (p274 γ)
theorem p276 (γ : Binding.Globals) : Binding.Reduction (t138 γ) (t26 γ) := .trans (p269 γ) (p275 γ)
theorem p277 (γ : Binding.Globals) : Binding.Reduction (t137 γ) (t132 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p220 γ) (p4 γ)
theorem p278 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t133 γ) := .ofEq (fun _ _ => rfl)
theorem p279 (γ : Binding.Globals) : Binding.Reduction (t132 γ) (t32 γ) := .trans (p278 γ) (p256 γ)
theorem p280 (γ : Binding.Globals) : Binding.Reduction (t137 γ) (t32 γ) := .trans (p277 γ) (p279 γ)
theorem p281 (γ : Binding.Globals) : Binding.Reduction (t139 γ) (t150 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p276 γ) (p280 γ)
theorem p282 (γ : Binding.Globals) : Binding.Reduction (t150 γ) (t151 γ) := .ofEq (fun _ _ => rfl)
theorem p283 (γ : Binding.Globals) : Binding.Reduction (t151 γ) (t151 γ) := .refl (t151 γ)
theorem p284 (γ : Binding.Globals) : Binding.Reduction (t151 γ) (t152 γ) := .scalarSimplify n31 n17 n4 QSym.BindingScalar16.DomainCertificate.domain_correct QSym.BindingScalar16.ValueCertificate.refinement
theorem p285 (γ : Binding.Globals) : Binding.Reduction (t152 γ) (t152 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p16 γ)
theorem p286 (γ : Binding.Globals) : Binding.Reduction (t152 γ) (t17 γ) := .guardTrue (t17 γ)
theorem p287 (γ : Binding.Globals) : Binding.Reduction (t152 γ) (t17 γ) := .trans (p286 γ) (p16 γ)
theorem p288 (γ : Binding.Globals) : Binding.Reduction (t152 γ) (t17 γ) := .trans (p285 γ) (p287 γ)
theorem p289 (γ : Binding.Globals) : Binding.Reduction (t151 γ) (t17 γ) := .trans (p284 γ) (p288 γ)
theorem p290 (γ : Binding.Globals) : Binding.Reduction (t151 γ) (t17 γ) := .trans (p283 γ) (p289 γ)
theorem p291 (γ : Binding.Globals) : Binding.Reduction (t150 γ) (t17 γ) := .trans (p282 γ) (p290 γ)
theorem p292 (γ : Binding.Globals) : Binding.Reduction (t139 γ) (t17 γ) := .trans (p281 γ) (p291 γ)
theorem p293 (γ : Binding.Globals) : Binding.Reduction (t140 γ) (t153 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p236 γ) (p1 γ)
theorem p294 (γ : Binding.Globals) : Binding.Reduction (t141 γ) (t154 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p292 γ) (p293 γ)
theorem p295 (γ : Binding.Globals) : Binding.Reduction (t142 γ) (t142 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p31 γ)
theorem p296 (γ : Binding.Globals) : Binding.Reduction (t142 γ) (t155 γ) := .ofEq (fun _ _ => rfl)
theorem p297 (γ : Binding.Globals) : Binding.Reduction (t155 γ) (t155 γ) := .refl (t155 γ)
theorem p298 (γ : Binding.Globals) : Binding.Reduction (t155 γ) (t68 γ) := .scalarSimplify n32 n17 n1 QSym.BindingScalar17.DomainCertificate.domain_correct QSym.BindingScalar17.ValueCertificate.refinement
theorem p299 (γ : Binding.Globals) : Binding.Reduction (t155 γ) (t4 γ) := .trans (p298 γ) (p68 γ)
theorem p300 (γ : Binding.Globals) : Binding.Reduction (t155 γ) (t4 γ) := .trans (p297 γ) (p299 γ)
theorem p301 (γ : Binding.Globals) : Binding.Reduction (t142 γ) (t4 γ) := .trans (p296 γ) (p300 γ)
theorem p302 (γ : Binding.Globals) : Binding.Reduction (t142 γ) (t4 γ) := .trans (p295 γ) (p301 γ)
theorem p303 (γ : Binding.Globals) : Binding.Reduction (t143 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p302 γ) (p4 γ)
theorem p304 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p305 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p304 γ) (p78 γ)
theorem p306 (γ : Binding.Globals) : Binding.Reduction (t143 γ) (t4 γ) := .trans (p303 γ) (p305 γ)
theorem p307 (γ : Binding.Globals) : Binding.Reduction (t144 γ) (t156 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p276 γ) (p306 γ)
theorem p308 (γ : Binding.Globals) : Binding.Reduction (t156 γ) (t157 γ) := .ofEq (fun _ _ => rfl)
theorem p309 (γ : Binding.Globals) : Binding.Reduction (t157 γ) (t157 γ) := .refl (t157 γ)
theorem p310 (γ : Binding.Globals) : Binding.Reduction (t157 γ) (t128 γ) := .scalarSimplify n33 n17 n7 QSym.BindingScalar18.DomainCertificate.domain_correct QSym.BindingScalar18.ValueCertificate.refinement
theorem p311 (γ : Binding.Globals) : Binding.Reduction (t157 γ) (t26 γ) := .trans (p310 γ) (p232 γ)
theorem p312 (γ : Binding.Globals) : Binding.Reduction (t157 γ) (t26 γ) := .trans (p309 γ) (p311 γ)
theorem p313 (γ : Binding.Globals) : Binding.Reduction (t156 γ) (t26 γ) := .trans (p308 γ) (p312 γ)
theorem p314 (γ : Binding.Globals) : Binding.Reduction (t144 γ) (t26 γ) := .trans (p307 γ) (p313 γ)
theorem p315 (γ : Binding.Globals) : Binding.Reduction (t145 γ) (t129 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p258 γ) (p1 γ)
theorem p316 (γ : Binding.Globals) : Binding.Reduction (t146 γ) (t130 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p314 γ) (p315 γ)
theorem p317 (γ : Binding.Globals) : Binding.Reduction (t147 γ) (t158 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p316 γ) (p7 γ)
theorem p318 (γ : Binding.Globals) : Binding.Reduction (t148 γ) (t159 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p294 γ) (p317 γ)
theorem p319 (γ : Binding.Globals) : Binding.Reduction (t136 γ) (t159 γ) := .trans (p268 γ) (p318 γ)
theorem p320 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t159 γ) := .trans (p267 γ) (p319 γ)
theorem p321 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t159 γ) := .trans (p27 γ) (p320 γ)
theorem p322 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t159 γ) := .trans (p26 γ) (p321 γ)
theorem p323 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t160 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p322 γ)
theorem p324 (γ : Binding.Globals) : Binding.Reduction (t160 γ) (t172 γ) := .ofEq (fun ξ ρ => rfl)
theorem p325 (γ : Binding.Globals) : Binding.Reduction (t162 γ) (t162 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p16 γ)
theorem p326 (γ : Binding.Globals) : Binding.Reduction (t162 γ) (t173 γ) := .ofEq (fun _ _ => rfl)
theorem p327 (γ : Binding.Globals) : Binding.Reduction (t173 γ) (t173 γ) := .refl (t173 γ)
theorem p328 (γ : Binding.Globals) : Binding.Reduction (t173 γ) (t152 γ) := .scalarSimplify n34 n17 n4 QSym.BindingScalar19.DomainCertificate.domain_correct QSym.BindingScalar19.ValueCertificate.refinement
theorem p329 (γ : Binding.Globals) : Binding.Reduction (t173 γ) (t17 γ) := .trans (p328 γ) (p288 γ)
theorem p330 (γ : Binding.Globals) : Binding.Reduction (t173 γ) (t17 γ) := .trans (p327 γ) (p329 γ)
theorem p331 (γ : Binding.Globals) : Binding.Reduction (t162 γ) (t17 γ) := .trans (p326 γ) (p330 γ)
theorem p332 (γ : Binding.Globals) : Binding.Reduction (t162 γ) (t17 γ) := .trans (p325 γ) (p331 γ)
theorem p333 (γ : Binding.Globals) : Binding.Reduction (t161 γ) (t156 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p276 γ) (p4 γ)
theorem p334 (γ : Binding.Globals) : Binding.Reduction (t156 γ) (t157 γ) := .ofEq (fun _ _ => rfl)
theorem p335 (γ : Binding.Globals) : Binding.Reduction (t156 γ) (t26 γ) := .trans (p334 γ) (p312 γ)
theorem p336 (γ : Binding.Globals) : Binding.Reduction (t161 γ) (t26 γ) := .trans (p333 γ) (p335 γ)
theorem p337 (γ : Binding.Globals) : Binding.Reduction (t163 γ) (t174 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p332 γ) (p336 γ)
theorem p338 (γ : Binding.Globals) : Binding.Reduction (t174 γ) (t175 γ) := .ofEq (fun _ _ => rfl)
theorem p339 (γ : Binding.Globals) : Binding.Reduction (t175 γ) (t175 γ) := .refl (t175 γ)
theorem p340 (γ : Binding.Globals) : Binding.Reduction (t175 γ) (t177 γ) := .scalarSimplify n35 n17 n36 QSym.BindingScalar20.DomainCertificate.domain_correct QSym.BindingScalar20.ValueCertificate.refinement
theorem p341 (γ : Binding.Globals) : Binding.Reduction (t176 γ) (t176 γ) := .refl (t176 γ)
theorem p342 (γ : Binding.Globals) : Binding.Reduction (t177 γ) (t177 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p341 γ)
theorem p343 (γ : Binding.Globals) : Binding.Reduction (t177 γ) (t176 γ) := .guardTrue (t176 γ)
theorem p344 (γ : Binding.Globals) : Binding.Reduction (t177 γ) (t176 γ) := .trans (p343 γ) (p341 γ)
theorem p345 (γ : Binding.Globals) : Binding.Reduction (t177 γ) (t176 γ) := .trans (p342 γ) (p344 γ)
theorem p346 (γ : Binding.Globals) : Binding.Reduction (t175 γ) (t176 γ) := .trans (p340 γ) (p345 γ)
theorem p347 (γ : Binding.Globals) : Binding.Reduction (t175 γ) (t176 γ) := .trans (p339 γ) (p346 γ)
theorem p348 (γ : Binding.Globals) : Binding.Reduction (t174 γ) (t176 γ) := .trans (p338 γ) (p347 γ)
theorem p349 (γ : Binding.Globals) : Binding.Reduction (t163 γ) (t176 γ) := .trans (p337 γ) (p348 γ)
theorem p350 (γ : Binding.Globals) : Binding.Reduction (t164 γ) (t178 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p292 γ) (p1 γ)
theorem p351 (γ : Binding.Globals) : Binding.Reduction (t165 γ) (t179 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p349 γ) (p350 γ)
theorem p352 (γ : Binding.Globals) : Binding.Reduction (t166 γ) (t166 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p25 γ)
theorem p353 (γ : Binding.Globals) : Binding.Reduction (t166 γ) (t180 γ) := .ofEq (fun _ _ => rfl)
theorem p354 (γ : Binding.Globals) : Binding.Reduction (t180 γ) (t180 γ) := .refl (t180 γ)
theorem p355 (γ : Binding.Globals) : Binding.Reduction (t180 γ) (t68 γ) := .scalarSimplify n37 n17 n1 QSym.BindingScalar21.DomainCertificate.domain_correct QSym.BindingScalar21.ValueCertificate.refinement
theorem p356 (γ : Binding.Globals) : Binding.Reduction (t180 γ) (t4 γ) := .trans (p355 γ) (p68 γ)
theorem p357 (γ : Binding.Globals) : Binding.Reduction (t180 γ) (t4 γ) := .trans (p354 γ) (p356 γ)
theorem p358 (γ : Binding.Globals) : Binding.Reduction (t166 γ) (t4 γ) := .trans (p353 γ) (p357 γ)
theorem p359 (γ : Binding.Globals) : Binding.Reduction (t166 γ) (t4 γ) := .trans (p352 γ) (p358 γ)
theorem p360 (γ : Binding.Globals) : Binding.Reduction (t167 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p359 γ) (p4 γ)
theorem p361 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p362 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p361 γ) (p78 γ)
theorem p363 (γ : Binding.Globals) : Binding.Reduction (t167 γ) (t4 γ) := .trans (p360 γ) (p362 γ)
theorem p364 (γ : Binding.Globals) : Binding.Reduction (t168 γ) (t181 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p332 γ) (p363 γ)
theorem p365 (γ : Binding.Globals) : Binding.Reduction (t181 γ) (t182 γ) := .ofEq (fun _ _ => rfl)
theorem p366 (γ : Binding.Globals) : Binding.Reduction (t182 γ) (t182 γ) := .refl (t182 γ)
theorem p367 (γ : Binding.Globals) : Binding.Reduction (t182 γ) (t152 γ) := .scalarSimplify n38 n17 n4 QSym.BindingScalar22.DomainCertificate.domain_correct QSym.BindingScalar22.ValueCertificate.refinement
theorem p368 (γ : Binding.Globals) : Binding.Reduction (t182 γ) (t17 γ) := .trans (p367 γ) (p288 γ)
theorem p369 (γ : Binding.Globals) : Binding.Reduction (t182 γ) (t17 γ) := .trans (p366 γ) (p368 γ)
theorem p370 (γ : Binding.Globals) : Binding.Reduction (t181 γ) (t17 γ) := .trans (p365 γ) (p369 γ)
theorem p371 (γ : Binding.Globals) : Binding.Reduction (t168 γ) (t17 γ) := .trans (p364 γ) (p370 γ)
theorem p372 (γ : Binding.Globals) : Binding.Reduction (t169 γ) (t153 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p314 γ) (p1 γ)
theorem p373 (γ : Binding.Globals) : Binding.Reduction (t170 γ) (t154 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p371 γ) (p372 γ)
theorem p374 (γ : Binding.Globals) : Binding.Reduction (t171 γ) (t183 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p373 γ) (p7 γ)
theorem p375 (γ : Binding.Globals) : Binding.Reduction (t172 γ) (t184 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p351 γ) (p374 γ)
theorem p376 (γ : Binding.Globals) : Binding.Reduction (t160 γ) (t184 γ) := .trans (p324 γ) (p375 γ)
theorem p377 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t184 γ) := .trans (p323 γ) (p376 γ)
theorem p378 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t184 γ) := .trans (p24 γ) (p377 γ)
theorem p379 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t184 γ) := .trans (p23 γ) (p378 γ)
theorem p380 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t185 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p379 γ)
theorem p381 (γ : Binding.Globals) : Binding.Reduction (t185 γ) (t197 γ) := .ofEq (fun ξ ρ => rfl)
theorem p382 (γ : Binding.Globals) : Binding.Reduction (t187 γ) (t187 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p341 γ)
theorem p383 (γ : Binding.Globals) : Binding.Reduction (t187 γ) (t198 γ) := .ofEq (fun _ _ => rfl)
theorem p384 (γ : Binding.Globals) : Binding.Reduction (t198 γ) (t198 γ) := .refl (t198 γ)
theorem p385 (γ : Binding.Globals) : Binding.Reduction (t198 γ) (t177 γ) := .scalarSimplify n39 n17 n36 QSym.BindingScalar23.DomainCertificate.domain_correct QSym.BindingScalar23.ValueCertificate.refinement
theorem p386 (γ : Binding.Globals) : Binding.Reduction (t198 γ) (t176 γ) := .trans (p385 γ) (p345 γ)
theorem p387 (γ : Binding.Globals) : Binding.Reduction (t198 γ) (t176 γ) := .trans (p384 γ) (p386 γ)
theorem p388 (γ : Binding.Globals) : Binding.Reduction (t187 γ) (t176 γ) := .trans (p383 γ) (p387 γ)
theorem p389 (γ : Binding.Globals) : Binding.Reduction (t187 γ) (t176 γ) := .trans (p382 γ) (p388 γ)
theorem p390 (γ : Binding.Globals) : Binding.Reduction (t186 γ) (t181 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p332 γ) (p4 γ)
theorem p391 (γ : Binding.Globals) : Binding.Reduction (t181 γ) (t182 γ) := .ofEq (fun _ _ => rfl)
theorem p392 (γ : Binding.Globals) : Binding.Reduction (t181 γ) (t17 γ) := .trans (p391 γ) (p369 γ)
theorem p393 (γ : Binding.Globals) : Binding.Reduction (t186 γ) (t17 γ) := .trans (p390 γ) (p392 γ)
theorem p394 (γ : Binding.Globals) : Binding.Reduction (t188 γ) (t199 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p389 γ) (p393 γ)
theorem p395 (γ : Binding.Globals) : Binding.Reduction (t199 γ) (t200 γ) := .ofEq (fun _ _ => rfl)
theorem p396 (γ : Binding.Globals) : Binding.Reduction (t200 γ) (t200 γ) := .refl (t200 γ)
theorem p397 (γ : Binding.Globals) : Binding.Reduction (t200 γ) (t202 γ) := .scalarSimplify n40 n17 n41 QSym.BindingScalar24.DomainCertificate.domain_correct QSym.BindingScalar24.ValueCertificate.refinement
theorem p398 (γ : Binding.Globals) : Binding.Reduction (t201 γ) (t201 γ) := .refl (t201 γ)
theorem p399 (γ : Binding.Globals) : Binding.Reduction (t202 γ) (t202 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p398 γ)
theorem p400 (γ : Binding.Globals) : Binding.Reduction (t202 γ) (t201 γ) := .guardTrue (t201 γ)
theorem p401 (γ : Binding.Globals) : Binding.Reduction (t202 γ) (t201 γ) := .trans (p400 γ) (p398 γ)
theorem p402 (γ : Binding.Globals) : Binding.Reduction (t202 γ) (t201 γ) := .trans (p399 γ) (p401 γ)
theorem p403 (γ : Binding.Globals) : Binding.Reduction (t200 γ) (t201 γ) := .trans (p397 γ) (p402 γ)
theorem p404 (γ : Binding.Globals) : Binding.Reduction (t200 γ) (t201 γ) := .trans (p396 γ) (p403 γ)
theorem p405 (γ : Binding.Globals) : Binding.Reduction (t199 γ) (t201 γ) := .trans (p395 γ) (p404 γ)
theorem p406 (γ : Binding.Globals) : Binding.Reduction (t188 γ) (t201 γ) := .trans (p394 γ) (p405 γ)
theorem p407 (γ : Binding.Globals) : Binding.Reduction (t189 γ) (t203 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p349 γ) (p1 γ)
theorem p408 (γ : Binding.Globals) : Binding.Reduction (t190 γ) (t204 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p406 γ) (p407 γ)
theorem p409 (γ : Binding.Globals) : Binding.Reduction (t191 γ) (t191 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p16 γ)
theorem p410 (γ : Binding.Globals) : Binding.Reduction (t191 γ) (t205 γ) := .ofEq (fun _ _ => rfl)
theorem p411 (γ : Binding.Globals) : Binding.Reduction (t205 γ) (t205 γ) := .refl (t205 γ)
theorem p412 (γ : Binding.Globals) : Binding.Reduction (t205 γ) (t68 γ) := .scalarSimplify n42 n17 n1 QSym.BindingScalar25.DomainCertificate.domain_correct QSym.BindingScalar25.ValueCertificate.refinement
theorem p413 (γ : Binding.Globals) : Binding.Reduction (t205 γ) (t4 γ) := .trans (p412 γ) (p68 γ)
theorem p414 (γ : Binding.Globals) : Binding.Reduction (t205 γ) (t4 γ) := .trans (p411 γ) (p413 γ)
theorem p415 (γ : Binding.Globals) : Binding.Reduction (t191 γ) (t4 γ) := .trans (p410 γ) (p414 γ)
theorem p416 (γ : Binding.Globals) : Binding.Reduction (t191 γ) (t4 γ) := .trans (p409 γ) (p415 γ)
theorem p417 (γ : Binding.Globals) : Binding.Reduction (t192 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p416 γ) (p4 γ)
theorem p418 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p419 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p418 γ) (p78 γ)
theorem p420 (γ : Binding.Globals) : Binding.Reduction (t192 γ) (t4 γ) := .trans (p417 γ) (p419 γ)
theorem p421 (γ : Binding.Globals) : Binding.Reduction (t193 γ) (t206 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p389 γ) (p420 γ)
theorem p422 (γ : Binding.Globals) : Binding.Reduction (t206 γ) (t207 γ) := .ofEq (fun _ _ => rfl)
theorem p423 (γ : Binding.Globals) : Binding.Reduction (t207 γ) (t207 γ) := .refl (t207 γ)
theorem p424 (γ : Binding.Globals) : Binding.Reduction (t207 γ) (t177 γ) := .scalarSimplify n43 n17 n36 QSym.BindingScalar26.DomainCertificate.domain_correct QSym.BindingScalar26.ValueCertificate.refinement
theorem p425 (γ : Binding.Globals) : Binding.Reduction (t207 γ) (t176 γ) := .trans (p424 γ) (p345 γ)
theorem p426 (γ : Binding.Globals) : Binding.Reduction (t207 γ) (t176 γ) := .trans (p423 γ) (p425 γ)
theorem p427 (γ : Binding.Globals) : Binding.Reduction (t206 γ) (t176 γ) := .trans (p422 γ) (p426 γ)
theorem p428 (γ : Binding.Globals) : Binding.Reduction (t193 γ) (t176 γ) := .trans (p421 γ) (p427 γ)
theorem p429 (γ : Binding.Globals) : Binding.Reduction (t194 γ) (t178 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p371 γ) (p1 γ)
theorem p430 (γ : Binding.Globals) : Binding.Reduction (t195 γ) (t179 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p428 γ) (p429 γ)
theorem p431 (γ : Binding.Globals) : Binding.Reduction (t196 γ) (t208 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p430 γ) (p7 γ)
theorem p432 (γ : Binding.Globals) : Binding.Reduction (t197 γ) (t209 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p408 γ) (p431 γ)
theorem p433 (γ : Binding.Globals) : Binding.Reduction (t185 γ) (t209 γ) := .trans (p381 γ) (p432 γ)
theorem p434 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t209 γ) := .trans (p380 γ) (p433 γ)
theorem p435 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t209 γ) := .trans (p21 γ) (p434 γ)
theorem p436 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t209 γ) := .trans (p20 γ) (p435 γ)
theorem p437 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t210 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p436 γ)
theorem p438 (γ : Binding.Globals) : Binding.Reduction (t210 γ) (t222 γ) := .ofEq (fun ξ ρ => rfl)
theorem p439 (γ : Binding.Globals) : Binding.Reduction (t212 γ) (t212 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p398 γ)
theorem p440 (γ : Binding.Globals) : Binding.Reduction (t212 γ) (t223 γ) := .ofEq (fun _ _ => rfl)
theorem p441 (γ : Binding.Globals) : Binding.Reduction (t223 γ) (t223 γ) := .refl (t223 γ)
theorem p442 (γ : Binding.Globals) : Binding.Reduction (t223 γ) (t202 γ) := .scalarSimplify n44 n17 n41 QSym.BindingScalar27.DomainCertificate.domain_correct QSym.BindingScalar27.ValueCertificate.refinement
theorem p443 (γ : Binding.Globals) : Binding.Reduction (t223 γ) (t201 γ) := .trans (p442 γ) (p402 γ)
theorem p444 (γ : Binding.Globals) : Binding.Reduction (t223 γ) (t201 γ) := .trans (p441 γ) (p443 γ)
theorem p445 (γ : Binding.Globals) : Binding.Reduction (t212 γ) (t201 γ) := .trans (p440 γ) (p444 γ)
theorem p446 (γ : Binding.Globals) : Binding.Reduction (t212 γ) (t201 γ) := .trans (p439 γ) (p445 γ)
theorem p447 (γ : Binding.Globals) : Binding.Reduction (t211 γ) (t206 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p389 γ) (p4 γ)
theorem p448 (γ : Binding.Globals) : Binding.Reduction (t206 γ) (t207 γ) := .ofEq (fun _ _ => rfl)
theorem p449 (γ : Binding.Globals) : Binding.Reduction (t206 γ) (t176 γ) := .trans (p448 γ) (p426 γ)
theorem p450 (γ : Binding.Globals) : Binding.Reduction (t211 γ) (t176 γ) := .trans (p447 γ) (p449 γ)
theorem p451 (γ : Binding.Globals) : Binding.Reduction (t213 γ) (t224 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p446 γ) (p450 γ)
theorem p452 (γ : Binding.Globals) : Binding.Reduction (t224 γ) (t225 γ) := .ofEq (fun _ _ => rfl)
theorem p453 (γ : Binding.Globals) : Binding.Reduction (t225 γ) (t225 γ) := .refl (t225 γ)
theorem p454 (γ : Binding.Globals) : Binding.Reduction (t225 γ) (t227 γ) := .scalarSimplify n45 n17 n46 QSym.BindingScalar28.DomainCertificate.domain_correct QSym.BindingScalar28.ValueCertificate.refinement
theorem p455 (γ : Binding.Globals) : Binding.Reduction (t226 γ) (t226 γ) := .refl (t226 γ)
theorem p456 (γ : Binding.Globals) : Binding.Reduction (t227 γ) (t227 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p455 γ)
theorem p457 (γ : Binding.Globals) : Binding.Reduction (t227 γ) (t226 γ) := .guardTrue (t226 γ)
theorem p458 (γ : Binding.Globals) : Binding.Reduction (t227 γ) (t226 γ) := .trans (p457 γ) (p455 γ)
theorem p459 (γ : Binding.Globals) : Binding.Reduction (t227 γ) (t226 γ) := .trans (p456 γ) (p458 γ)
theorem p460 (γ : Binding.Globals) : Binding.Reduction (t225 γ) (t226 γ) := .trans (p454 γ) (p459 γ)
theorem p461 (γ : Binding.Globals) : Binding.Reduction (t225 γ) (t226 γ) := .trans (p453 γ) (p460 γ)
theorem p462 (γ : Binding.Globals) : Binding.Reduction (t224 γ) (t226 γ) := .trans (p452 γ) (p461 γ)
theorem p463 (γ : Binding.Globals) : Binding.Reduction (t213 γ) (t226 γ) := .trans (p451 γ) (p462 γ)
theorem p464 (γ : Binding.Globals) : Binding.Reduction (t214 γ) (t228 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p406 γ) (p1 γ)
theorem p465 (γ : Binding.Globals) : Binding.Reduction (t215 γ) (t229 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p463 γ) (p464 γ)
theorem p466 (γ : Binding.Globals) : Binding.Reduction (t216 γ) (t216 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p341 γ)
theorem p467 (γ : Binding.Globals) : Binding.Reduction (t216 γ) (t230 γ) := .ofEq (fun _ _ => rfl)
theorem p468 (γ : Binding.Globals) : Binding.Reduction (t230 γ) (t230 γ) := .refl (t230 γ)
theorem p469 (γ : Binding.Globals) : Binding.Reduction (t230 γ) (t68 γ) := .scalarSimplify n47 n17 n1 QSym.BindingScalar29.DomainCertificate.domain_correct QSym.BindingScalar29.ValueCertificate.refinement
theorem p470 (γ : Binding.Globals) : Binding.Reduction (t230 γ) (t4 γ) := .trans (p469 γ) (p68 γ)
theorem p471 (γ : Binding.Globals) : Binding.Reduction (t230 γ) (t4 γ) := .trans (p468 γ) (p470 γ)
theorem p472 (γ : Binding.Globals) : Binding.Reduction (t216 γ) (t4 γ) := .trans (p467 γ) (p471 γ)
theorem p473 (γ : Binding.Globals) : Binding.Reduction (t216 γ) (t4 γ) := .trans (p466 γ) (p472 γ)
theorem p474 (γ : Binding.Globals) : Binding.Reduction (t217 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p473 γ) (p4 γ)
theorem p475 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p476 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p475 γ) (p78 γ)
theorem p477 (γ : Binding.Globals) : Binding.Reduction (t217 γ) (t4 γ) := .trans (p474 γ) (p476 γ)
theorem p478 (γ : Binding.Globals) : Binding.Reduction (t218 γ) (t231 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p446 γ) (p477 γ)
theorem p479 (γ : Binding.Globals) : Binding.Reduction (t231 γ) (t232 γ) := .ofEq (fun _ _ => rfl)
theorem p480 (γ : Binding.Globals) : Binding.Reduction (t232 γ) (t232 γ) := .refl (t232 γ)
theorem p481 (γ : Binding.Globals) : Binding.Reduction (t232 γ) (t202 γ) := .scalarSimplify n48 n17 n41 QSym.BindingScalar30.DomainCertificate.domain_correct QSym.BindingScalar30.ValueCertificate.refinement
theorem p482 (γ : Binding.Globals) : Binding.Reduction (t232 γ) (t201 γ) := .trans (p481 γ) (p402 γ)
theorem p483 (γ : Binding.Globals) : Binding.Reduction (t232 γ) (t201 γ) := .trans (p480 γ) (p482 γ)
theorem p484 (γ : Binding.Globals) : Binding.Reduction (t231 γ) (t201 γ) := .trans (p479 γ) (p483 γ)
theorem p485 (γ : Binding.Globals) : Binding.Reduction (t218 γ) (t201 γ) := .trans (p478 γ) (p484 γ)
theorem p486 (γ : Binding.Globals) : Binding.Reduction (t219 γ) (t203 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p428 γ) (p1 γ)
theorem p487 (γ : Binding.Globals) : Binding.Reduction (t220 γ) (t204 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p485 γ) (p486 γ)
theorem p488 (γ : Binding.Globals) : Binding.Reduction (t221 γ) (t233 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p487 γ) (p7 γ)
theorem p489 (γ : Binding.Globals) : Binding.Reduction (t222 γ) (t234 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p465 γ) (p488 γ)
theorem p490 (γ : Binding.Globals) : Binding.Reduction (t210 γ) (t234 γ) := .trans (p438 γ) (p489 γ)
theorem p491 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t234 γ) := .trans (p437 γ) (p490 γ)
theorem p492 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t234 γ) := .trans (p18 γ) (p491 γ)
theorem p493 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t234 γ) := .trans (p17 γ) (p492 γ)
theorem p494 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t235 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p493 γ)
theorem p495 (γ : Binding.Globals) : Binding.Reduction (t235 γ) (t247 γ) := .ofEq (fun ξ ρ => rfl)
theorem p496 (γ : Binding.Globals) : Binding.Reduction (t237 γ) (t237 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p455 γ)
theorem p497 (γ : Binding.Globals) : Binding.Reduction (t237 γ) (t248 γ) := .ofEq (fun _ _ => rfl)
theorem p498 (γ : Binding.Globals) : Binding.Reduction (t248 γ) (t248 γ) := .refl (t248 γ)
theorem p499 (γ : Binding.Globals) : Binding.Reduction (t248 γ) (t227 γ) := .scalarSimplify n49 n17 n46 QSym.BindingScalar31.DomainCertificate.domain_correct QSym.BindingScalar31.ValueCertificate.refinement
theorem p500 (γ : Binding.Globals) : Binding.Reduction (t248 γ) (t226 γ) := .trans (p499 γ) (p459 γ)
theorem p501 (γ : Binding.Globals) : Binding.Reduction (t248 γ) (t226 γ) := .trans (p498 γ) (p500 γ)
theorem p502 (γ : Binding.Globals) : Binding.Reduction (t237 γ) (t226 γ) := .trans (p497 γ) (p501 γ)
theorem p503 (γ : Binding.Globals) : Binding.Reduction (t237 γ) (t226 γ) := .trans (p496 γ) (p502 γ)
theorem p504 (γ : Binding.Globals) : Binding.Reduction (t236 γ) (t231 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p446 γ) (p4 γ)
theorem p505 (γ : Binding.Globals) : Binding.Reduction (t231 γ) (t232 γ) := .ofEq (fun _ _ => rfl)
theorem p506 (γ : Binding.Globals) : Binding.Reduction (t231 γ) (t201 γ) := .trans (p505 γ) (p483 γ)
theorem p507 (γ : Binding.Globals) : Binding.Reduction (t236 γ) (t201 γ) := .trans (p504 γ) (p506 γ)
theorem p508 (γ : Binding.Globals) : Binding.Reduction (t238 γ) (t249 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p503 γ) (p507 γ)
theorem p509 (γ : Binding.Globals) : Binding.Reduction (t249 γ) (t250 γ) := .ofEq (fun _ _ => rfl)
theorem p510 (γ : Binding.Globals) : Binding.Reduction (t250 γ) (t250 γ) := .refl (t250 γ)
theorem p511 (γ : Binding.Globals) : Binding.Reduction (t250 γ) (t252 γ) := .scalarSimplify n50 n17 n51 QSym.BindingScalar32.DomainCertificate.domain_correct QSym.BindingScalar32.ValueCertificate.refinement
theorem p512 (γ : Binding.Globals) : Binding.Reduction (t251 γ) (t251 γ) := .refl (t251 γ)
theorem p513 (γ : Binding.Globals) : Binding.Reduction (t252 γ) (t252 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p512 γ)
theorem p514 (γ : Binding.Globals) : Binding.Reduction (t252 γ) (t251 γ) := .guardTrue (t251 γ)
theorem p515 (γ : Binding.Globals) : Binding.Reduction (t252 γ) (t251 γ) := .trans (p514 γ) (p512 γ)
theorem p516 (γ : Binding.Globals) : Binding.Reduction (t252 γ) (t251 γ) := .trans (p513 γ) (p515 γ)
theorem p517 (γ : Binding.Globals) : Binding.Reduction (t250 γ) (t251 γ) := .trans (p511 γ) (p516 γ)
theorem p518 (γ : Binding.Globals) : Binding.Reduction (t250 γ) (t251 γ) := .trans (p510 γ) (p517 γ)
theorem p519 (γ : Binding.Globals) : Binding.Reduction (t249 γ) (t251 γ) := .trans (p509 γ) (p518 γ)
theorem p520 (γ : Binding.Globals) : Binding.Reduction (t238 γ) (t251 γ) := .trans (p508 γ) (p519 γ)
theorem p521 (γ : Binding.Globals) : Binding.Reduction (t239 γ) (t253 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p463 γ) (p1 γ)
theorem p522 (γ : Binding.Globals) : Binding.Reduction (t240 γ) (t254 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p520 γ) (p521 γ)
theorem p523 (γ : Binding.Globals) : Binding.Reduction (t241 γ) (t241 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p398 γ)
theorem p524 (γ : Binding.Globals) : Binding.Reduction (t241 γ) (t255 γ) := .ofEq (fun _ _ => rfl)
theorem p525 (γ : Binding.Globals) : Binding.Reduction (t255 γ) (t255 γ) := .refl (t255 γ)
theorem p526 (γ : Binding.Globals) : Binding.Reduction (t255 γ) (t68 γ) := .scalarSimplify n52 n17 n1 QSym.BindingScalar33.DomainCertificate.domain_correct QSym.BindingScalar33.ValueCertificate.refinement
theorem p527 (γ : Binding.Globals) : Binding.Reduction (t255 γ) (t4 γ) := .trans (p526 γ) (p68 γ)
theorem p528 (γ : Binding.Globals) : Binding.Reduction (t255 γ) (t4 γ) := .trans (p525 γ) (p527 γ)
theorem p529 (γ : Binding.Globals) : Binding.Reduction (t241 γ) (t4 γ) := .trans (p524 γ) (p528 γ)
theorem p530 (γ : Binding.Globals) : Binding.Reduction (t241 γ) (t4 γ) := .trans (p523 γ) (p529 γ)
theorem p531 (γ : Binding.Globals) : Binding.Reduction (t242 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p530 γ) (p4 γ)
theorem p532 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p533 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p532 γ) (p78 γ)
theorem p534 (γ : Binding.Globals) : Binding.Reduction (t242 γ) (t4 γ) := .trans (p531 γ) (p533 γ)
theorem p535 (γ : Binding.Globals) : Binding.Reduction (t243 γ) (t256 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p503 γ) (p534 γ)
theorem p536 (γ : Binding.Globals) : Binding.Reduction (t256 γ) (t257 γ) := .ofEq (fun _ _ => rfl)
theorem p537 (γ : Binding.Globals) : Binding.Reduction (t257 γ) (t257 γ) := .refl (t257 γ)
theorem p538 (γ : Binding.Globals) : Binding.Reduction (t257 γ) (t227 γ) := .scalarSimplify n53 n17 n46 QSym.BindingScalar34.DomainCertificate.domain_correct QSym.BindingScalar34.ValueCertificate.refinement
theorem p539 (γ : Binding.Globals) : Binding.Reduction (t257 γ) (t226 γ) := .trans (p538 γ) (p459 γ)
theorem p540 (γ : Binding.Globals) : Binding.Reduction (t257 γ) (t226 γ) := .trans (p537 γ) (p539 γ)
theorem p541 (γ : Binding.Globals) : Binding.Reduction (t256 γ) (t226 γ) := .trans (p536 γ) (p540 γ)
theorem p542 (γ : Binding.Globals) : Binding.Reduction (t243 γ) (t226 γ) := .trans (p535 γ) (p541 γ)
theorem p543 (γ : Binding.Globals) : Binding.Reduction (t244 γ) (t228 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p485 γ) (p1 γ)
theorem p544 (γ : Binding.Globals) : Binding.Reduction (t245 γ) (t229 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p542 γ) (p543 γ)
theorem p545 (γ : Binding.Globals) : Binding.Reduction (t246 γ) (t258 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p544 γ) (p7 γ)
theorem p546 (γ : Binding.Globals) : Binding.Reduction (t247 γ) (t259 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p522 γ) (p545 γ)
theorem p547 (γ : Binding.Globals) : Binding.Reduction (t235 γ) (t259 γ) := .trans (p495 γ) (p546 γ)
theorem p548 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t259 γ) := .trans (p494 γ) (p547 γ)
theorem p549 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t259 γ) := .trans (p15 γ) (p548 γ)
theorem p550 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t259 γ) := .trans (p14 γ) (p549 γ)
theorem p551 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t260 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p9 γ) (p550 γ)
theorem p552 (γ : Binding.Globals) : Binding.Reduction (t260 γ) (t272 γ) := .ofEq (fun ξ ρ => rfl)
theorem p553 (γ : Binding.Globals) : Binding.Reduction (t262 γ) (t262 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p512 γ)
theorem p554 (γ : Binding.Globals) : Binding.Reduction (t262 γ) (t273 γ) := .ofEq (fun _ _ => rfl)
theorem p555 (γ : Binding.Globals) : Binding.Reduction (t273 γ) (t273 γ) := .refl (t273 γ)
theorem p556 (γ : Binding.Globals) : Binding.Reduction (t273 γ) (t252 γ) := .scalarSimplify n54 n17 n51 QSym.BindingScalar35.DomainCertificate.domain_correct QSym.BindingScalar35.ValueCertificate.refinement
theorem p557 (γ : Binding.Globals) : Binding.Reduction (t273 γ) (t251 γ) := .trans (p556 γ) (p516 γ)
theorem p558 (γ : Binding.Globals) : Binding.Reduction (t273 γ) (t251 γ) := .trans (p555 γ) (p557 γ)
theorem p559 (γ : Binding.Globals) : Binding.Reduction (t262 γ) (t251 γ) := .trans (p554 γ) (p558 γ)
theorem p560 (γ : Binding.Globals) : Binding.Reduction (t262 γ) (t251 γ) := .trans (p553 γ) (p559 γ)
theorem p561 (γ : Binding.Globals) : Binding.Reduction (t261 γ) (t256 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p503 γ) (p4 γ)
theorem p562 (γ : Binding.Globals) : Binding.Reduction (t256 γ) (t257 γ) := .ofEq (fun _ _ => rfl)
theorem p563 (γ : Binding.Globals) : Binding.Reduction (t256 γ) (t226 γ) := .trans (p562 γ) (p540 γ)
theorem p564 (γ : Binding.Globals) : Binding.Reduction (t261 γ) (t226 γ) := .trans (p561 γ) (p563 γ)
theorem p565 (γ : Binding.Globals) : Binding.Reduction (t263 γ) (t274 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p560 γ) (p564 γ)
theorem p566 (γ : Binding.Globals) : Binding.Reduction (t274 γ) (t275 γ) := .ofEq (fun _ _ => rfl)
theorem p567 (γ : Binding.Globals) : Binding.Reduction (t275 γ) (t275 γ) := .refl (t275 γ)
theorem p568 (γ : Binding.Globals) : Binding.Reduction (t275 γ) (t277 γ) := .scalarSimplify n55 n17 n56 QSym.BindingScalar36.DomainCertificate.domain_correct QSym.BindingScalar36.ValueCertificate.refinement
theorem p569 (γ : Binding.Globals) : Binding.Reduction (t276 γ) (t276 γ) := .refl (t276 γ)
theorem p570 (γ : Binding.Globals) : Binding.Reduction (t277 γ) (t277 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p52 γ) (p569 γ)
theorem p571 (γ : Binding.Globals) : Binding.Reduction (t277 γ) (t276 γ) := .guardTrue (t276 γ)
theorem p572 (γ : Binding.Globals) : Binding.Reduction (t277 γ) (t276 γ) := .trans (p571 γ) (p569 γ)
theorem p573 (γ : Binding.Globals) : Binding.Reduction (t277 γ) (t276 γ) := .trans (p570 γ) (p572 γ)
theorem p574 (γ : Binding.Globals) : Binding.Reduction (t275 γ) (t276 γ) := .trans (p568 γ) (p573 γ)
theorem p575 (γ : Binding.Globals) : Binding.Reduction (t275 γ) (t276 γ) := .trans (p567 γ) (p574 γ)
theorem p576 (γ : Binding.Globals) : Binding.Reduction (t274 γ) (t276 γ) := .trans (p566 γ) (p575 γ)
theorem p577 (γ : Binding.Globals) : Binding.Reduction (t263 γ) (t276 γ) := .trans (p565 γ) (p576 γ)
theorem p578 (γ : Binding.Globals) : Binding.Reduction (t264 γ) (t278 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p520 γ) (p1 γ)
theorem p579 (γ : Binding.Globals) : Binding.Reduction (t265 γ) (t279 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p577 γ) (p578 γ)
theorem p580 (γ : Binding.Globals) : Binding.Reduction (t266 γ) (t266 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p4 γ) (p455 γ)
theorem p581 (γ : Binding.Globals) : Binding.Reduction (t266 γ) (t280 γ) := .ofEq (fun _ _ => rfl)
theorem p582 (γ : Binding.Globals) : Binding.Reduction (t280 γ) (t280 γ) := .refl (t280 γ)
theorem p583 (γ : Binding.Globals) : Binding.Reduction (t280 γ) (t68 γ) := .scalarSimplify n57 n17 n1 QSym.BindingScalar37.DomainCertificate.domain_correct QSym.BindingScalar37.ValueCertificate.refinement
theorem p584 (γ : Binding.Globals) : Binding.Reduction (t280 γ) (t4 γ) := .trans (p583 γ) (p68 γ)
theorem p585 (γ : Binding.Globals) : Binding.Reduction (t280 γ) (t4 γ) := .trans (p582 γ) (p584 γ)
theorem p586 (γ : Binding.Globals) : Binding.Reduction (t266 γ) (t4 γ) := .trans (p581 γ) (p585 γ)
theorem p587 (γ : Binding.Globals) : Binding.Reduction (t266 γ) (t4 γ) := .trans (p580 γ) (p586 γ)
theorem p588 (γ : Binding.Globals) : Binding.Reduction (t267 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p587 γ) (p4 γ)
theorem p589 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p590 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p589 γ) (p78 γ)
theorem p591 (γ : Binding.Globals) : Binding.Reduction (t267 γ) (t4 γ) := .trans (p588 γ) (p590 γ)
theorem p592 (γ : Binding.Globals) : Binding.Reduction (t268 γ) (t281 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p560 γ) (p591 γ)
theorem p593 (γ : Binding.Globals) : Binding.Reduction (t281 γ) (t282 γ) := .ofEq (fun _ _ => rfl)
theorem p594 (γ : Binding.Globals) : Binding.Reduction (t282 γ) (t282 γ) := .refl (t282 γ)
theorem p595 (γ : Binding.Globals) : Binding.Reduction (t282 γ) (t252 γ) := .scalarSimplify n58 n17 n51 QSym.BindingScalar38.DomainCertificate.domain_correct QSym.BindingScalar38.ValueCertificate.refinement
theorem p596 (γ : Binding.Globals) : Binding.Reduction (t282 γ) (t251 γ) := .trans (p595 γ) (p516 γ)
theorem p597 (γ : Binding.Globals) : Binding.Reduction (t282 γ) (t251 γ) := .trans (p594 γ) (p596 γ)
theorem p598 (γ : Binding.Globals) : Binding.Reduction (t281 γ) (t251 γ) := .trans (p593 γ) (p597 γ)
theorem p599 (γ : Binding.Globals) : Binding.Reduction (t268 γ) (t251 γ) := .trans (p592 γ) (p598 γ)
theorem p600 (γ : Binding.Globals) : Binding.Reduction (t269 γ) (t253 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p542 γ) (p1 γ)
theorem p601 (γ : Binding.Globals) : Binding.Reduction (t270 γ) (t254 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p599 γ) (p600 γ)
theorem p602 (γ : Binding.Globals) : Binding.Reduction (t271 γ) (t283 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p601 γ) (p7 γ)
theorem p603 (γ : Binding.Globals) : Binding.Reduction (t272 γ) (t284 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p579 γ) (p602 γ)
theorem p604 (γ : Binding.Globals) : Binding.Reduction (t260 γ) (t284 γ) := .trans (p552 γ) (p603 γ)
theorem p605 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t284 γ) := .trans (p551 γ) (p604 γ)
theorem p606 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t284 γ) := .trans (p12 γ) (p605 γ)
theorem p607 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t284 γ) := .trans (p11 γ) (p606 γ)
theorem p608 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t285 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.scalar .natural) 2)) (c := (.vector (.scalar .natural) 2)) (Tensor.matvecValue Functions.addN.apply Functions.mulN.apply 0 2 2) (p607 γ) (p6 γ)
theorem p609 (γ : Binding.Globals) : Binding.Reduction (t285 γ) (t295 γ) := .ofEq (fun ξ ρ => rfl)
theorem p610 (γ : Binding.Globals) : Binding.Reduction (t288 γ) (t288 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p569 γ) (p0 γ)
theorem p611 (γ : Binding.Globals) : Binding.Reduction (t288 γ) (t296 γ) := .ofEq (fun _ _ => rfl)
theorem p612 (γ : Binding.Globals) : Binding.Reduction (t296 γ) (t296 γ) := .refl (t296 γ)
theorem p613 (γ : Binding.Globals) : Binding.Reduction (t296 γ) (t277 γ) := .scalarSimplify n59 n17 n56 QSym.BindingScalar39.DomainCertificate.domain_correct QSym.BindingScalar39.ValueCertificate.refinement
theorem p614 (γ : Binding.Globals) : Binding.Reduction (t296 γ) (t276 γ) := .trans (p613 γ) (p573 γ)
theorem p615 (γ : Binding.Globals) : Binding.Reduction (t296 γ) (t276 γ) := .trans (p612 γ) (p614 γ)
theorem p616 (γ : Binding.Globals) : Binding.Reduction (t288 γ) (t276 γ) := .trans (p611 γ) (p615 γ)
theorem p617 (γ : Binding.Globals) : Binding.Reduction (t288 γ) (t276 γ) := .trans (p610 γ) (p616 γ)
theorem p618 (γ : Binding.Globals) : Binding.Reduction (t286 γ) (t286 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p512 γ) (p4 γ)
theorem p619 (γ : Binding.Globals) : Binding.Reduction (t286 γ) (t297 γ) := .ofEq (fun _ _ => rfl)
theorem p620 (γ : Binding.Globals) : Binding.Reduction (t297 γ) (t297 γ) := .refl (t297 γ)
theorem p621 (γ : Binding.Globals) : Binding.Reduction (t297 γ) (t68 γ) := .scalarSimplify n60 n17 n1 QSym.BindingScalar40.DomainCertificate.domain_correct QSym.BindingScalar40.ValueCertificate.refinement
theorem p622 (γ : Binding.Globals) : Binding.Reduction (t297 γ) (t4 γ) := .trans (p621 γ) (p68 γ)
theorem p623 (γ : Binding.Globals) : Binding.Reduction (t297 γ) (t4 γ) := .trans (p620 γ) (p622 γ)
theorem p624 (γ : Binding.Globals) : Binding.Reduction (t286 γ) (t4 γ) := .trans (p619 γ) (p623 γ)
theorem p625 (γ : Binding.Globals) : Binding.Reduction (t286 γ) (t4 γ) := .trans (p618 γ) (p624 γ)
theorem p626 (γ : Binding.Globals) : Binding.Reduction (t287 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p625 γ) (p4 γ)
theorem p627 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p628 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p627 γ) (p78 γ)
theorem p629 (γ : Binding.Globals) : Binding.Reduction (t287 γ) (t4 γ) := .trans (p626 γ) (p628 γ)
theorem p630 (γ : Binding.Globals) : Binding.Reduction (t289 γ) (t298 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p617 γ) (p629 γ)
theorem p631 (γ : Binding.Globals) : Binding.Reduction (t298 γ) (t299 γ) := .ofEq (fun _ _ => rfl)
theorem p632 (γ : Binding.Globals) : Binding.Reduction (t299 γ) (t299 γ) := .refl (t299 γ)
theorem p633 (γ : Binding.Globals) : Binding.Reduction (t299 γ) (t277 γ) := .scalarSimplify n61 n17 n56 QSym.BindingScalar41.DomainCertificate.domain_correct QSym.BindingScalar41.ValueCertificate.refinement
theorem p634 (γ : Binding.Globals) : Binding.Reduction (t299 γ) (t276 γ) := .trans (p633 γ) (p573 γ)
theorem p635 (γ : Binding.Globals) : Binding.Reduction (t299 γ) (t276 γ) := .trans (p632 γ) (p634 γ)
theorem p636 (γ : Binding.Globals) : Binding.Reduction (t298 γ) (t276 γ) := .trans (p631 γ) (p635 γ)
theorem p637 (γ : Binding.Globals) : Binding.Reduction (t289 γ) (t276 γ) := .trans (p630 γ) (p636 γ)
theorem p638 (γ : Binding.Globals) : Binding.Reduction (t292 γ) (t292 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p512 γ) (p0 γ)
theorem p639 (γ : Binding.Globals) : Binding.Reduction (t292 γ) (t300 γ) := .ofEq (fun _ _ => rfl)
theorem p640 (γ : Binding.Globals) : Binding.Reduction (t300 γ) (t300 γ) := .refl (t300 γ)
theorem p641 (γ : Binding.Globals) : Binding.Reduction (t300 γ) (t252 γ) := .scalarSimplify n62 n17 n51 QSym.BindingScalar42.DomainCertificate.domain_correct QSym.BindingScalar42.ValueCertificate.refinement
theorem p642 (γ : Binding.Globals) : Binding.Reduction (t300 γ) (t251 γ) := .trans (p641 γ) (p516 γ)
theorem p643 (γ : Binding.Globals) : Binding.Reduction (t300 γ) (t251 γ) := .trans (p640 γ) (p642 γ)
theorem p644 (γ : Binding.Globals) : Binding.Reduction (t292 γ) (t251 γ) := .trans (p639 γ) (p643 γ)
theorem p645 (γ : Binding.Globals) : Binding.Reduction (t292 γ) (t251 γ) := .trans (p638 γ) (p644 γ)
theorem p646 (γ : Binding.Globals) : Binding.Reduction (t290 γ) (t290 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p455 γ) (p4 γ)
theorem p647 (γ : Binding.Globals) : Binding.Reduction (t290 γ) (t301 γ) := .ofEq (fun _ _ => rfl)
theorem p648 (γ : Binding.Globals) : Binding.Reduction (t301 γ) (t301 γ) := .refl (t301 γ)
theorem p649 (γ : Binding.Globals) : Binding.Reduction (t301 γ) (t68 γ) := .scalarSimplify n63 n17 n1 QSym.BindingScalar43.DomainCertificate.domain_correct QSym.BindingScalar43.ValueCertificate.refinement
theorem p650 (γ : Binding.Globals) : Binding.Reduction (t301 γ) (t4 γ) := .trans (p649 γ) (p68 γ)
theorem p651 (γ : Binding.Globals) : Binding.Reduction (t301 γ) (t4 γ) := .trans (p648 γ) (p650 γ)
theorem p652 (γ : Binding.Globals) : Binding.Reduction (t290 γ) (t4 γ) := .trans (p647 γ) (p651 γ)
theorem p653 (γ : Binding.Globals) : Binding.Reduction (t290 γ) (t4 γ) := .trans (p646 γ) (p652 γ)
theorem p654 (γ : Binding.Globals) : Binding.Reduction (t291 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p653 γ) (p4 γ)
theorem p655 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t70 γ) := .ofEq (fun _ _ => rfl)
theorem p656 (γ : Binding.Globals) : Binding.Reduction (t69 γ) (t4 γ) := .trans (p655 γ) (p78 γ)
theorem p657 (γ : Binding.Globals) : Binding.Reduction (t291 γ) (t4 γ) := .trans (p654 γ) (p656 γ)
theorem p658 (γ : Binding.Globals) : Binding.Reduction (t293 γ) (t281 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p645 γ) (p657 γ)
theorem p659 (γ : Binding.Globals) : Binding.Reduction (t281 γ) (t282 γ) := .ofEq (fun _ _ => rfl)
theorem p660 (γ : Binding.Globals) : Binding.Reduction (t281 γ) (t251 γ) := .trans (p659 γ) (p597 γ)
theorem p661 (γ : Binding.Globals) : Binding.Reduction (t293 γ) (t251 γ) := .trans (p658 γ) (p660 γ)
theorem p662 (γ : Binding.Globals) : Binding.Reduction (t294 γ) (t278 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p661 γ) (p1 γ)
theorem p663 (γ : Binding.Globals) : Binding.Reduction (t295 γ) (t279 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p637 γ) (p662 γ)
theorem p664 (γ : Binding.Globals) : Binding.Reduction (t285 γ) (t279 γ) := .trans (p609 γ) (p663 γ)
theorem p665 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t279 γ) := .trans (p608 γ) (p664 γ)
theorem p666 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t302 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.scalar .natural)) (c := (.scalar .natural)) Tensor.getValue (p665 γ) (p0 γ)
theorem p667 (γ : Binding.Globals) : Binding.Reduction (t302 γ) (t251 γ) := .ofEq (fun ξ ρ => rfl)
theorem p668 (γ : Binding.Globals) : Binding.Reduction (t302 γ) (t251 γ) := .trans (p667 γ) (p512 γ)
theorem p669 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t251 γ) := .trans (p666 γ) (p668 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t251 γ) := (p669 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t13 γ).eval ξ ρ = (t251 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t13 γ).eval ξ ρ) ↔ Value.Defined ((t251 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t13 γ).eval ξ ρ = n51.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n51 : Expr .natural := (.nat (55))
noncomputable def v51 (ρ : Env) : Option (Ty.denote .natural) := some (55)
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n51) (Expr.eval ρ n51) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_51 ρ) (eval_51 ρ)) (Value.refines_refl (v51 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n51) : (Expr.eval ρ n51) = (Expr.eval ρ n51) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v51 ρ) := (total_51 ρ)
def d51 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n51 ↔ (d51 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_51 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n51 := Eq.mpr (congrArg Value.Defined (eval_51 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t13 γ).eval ξ ρ) (FunctionScalar.n51.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n51.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t13 γ).eval ξ ρ)) : ((BindingCertificate.t13 γ).eval ξ ρ) = (FunctionScalar.n51.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
