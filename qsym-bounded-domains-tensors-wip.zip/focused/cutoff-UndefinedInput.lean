import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (0))
def n26 : Expr .bool := (.bool false)
def n33 : Expr .bool := (.bool true)
def n47 : Expr .integer := (.int (1))
def n55 : Expr .bool := (.leN n1 n3)
def n56 : Expr .integer := (.castNZ n1)
def n62 : Expr .bool := (.nonzeroZ n47)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .bool) := some false
noncomputable def v27 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v26 ρ)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v47 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v1 ρ) (v3 ρ)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroZ.apply (v56 ρ)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v57 ρ)
noncomputable def v62 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroZ.apply (v47 ρ)
noncomputable def v63 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v33 ρ)
noncomputable def v64 (ρ : Env) : Option (Ty.denote .bool) := Value.not (v63 ρ)
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl
theorem eval_47 (ρ : Env) : (Expr.eval ρ n47) = (v47 ρ) := rfl
theorem eval_55 (ρ : Env) : (Expr.eval ρ n55) = (v55 ρ) := rfl
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl
theorem eval_62 (ρ : Env) : (Expr.eval ρ n62) = (v62 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v55 ρ) (v58 ρ) :=
  (Generated.r_natural_nonpositive_zero (v1 ρ))

theorem p1 (ρ : Env) : Value.Refines (v56 ρ) (v47 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_56 ρ) (eval_47 ρ)) (Numeric.sound ρ n56 n47 rfl)

theorem p2 (ρ : Env) : Value.Refines (v57 ρ) (v62 ρ) :=
  Value.refines_function1 Functions.nonzeroZ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v62 ρ) (v33 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_62 ρ) (eval_33 ρ)) (Numeric.sound ρ n62 n33 rfl)

theorem p4 (ρ : Env) : Value.Refines (v57 ρ) (v33 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v58 ρ) (v63 ρ) :=
  Value.refines_not (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v63 ρ) (v26 ρ) :=
  (Generated.r_bool_not_true)

theorem p7 (ρ : Env) : Value.Refines (v64 ρ) (v27 ρ) :=
  Value.refines_not (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v27 ρ) (v33 ρ) :=
  (Generated.r_bool_not_false)

theorem p9 (ρ : Env) : Value.Refines (v64 ρ) (v33 ρ) :=
  (p7 ρ).trans (p8 ρ)

theorem p10 (ρ : Env) : Value.Refines (v63 ρ) (v26 ρ) :=
  (Generated.r_bool_false (v63 ρ) (p9 ρ))

theorem p11 (ρ : Env) : Value.Refines (v58 ρ) (v26 ρ) :=
  (p5 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v55 ρ) (v26 ρ) :=
  (p0 ρ).trans (p11 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n55) (Expr.eval ρ n26) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_55 ρ) (eval_26 ρ)) (p12 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n55) : (Expr.eval ρ n55) = (Expr.eval ρ n26) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d55 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v3 ρ) = some y ∧ Functions.leN.domain x y
theorem domain_55 (ρ : Env) : Value.Defined (v55 ρ) ↔ d55 ρ :=
  Functions.leN.defined (v1 ρ) (v3 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n55 ↔ (d55 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_55 ρ))).trans (domain_55 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_55 (ρ : Env) : Value.Defined (v55 ρ) :=
  Functions.leN.total (fun _ _ => True.intro) (v1 ρ) (v3 ρ) (total_1 ρ) (total_3 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n55 := Eq.mpr (congrArg Value.Defined (eval_55 ρ)) (total_55 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n1 : Expr .natural := (.nat (1))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n3 : Expr .natural := (.nat (0))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n30 : Expr .natural := (.subN n3 n1)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := Functions.subN.apply (v3 ρ) (v1 ρ)
def n33 : Expr .bool := (.bool true)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .bool) := some true
def n55 : Expr .bool := (.leN n1 n3)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .bool) := Functions.leN.apply (v1 ρ) (v3 ρ)
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v33 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v55 ρ) :=
  Domain.partial2 Functions.subN (x := (v3 ρ)) (y := (v1 ρ)) (dx := (v33 ρ)) (dy := (v33 ρ)) (p := (v55 ρ)) (Domain.test_subN (v3 ρ) (v1 ρ)) (q3 ρ) (q1 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n30) (Expr.eval ρ Certificate.n26) :=
  Domain.simplify (q30 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n26) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n30 ↔ (Expr.eval ρ Certificate.n26) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (1))
def n3 : Expr .natural := (.nat (0))
def n13 : Expr .natural := (.nat (10))
def n26 : Expr .bool := (.bool false)
def n30 : Expr .natural := (.subN n3 n1)
def n51 : Expr .bool := (.leN n30 n13)
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.arrow (.scalar .natural) (.scalar .natural)) :: c0
abbrev c2 : List Binding.Ty := (.scalar .natural) :: c1
abbrev c3 : List Binding.Ty := (.scalar .natural) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .var .here
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c2 (.arrow (.scalar .natural) (.scalar .natural)) := .var (.there .here)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n1
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.subN.apply (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t0 γ) (t2 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .app (t1 γ) (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .integer) := .unary Functions.castNZ.apply (t0 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Functions.nonzeroZ.apply (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n3
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t9 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t9 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .scalar n13
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .binary Functions.leN.apply (t0 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t14 γ) (t4 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .bool) := .unary Value.not (t14 γ)
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t16 γ) (t6 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t15 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Value.mask (t12 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c2 (.scalar .natural) := .binary Functions.addN.apply (t11 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c1 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .unary Recursion.fixedValue (.lam (t21 γ))
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n30
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .app (t22 γ) (t25 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t26 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .var .here
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n13
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .bool) := .binary Functions.leN.apply (t28 γ) (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .scalar n3
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c3 (.scalar .natural) := .binary Binding.guardValue (t30 γ) (t31 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.scalar .natural) (.scalar .natural)) := .lam (t32 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .app (t33 γ) (t25 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n13
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .binary Functions.leN.apply (t25 γ) (t35 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t36 γ) (t23 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .seq (t25 γ) (t37 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n51
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t39 γ) (t23 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .seq (t25 γ) (t40 γ)
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t25 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t42 γ) (t40 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n26
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t44 γ) (t40 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .constant none
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t46 γ)
noncomputable def rec22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Recursion.Program ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote ((.scalar .natural) : Binding.Ty).denote := (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.constant (fun x => (t11 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.branch (.constant (fun x => (t12 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.binary Functions.addN.apply (fun _ => rfl) (fun x => Option.casesOn x rfl (fun _ => rfl)) (.branch (.constant (fun x => (t14 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t3 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0))) (.branch (.constant (fun x => (t16 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ)))) (.call (.constant (fun x => (t5 γ).eval ξ (Binding.Env.cons (a := (.scalar .natural)) (some x) (Binding.Env.cons (a := (.arrow (.scalar .natural) (.scalar .natural))) (some (fun (_ : ((.scalar .natural) : Binding.Ty).denote) => (none : Option ((.scalar .natural) : Binding.Ty).denote))) ρ))))) (.constant (fun _ => some 0)))) (.constant (fun _ => some 0))))
theorem fixed22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = some (FixedPoint.value (rec22 γ ξ ρ).functional) := Recursion.fixed_program (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem unroll22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (Binding.Expr.app (.lam (t21 γ)) (t22 γ)).eval ξ ρ := Recursion.program_unfold (rec22 γ ξ ρ) _ (fun g => congrArg some (funext (fun x => (congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _))))))
theorem solve22 (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t33 γ).eval ξ ρ :=
  Eq.trans (fixed22 γ ξ ρ) (congrArg some (Recursion.solve_nat_cutoff (rec22 γ ξ ρ) ((n3.eval ξ).getD 0) ((n13.eval ξ).getD 0) (fun g x => ((congrArg₂ Functions.addN.apply rfl (Eq.trans (congrArg₂ Value.mask rfl (congrArg₂ Functions.addN.apply (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)) (Eq.trans (congrArg₂ Value.mask rfl rfl) (Recursion.mask_branch _ _)))) (Recursion.mask_branch _ _)))).symm)))
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .unary (a := .arrow (.arrow (.scalar .natural) (.scalar .natural)) (.arrow (.scalar .natural) (.scalar .natural))) (b := (.arrow (.scalar .natural) (.scalar .natural))) Recursion.fixedValue (.lam (p0 γ))
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t33 γ) := .ofEq (fun ξ ρ => solve22 γ ξ ρ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .refl (t28 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .refl (t29 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p3 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .refl (t31 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p5 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .lam (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t33 γ) := .trans (p2 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t33 γ) := .trans (p1 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .refl (t25 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t34 γ) := .app (p10 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t38 γ) := .beta (t32 γ) (t25 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .refl (t35 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .bool)) Functions.leN.apply (p11 γ) (p14 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t39 γ) := .ofEq (fun _ _ => rfl)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .refl (t39 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t39 γ) := .trans (p16 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t39 γ) := .trans (p15 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t40 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p19 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t41 γ) := .seq (p11 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t43 γ) := .seqGuard (t25 γ) (t40 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p11 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t44 γ) := .scalarDomain n30 n26 QSym.BindingScalar0.DomainCertificate.domain_correct
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t44 γ) := .refl (t44 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t44 γ) := .trans (p25 γ) (p26 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t44 γ) := .trans (p24 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .refl (t40 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t45 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .ofEq (fun _ _ => rfl)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .refl (t46 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .trans (p31 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t46 γ) := .trans (p30 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t46 γ) := .trans (p23 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t46 γ) := .trans (p22 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t46 γ) := .trans (p13 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t46 γ) := .trans (p12 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t47 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t44 γ) := .ofEq (fun _ _ => rfl)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t44 γ) := .trans (p40 γ) (p26 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t44 γ) := .trans (p39 γ) (p41 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t44 γ) := (p42 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t27 γ).eval ξ ρ = (t44 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t27 γ).eval ξ ρ) ↔ Value.Defined ((t44 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t27 γ).eval ξ ρ = n26.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n26 : Expr .bool := (.bool false)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n26) (Expr.eval ρ n26) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_26 ρ) (eval_26 ρ)) (Value.refines_refl (v26 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n26) : (Expr.eval ρ n26) = (Expr.eval ρ n26) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_26 (ρ : Env) : Value.Defined (v26 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v26 ρ) := (total_26 ρ)
def d26 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n26 ↔ (d26 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_26 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n26 := Eq.mpr (congrArg Value.Defined (eval_26 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t27 γ).eval ξ ρ) (FunctionScalar.n26.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n26.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t27 γ).eval ξ ρ)) : ((BindingCertificate.t27 γ).eval ξ ρ) = (FunctionScalar.n26.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
