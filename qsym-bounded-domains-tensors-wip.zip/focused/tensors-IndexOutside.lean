import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .bool := (.bool false)
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Tensor.getValue (t4 γ) (t1 γ)
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t5 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .constant none
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .unary Binding.definedValue (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n2
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.scalar .natural)) (c := (.scalar .natural)) Tensor.getValue (p4 γ) (p1 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t7 γ) := .ofEq (fun ξ ρ => rfl)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t7 γ) := .trans (p6 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t7 γ) := .trans (p5 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t8 γ) := .unary (a := (.scalar .natural)) (b := (.scalar .bool)) Binding.definedValue (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t9 γ) := .ofEq (fun _ _ => rfl)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t9 γ) := .trans (p11 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t9 γ) := .trans (p10 γ) (p13 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t9 γ) := (p14 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t6 γ).eval ξ ρ = (t9 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t6 γ).eval ξ ρ) ↔ Value.Defined ((t9 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t6 γ).eval ξ ρ = n2.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .bool := (.bool false)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_2 (ρ : Env) : (Expr.eval ρ n2) = (v2 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n2) (Expr.eval ρ n2) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_2 ρ) (eval_2 ρ)) (Value.refines_refl (v2 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n2) : (Expr.eval ρ n2) = (Expr.eval ρ n2) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v2 ρ) := (total_2 ρ)
def d2 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n2 ↔ (d2 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_2 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n2 := Eq.mpr (congrArg Value.Defined (eval_2 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t6 γ).eval ξ ρ) (FunctionScalar.n2.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n2.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t6 γ).eval ξ ρ)) : ((BindingCertificate.t6 γ).eval ξ ρ) = (FunctionScalar.n2.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
