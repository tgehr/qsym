import QSym.Refinement
import QSym.AxiomCheck
namespace QSym.Generated
theorem r_natural_literal_coefficient (v_x : Option (Ty.denote .natural)) (v_c : Option (Ty.denote .natural)) :
    Value.Refines (Functions.mulN.apply v_x v_c) (Functions.mulN.apply v_c v_x) := by
  cases v_x <;> cases v_c
  all_goals qsym_rule

#qsym_check_axioms r_natural_literal_coefficient


end QSym.Generated
