import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n14 : Expr .natural := (.mulN n0 n4)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v4 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q0 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n14) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q14 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n14 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n4 : Expr .natural := (.nat (5))
def n14 : Expr .natural := (.mulN n0 n4)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v4 ρ)
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v14 ρ) (v4 ρ) :=
  (Generated.r_natural_one_mul (v4 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n14) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_14 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n14) : (Expr.eval ρ n14) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d14 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.mulN.defined (v0 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n14 ↔ (d14 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_14 ρ))).trans (domain_14 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v4 ρ) (total_0 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n14 := Eq.mpr (congrArg Value.Defined (eval_14 ρ)) (total_14 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n6 : Expr .natural := (.nat (7))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n16 : Expr .natural := (.mulN n1 n6)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v6 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v6 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q1 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n16) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q16 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n16 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n6 : Expr .natural := (.nat (7))
def n16 : Expr .natural := (.mulN n1 n6)
def n17 : Expr .natural := (.nat (14))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v6 ρ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (14)
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v16 ρ) (v17 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_16 ρ) (eval_17 ρ)) (Numeric.sound ρ n16 n17 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n16) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_16 ρ) (eval_17 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n16) : (Expr.eval ρ n16) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d16 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  Functions.mulN.defined (v1 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n16 ↔ (d16 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_16 ρ))).trans (domain_16 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v6 ρ) (total_1 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n16 := Eq.mpr (congrArg Value.Defined (eval_16 ρ)) (total_16 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n8 : Expr .natural := (.nat (0))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n17 : Expr .natural := (.nat (14))
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (14)
def n18 : Expr .natural := (.addN n17 n8)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v17 ρ) (v8 ρ)
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q18 (ρ : Env) : Domain.Correct (v18 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v17 ρ)) (y := (v8 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q17 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n18) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q18 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n18 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .natural := (.nat (0))
def n17 : Expr .natural := (.nat (14))
def n18 : Expr .natural := (.addN n17 n8)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (14)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v17 ρ) (v8 ρ)
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v18 ρ) (v17 ρ) :=
  (Generated.r_natural_add_zero (v17 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n18) (Expr.eval ρ n17) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_18 ρ) (eval_17 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n18) : (Expr.eval ρ n18) = (Expr.eval ρ n17) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d17 (ρ : Env) : Prop := True
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d18 (ρ : Env) : Prop := ∃ x y, (v17 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_18 (ρ : Env) : Value.Defined (v18 ρ) ↔ d18 ρ :=
  Functions.addN.defined (v17 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n18 ↔ (d18 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_18 ρ))).trans (domain_18 ρ)
#qsym_check_axioms definedness
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_18 (ρ : Env) : Value.Defined (v18 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v17 ρ) (v8 ρ) (total_17 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n18 := Eq.mpr (congrArg Value.Defined (eval_18 ρ)) (total_18 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n17 : Expr .natural := (.nat (14))
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (14)
def n19 : Expr .natural := (.addN n4 n17)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v17 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q19 (ρ : Env) : Domain.Correct (v19 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v4 ρ)) (y := (v17 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q4 ρ) (q17 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n19) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q19 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n19 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n4 : Expr .natural := (.nat (5))
def n17 : Expr .natural := (.nat (14))
def n19 : Expr .natural := (.addN n4 n17)
def n20 : Expr .natural := (.nat (19))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .natural) := some (14)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v4 ρ) (v17 ρ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .natural) := some (19)
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v19 ρ) (v20 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (Numeric.sound ρ n19 n20 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n19) (Expr.eval ρ n20) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n19) : (Expr.eval ρ n19) = (Expr.eval ρ n20) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d17 (ρ : Env) : Prop := True
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d19 (ρ : Env) : Prop := ∃ x y, (v4 ρ) = some x ∧ (v17 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_19 (ρ : Env) : Value.Defined (v19 ρ) ↔ d19 ρ :=
  Functions.addN.defined (v4 ρ) (v17 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n19 ↔ (d19 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_19 ρ))).trans (domain_19 ρ)
#qsym_check_axioms definedness
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_19 (ρ : Env) : Value.Defined (v19 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v4 ρ) (v17 ρ) (total_4 ρ) (total_17 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n19 := Eq.mpr (congrArg Value.Defined (eval_19 ρ)) (total_19 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n21 : Expr .natural := (.mulN n0 n5)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v5 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q21 (ρ : Env) : Domain.Correct (v21 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v0 ρ)) (y := (v5 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q0 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n21) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q21 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n21 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n5 : Expr .natural := (.nat (6))
def n21 : Expr .natural := (.mulN n0 n5)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v0 ρ) (v5 ρ)
theorem eval_5 (ρ : Env) : (Expr.eval ρ n5) = (v5 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v21 ρ) (v5 ρ) :=
  (Generated.r_natural_one_mul (v5 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n21) (Expr.eval ρ n5) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_21 ρ) (eval_5 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n21) : (Expr.eval ρ n21) = (Expr.eval ρ n5) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d21 (ρ : Env) : Prop := ∃ x y, (v0 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_21 (ρ : Env) : Value.Defined (v21 ρ) ↔ d21 ρ :=
  Functions.mulN.defined (v0 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n21 ↔ (d21 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_21 ρ))).trans (domain_21 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_21 (ρ : Env) : Value.Defined (v21 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v0 ρ) (v5 ρ) (total_0 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n21 := Eq.mpr (congrArg Value.Defined (eval_21 ρ)) (total_21 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n7 : Expr .natural := (.nat (8))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n22 : Expr .natural := (.mulN n1 n7)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v7 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v1 ρ)) (y := (v7 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q1 ρ) (q7 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n22) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q22 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n22 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n7 : Expr .natural := (.nat (8))
def n22 : Expr .natural := (.mulN n1 n7)
def n23 : Expr .natural := (.nat (16))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v1 ρ) (v7 ρ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (16)
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v22 ρ) (v23 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_22 ρ) (eval_23 ρ)) (Numeric.sound ρ n22 n23 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n22) (Expr.eval ρ n23) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_22 ρ) (eval_23 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n22) : (Expr.eval ρ n22) = (Expr.eval ρ n23) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d22 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v7 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  Functions.mulN.defined (v1 ρ) (v7 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n22 ↔ (d22 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_22 ρ))).trans (domain_22 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v1 ρ) (v7 ρ) (total_1 ρ) (total_7 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n22 := Eq.mpr (congrArg Value.Defined (eval_22 ρ)) (total_22 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n8 : Expr .natural := (.nat (0))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .natural := (.nat (16))
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (16)
def n24 : Expr .natural := (.addN n23 n8)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v23 ρ) (v8 ρ)
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q24 (ρ : Env) : Domain.Correct (v24 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v23 ρ)) (y := (v8 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q23 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n24) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q24 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n24 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .natural := (.nat (0))
def n23 : Expr .natural := (.nat (16))
def n24 : Expr .natural := (.addN n23 n8)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (16)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v23 ρ) (v8 ρ)
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v24 ρ) (v23 ρ) :=
  (Generated.r_natural_add_zero (v23 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n24) (Expr.eval ρ n23) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_24 ρ) (eval_23 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n24) : (Expr.eval ρ n24) = (Expr.eval ρ n23) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d23 (ρ : Env) : Prop := True
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d24 (ρ : Env) : Prop := ∃ x y, (v23 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_24 (ρ : Env) : Value.Defined (v24 ρ) ↔ d24 ρ :=
  Functions.addN.defined (v23 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n24 ↔ (d24 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_24 ρ))).trans (domain_24 ρ)
#qsym_check_axioms definedness
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_24 (ρ : Env) : Value.Defined (v24 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v23 ρ) (v8 ρ) (total_23 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n24 := Eq.mpr (congrArg Value.Defined (eval_24 ρ)) (total_24 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .natural := (.nat (16))
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (16)
def n25 : Expr .natural := (.addN n5 n23)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v5 ρ) (v23 ρ)
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q23 (ρ : Env) : Domain.Correct (v23 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q25 (ρ : Env) : Domain.Correct (v25 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v5 ρ)) (y := (v23 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q5 ρ) (q23 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n25) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q25 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n25 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n5 : Expr .natural := (.nat (6))
def n23 : Expr .natural := (.nat (16))
def n25 : Expr .natural := (.addN n5 n23)
def n26 : Expr .natural := (.nat (22))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .natural) := some (16)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v5 ρ) (v23 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .natural) := some (22)
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v25 ρ) (v26 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_25 ρ) (eval_26 ρ)) (Numeric.sound ρ n25 n26 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n25) (Expr.eval ρ n26) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_25 ρ) (eval_26 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n25) : (Expr.eval ρ n25) = (Expr.eval ρ n26) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d23 (ρ : Env) : Prop := True
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d25 (ρ : Env) : Prop := ∃ x y, (v5 ρ) = some x ∧ (v23 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_25 (ρ : Env) : Value.Defined (v25 ρ) ↔ d25 ρ :=
  Functions.addN.defined (v5 ρ) (v23 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n25 ↔ (d25 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_25 ρ))).trans (domain_25 ρ)
#qsym_check_axioms definedness
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  ⟨_, rfl⟩
theorem total_25 (ρ : Env) : Value.Defined (v25 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v5 ρ) (v23 ρ) (total_5 ρ) (total_23 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n25 := Eq.mpr (congrArg Value.Defined (eval_25 ρ)) (total_25 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.Certificate

namespace QSym.BindingScalar8.DomainCertificate
def n2 : Expr .natural := (.nat (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n4 : Expr .natural := (.nat (5))
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n27 : Expr .natural := (.mulN n2 n4)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v4 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q27 (ρ : Env) : Domain.Correct (v27 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v2 ρ)) (y := (v4 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q2 ρ) (q4 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n27) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q27 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n27 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar8.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (3))
def n4 : Expr .natural := (.nat (5))
def n27 : Expr .natural := (.mulN n2 n4)
def n28 : Expr .natural := (.nat (15))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .natural) := some (5)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v4 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := some (15)
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v27 ρ) (v28 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_27 ρ) (eval_28 ρ)) (Numeric.sound ρ n27 n28 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n27) (Expr.eval ρ n28) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_27 ρ) (eval_28 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n27) : (Expr.eval ρ n27) = (Expr.eval ρ n28) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d4 (ρ : Env) : Prop := True
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d27 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v4 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_27 (ρ : Env) : Value.Defined (v27 ρ) ↔ d27 ρ :=
  Functions.mulN.defined (v2 ρ) (v4 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n27 ↔ (d27 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_27 ρ))).trans (domain_27 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_4 (ρ : Env) : Value.Defined (v4 ρ) :=
  ⟨_, rfl⟩
theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v2 ρ) (v4 ρ) (total_2 ρ) (total_4 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n27 := Eq.mpr (congrArg Value.Defined (eval_27 ρ)) (total_27 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.Certificate

namespace QSym.BindingScalar9.DomainCertificate
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n6 : Expr .natural := (.nat (7))
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n29 : Expr .natural := (.mulN n3 n6)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v6 ρ)
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q29 (ρ : Env) : Domain.Correct (v29 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v3 ρ)) (y := (v6 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q3 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n29) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q29 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n29 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar9.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar9.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n3 : Expr .natural := (.nat (4))
def n6 : Expr .natural := (.nat (7))
def n29 : Expr .natural := (.mulN n3 n6)
def n30 : Expr .natural := (.nat (28))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .natural) := some (7)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v6 ρ)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (28)
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v29 ρ) (v30 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_29 ρ) (eval_30 ρ)) (Numeric.sound ρ n29 n30 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n29) (Expr.eval ρ n30) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_29 ρ) (eval_30 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n29) : (Expr.eval ρ n29) = (Expr.eval ρ n30) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := True
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d29 (ρ : Env) : Prop := ∃ x y, (v3 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_29 (ρ : Env) : Value.Defined (v29 ρ) ↔ d29 ρ :=
  Functions.mulN.defined (v3 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n29 ↔ (d29 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_29 ρ))).trans (domain_29 ρ)
#qsym_check_axioms definedness
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_6 (ρ : Env) : Value.Defined (v6 ρ) :=
  ⟨_, rfl⟩
theorem total_29 (ρ : Env) : Value.Defined (v29 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v3 ρ) (v6 ρ) (total_3 ρ) (total_6 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n29 := Eq.mpr (congrArg Value.Defined (eval_29 ρ)) (total_29 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar9.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.Certificate

namespace QSym.BindingScalar10.DomainCertificate
def n8 : Expr .natural := (.nat (0))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n30 : Expr .natural := (.nat (28))
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (28)
def n31 : Expr .natural := (.addN n30 n8)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v30 ρ) (v8 ρ)
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q31 (ρ : Env) : Domain.Correct (v31 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v30 ρ)) (y := (v8 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q30 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n31) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q31 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n31 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar10.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar10.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .natural := (.nat (0))
def n30 : Expr .natural := (.nat (28))
def n31 : Expr .natural := (.addN n30 n8)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (28)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v30 ρ) (v8 ρ)
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v31 ρ) (v30 ρ) :=
  (Generated.r_natural_add_zero (v30 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n31) (Expr.eval ρ n30) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_31 ρ) (eval_30 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n31) : (Expr.eval ρ n31) = (Expr.eval ρ n30) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d30 (ρ : Env) : Prop := True
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d31 (ρ : Env) : Prop := ∃ x y, (v30 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_31 (ρ : Env) : Value.Defined (v31 ρ) ↔ d31 ρ :=
  Functions.addN.defined (v30 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n31 ↔ (d31 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_31 ρ))).trans (domain_31 ρ)
#qsym_check_axioms definedness
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v30 ρ) (v8 ρ) (total_30 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n31 := Eq.mpr (congrArg Value.Defined (eval_31 ρ)) (total_31 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar10.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.Certificate

namespace QSym.BindingScalar11.DomainCertificate
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n28 : Expr .natural := (.nat (15))
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := some (15)
def n30 : Expr .natural := (.nat (28))
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (28)
def n32 : Expr .natural := (.addN n28 n30)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v28 ρ) (v30 ρ)
theorem q28 (ρ : Env) : Domain.Correct (v28 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q32 (ρ : Env) : Domain.Correct (v32 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v28 ρ)) (y := (v30 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q28 ρ) (q30 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n32) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q32 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n32 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar11.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar11.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n28 : Expr .natural := (.nat (15))
def n30 : Expr .natural := (.nat (28))
def n32 : Expr .natural := (.addN n28 n30)
def n33 : Expr .natural := (.nat (43))
noncomputable def v28 (ρ : Env) : Option (Ty.denote .natural) := some (15)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .natural) := some (28)
noncomputable def v32 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v28 ρ) (v30 ρ)
noncomputable def v33 (ρ : Env) : Option (Ty.denote .natural) := some (43)
theorem eval_32 (ρ : Env) : (Expr.eval ρ n32) = (v32 ρ) := rfl
theorem eval_33 (ρ : Env) : (Expr.eval ρ n33) = (v33 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v32 ρ) (v33 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_32 ρ) (eval_33 ρ)) (Numeric.sound ρ n32 n33 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n32) (Expr.eval ρ n33) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_32 ρ) (eval_33 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n32) : (Expr.eval ρ n32) = (Expr.eval ρ n33) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d28 (ρ : Env) : Prop := True
theorem domain_28 (ρ : Env) : Value.Defined (v28 ρ) ↔ d28 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d30 (ρ : Env) : Prop := True
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d32 (ρ : Env) : Prop := ∃ x y, (v28 ρ) = some x ∧ (v30 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_32 (ρ : Env) : Value.Defined (v32 ρ) ↔ d32 ρ :=
  Functions.addN.defined (v28 ρ) (v30 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n32 ↔ (d32 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_32 ρ))).trans (domain_32 ρ)
#qsym_check_axioms definedness
theorem total_28 (ρ : Env) : Value.Defined (v28 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  ⟨_, rfl⟩
theorem total_32 (ρ : Env) : Value.Defined (v32 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v28 ρ) (v30 ρ) (total_28 ρ) (total_30 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n32 := Eq.mpr (congrArg Value.Defined (eval_32 ρ)) (total_32 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar11.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar12.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar12.Certificate

namespace QSym.BindingScalar12.DomainCertificate
def n2 : Expr .natural := (.nat (3))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
def n5 : Expr .natural := (.nat (6))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n34 : Expr .natural := (.mulN n2 n5)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v5 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q34 (ρ : Env) : Domain.Correct (v34 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v2 ρ)) (y := (v5 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q2 ρ) (q5 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n34) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q34 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n34 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar12.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar12.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .natural := (.nat (3))
def n5 : Expr .natural := (.nat (6))
def n34 : Expr .natural := (.mulN n2 n5)
def n35 : Expr .natural := (.nat (18))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .natural) := some (3)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .natural) := some (6)
noncomputable def v34 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v2 ρ) (v5 ρ)
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := some (18)
theorem eval_34 (ρ : Env) : (Expr.eval ρ n34) = (v34 ρ) := rfl
theorem eval_35 (ρ : Env) : (Expr.eval ρ n35) = (v35 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v34 ρ) (v35 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_34 ρ) (eval_35 ρ)) (Numeric.sound ρ n34 n35 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n34) (Expr.eval ρ n35) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_34 ρ) (eval_35 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n34) : (Expr.eval ρ n34) = (Expr.eval ρ n35) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d34 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v5 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_34 (ρ : Env) : Value.Defined (v34 ρ) ↔ d34 ρ :=
  Functions.mulN.defined (v2 ρ) (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n34 ↔ (d34 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_34 ρ))).trans (domain_34 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_34 (ρ : Env) : Value.Defined (v34 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v2 ρ) (v5 ρ) (total_2 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n34 := Eq.mpr (congrArg Value.Defined (eval_34 ρ)) (total_34 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar12.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar13.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar13.Certificate

namespace QSym.BindingScalar13.DomainCertificate
def n3 : Expr .natural := (.nat (4))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
def n7 : Expr .natural := (.nat (8))
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n36 : Expr .natural := (.mulN n3 n7)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v7 ρ)
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q36 (ρ : Env) : Domain.Correct (v36 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulN (x := (v3 ρ)) (y := (v7 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q3 ρ) (q7 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n36) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q36 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n36 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar13.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar13.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n3 : Expr .natural := (.nat (4))
def n7 : Expr .natural := (.nat (8))
def n36 : Expr .natural := (.mulN n3 n7)
def n37 : Expr .natural := (.nat (32))
noncomputable def v3 (ρ : Env) : Option (Ty.denote .natural) := some (4)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .natural) := some (8)
noncomputable def v36 (ρ : Env) : Option (Ty.denote .natural) := Functions.mulN.apply (v3 ρ) (v7 ρ)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := some (32)
theorem eval_36 (ρ : Env) : (Expr.eval ρ n36) = (v36 ρ) := rfl
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v36 ρ) (v37 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_36 ρ) (eval_37 ρ)) (Numeric.sound ρ n36 n37 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n36) (Expr.eval ρ n37) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_36 ρ) (eval_37 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n36) : (Expr.eval ρ n36) = (Expr.eval ρ n37) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d3 (ρ : Env) : Prop := True
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d7 (ρ : Env) : Prop := True
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d36 (ρ : Env) : Prop := ∃ x y, (v3 ρ) = some x ∧ (v7 ρ) = some y ∧ Functions.mulN.domain x y
theorem domain_36 (ρ : Env) : Value.Defined (v36 ρ) ↔ d36 ρ :=
  Functions.mulN.defined (v3 ρ) (v7 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n36 ↔ (d36 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_36 ρ))).trans (domain_36 ρ)
#qsym_check_axioms definedness
theorem total_3 (ρ : Env) : Value.Defined (v3 ρ) :=
  ⟨_, rfl⟩
theorem total_7 (ρ : Env) : Value.Defined (v7 ρ) :=
  ⟨_, rfl⟩
theorem total_36 (ρ : Env) : Value.Defined (v36 ρ) :=
  Functions.mulN.total (fun _ _ => True.intro) (v3 ρ) (v7 ρ) (total_3 ρ) (total_7 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n36 := Eq.mpr (congrArg Value.Defined (eval_36 ρ)) (total_36 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar13.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar14.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar14.Certificate

namespace QSym.BindingScalar14.DomainCertificate
def n8 : Expr .natural := (.nat (0))
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n37 : Expr .natural := (.nat (32))
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := some (32)
def n38 : Expr .natural := (.addN n37 n8)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v37 ρ) (v8 ρ)
theorem q37 (ρ : Env) : Domain.Correct (v37 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q38 (ρ : Env) : Domain.Correct (v38 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v37 ρ)) (y := (v8 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q37 ρ) (q8 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n38) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q38 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n38 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar14.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar14.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n8 : Expr .natural := (.nat (0))
def n37 : Expr .natural := (.nat (32))
def n38 : Expr .natural := (.addN n37 n8)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := some (32)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v37 ρ) (v8 ρ)
theorem eval_37 (ρ : Env) : (Expr.eval ρ n37) = (v37 ρ) := rfl
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v38 ρ) (v37 ρ) :=
  (Generated.r_natural_add_zero (v37 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n38) (Expr.eval ρ n37) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_38 ρ) (eval_37 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n38) : (Expr.eval ρ n38) = (Expr.eval ρ n37) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d37 (ρ : Env) : Prop := True
theorem domain_37 (ρ : Env) : Value.Defined (v37 ρ) ↔ d37 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := True
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d38 (ρ : Env) : Prop := ∃ x y, (v37 ρ) = some x ∧ (v8 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_38 (ρ : Env) : Value.Defined (v38 ρ) ↔ d38 ρ :=
  Functions.addN.defined (v37 ρ) (v8 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n38 ↔ (d38 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_38 ρ))).trans (domain_38 ρ)
#qsym_check_axioms definedness
theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  ⟨_, rfl⟩
theorem total_38 (ρ : Env) : Value.Defined (v38 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v37 ρ) (v8 ρ) (total_37 ρ) (total_8 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n38 := Eq.mpr (congrArg Value.Defined (eval_38 ρ)) (total_38 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar14.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar15.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar15.Certificate

namespace QSym.BindingScalar15.DomainCertificate
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n35 : Expr .natural := (.nat (18))
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := some (18)
def n37 : Expr .natural := (.nat (32))
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := some (32)
def n39 : Expr .natural := (.addN n35 n37)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v35 ρ) (v37 ρ)
theorem q35 (ρ : Env) : Domain.Correct (v35 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q37 (ρ : Env) : Domain.Correct (v37 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q39 (ρ : Env) : Domain.Correct (v39 ρ) (v15 ρ) :=
  Domain.total2 Functions.addN (x := (v35 ρ)) (y := (v37 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q35 ρ) (q37 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n39) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q39 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n39 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar15.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar15.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n35 : Expr .natural := (.nat (18))
def n37 : Expr .natural := (.nat (32))
def n39 : Expr .natural := (.addN n35 n37)
def n40 : Expr .natural := (.nat (50))
noncomputable def v35 (ρ : Env) : Option (Ty.denote .natural) := some (18)
noncomputable def v37 (ρ : Env) : Option (Ty.denote .natural) := some (32)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .natural) := Functions.addN.apply (v35 ρ) (v37 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .natural) := some (50)
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v39 ρ) (v40 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_39 ρ) (eval_40 ρ)) (Numeric.sound ρ n39 n40 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n40) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_40 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n40) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d35 (ρ : Env) : Prop := True
theorem domain_35 (ρ : Env) : Value.Defined (v35 ρ) ↔ d35 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d37 (ρ : Env) : Prop := True
theorem domain_37 (ρ : Env) : Value.Defined (v37 ρ) ↔ d37 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d39 (ρ : Env) : Prop := ∃ x y, (v35 ρ) = some x ∧ (v37 ρ) = some y ∧ Functions.addN.domain x y
theorem domain_39 (ρ : Env) : Value.Defined (v39 ρ) ↔ d39 ρ :=
  Functions.addN.defined (v35 ρ) (v37 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (domain_39 ρ)
#qsym_check_axioms definedness
theorem total_35 (ρ : Env) : Value.Defined (v35 ρ) :=
  ⟨_, rfl⟩
theorem total_37 (ρ : Env) : Value.Defined (v37 ρ) :=
  ⟨_, rfl⟩
theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  Functions.addN.total (fun _ _ => True.intro) (v35 ρ) (v37 ρ) (total_35 ρ) (total_37 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_39 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar15.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .natural := (.nat (3))
def n3 : Expr .natural := (.nat (4))
def n4 : Expr .natural := (.nat (5))
def n5 : Expr .natural := (.nat (6))
def n6 : Expr .natural := (.nat (7))
def n7 : Expr .natural := (.nat (8))
def n8 : Expr .natural := (.nat (0))
def n14 : Expr .natural := (.mulN n0 n4)
def n15 : Expr .bool := (.bool true)
def n16 : Expr .natural := (.mulN n1 n6)
def n17 : Expr .natural := (.nat (14))
def n18 : Expr .natural := (.addN n17 n8)
def n19 : Expr .natural := (.addN n4 n17)
def n20 : Expr .natural := (.nat (19))
def n21 : Expr .natural := (.mulN n0 n5)
def n22 : Expr .natural := (.mulN n1 n7)
def n23 : Expr .natural := (.nat (16))
def n24 : Expr .natural := (.addN n23 n8)
def n25 : Expr .natural := (.addN n5 n23)
def n26 : Expr .natural := (.nat (22))
def n27 : Expr .natural := (.mulN n2 n4)
def n28 : Expr .natural := (.nat (15))
def n29 : Expr .natural := (.mulN n3 n6)
def n30 : Expr .natural := (.nat (28))
def n31 : Expr .natural := (.addN n30 n8)
def n32 : Expr .natural := (.addN n28 n30)
def n33 : Expr .natural := (.nat (43))
def n34 : Expr .natural := (.mulN n2 n5)
def n35 : Expr .natural := (.nat (18))
def n36 : Expr .natural := (.mulN n3 n7)
def n37 : Expr .natural := (.nat (32))
def n38 : Expr .natural := (.addN n37 n8)
def n39 : Expr .natural := (.addN n35 n37)
def n40 : Expr .natural := (.nat (50))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n0
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n1
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 0) := .constant Tensor.nilValue
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t1 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t0 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n2
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n3
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t6 γ) (t2 γ)
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t5 γ) (t7 γ)
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 0) := .constant Tensor.nilValue
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t8 γ) (t9 γ)
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t4 γ) (t10 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n4
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n5
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t13 γ) (t2 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t12 γ) (t14 γ)
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n6
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n7
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t17 γ) (t2 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t16 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t19 γ) (t9 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t15 γ) (t20 γ)
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (t11 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n8
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t1 γ) (t16 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t24 γ) (t23 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t12 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t26 γ) (t25 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t1 γ) (t17 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t28 γ) (t23 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t0 γ) (t13 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t30 γ) (t29 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t31 γ) (t2 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t27 γ) (t32 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t6 γ) (t16 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t34 γ) (t23 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t5 γ) (t12 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t36 γ) (t35 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t6 γ) (t17 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t38 γ) (t23 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.mulN.apply (t5 γ) (t13 γ)
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t40 γ) (t39 γ)
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t41 γ) (t2 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t37 γ) (t42 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t43 γ) (t9 γ)
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t33 γ) (t44 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n14
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n15
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t12 γ)
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n16
noncomputable def t50 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n17
noncomputable def t51 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t50 γ)
noncomputable def t52 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t50 γ) (t23 γ)
noncomputable def t53 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n18
noncomputable def t54 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t12 γ) (t50 γ)
noncomputable def t55 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n19
noncomputable def t56 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n20
noncomputable def t57 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t56 γ)
noncomputable def t58 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n21
noncomputable def t59 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t13 γ)
noncomputable def t60 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n22
noncomputable def t61 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n23
noncomputable def t62 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t61 γ)
noncomputable def t63 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t61 γ) (t23 γ)
noncomputable def t64 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n24
noncomputable def t65 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t13 γ) (t61 γ)
noncomputable def t66 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n25
noncomputable def t67 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n26
noncomputable def t68 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t67 γ)
noncomputable def t69 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t67 γ) (t2 γ)
noncomputable def t70 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t56 γ) (t69 γ)
noncomputable def t71 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n27
noncomputable def t72 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n28
noncomputable def t73 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t72 γ)
noncomputable def t74 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n29
noncomputable def t75 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n30
noncomputable def t76 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t75 γ)
noncomputable def t77 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t75 γ) (t23 γ)
noncomputable def t78 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n31
noncomputable def t79 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t72 γ) (t75 γ)
noncomputable def t80 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n32
noncomputable def t81 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n33
noncomputable def t82 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t81 γ)
noncomputable def t83 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n34
noncomputable def t84 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n35
noncomputable def t85 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t84 γ)
noncomputable def t86 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n36
noncomputable def t87 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n37
noncomputable def t88 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t87 γ)
noncomputable def t89 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t87 γ) (t23 γ)
noncomputable def t90 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n38
noncomputable def t91 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Functions.addN.apply (t84 γ) (t87 γ)
noncomputable def t92 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n39
noncomputable def t93 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .scalar n40
noncomputable def t94 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .natural) := .binary Binding.guardValue (t47 γ) (t93 γ)
noncomputable def t95 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 1) := .binary Tensor.consValue (t93 γ) (t2 γ)
noncomputable def t96 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .natural) 2) := .binary Tensor.consValue (t81 γ) (t95 γ)
noncomputable def t97 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 1) := .binary Tensor.consValue (t96 γ) (t9 γ)
noncomputable def t98 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .natural) 2) 2) := .binary Tensor.consValue (t70 γ) (t97 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p0 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p6 γ) (p2 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p5 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t9 γ) := .refl (t9 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p8 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p4 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .refl (t13 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p13 γ) (p2 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p12 γ) (p14 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .refl (t17 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p17 γ) (p2 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p16 γ) (p18 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p19 γ) (p9 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p15 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.vector (.vector (.scalar .natural) 2) 2)) (b := (.vector (.vector (.scalar .natural) 2) 2)) (c := (.vector (.vector (.scalar .natural) 2) 2)) (Tensor.matmulValue Functions.addN.apply Functions.mulN.apply 0 2 2 2) (p11 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t45 γ) := .ofEq (fun ξ ρ => rfl)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t26 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p12 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t46 γ) := .ofEq (fun _ _ => rfl)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .refl (t46 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t48 γ) := .scalarSimplify n14 n15 n4 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t47 γ) := .refl (t47 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t48 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p12 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t12 γ) := .guardTrue (t12 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t12 γ) := .trans (p30 γ) (p12 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t12 γ) := .trans (p29 γ) (p31 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t12 γ) := .trans (p27 γ) (p32 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t12 γ) := .trans (p26 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t12 γ) := .trans (p25 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t12 γ) := .trans (p24 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p1 γ) (p16 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t49 γ) := .ofEq (fun _ _ => rfl)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t49 γ) := .refl (t49 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t51 γ) := .scalarSimplify n16 n15 n17 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t50 γ) := .refl (t50 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t51 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t50 γ) := .guardTrue (t50 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t50 γ) := .trans (p43 γ) (p41 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t50 γ) := .trans (p42 γ) (p44 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t50 γ) := .trans (p40 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t50 γ) := .trans (p39 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t50 γ) := .trans (p38 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t50 γ) := .trans (p37 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t52 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p49 γ) (p50 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t53 γ) := .ofEq (fun _ _ => rfl)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t53 γ) := .refl (t53 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t51 γ) := .scalarSimplify n18 n15 n17 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t50 γ) := .trans (p54 γ) (p45 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t50 γ) := .trans (p53 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t50 γ) := .trans (p52 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t50 γ) := .trans (p51 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t54 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p36 γ) (p58 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .ofEq (fun _ _ => rfl)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t55 γ) := .refl (t55 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t57 γ) := .scalarSimplify n19 n15 n20 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t56 γ) := .refl (t56 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t57 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p63 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t56 γ) := .guardTrue (t56 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t56 γ) := .trans (p65 γ) (p63 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t56 γ) := .trans (p64 γ) (p66 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t56 γ) := .trans (p62 γ) (p67 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t56 γ) := .trans (p61 γ) (p68 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t56 γ) := .trans (p60 γ) (p69 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t56 γ) := .trans (p59 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p0 γ) (p13 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t58 γ) := .ofEq (fun _ _ => rfl)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t58 γ) := .refl (t58 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t59 γ) := .scalarSimplify n21 n15 n5 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t59 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p13 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t13 γ) := .guardTrue (t13 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t13 γ) := .trans (p77 γ) (p13 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t59 γ) (t13 γ) := .trans (p76 γ) (p78 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t13 γ) := .trans (p75 γ) (p79 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t58 γ) (t13 γ) := .trans (p74 γ) (p80 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t13 γ) := .trans (p73 γ) (p81 γ)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t13 γ) := .trans (p72 γ) (p82 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p1 γ) (p17 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t60 γ) := .ofEq (fun _ _ => rfl)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t60 γ) := .refl (t60 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t62 γ) := .scalarSimplify n22 n15 n23 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t61 γ) (t61 γ) := .refl (t61 γ)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t62 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p88 γ)
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t61 γ) := .guardTrue (t61 γ)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t61 γ) := .trans (p90 γ) (p88 γ)
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t62 γ) (t61 γ) := .trans (p89 γ) (p91 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t61 γ) := .trans (p87 γ) (p92 γ)
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t60 γ) (t61 γ) := .trans (p86 γ) (p93 γ)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t61 γ) := .trans (p85 γ) (p94 γ)
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t61 γ) := .trans (p84 γ) (p95 γ)
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t63 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p96 γ) (p50 γ)
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t64 γ) := .ofEq (fun _ _ => rfl)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t64 γ) := .refl (t64 γ)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t62 γ) := .scalarSimplify n24 n15 n23 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p101 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t61 γ) := .trans (p100 γ) (p92 γ)
theorem p102 (γ : Binding.Globals) : Binding.Reduction (t64 γ) (t61 γ) := .trans (p99 γ) (p101 γ)
theorem p103 (γ : Binding.Globals) : Binding.Reduction (t63 γ) (t61 γ) := .trans (p98 γ) (p102 γ)
theorem p104 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t61 γ) := .trans (p97 γ) (p103 γ)
theorem p105 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t65 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p83 γ) (p104 γ)
theorem p106 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t66 γ) := .ofEq (fun _ _ => rfl)
theorem p107 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t66 γ) := .refl (t66 γ)
theorem p108 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t68 γ) := .scalarSimplify n25 n15 n26 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p109 (γ : Binding.Globals) : Binding.Reduction (t67 γ) (t67 γ) := .refl (t67 γ)
theorem p110 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t68 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p109 γ)
theorem p111 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t67 γ) := .guardTrue (t67 γ)
theorem p112 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t67 γ) := .trans (p111 γ) (p109 γ)
theorem p113 (γ : Binding.Globals) : Binding.Reduction (t68 γ) (t67 γ) := .trans (p110 γ) (p112 γ)
theorem p114 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t67 γ) := .trans (p108 γ) (p113 γ)
theorem p115 (γ : Binding.Globals) : Binding.Reduction (t66 γ) (t67 γ) := .trans (p107 γ) (p114 γ)
theorem p116 (γ : Binding.Globals) : Binding.Reduction (t65 γ) (t67 γ) := .trans (p106 γ) (p115 γ)
theorem p117 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t67 γ) := .trans (p105 γ) (p116 γ)
theorem p118 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t69 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p117 γ) (p2 γ)
theorem p119 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t70 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p71 γ) (p118 γ)
theorem p120 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p5 γ) (p12 γ)
theorem p121 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t71 γ) := .ofEq (fun _ _ => rfl)
theorem p122 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t71 γ) := .refl (t71 γ)
theorem p123 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t73 γ) := .scalarSimplify n27 n15 n28 QSym.BindingScalar8.DomainCertificate.domain_correct QSym.BindingScalar8.ValueCertificate.refinement
theorem p124 (γ : Binding.Globals) : Binding.Reduction (t72 γ) (t72 γ) := .refl (t72 γ)
theorem p125 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t73 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p124 γ)
theorem p126 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t72 γ) := .guardTrue (t72 γ)
theorem p127 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t72 γ) := .trans (p126 γ) (p124 γ)
theorem p128 (γ : Binding.Globals) : Binding.Reduction (t73 γ) (t72 γ) := .trans (p125 γ) (p127 γ)
theorem p129 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t72 γ) := .trans (p123 γ) (p128 γ)
theorem p130 (γ : Binding.Globals) : Binding.Reduction (t71 γ) (t72 γ) := .trans (p122 γ) (p129 γ)
theorem p131 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t72 γ) := .trans (p121 γ) (p130 γ)
theorem p132 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t72 γ) := .trans (p120 γ) (p131 γ)
theorem p133 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t34 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p6 γ) (p16 γ)
theorem p134 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t74 γ) := .ofEq (fun _ _ => rfl)
theorem p135 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t74 γ) := .refl (t74 γ)
theorem p136 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t76 γ) := .scalarSimplify n29 n15 n30 QSym.BindingScalar9.DomainCertificate.domain_correct QSym.BindingScalar9.ValueCertificate.refinement
theorem p137 (γ : Binding.Globals) : Binding.Reduction (t75 γ) (t75 γ) := .refl (t75 γ)
theorem p138 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t76 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p137 γ)
theorem p139 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t75 γ) := .guardTrue (t75 γ)
theorem p140 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t75 γ) := .trans (p139 γ) (p137 γ)
theorem p141 (γ : Binding.Globals) : Binding.Reduction (t76 γ) (t75 γ) := .trans (p138 γ) (p140 γ)
theorem p142 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t75 γ) := .trans (p136 γ) (p141 γ)
theorem p143 (γ : Binding.Globals) : Binding.Reduction (t74 γ) (t75 γ) := .trans (p135 γ) (p142 γ)
theorem p144 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t75 γ) := .trans (p134 γ) (p143 γ)
theorem p145 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t75 γ) := .trans (p133 γ) (p144 γ)
theorem p146 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t77 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p145 γ) (p50 γ)
theorem p147 (γ : Binding.Globals) : Binding.Reduction (t77 γ) (t78 γ) := .ofEq (fun _ _ => rfl)
theorem p148 (γ : Binding.Globals) : Binding.Reduction (t78 γ) (t78 γ) := .refl (t78 γ)
theorem p149 (γ : Binding.Globals) : Binding.Reduction (t78 γ) (t76 γ) := .scalarSimplify n31 n15 n30 QSym.BindingScalar10.DomainCertificate.domain_correct QSym.BindingScalar10.ValueCertificate.refinement
theorem p150 (γ : Binding.Globals) : Binding.Reduction (t78 γ) (t75 γ) := .trans (p149 γ) (p141 γ)
theorem p151 (γ : Binding.Globals) : Binding.Reduction (t78 γ) (t75 γ) := .trans (p148 γ) (p150 γ)
theorem p152 (γ : Binding.Globals) : Binding.Reduction (t77 γ) (t75 γ) := .trans (p147 γ) (p151 γ)
theorem p153 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t75 γ) := .trans (p146 γ) (p152 γ)
theorem p154 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t79 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p132 γ) (p153 γ)
theorem p155 (γ : Binding.Globals) : Binding.Reduction (t79 γ) (t80 γ) := .ofEq (fun _ _ => rfl)
theorem p156 (γ : Binding.Globals) : Binding.Reduction (t80 γ) (t80 γ) := .refl (t80 γ)
theorem p157 (γ : Binding.Globals) : Binding.Reduction (t80 γ) (t82 γ) := .scalarSimplify n32 n15 n33 QSym.BindingScalar11.DomainCertificate.domain_correct QSym.BindingScalar11.ValueCertificate.refinement
theorem p158 (γ : Binding.Globals) : Binding.Reduction (t81 γ) (t81 γ) := .refl (t81 γ)
theorem p159 (γ : Binding.Globals) : Binding.Reduction (t82 γ) (t82 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p158 γ)
theorem p160 (γ : Binding.Globals) : Binding.Reduction (t82 γ) (t81 γ) := .guardTrue (t81 γ)
theorem p161 (γ : Binding.Globals) : Binding.Reduction (t82 γ) (t81 γ) := .trans (p160 γ) (p158 γ)
theorem p162 (γ : Binding.Globals) : Binding.Reduction (t82 γ) (t81 γ) := .trans (p159 γ) (p161 γ)
theorem p163 (γ : Binding.Globals) : Binding.Reduction (t80 γ) (t81 γ) := .trans (p157 γ) (p162 γ)
theorem p164 (γ : Binding.Globals) : Binding.Reduction (t80 γ) (t81 γ) := .trans (p156 γ) (p163 γ)
theorem p165 (γ : Binding.Globals) : Binding.Reduction (t79 γ) (t81 γ) := .trans (p155 γ) (p164 γ)
theorem p166 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t81 γ) := .trans (p154 γ) (p165 γ)
theorem p167 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p5 γ) (p13 γ)
theorem p168 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t83 γ) := .ofEq (fun _ _ => rfl)
theorem p169 (γ : Binding.Globals) : Binding.Reduction (t83 γ) (t83 γ) := .refl (t83 γ)
theorem p170 (γ : Binding.Globals) : Binding.Reduction (t83 γ) (t85 γ) := .scalarSimplify n34 n15 n35 QSym.BindingScalar12.DomainCertificate.domain_correct QSym.BindingScalar12.ValueCertificate.refinement
theorem p171 (γ : Binding.Globals) : Binding.Reduction (t84 γ) (t84 γ) := .refl (t84 γ)
theorem p172 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t85 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p171 γ)
theorem p173 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t84 γ) := .guardTrue (t84 γ)
theorem p174 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t84 γ) := .trans (p173 γ) (p171 γ)
theorem p175 (γ : Binding.Globals) : Binding.Reduction (t85 γ) (t84 γ) := .trans (p172 γ) (p174 γ)
theorem p176 (γ : Binding.Globals) : Binding.Reduction (t83 γ) (t84 γ) := .trans (p170 γ) (p175 γ)
theorem p177 (γ : Binding.Globals) : Binding.Reduction (t83 γ) (t84 γ) := .trans (p169 γ) (p176 γ)
theorem p178 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t84 γ) := .trans (p168 γ) (p177 γ)
theorem p179 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t84 γ) := .trans (p167 γ) (p178 γ)
theorem p180 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.mulN.apply (p6 γ) (p17 γ)
theorem p181 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t86 γ) := .ofEq (fun _ _ => rfl)
theorem p182 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t86 γ) := .refl (t86 γ)
theorem p183 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t88 γ) := .scalarSimplify n36 n15 n37 QSym.BindingScalar13.DomainCertificate.domain_correct QSym.BindingScalar13.ValueCertificate.refinement
theorem p184 (γ : Binding.Globals) : Binding.Reduction (t87 γ) (t87 γ) := .refl (t87 γ)
theorem p185 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t88 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p184 γ)
theorem p186 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t87 γ) := .guardTrue (t87 γ)
theorem p187 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t87 γ) := .trans (p186 γ) (p184 γ)
theorem p188 (γ : Binding.Globals) : Binding.Reduction (t88 γ) (t87 γ) := .trans (p185 γ) (p187 γ)
theorem p189 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t87 γ) := .trans (p183 γ) (p188 γ)
theorem p190 (γ : Binding.Globals) : Binding.Reduction (t86 γ) (t87 γ) := .trans (p182 γ) (p189 γ)
theorem p191 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t87 γ) := .trans (p181 γ) (p190 γ)
theorem p192 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t87 γ) := .trans (p180 γ) (p191 γ)
theorem p193 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t89 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p192 γ) (p50 γ)
theorem p194 (γ : Binding.Globals) : Binding.Reduction (t89 γ) (t90 γ) := .ofEq (fun _ _ => rfl)
theorem p195 (γ : Binding.Globals) : Binding.Reduction (t90 γ) (t90 γ) := .refl (t90 γ)
theorem p196 (γ : Binding.Globals) : Binding.Reduction (t90 γ) (t88 γ) := .scalarSimplify n38 n15 n37 QSym.BindingScalar14.DomainCertificate.domain_correct QSym.BindingScalar14.ValueCertificate.refinement
theorem p197 (γ : Binding.Globals) : Binding.Reduction (t90 γ) (t87 γ) := .trans (p196 γ) (p188 γ)
theorem p198 (γ : Binding.Globals) : Binding.Reduction (t90 γ) (t87 γ) := .trans (p195 γ) (p197 γ)
theorem p199 (γ : Binding.Globals) : Binding.Reduction (t89 γ) (t87 γ) := .trans (p194 γ) (p198 γ)
theorem p200 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t87 γ) := .trans (p193 γ) (p199 γ)
theorem p201 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t91 γ) := .binary (a := (.scalar .natural)) (b := (.scalar .natural)) (c := (.scalar .natural)) Functions.addN.apply (p179 γ) (p200 γ)
theorem p202 (γ : Binding.Globals) : Binding.Reduction (t91 γ) (t92 γ) := .ofEq (fun _ _ => rfl)
theorem p203 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t92 γ) := .refl (t92 γ)
theorem p204 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t94 γ) := .scalarSimplify n39 n15 n40 QSym.BindingScalar15.DomainCertificate.domain_correct QSym.BindingScalar15.ValueCertificate.refinement
theorem p205 (γ : Binding.Globals) : Binding.Reduction (t93 γ) (t93 γ) := .refl (t93 γ)
theorem p206 (γ : Binding.Globals) : Binding.Reduction (t94 γ) (t94 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .natural)) (c := (.scalar .natural)) Binding.guardValue (p28 γ) (p205 γ)
theorem p207 (γ : Binding.Globals) : Binding.Reduction (t94 γ) (t93 γ) := .guardTrue (t93 γ)
theorem p208 (γ : Binding.Globals) : Binding.Reduction (t94 γ) (t93 γ) := .trans (p207 γ) (p205 γ)
theorem p209 (γ : Binding.Globals) : Binding.Reduction (t94 γ) (t93 γ) := .trans (p206 γ) (p208 γ)
theorem p210 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t93 γ) := .trans (p204 γ) (p209 γ)
theorem p211 (γ : Binding.Globals) : Binding.Reduction (t92 γ) (t93 γ) := .trans (p203 γ) (p210 γ)
theorem p212 (γ : Binding.Globals) : Binding.Reduction (t91 γ) (t93 γ) := .trans (p202 γ) (p211 γ)
theorem p213 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t93 γ) := .trans (p201 γ) (p212 γ)
theorem p214 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t95 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 0)) (c := (.vector (.scalar .natural) 1)) Tensor.consValue (p213 γ) (p2 γ)
theorem p215 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t96 γ) := .binary (a := (.scalar .natural)) (b := (.vector (.scalar .natural) 1)) (c := (.vector (.scalar .natural) 2)) Tensor.consValue (p166 γ) (p214 γ)
theorem p216 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t97 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 0)) (c := (.vector (.vector (.scalar .natural) 2) 1)) Tensor.consValue (p215 γ) (p9 γ)
theorem p217 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t98 γ) := .binary (a := (.vector (.scalar .natural) 2)) (b := (.vector (.vector (.scalar .natural) 2) 1)) (c := (.vector (.vector (.scalar .natural) 2) 2)) Tensor.consValue (p119 γ) (p216 γ)
theorem p218 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t98 γ) := .trans (p23 γ) (p217 γ)
theorem p219 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t98 γ) := .trans (p22 γ) (p218 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t98 γ) := (p219 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t22 γ).eval ξ ρ = (t98 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t22 γ).eval ξ ρ) ↔ Value.Defined ((t98 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
