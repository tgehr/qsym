import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .real := (.real (0))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 0) := .constant Tensor.nilValue
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .real) 0) 0) := .constant Tensor.nilValue
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .real) 0) 1) := .binary Tensor.consValue (t0 γ) (t1 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.vector (.scalar .real) 0) 2) := .binary Tensor.consValue (t0 γ) (t2 γ)
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary (Tensor.matvecValue Value.add Value.mul ((0 : ℤ) : ℝ) 2 0) (t3 γ) (t0 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n0
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 1) := .binary Tensor.consValue (t5 γ) (t0 γ)
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 2) := .binary Tensor.consValue (t5 γ) (t6 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .refl (t1 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .binary (a := (.vector (.scalar .real) 0)) (b := (.vector (.vector (.scalar .real) 0) 0)) (c := (.vector (.vector (.scalar .real) 0) 1)) Tensor.consValue (p0 γ) (p1 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .binary (a := (.vector (.scalar .real) 0)) (b := (.vector (.vector (.scalar .real) 0) 1)) (c := (.vector (.vector (.scalar .real) 0) 2)) Tensor.consValue (p0 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.vector (.vector (.scalar .real) 0) 2)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 2)) (Tensor.matvecValue Value.add Value.mul ((0 : ℤ) : ℝ) 2 0) (p3 γ) (p0 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t7 γ) := .ofEq (fun ξ ρ => rfl)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .refl (t5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 0)) (c := (.vector (.scalar .real) 1)) Tensor.consValue (p6 γ) (p0 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .binary (a := (.scalar .real)) (b := (.vector (.scalar .real) 1)) (c := (.vector (.scalar .real) 2)) Tensor.consValue (p6 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t7 γ) := .trans (p5 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t7 γ) := .trans (p4 γ) (p9 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t7 γ) := (p10 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t4 γ).eval ξ ρ = (t7 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t4 γ).eval ξ ρ) ↔ Value.Defined ((t7 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
