import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n8 : Expr .integer := (.castNZ n0)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
def n9 : Expr .rational := (.castZQ n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v8 ρ)
def n10 : Expr .real := (.castQR n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v9 ρ)
def n11 : Expr .complex := (.castRC n10)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v10 ρ)
def n38 : Expr .complex := (.conj n11)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v11 ρ)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v39 ρ) :=
  Domain.total1 Functions.castNZ (x := (v0 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q0 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v39 ρ) :=
  Domain.total1 Functions.castZQ (x := (v8 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v39 ρ) :=
  Domain.total1 Functions.castQR (x := (v9 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v39 ρ) :=
  Domain.total1 Functions.castRC (x := (v10 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q10 ρ)
theorem q38 (ρ : Env) : Domain.Correct (v38 ρ) (v39 ρ) :=
  Domain.transport (x := (v11 ρ)) (d := (v39 ρ)) (Value.defined_conj (v11 ρ)) (q11 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n38) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q38 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n38 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n8 : Expr .integer := (.castNZ n0)
def n9 : Expr .rational := (.castZQ n8)
def n10 : Expr .real := (.castQR n9)
def n11 : Expr .complex := (.castRC n10)
def n16 : Expr .complex := (.complex (1) (0))
def n18 : Expr .integer := (.int (1))
def n19 : Expr .rational := (.castZQ n18)
def n20 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n21 : Expr .real := (.castQR n20)
def n22 : Expr .real := (.real (1))
def n23 : Expr .complex := (.castRC n22)
def n38 : Expr .complex := (.conj n11)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v10 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v18 ρ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v20 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v22 ρ)
noncomputable def v38 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v11 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_8 (ρ : Env) : (Expr.eval ρ n8) = (v8 ρ) := rfl
theorem eval_11 (ρ : Env) : (Expr.eval ρ n11) = (v11 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl
theorem eval_38 (ρ : Env) : (Expr.eval ρ n38) = (v38 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v38 ρ) (v11 ρ) :=
  (Generated.r_conjugate_real_cast (v10 ρ))

theorem p1 (ρ : Env) : Value.Refines (v8 ρ) (v18 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_8 ρ) (eval_18 ρ)) (Numeric.sound ρ n8 n18 rfl)

theorem p2 (ρ : Env) : Value.Refines (v9 ρ) (v19 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v19 ρ) (v20 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (Numeric.sound ρ n19 n20 rfl)

theorem p4 (ρ : Env) : Value.Refines (v9 ρ) (v20 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v10 ρ) (v21 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v21 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_21 ρ) (eval_22 ρ)) (Numeric.sound ρ n21 n22 rfl)

theorem p7 (ρ : Env) : Value.Refines (v10 ρ) (v22 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v11 ρ) (v23 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v23 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_23 ρ) (eval_16 ρ)) (Numeric.sound ρ n23 n16 rfl)

theorem p10 (ρ : Env) : Value.Refines (v11 ρ) (v16 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v38 ρ) (v16 ρ) :=
  (p0 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v16 ρ) (v11 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_16 ρ) (eval_11 ρ)) (Numeric.sound ρ n16 n11 rfl)

theorem p13 (ρ : Env) : Value.Refines (v38 ρ) (v11 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n38) (Expr.eval ρ n11) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_38 ρ) (eval_11 ρ)) (p13 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n38) : (Expr.eval ρ n38) = (Expr.eval ρ n11) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := ∃ x, (v0 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castNZ.defined (v0 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castZQ.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castQR.defined (v9 ρ)

def d11 (ρ : Env) : Prop := ∃ x, (v10 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  Functions.castRC.defined (v10 ρ)

def d38 (ρ : Env) : Prop := (d11 ρ)
theorem domain_38 (ρ : Env) : Value.Defined (v38 ρ) ↔ d38 ρ :=
  (Value.defined_conj (v11 ρ)).trans (domain_11 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n38 ↔ (d38 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_38 ρ))).trans (domain_38 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v0 ρ) (total_0 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v10 ρ) (total_10 ρ)
theorem total_38 (ρ : Env) : Value.Defined (v38 ρ) :=
  (Value.defined_conj (v11 ρ)).mpr (total_11 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n38 := Eq.mpr (congrArg Value.Defined (eval_38 ρ)) (total_38 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n0 : Expr .natural := (.nat (1))
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
def n2 : Expr .complex := (.complex (0) (1))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n8 : Expr .integer := (.castNZ n0)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
def n9 : Expr .rational := (.castZQ n8)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v8 ρ)
def n10 : Expr .real := (.castQR n9)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v9 ρ)
def n11 : Expr .complex := (.castRC n10)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v10 ρ)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n40 : Expr .complex := (.mulC n11 n2)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v11 ρ) (v2 ρ)
theorem q0 (ρ : Env) : Domain.Correct (v0 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q8 (ρ : Env) : Domain.Correct (v8 ρ) (v39 ρ) :=
  Domain.total1 Functions.castNZ (x := (v0 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q0 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v39 ρ) :=
  Domain.total1 Functions.castZQ (x := (v8 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q8 ρ)
theorem q10 (ρ : Env) : Domain.Correct (v10 ρ) (v39 ρ) :=
  Domain.total1 Functions.castQR (x := (v9 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q9 ρ)
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v39 ρ) :=
  Domain.total1 Functions.castRC (x := (v10 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q10 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q40 (ρ : Env) : Domain.Correct (v40 ρ) (v39 ρ) :=
  Domain.strict2 (x := (v11 ρ)) (y := (v2 ρ)) (dx := (v39 ρ)) (dy := (v39 ρ)) (Value.defined_mul (v11 ρ) (v2 ρ)) (q11 ρ) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n40) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q40 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n40 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .natural := (.nat (1))
def n2 : Expr .complex := (.complex (0) (1))
def n8 : Expr .integer := (.castNZ n0)
def n9 : Expr .rational := (.castZQ n8)
def n10 : Expr .real := (.castQR n9)
def n11 : Expr .complex := (.castRC n10)
def n16 : Expr .complex := (.complex (1) (0))
def n18 : Expr .integer := (.int (1))
def n19 : Expr .rational := (.castZQ n18)
def n20 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n21 : Expr .real := (.castQR n20)
def n22 : Expr .real := (.real (1))
def n23 : Expr .complex := (.castRC n22)
def n40 : Expr .complex := (.mulC n11 n2)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .natural) := some (1)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v8 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v0 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v8 ρ)
noncomputable def v10 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v9 ρ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v10 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v18 (ρ : Env) : Option (Ty.denote .integer) := some (1)
noncomputable def v19 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v18 ρ)
noncomputable def v20 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v21 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v20 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .real) := some ((1 : Int) : ℝ)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v22 ρ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v11 ρ) (v2 ρ)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v2 ρ) (v11 ρ)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v2 ρ) (v11 ρ)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v2 ρ) (v16 ρ)
theorem eval_2 (ρ : Env) : (Expr.eval ρ n2) = (v2 ρ) := rfl
theorem eval_8 (ρ : Env) : (Expr.eval ρ n8) = (v8 ρ) := rfl
theorem eval_16 (ρ : Env) : (Expr.eval ρ n16) = (v16 ρ) := rfl
theorem eval_18 (ρ : Env) : (Expr.eval ρ n18) = (v18 ρ) := rfl
theorem eval_19 (ρ : Env) : (Expr.eval ρ n19) = (v19 ρ) := rfl
theorem eval_20 (ρ : Env) : (Expr.eval ρ n20) = (v20 ρ) := rfl
theorem eval_21 (ρ : Env) : (Expr.eval ρ n21) = (v21 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v40 ρ) (v41 ρ) :=
  let ac2 : Replay.Tree := (.leaf 0)
  let ac11 : Replay.Tree := (.leaf 1)
  let ac40 : Replay.Tree := (.node ac11 ac2)
  let ac41 : Replay.Tree := (.node ac2 ac11)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v2 ρ),(v11 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac40 ac41 rfl)

theorem p1 (ρ : Env) : Value.Refines (v8 ρ) (v18 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_8 ρ) (eval_18 ρ)) (Numeric.sound ρ n8 n18 rfl)

theorem p2 (ρ : Env) : Value.Refines (v9 ρ) (v19 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v19 ρ) (v20 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_19 ρ) (eval_20 ρ)) (Numeric.sound ρ n19 n20 rfl)

theorem p4 (ρ : Env) : Value.Refines (v9 ρ) (v20 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v10 ρ) (v21 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v21 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_21 ρ) (eval_22 ρ)) (Numeric.sound ρ n21 n22 rfl)

theorem p7 (ρ : Env) : Value.Refines (v10 ρ) (v22 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v11 ρ) (v23 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v23 ρ) (v16 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_23 ρ) (eval_16 ρ)) (Numeric.sound ρ n23 n16 rfl)

theorem p10 (ρ : Env) : Value.Refines (v11 ρ) (v16 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v41 ρ) (v42 ρ) :=
  Value.refines_refl (v41 ρ)

theorem p12 (ρ : Env) : Value.Refines (v42 ρ) (v43 ρ) :=
  Value.refines_mul (Value.refines_refl (v2 ρ)) (p10 ρ)

theorem p13 (ρ : Env) : Value.Refines (v41 ρ) (v43 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem p14 (ρ : Env) : Value.Refines (v43 ρ) (v2 ρ) :=
  let ac2 : Replay.Tree := (.leaf 0)
  let ac16 : Replay.Tree := .unit
  let ac43 : Replay.Tree := (.node ac2 ac16)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v2 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac43 ac2 rfl)

theorem p15 (ρ : Env) : Value.Refines (v41 ρ) (v2 ρ) :=
  (p13 ρ).trans (p14 ρ)

theorem p16 (ρ : Env) : Value.Refines (v40 ρ) (v2 ρ) :=
  (p0 ρ).trans (p15 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n40) (Expr.eval ρ n2) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_40 ρ) (eval_2 ρ)) (p16 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n40) : (Expr.eval ρ n40) = (Expr.eval ρ n2) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d0 (ρ : Env) : Prop := True
theorem domain_0 (ρ : Env) : Value.Defined (v0 ρ) ↔ d0 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d8 (ρ : Env) : Prop := ∃ x, (v0 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_8 (ρ : Env) : Value.Defined (v8 ρ) ↔ d8 ρ :=
  Functions.castNZ.defined (v0 ρ)

def d9 (ρ : Env) : Prop := ∃ x, (v8 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.castZQ.defined (v8 ρ)

def d10 (ρ : Env) : Prop := ∃ x, (v9 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_10 (ρ : Env) : Value.Defined (v10 ρ) ↔ d10 ρ :=
  Functions.castQR.defined (v9 ρ)

def d11 (ρ : Env) : Prop := ∃ x, (v10 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  Functions.castRC.defined (v10 ρ)

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d40 (ρ : Env) : Prop := (d11 ρ) ∧ (d2 ρ)
theorem domain_40 (ρ : Env) : Value.Defined (v40 ρ) ↔ d40 ρ :=
  (Value.defined_mul (v11 ρ) (v2 ρ)).trans (and_congr (domain_11 ρ) (domain_2 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n40 ↔ (d40 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_40 ρ))).trans (domain_40 ρ)
#qsym_check_axioms definedness
theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_8 (ρ : Env) : Value.Defined (v8 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v0 ρ) (total_0 ρ)
theorem total_9 (ρ : Env) : Value.Defined (v9 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v8 ρ) (total_8 ρ)
theorem total_10 (ρ : Env) : Value.Defined (v10 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v9 ρ) (total_9 ρ)
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v10 ρ) (total_10 ρ)
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_40 (ρ : Env) : Value.Defined (v40 ρ) :=
  (Value.defined_mul (v11 ρ) (v2 ρ)).mpr ⟨(total_11 ρ), (total_2 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n40 := Eq.mpr (congrArg Value.Defined (eval_40 ρ)) (total_40 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .integer := (.castNZ n1)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
def n13 : Expr .rational := (.castZQ n12)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
def n14 : Expr .real := (.castQR n13)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
def n15 : Expr .complex := (.castRC n14)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v14 ρ)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n44 : Expr .complex := (.conj n15)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v15 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v39 ρ) :=
  Domain.total1 Functions.castNZ (x := (v1 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q1 ρ)
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v39 ρ) :=
  Domain.total1 Functions.castZQ (x := (v12 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q12 ρ)
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v39 ρ) :=
  Domain.total1 Functions.castQR (x := (v13 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q13 ρ)
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v39 ρ) :=
  Domain.total1 Functions.castRC (x := (v14 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q14 ρ)
theorem q44 (ρ : Env) : Domain.Correct (v44 ρ) (v39 ρ) :=
  Domain.transport (x := (v15 ρ)) (d := (v39 ρ)) (Value.defined_conj (v15 ρ)) (q15 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n44) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q44 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n44 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n12 : Expr .integer := (.castNZ n1)
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .real := (.castQR n13)
def n15 : Expr .complex := (.castRC n14)
def n17 : Expr .complex := (.complex (2) (0))
def n24 : Expr .integer := (.int (2))
def n25 : Expr .rational := (.castZQ n24)
def n26 : Expr .rational := (.rat ((2) / (1) : ℚ))
def n27 : Expr .real := (.castQR n26)
def n28 : Expr .real := (.real (2))
def n29 : Expr .complex := (.castRC n28)
def n44 : Expr .complex := (.conj n15)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v14 ρ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := some (2)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v26 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .real) := some ((2 : Int) : ℝ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v28 ρ)
noncomputable def v44 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v15 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_44 (ρ : Env) : (Expr.eval ρ n44) = (v44 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v44 ρ) (v15 ρ) :=
  (Generated.r_conjugate_real_cast (v14 ρ))

theorem p1 (ρ : Env) : Value.Refines (v12 ρ) (v24 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_12 ρ) (eval_24 ρ)) (Numeric.sound ρ n12 n24 rfl)

theorem p2 (ρ : Env) : Value.Refines (v13 ρ) (v25 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v25 ρ) (v26 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_25 ρ) (eval_26 ρ)) (Numeric.sound ρ n25 n26 rfl)

theorem p4 (ρ : Env) : Value.Refines (v13 ρ) (v26 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v14 ρ) (v27 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v27 ρ) (v28 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_27 ρ) (eval_28 ρ)) (Numeric.sound ρ n27 n28 rfl)

theorem p7 (ρ : Env) : Value.Refines (v14 ρ) (v28 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v15 ρ) (v29 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v29 ρ) (v17 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_29 ρ) (eval_17 ρ)) (Numeric.sound ρ n29 n17 rfl)

theorem p10 (ρ : Env) : Value.Refines (v15 ρ) (v17 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v44 ρ) (v17 ρ) :=
  (p0 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v17 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_15 ρ)) (Numeric.sound ρ n17 n15 rfl)

theorem p13 (ρ : Env) : Value.Refines (v44 ρ) (v15 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n44) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_44 ρ) (eval_15 ρ)) (p13 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n44) : (Expr.eval ρ n44) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x, (v1 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.castNZ.defined (v1 ρ)

def d13 (ρ : Env) : Prop := ∃ x, (v12 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.castZQ.defined (v12 ρ)

def d14 (ρ : Env) : Prop := ∃ x, (v13 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.castQR.defined (v13 ρ)

def d15 (ρ : Env) : Prop := ∃ x, (v14 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  Functions.castRC.defined (v14 ρ)

def d44 (ρ : Env) : Prop := (d15 ρ)
theorem domain_44 (ρ : Env) : Value.Defined (v44 ρ) ↔ d44 ρ :=
  (Value.defined_conj (v15 ρ)).trans (domain_15 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n44 ↔ (d44 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_44 ρ))).trans (domain_44 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v1 ρ) (total_1 ρ)
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v12 ρ) (total_12 ρ)
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v13 ρ) (total_13 ρ)
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v14 ρ) (total_14 ρ)
theorem total_44 (ρ : Env) : Value.Defined (v44 ρ) :=
  (Value.defined_conj (v15 ρ)).mpr (total_15 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n44 := Eq.mpr (congrArg Value.Defined (eval_44 ρ)) (total_44 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .integer := (.castNZ n1)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
def n13 : Expr .rational := (.castZQ n12)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
def n14 : Expr .real := (.castQR n13)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
def n15 : Expr .complex := (.castRC n14)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v14 ρ)
def n16 : Expr .complex := (.complex (1) (0))
noncomputable def v16 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n45 : Expr .complex := (.mulC n15 n16)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v15 ρ) (v16 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v39 ρ) :=
  Domain.total1 Functions.castNZ (x := (v1 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q1 ρ)
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v39 ρ) :=
  Domain.total1 Functions.castZQ (x := (v12 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q12 ρ)
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v39 ρ) :=
  Domain.total1 Functions.castQR (x := (v13 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q13 ρ)
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v39 ρ) :=
  Domain.total1 Functions.castRC (x := (v14 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q14 ρ)
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q45 (ρ : Env) : Domain.Correct (v45 ρ) (v39 ρ) :=
  Domain.strict2 (x := (v15 ρ)) (y := (v16 ρ)) (dx := (v39 ρ)) (dy := (v39 ρ)) (Value.defined_mul (v15 ρ) (v16 ρ)) (q15 ρ) (q16 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n45) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q45 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n45 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n12 : Expr .integer := (.castNZ n1)
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .real := (.castQR n13)
def n15 : Expr .complex := (.castRC n14)
def n16 : Expr .complex := (.complex (1) (0))
def n17 : Expr .complex := (.complex (2) (0))
def n24 : Expr .integer := (.int (2))
def n25 : Expr .rational := (.castZQ n24)
def n26 : Expr .rational := (.rat ((2) / (1) : ℚ))
def n27 : Expr .real := (.castQR n26)
def n28 : Expr .real := (.real (2))
def n29 : Expr .complex := (.castRC n28)
def n45 : Expr .complex := (.mulC n15 n16)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v14 ρ)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .complex) := some (((1 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := some (2)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v26 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .real) := some ((2 : Int) : ℝ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v28 ρ)
noncomputable def v45 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v15 ρ) (v16 ρ)
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_45 (ρ : Env) : (Expr.eval ρ n45) = (v45 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v45 ρ) (v15 ρ) :=
  let ac15 : Replay.Tree := (.leaf 0)
  let ac16 : Replay.Tree := .unit
  let ac45 : Replay.Tree := (.node ac15 ac16)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v15 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac45 ac15 rfl)

theorem p1 (ρ : Env) : Value.Refines (v12 ρ) (v24 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_12 ρ) (eval_24 ρ)) (Numeric.sound ρ n12 n24 rfl)

theorem p2 (ρ : Env) : Value.Refines (v13 ρ) (v25 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v25 ρ) (v26 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_25 ρ) (eval_26 ρ)) (Numeric.sound ρ n25 n26 rfl)

theorem p4 (ρ : Env) : Value.Refines (v13 ρ) (v26 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v14 ρ) (v27 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v27 ρ) (v28 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_27 ρ) (eval_28 ρ)) (Numeric.sound ρ n27 n28 rfl)

theorem p7 (ρ : Env) : Value.Refines (v14 ρ) (v28 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v15 ρ) (v29 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v29 ρ) (v17 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_29 ρ) (eval_17 ρ)) (Numeric.sound ρ n29 n17 rfl)

theorem p10 (ρ : Env) : Value.Refines (v15 ρ) (v17 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v45 ρ) (v17 ρ) :=
  (p0 ρ).trans (p10 ρ)

theorem p12 (ρ : Env) : Value.Refines (v17 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_15 ρ)) (Numeric.sound ρ n17 n15 rfl)

theorem p13 (ρ : Env) : Value.Refines (v45 ρ) (v15 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n45) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_45 ρ) (eval_15 ρ)) (p13 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n45) : (Expr.eval ρ n45) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x, (v1 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.castNZ.defined (v1 ρ)

def d13 (ρ : Env) : Prop := ∃ x, (v12 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.castZQ.defined (v12 ρ)

def d14 (ρ : Env) : Prop := ∃ x, (v13 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.castQR.defined (v13 ρ)

def d15 (ρ : Env) : Prop := ∃ x, (v14 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  Functions.castRC.defined (v14 ρ)

def d16 (ρ : Env) : Prop := True
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d45 (ρ : Env) : Prop := (d15 ρ) ∧ (d16 ρ)
theorem domain_45 (ρ : Env) : Value.Defined (v45 ρ) ↔ d45 ρ :=
  (Value.defined_mul (v15 ρ) (v16 ρ)).trans (and_congr (domain_15 ρ) (domain_16 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n45 ↔ (d45 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_45 ρ))).trans (domain_45 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v1 ρ) (total_1 ρ)
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v12 ρ) (total_12 ρ)
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v13 ρ) (total_13 ρ)
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v14 ρ) (total_14 ρ)
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_45 (ρ : Env) : Value.Defined (v45 ρ) :=
  (Value.defined_mul (v15 ρ) (v16 ρ)).mpr ⟨(total_15 ρ), (total_16 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n45 := Eq.mpr (congrArg Value.Defined (eval_45 ρ)) (total_45 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n2 : Expr .complex := (.complex (0) (1))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n46 : Expr .complex := (.conj n2)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v2 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q46 (ρ : Env) : Domain.Correct (v46 ρ) (v39 ρ) :=
  Domain.transport (x := (v2 ρ)) (d := (v39 ρ)) (Value.defined_conj (v2 ρ)) (q2 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n46) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q46 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n46 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .complex := (.complex (0) (1))
def n46 : Expr .complex := (.conj n2)
def n47 : Expr .complex := (.complex (0) (-1))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v46 (ρ : Env) : Option (Ty.denote .complex) := Value.conj (v2 ρ)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
theorem eval_46 (ρ : Env) : (Expr.eval ρ n46) = (v46 ρ) := rfl
theorem eval_47 (ρ : Env) : (Expr.eval ρ n47) = (v47 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v46 ρ) (v47 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_46 ρ) (eval_47 ρ)) (Numeric.sound ρ n46 n47 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n46) (Expr.eval ρ n47) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_46 ρ) (eval_47 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n46) : (Expr.eval ρ n46) = (Expr.eval ρ n47) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_46 (ρ : Env) : Value.Defined (v46 ρ) :=
  (Value.defined_conj (v2 ρ)).mpr (total_2 ρ)
theorem total_root (ρ : Env) : Value.Defined (v46 ρ) := (total_46 ρ)
def d46 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n46 ↔ (d46 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_46 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n46 := Eq.mpr (congrArg Value.Defined (eval_46 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n17 : Expr .complex := (.complex (2) (0))
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n47 : Expr .complex := (.complex (0) (-1))
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
def n48 : Expr .complex := (.mulC n47 n17)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v47 ρ) (v17 ρ)
theorem q47 (ρ : Env) : Domain.Correct (v47 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q17 (ρ : Env) : Domain.Correct (v17 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q48 (ρ : Env) : Domain.Correct (v48 ρ) (v39 ρ) :=
  Domain.strict2 (x := (v47 ρ)) (y := (v17 ρ)) (dx := (v39 ρ)) (dy := (v39 ρ)) (Value.defined_mul (v47 ρ) (v17 ρ)) (q47 ρ) (q17 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n48) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q48 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n48 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n17 : Expr .complex := (.complex (2) (0))
def n47 : Expr .complex := (.complex (0) (-1))
def n48 : Expr .complex := (.mulC n47 n17)
def b49 : Region (Expr .complex) := .join (.item n17 .one) (.item n47 .one)
def n49 : Expr .complex := Expr.productC b49
def n50 : Expr .complex := (.complex (0) (-2))
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v47 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
noncomputable def v48 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v47 ρ) (v17 ρ)
noncomputable def v49 (ρ : Env) : Option (Ty.denote .complex) := Value.mul (v17 ρ) (v47 ρ)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
theorem eval_48 (ρ : Env) : (Expr.eval ρ n48) = (v48 ρ) := rfl
theorem eval_49 (ρ : Env) : (Expr.eval ρ n49) = (v49 ρ) := rfl
theorem eval_50 (ρ : Env) : (Expr.eval ρ n50) = (v50 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v48 ρ) (v49 ρ) :=
  let ac17 : Replay.Tree := (.leaf 0)
  let ac47 : Replay.Tree := (.leaf 1)
  let ac48 : Replay.Tree := (.node ac47 ac17)
  let ac49 : Replay.Tree := (.node ac17 ac47)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.mulC (fun i => ([(v17 ρ),(v47 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac48 ac49 rfl)

theorem p1 (ρ : Env) : Value.Refines (v49 ρ) (v50 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_49 ρ) (eval_50 ρ)) (Numeric.sound ρ n49 n50 rfl)

theorem p2 (ρ : Env) : Value.Refines (v48 ρ) (v50 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n48) (Expr.eval ρ n50) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_48 ρ) (eval_50 ρ)) (p2 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n48) : (Expr.eval ρ n48) = (Expr.eval ρ n50) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_47 (ρ : Env) : Value.Defined (v47 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  ⟨_, rfl⟩
theorem total_48 (ρ : Env) : Value.Defined (v48 ρ) :=
  (Value.defined_mul (v47 ρ) (v17 ρ)).mpr ⟨(total_47 ρ), (total_17 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v48 ρ) := (total_48 ρ)
def d48 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n48 ↔ (d48 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_48 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n48 := Eq.mpr (congrArg Value.Defined (eval_48 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n30 : Expr .complex := (.complex (0) (0))
noncomputable def v30 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n50 : Expr .complex := (.complex (0) (-2))
noncomputable def v50 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
def n51 : Expr .complex := (.addC n50 n30)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v50 ρ) (v30 ρ)
theorem q50 (ρ : Env) : Domain.Correct (v50 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q51 (ρ : Env) : Domain.Correct (v51 ρ) (v39 ρ) :=
  Domain.strict2 (x := (v50 ρ)) (y := (v30 ρ)) (dx := (v39 ρ)) (dy := (v39 ρ)) (Value.defined_add (v50 ρ) (v30 ρ)) (q50 ρ) (q30 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n51) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q51 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n51 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n30 : Expr .complex := (.complex (0) (0))
def n50 : Expr .complex := (.complex (0) (-2))
def n51 : Expr .complex := (.addC n50 n30)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
noncomputable def v51 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v50 ρ) (v30 ρ)
theorem eval_50 (ρ : Env) : (Expr.eval ρ n50) = (v50 ρ) := rfl
theorem eval_51 (ρ : Env) : (Expr.eval ρ n51) = (v51 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v51 ρ) (v50 ρ) :=
  let ac30 : Replay.Tree := .unit
  let ac50 : Replay.Tree := (.leaf 0)
  let ac51 : Replay.Tree := (.node ac50 ac30)
  Value.refines_of_eq (Replay.AC.sound_counts Replay.addC (fun i => ([(v50 ρ)] : List (Option (Ty.denote .complex))).getD i none) ac51 ac50 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n51) (Expr.eval ρ n50) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_51 ρ) (eval_50 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n51) : (Expr.eval ρ n51) = (Expr.eval ρ n50) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_50 (ρ : Env) : Value.Defined (v50 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  ⟨_, rfl⟩
theorem total_51 (ρ : Env) : Value.Defined (v51 ρ) :=
  (Value.defined_add (v50 ρ) (v30 ρ)).mpr ⟨(total_50 ρ), (total_30 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v51 ρ) := (total_51 ρ)
def d51 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n51 ↔ (d51 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_51 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n51 := Eq.mpr (congrArg Value.Defined (eval_51 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n1 : Expr .natural := (.nat (2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
def n12 : Expr .integer := (.castNZ n1)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
def n13 : Expr .rational := (.castZQ n12)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
def n14 : Expr .real := (.castQR n13)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
def n15 : Expr .complex := (.castRC n14)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v14 ρ)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n50 : Expr .complex := (.complex (0) (-2))
noncomputable def v50 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
def n52 : Expr .complex := (.addC n15 n50)
noncomputable def v52 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v15 ρ) (v50 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v39 ρ) :=
  Domain.total1 Functions.castNZ (x := (v1 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q1 ρ)
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v39 ρ) :=
  Domain.total1 Functions.castZQ (x := (v12 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q12 ρ)
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v39 ρ) :=
  Domain.total1 Functions.castQR (x := (v13 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q13 ρ)
theorem q15 (ρ : Env) : Domain.Correct (v15 ρ) (v39 ρ) :=
  Domain.total1 Functions.castRC (x := (v14 ρ)) (d := (v39 ρ)) (fun _ => True.intro) (q14 ρ)
theorem q50 (ρ : Env) : Domain.Correct (v50 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q52 (ρ : Env) : Domain.Correct (v52 ρ) (v39 ρ) :=
  Domain.strict2 (x := (v15 ρ)) (y := (v50 ρ)) (dx := (v39 ρ)) (dy := (v39 ρ)) (Value.defined_add (v15 ρ) (v50 ρ)) (q15 ρ) (q50 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n52) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q52 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n52 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .natural := (.nat (2))
def n12 : Expr .integer := (.castNZ n1)
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .real := (.castQR n13)
def n15 : Expr .complex := (.castRC n14)
def n17 : Expr .complex := (.complex (2) (0))
def n24 : Expr .integer := (.int (2))
def n25 : Expr .rational := (.castZQ n24)
def n26 : Expr .rational := (.rat ((2) / (1) : ℚ))
def n27 : Expr .real := (.castQR n26)
def n28 : Expr .real := (.real (2))
def n29 : Expr .complex := (.castRC n28)
def n50 : Expr .complex := (.complex (0) (-2))
def n52 : Expr .complex := (.addC n15 n50)
def b55 : Region (Expr .complex) := .join (.item n17 .one) (.item n50 .one)
def n55 : Expr .complex := Expr.sumC b55
def n56 : Expr .complex := (.complex (2) (-2))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (2)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v12 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v13 ρ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v14 ρ)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((0 : Int) : ℂ) * Complex.I)
noncomputable def v24 (ρ : Env) : Option (Ty.denote .integer) := some (2)
noncomputable def v25 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v24 ρ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v26 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .real) := some ((2 : Int) : ℝ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .complex) := Functions.castRC.apply (v28 ρ)
noncomputable def v50 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
noncomputable def v52 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v15 ρ) (v50 ρ)
noncomputable def v53 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v15 ρ) (v50 ρ)
noncomputable def v54 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v17 ρ) (v50 ρ)
noncomputable def v55 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v17 ρ) (v50 ρ)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl
theorem eval_24 (ρ : Env) : (Expr.eval ρ n24) = (v24 ρ) := rfl
theorem eval_25 (ρ : Env) : (Expr.eval ρ n25) = (v25 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_52 (ρ : Env) : (Expr.eval ρ n52) = (v52 ρ) := rfl
theorem eval_55 (ρ : Env) : (Expr.eval ρ n55) = (v55 ρ) := rfl
theorem eval_56 (ρ : Env) : (Expr.eval ρ n56) = (v56 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v52 ρ) (v53 ρ) :=
  Value.refines_refl (v52 ρ)

theorem p1 (ρ : Env) : Value.Refines (v12 ρ) (v24 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_12 ρ) (eval_24 ρ)) (Numeric.sound ρ n12 n24 rfl)

theorem p2 (ρ : Env) : Value.Refines (v13 ρ) (v25 ρ) :=
  Value.refines_function1 Functions.castZQ (p1 ρ)

theorem p3 (ρ : Env) : Value.Refines (v25 ρ) (v26 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_25 ρ) (eval_26 ρ)) (Numeric.sound ρ n25 n26 rfl)

theorem p4 (ρ : Env) : Value.Refines (v13 ρ) (v26 ρ) :=
  (p2 ρ).trans (p3 ρ)

theorem p5 (ρ : Env) : Value.Refines (v14 ρ) (v27 ρ) :=
  Value.refines_function1 Functions.castQR (p4 ρ)

theorem p6 (ρ : Env) : Value.Refines (v27 ρ) (v28 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_27 ρ) (eval_28 ρ)) (Numeric.sound ρ n27 n28 rfl)

theorem p7 (ρ : Env) : Value.Refines (v14 ρ) (v28 ρ) :=
  (p5 ρ).trans (p6 ρ)

theorem p8 (ρ : Env) : Value.Refines (v15 ρ) (v29 ρ) :=
  Value.refines_function1 Functions.castRC (p7 ρ)

theorem p9 (ρ : Env) : Value.Refines (v29 ρ) (v17 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_29 ρ) (eval_17 ρ)) (Numeric.sound ρ n29 n17 rfl)

theorem p10 (ρ : Env) : Value.Refines (v15 ρ) (v17 ρ) :=
  (p8 ρ).trans (p9 ρ)

theorem p11 (ρ : Env) : Value.Refines (v53 ρ) (v52 ρ) :=
  Value.refines_refl (v53 ρ)

theorem p12 (ρ : Env) : Value.Refines (v52 ρ) (v54 ρ) :=
  Value.refines_add (p10 ρ) (Value.refines_refl (v50 ρ))

theorem p13 (ρ : Env) : Value.Refines (v53 ρ) (v54 ρ) :=
  (p11 ρ).trans (p12 ρ)

theorem p14 (ρ : Env) : Value.Refines (v54 ρ) (v55 ρ) :=
  Value.refines_refl (v54 ρ)

theorem p15 (ρ : Env) : Value.Refines (v53 ρ) (v55 ρ) :=
  (p13 ρ).trans (p14 ρ)

theorem p16 (ρ : Env) : Value.Refines (v55 ρ) (v56 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_55 ρ) (eval_56 ρ)) (Numeric.sound ρ n55 n56 rfl)

theorem p17 (ρ : Env) : Value.Refines (v53 ρ) (v56 ρ) :=
  (p15 ρ).trans (p16 ρ)

theorem p18 (ρ : Env) : Value.Refines (v52 ρ) (v56 ρ) :=
  (p0 ρ).trans (p17 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n52) (Expr.eval ρ n56) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_52 ρ) (eval_56 ρ)) (p18 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n52) : (Expr.eval ρ n52) = (Expr.eval ρ n56) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x, (v1 ρ) = some x ∧ Functions.castNZ.domain x
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.castNZ.defined (v1 ρ)

def d13 (ρ : Env) : Prop := ∃ x, (v12 ρ) = some x ∧ Functions.castZQ.domain x
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.castZQ.defined (v12 ρ)

def d14 (ρ : Env) : Prop := ∃ x, (v13 ρ) = some x ∧ Functions.castQR.domain x
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  Functions.castQR.defined (v13 ρ)

def d15 (ρ : Env) : Prop := ∃ x, (v14 ρ) = some x ∧ Functions.castRC.domain x
theorem domain_15 (ρ : Env) : Value.Defined (v15 ρ) ↔ d15 ρ :=
  Functions.castRC.defined (v14 ρ)

def d50 (ρ : Env) : Prop := True
theorem domain_50 (ρ : Env) : Value.Defined (v50 ρ) ↔ d50 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d52 (ρ : Env) : Prop := (d15 ρ) ∧ (d50 ρ)
theorem domain_52 (ρ : Env) : Value.Defined (v52 ρ) ↔ d52 ρ :=
  (Value.defined_add (v15 ρ) (v50 ρ)).trans (and_congr (domain_15 ρ) (domain_50 ρ))

theorem definedness (ρ : Env) : Expr.Defined ρ n52 ↔ (d52 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_52 ρ))).trans (domain_52 ρ)
#qsym_check_axioms definedness
theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_12 (ρ : Env) : Value.Defined (v12 ρ) :=
  Functions.castNZ.total (fun _ => True.intro) (v1 ρ) (total_1 ρ)
theorem total_13 (ρ : Env) : Value.Defined (v13 ρ) :=
  Functions.castZQ.total (fun _ => True.intro) (v12 ρ) (total_12 ρ)
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  Functions.castQR.total (fun _ => True.intro) (v13 ρ) (total_13 ρ)
theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  Functions.castRC.total (fun _ => True.intro) (v14 ρ) (total_14 ρ)
theorem total_50 (ρ : Env) : Value.Defined (v50 ρ) :=
  ⟨_, rfl⟩
theorem total_52 (ρ : Env) : Value.Defined (v52 ρ) :=
  (Value.defined_add (v15 ρ) (v50 ρ)).mpr ⟨(total_15 ρ), (total_50 ρ)⟩
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n52 := Eq.mpr (congrArg Value.Defined (eval_52 ρ)) (total_52 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n39) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_39 ρ)) (Value.refines_refl (v39 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n39) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v39 ρ) := (total_39 ρ)
def d39 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.Certificate

namespace QSym.BindingScalar8.DomainCertificate
def n2 : Expr .complex := (.complex (0) (1))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
def n39 : Expr .bool := (.bool true)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .bool) := some true
def n56 : Expr .complex := (.complex (2) (-2))
noncomputable def v56 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
def n57 : Expr .complex := (.addC n2 n56)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v2 ρ) (v56 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q56 (ρ : Env) : Domain.Correct (v56 ρ) (v39 ρ) :=
  Domain.leaf _
theorem q57 (ρ : Env) : Domain.Correct (v57 ρ) (v39 ρ) :=
  Domain.strict2 (x := (v2 ρ)) (y := (v56 ρ)) (dx := (v39 ρ)) (dy := (v39 ρ)) (Value.defined_add (v2 ρ) (v56 ρ)) (q2 ρ) (q56 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n57) (Expr.eval ρ Certificate.n39) :=
  Domain.simplify (q57 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n39) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n57 ↔ (Expr.eval ρ Certificate.n39) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar8.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar8.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .complex := (.complex (0) (1))
def n56 : Expr .complex := (.complex (2) (-2))
def n57 : Expr .complex := (.addC n2 n56)
def b58 : Region (Expr .complex) := .join (.item n2 .one) (.item n56 .one)
def n58 : Expr .complex := Expr.sumC b58
def n59 : Expr .complex := (.complex (2) (-1))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .complex) := some (((0 : Int) : ℂ) + ((1 : Int) : ℂ) * Complex.I)
noncomputable def v56 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((-2 : Int) : ℂ) * Complex.I)
noncomputable def v57 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v2 ρ) (v56 ρ)
noncomputable def v58 (ρ : Env) : Option (Ty.denote .complex) := Value.add (v2 ρ) (v56 ρ)
noncomputable def v59 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
theorem eval_57 (ρ : Env) : (Expr.eval ρ n57) = (v57 ρ) := rfl
theorem eval_58 (ρ : Env) : (Expr.eval ρ n58) = (v58 ρ) := rfl
theorem eval_59 (ρ : Env) : (Expr.eval ρ n59) = (v59 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v57 ρ) (v58 ρ) :=
  Value.refines_refl (v57 ρ)

theorem p1 (ρ : Env) : Value.Refines (v58 ρ) (v59 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_58 ρ) (eval_59 ρ)) (Numeric.sound ρ n58 n59 rfl)

theorem p2 (ρ : Env) : Value.Refines (v57 ρ) (v59 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n57) (Expr.eval ρ n59) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_57 ρ) (eval_59 ρ)) (p2 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n57) : (Expr.eval ρ n57) = (Expr.eval ρ n59) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_56 (ρ : Env) : Value.Defined (v56 ρ) :=
  ⟨_, rfl⟩
theorem total_57 (ρ : Env) : Value.Defined (v57 ρ) :=
  (Value.defined_add (v2 ρ) (v56 ρ)).mpr ⟨(total_2 ρ), (total_56 ρ)⟩
theorem total_root (ρ : Env) : Value.Defined (v57 ρ) := (total_57 ρ)
def d57 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n57 ↔ (d57 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_57 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n57 := Eq.mpr (congrArg Value.Defined (eval_57 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar8.ValueCertificate
namespace QSym.BindingCertificate
def n0 : Expr .natural := (.nat (1))
def n1 : Expr .natural := (.nat (2))
def n2 : Expr .complex := (.complex (0) (1))
def n8 : Expr .integer := (.castNZ n0)
def n9 : Expr .rational := (.castZQ n8)
def n10 : Expr .real := (.castQR n9)
def n11 : Expr .complex := (.castRC n10)
def n12 : Expr .integer := (.castNZ n1)
def n13 : Expr .rational := (.castZQ n12)
def n14 : Expr .real := (.castQR n13)
def n15 : Expr .complex := (.castRC n14)
def n16 : Expr .complex := (.complex (1) (0))
def n17 : Expr .complex := (.complex (2) (0))
def n30 : Expr .complex := (.complex (0) (0))
def n38 : Expr .complex := (.conj n11)
def n39 : Expr .bool := (.bool true)
def n40 : Expr .complex := (.mulC n11 n2)
def n44 : Expr .complex := (.conj n15)
def n45 : Expr .complex := (.mulC n15 n16)
def n46 : Expr .complex := (.conj n2)
def n47 : Expr .complex := (.complex (0) (-1))
def n48 : Expr .complex := (.mulC n47 n17)
def n50 : Expr .complex := (.complex (0) (-2))
def n51 : Expr .complex := (.addC n50 n30)
def n52 : Expr .complex := (.addC n15 n50)
def n56 : Expr .complex := (.complex (2) (-2))
def n57 : Expr .complex := (.addC n2 n56)
def n59 : Expr .complex := (.complex (2) (-1))
abbrev c0 : List Binding.Ty := []
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n2
noncomputable def t6 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n11
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n15
noncomputable def t11 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 0) := .constant Tensor.nilValue
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t2 γ) (t11 γ)
noncomputable def t13 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t10 γ) (t12 γ)
noncomputable def t14 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 3) := .binary Tensor.consValue (t6 γ) (t13 γ)
noncomputable def t15 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n16
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n17
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 1) := .binary Tensor.consValue (t16 γ) (t11 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 2) := .binary Tensor.consValue (t15 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .complex) 3) := .binary Tensor.consValue (t2 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary (Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 3) (t14 γ) (t19 γ)
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n30
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .unary Value.conj (t2 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t22 γ) (t16 γ)
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t23 γ) (t21 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .unary Value.conj (t10 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t25 γ) (t15 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t26 γ) (t24 γ)
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .unary Value.conj (t6 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t28 γ) (t2 γ)
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t29 γ) (t27 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n38
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n39
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t32 γ) (t6 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t6 γ) (t2 γ)
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n40
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t32 γ) (t2 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n44
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t32 γ) (t10 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t10 γ) (t15 γ)
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n45
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n46
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n47
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t32 γ) (t42 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.mul (t42 γ) (t16 γ)
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n48
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n50
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t32 γ) (t46 γ)
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t46 γ) (t21 γ)
noncomputable def t49 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n51
noncomputable def t50 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t10 γ) (t46 γ)
noncomputable def t51 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n52
noncomputable def t52 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n56
noncomputable def t53 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t32 γ) (t52 γ)
noncomputable def t54 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Value.add (t2 γ) (t52 γ)
noncomputable def t55 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n57
noncomputable def t56 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .scalar n59
noncomputable def t57 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .complex) := .binary Binding.guardValue (t32 γ) (t56 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t6 γ) (t6 γ) := .refl (t6 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t10 γ) := .refl (t10 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t11 γ) (t11 γ) := .refl (t11 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p2 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t13 γ) (t13 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p1 γ) (p4 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t14 γ) (t14 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 2)) (c := (.vector (.scalar .complex) 3)) Tensor.consValue (p0 γ) (p5 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t15 γ) (t15 γ) := .refl (t15 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t17 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 0)) (c := (.vector (.scalar .complex) 1)) Tensor.consValue (p8 γ) (p3 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t18 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 1)) (c := (.vector (.scalar .complex) 2)) Tensor.consValue (p7 γ) (p9 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t19 γ) := .binary (a := (.scalar .complex)) (b := (.vector (.scalar .complex) 2)) (c := (.vector (.scalar .complex) 3)) Tensor.consValue (p2 γ) (p10 γ)
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .binary (a := (.vector (.scalar .complex) 3)) (b := (.vector (.scalar .complex) 3)) (c := (.scalar .complex)) (Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 3) (p6 γ) (p11 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t30 γ) := .ofEq (fun ξ ρ => (Eq.mpr (congrArg (fun w0 : Option ((.scalar .complex) : Binding.Ty).denote => ((Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 3) (Tensor.consValue w0 (Tensor.consValue ((t10 γ).eval ξ ρ) (Tensor.consValue ((t2 γ).eval ξ ρ) ((t11 γ).eval ξ ρ)))) (Tensor.consValue ((t2 γ).eval ξ ρ) (Tensor.consValue ((t15 γ).eval ξ ρ) (Tensor.consValue ((t16 γ).eval ξ ρ) ((t11 γ).eval ξ ρ))))) = (Value.add (Value.mul (Value.conj w0) ((t2 γ).eval ξ ρ)) (Value.add (Value.mul (Value.conj ((t10 γ).eval ξ ρ)) ((t15 γ).eval ξ ρ)) (Value.add (Value.mul (Value.conj ((t2 γ).eval ξ ρ)) ((t16 γ).eval ξ ρ)) ((t21 γ).eval ξ ρ))))) (show n11.eval ξ = some (Functions.castRC.value (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0))))) from Eq.trans (congrArg Functions.castRC.apply (show n10.eval ξ = some (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0)))) from Eq.trans (congrArg Functions.castQR.apply (show n9.eval ξ = some (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0))) from Eq.trans (congrArg Functions.castZQ.apply (show n8.eval ξ = some (Functions.castNZ.value ((n0.eval ξ).getD 0)) from Eq.trans (congrArg Functions.castNZ.apply (show n0.eval ξ = some ((n0.eval ξ).getD 0) from rfl)) (Tensor.apply_some Functions.castNZ ((n0.eval ξ).getD 0) True.intro))) (Tensor.apply_some Functions.castZQ (Functions.castNZ.value ((n0.eval ξ).getD 0)) True.intro))) (Tensor.apply_some Functions.castQR (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0))) True.intro))) (Tensor.apply_some Functions.castRC (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0)))) True.intro))) (Eq.mpr (congrArg (fun w1 : Option ((.scalar .complex) : Binding.Ty).denote => ((Tensor.dotValue Value.add Value.mul Value.conj (((0 : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * Complex.I) 3) (Tensor.consValue (some (Functions.castRC.value (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0)))))) (Tensor.consValue w1 (Tensor.consValue ((t2 γ).eval ξ ρ) ((t11 γ).eval ξ ρ)))) (Tensor.consValue ((t2 γ).eval ξ ρ) (Tensor.consValue ((t15 γ).eval ξ ρ) (Tensor.consValue ((t16 γ).eval ξ ρ) ((t11 γ).eval ξ ρ))))) = (Value.add (Value.mul (Value.conj (some (Functions.castRC.value (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n0.eval ξ).getD 0))))))) ((t2 γ).eval ξ ρ)) (Value.add (Value.mul (Value.conj w1) ((t15 γ).eval ξ ρ)) (Value.add (Value.mul (Value.conj ((t2 γ).eval ξ ρ)) ((t16 γ).eval ξ ρ)) ((t21 γ).eval ξ ρ))))) (show n15.eval ξ = some (Functions.castRC.value (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0))))) from Eq.trans (congrArg Functions.castRC.apply (show n14.eval ξ = some (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0)))) from Eq.trans (congrArg Functions.castQR.apply (show n13.eval ξ = some (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0))) from Eq.trans (congrArg Functions.castZQ.apply (show n12.eval ξ = some (Functions.castNZ.value ((n1.eval ξ).getD 0)) from Eq.trans (congrArg Functions.castNZ.apply (show n1.eval ξ = some ((n1.eval ξ).getD 0) from rfl)) (Tensor.apply_some Functions.castNZ ((n1.eval ξ).getD 0) True.intro))) (Tensor.apply_some Functions.castZQ (Functions.castNZ.value ((n1.eval ξ).getD 0)) True.intro))) (Tensor.apply_some Functions.castQR (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0))) True.intro))) (Tensor.apply_some Functions.castRC (Functions.castQR.value (Functions.castZQ.value (Functions.castNZ.value ((n1.eval ξ).getD 0)))) True.intro))) rfl)))
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .unary (a := (.scalar .complex)) (b := (.scalar .complex)) Value.conj (p0 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t31 γ) := .ofEq (fun _ _ => rfl)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t31 γ) := .refl (t31 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t33 γ) := .scalarSimplify n38 n39 n11 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t32 γ) (t32 γ) := .refl (t32 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t33 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p0 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t6 γ) := .guardTrue (t6 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t6 γ) := .trans (p20 γ) (p0 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t6 γ) := .trans (p19 γ) (p21 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t6 γ) := .trans (p17 γ) (p22 γ)
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t31 γ) (t6 γ) := .trans (p16 γ) (p23 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t6 γ) := .trans (p15 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t6 γ) := .trans (p14 γ) (p25 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t34 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p26 γ) (p2 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t35 γ) := .ofEq (fun _ _ => rfl)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .refl (t35 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t36 γ) := .scalarSimplify n40 n39 n2 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t36 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p2 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t2 γ) := .guardTrue (t2 γ)
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t2 γ) := .trans (p32 γ) (p2 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t2 γ) := .trans (p31 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t2 γ) := .trans (p30 γ) (p34 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t2 γ) := .trans (p29 γ) (p35 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t2 γ) := .trans (p28 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t2 γ) := .trans (p27 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t25 γ) := .unary (a := (.scalar .complex)) (b := (.scalar .complex)) Value.conj (p1 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t37 γ) := .ofEq (fun _ _ => rfl)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .refl (t37 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t38 γ) := .scalarSimplify n44 n39 n15 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t38 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p1 γ)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t10 γ) := .guardTrue (t10 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t10 γ) := .trans (p44 γ) (p1 γ)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t10 γ) := .trans (p43 γ) (p45 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t10 γ) := .trans (p42 γ) (p46 γ)
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t10 γ) := .trans (p41 γ) (p47 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t10 γ) := .trans (p40 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t25 γ) (t10 γ) := .trans (p39 γ) (p49 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t39 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p50 γ) (p7 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t40 γ) := .ofEq (fun _ _ => rfl)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .refl (t40 γ)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t38 γ) := .scalarSimplify n45 n39 n15 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t10 γ) := .trans (p54 γ) (p46 γ)
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t10 γ) := .trans (p53 γ) (p55 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t10 γ) := .trans (p52 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t26 γ) (t10 γ) := .trans (p51 γ) (p57 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .unary (a := (.scalar .complex)) (b := (.scalar .complex)) Value.conj (p2 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t41 γ) := .ofEq (fun _ _ => rfl)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .refl (t41 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t43 γ) := .scalarSimplify n46 n39 n47 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .refl (t42 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t43 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p63 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .guardTrue (t42 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .trans (p65 γ) (p63 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t42 γ) := .trans (p64 γ) (p66 γ)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t42 γ) := .trans (p62 γ) (p67 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t42 γ) := .trans (p61 γ) (p68 γ)
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t42 γ) := .trans (p60 γ) (p69 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t42 γ) := .trans (p59 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t44 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.mul (p71 γ) (p8 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t45 γ) := .ofEq (fun _ _ => rfl)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t45 γ) := .refl (t45 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t47 γ) := .scalarSimplify n48 n39 n50 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .refl (t46 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t47 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p76 γ)
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t46 γ) := .guardTrue (t46 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t46 γ) := .trans (p78 γ) (p76 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t46 γ) := .trans (p77 γ) (p79 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .trans (p75 γ) (p80 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .trans (p74 γ) (p81 γ)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t46 γ) := .trans (p73 γ) (p82 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t46 γ) := .trans (p72 γ) (p83 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t48 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p84 γ) (p85 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t49 γ) := .ofEq (fun _ _ => rfl)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t49 γ) := .refl (t49 γ)
theorem p89 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t47 γ) := .scalarSimplify n51 n39 n50 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p90 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t46 γ) := .trans (p89 γ) (p80 γ)
theorem p91 (γ : Binding.Globals) : Binding.Reduction (t49 γ) (t46 γ) := .trans (p88 γ) (p90 γ)
theorem p92 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t46 γ) := .trans (p87 γ) (p91 γ)
theorem p93 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t46 γ) := .trans (p86 γ) (p92 γ)
theorem p94 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t50 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p58 γ) (p93 γ)
theorem p95 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t51 γ) := .ofEq (fun _ _ => rfl)
theorem p96 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t51 γ) := .refl (t51 γ)
theorem p97 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t53 γ) := .scalarSimplify n52 n39 n56 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p98 (γ : Binding.Globals) : Binding.Reduction (t52 γ) (t52 γ) := .refl (t52 γ)
theorem p99 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t53 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p98 γ)
theorem p100 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t52 γ) := .guardTrue (t52 γ)
theorem p101 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t52 γ) := .trans (p100 γ) (p98 γ)
theorem p102 (γ : Binding.Globals) : Binding.Reduction (t53 γ) (t52 γ) := .trans (p99 γ) (p101 γ)
theorem p103 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t52 γ) := .trans (p97 γ) (p102 γ)
theorem p104 (γ : Binding.Globals) : Binding.Reduction (t51 γ) (t52 γ) := .trans (p96 γ) (p103 γ)
theorem p105 (γ : Binding.Globals) : Binding.Reduction (t50 γ) (t52 γ) := .trans (p95 γ) (p104 γ)
theorem p106 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t52 γ) := .trans (p94 γ) (p105 γ)
theorem p107 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t54 γ) := .binary (a := (.scalar .complex)) (b := (.scalar .complex)) (c := (.scalar .complex)) Value.add (p38 γ) (p106 γ)
theorem p108 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t55 γ) := .ofEq (fun _ _ => rfl)
theorem p109 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t55 γ) := .refl (t55 γ)
theorem p110 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t57 γ) := .scalarSimplify n57 n39 n59 QSym.BindingScalar8.DomainCertificate.domain_correct QSym.BindingScalar8.ValueCertificate.refinement
theorem p111 (γ : Binding.Globals) : Binding.Reduction (t56 γ) (t56 γ) := .refl (t56 γ)
theorem p112 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t57 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .complex)) (c := (.scalar .complex)) Binding.guardValue (p18 γ) (p111 γ)
theorem p113 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t56 γ) := .guardTrue (t56 γ)
theorem p114 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t56 γ) := .trans (p113 γ) (p111 γ)
theorem p115 (γ : Binding.Globals) : Binding.Reduction (t57 γ) (t56 γ) := .trans (p112 γ) (p114 γ)
theorem p116 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t56 γ) := .trans (p110 γ) (p115 γ)
theorem p117 (γ : Binding.Globals) : Binding.Reduction (t55 γ) (t56 γ) := .trans (p109 γ) (p116 γ)
theorem p118 (γ : Binding.Globals) : Binding.Reduction (t54 γ) (t56 γ) := .trans (p108 γ) (p117 γ)
theorem p119 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t56 γ) := .trans (p107 γ) (p118 γ)
theorem p120 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t56 γ) := .trans (p13 γ) (p119 γ)
theorem p121 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t56 γ) := .trans (p12 γ) (p120 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t56 γ) := (p121 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t20 γ).eval ξ ρ = (t56 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t20 γ).eval ξ ρ) ↔ Value.Defined ((t56 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t20 γ).eval ξ ρ = n59.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n59 : Expr .complex := (.complex (2) (-1))
noncomputable def v59 (ρ : Env) : Option (Ty.denote .complex) := some (((2 : Int) : ℂ) + ((-1 : Int) : ℂ) * Complex.I)
theorem eval_59 (ρ : Env) : (Expr.eval ρ n59) = (v59 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n59) (Expr.eval ρ n59) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_59 ρ) (eval_59 ρ)) (Value.refines_refl (v59 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n59) : (Expr.eval ρ n59) = (Expr.eval ρ n59) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_59 (ρ : Env) : Value.Defined (v59 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v59 ρ) := (total_59 ρ)
def d59 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n59 ↔ (d59 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_59 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n59 := Eq.mpr (congrArg Value.Defined (eval_59 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t20 γ).eval ξ ρ) (FunctionScalar.n59.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n59.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t20 γ).eval ξ ρ)) : ((BindingCertificate.t20 γ).eval ξ ρ) = (FunctionScalar.n59.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
