import QSym.Refinement
import QSym.AxiomCheck
namespace QSym.Generated
theorem r_natural_recurrence_add_base (v_a : Option (Ty.denote .natural)) (v_d : Option (Ty.denote .natural))
    (hp0 : Value.Defined v_d) :
    (Functions.addN.apply v_a (Functions.mulN.apply (some ((0) : ℕ)) v_d)) = v_a := by
  cases v_a <;> cases v_d
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_natural_recurrence_add_base


theorem r_natural_recurrence_mul_base (v_a : Option (Ty.denote .natural)) (v_d : Option (Ty.denote .natural))
    (hp0 : Value.Defined v_d) :
    (Functions.mulN.apply v_a (Functions.powNN.apply v_d (some ((0) : ℕ)))) = v_a := by
  cases v_a <;> cases v_d
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_natural_recurrence_mul_base


theorem r_natural_recurrence_add_step (v_a : Option (Ty.denote .natural)) (v_d : Option (Ty.denote .natural)) (v_n : Option (Ty.denote .natural)) :
    (Functions.addN.apply (Functions.addN.apply v_a (Functions.mulN.apply v_n v_d)) v_d) = (Functions.addN.apply v_a (Functions.mulN.apply (Functions.addN.apply v_n (some ((1) : ℕ))) v_d)) := by
  cases v_a <;> cases v_d <;> cases v_n
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_natural_recurrence_add_step


theorem r_natural_recurrence_add_left_step (v_a : Option (Ty.denote .natural)) (v_d : Option (Ty.denote .natural)) (v_n : Option (Ty.denote .natural)) :
    (Functions.addN.apply v_d (Functions.addN.apply v_a (Functions.mulN.apply v_n v_d))) = (Functions.addN.apply v_a (Functions.mulN.apply (Functions.addN.apply v_n (some ((1) : ℕ))) v_d)) := by
  cases v_a <;> cases v_d <;> cases v_n
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_natural_recurrence_add_left_step


theorem r_natural_recurrence_mul_step (v_a : Option (Ty.denote .natural)) (v_d : Option (Ty.denote .natural)) (v_n : Option (Ty.denote .natural)) :
    (Functions.mulN.apply (Functions.mulN.apply v_a (Functions.powNN.apply v_d v_n)) v_d) = (Functions.mulN.apply v_a (Functions.powNN.apply v_d (Functions.addN.apply v_n (some ((1) : ℕ))))) := by
  cases v_a <;> cases v_d <;> cases v_n
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_natural_recurrence_mul_step


theorem r_natural_recurrence_mul_left_step (v_a : Option (Ty.denote .natural)) (v_d : Option (Ty.denote .natural)) (v_n : Option (Ty.denote .natural)) :
    (Functions.mulN.apply v_d (Functions.mulN.apply v_a (Functions.powNN.apply v_d v_n))) = (Functions.mulN.apply v_a (Functions.powNN.apply v_d (Functions.addN.apply v_n (some ((1) : ℕ))))) := by
  cases v_a <;> cases v_d <;> cases v_n
  all_goals apply Value.Refines.antisymm
  all_goals qsym_rule

#qsym_check_axioms r_natural_recurrence_mul_left_step


end QSym.Generated
