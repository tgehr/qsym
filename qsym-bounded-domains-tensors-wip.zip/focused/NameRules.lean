import QSym.Refinement
import QSym.AxiomCheck
namespace QSym.Generated
theorem r_natural_literal_constant (v_x : Option (Ty.denote .natural)) (v_c : Option (Ty.denote .natural)) :
    Value.Refines (Functions.addN.apply v_c v_x) (Functions.addN.apply v_x v_c) := by
  cases v_x <;> cases v_c
  all_goals qsym_rule

#qsym_check_axioms r_natural_literal_constant
end QSym.Generated
