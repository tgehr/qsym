import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .real := (.real (0))
abbrev c0 : List Binding.Ty := []
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .real) 0) := .constant Tensor.nilValue
noncomputable def t1 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .binary (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 0) (t0 γ) (t0 γ)
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .real) := .scalar n0
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t1 γ) := .binary (a := (.vector (.scalar .real) 0)) (b := (.vector (.scalar .real) 0)) (c := (.scalar .real)) (Tensor.dotValue Value.add Value.mul id ((0 : ℤ) : ℝ) 0) (p0 γ) (p0 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t2 γ) := .ofEq (fun ξ ρ => rfl)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .refl (t2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t2 γ) := .trans (p2 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t2 γ) := .trans (p1 γ) (p4 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t1 γ) (t2 γ) := (p5 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t1 γ).eval ξ ρ = (t2 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t1 γ).eval ξ ρ) ↔ Value.Defined ((t2 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t1 γ).eval ξ ρ = n0.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n0 : Expr .real := (.real (0))
def n1 : Expr .natural := (.nat (0))
def n2 : Expr .integer := (.castNZ n1)
def n3 : Expr .rational := (.castZQ n2)
def n4 : Expr .real := (.castQR n3)
noncomputable def v0 (ρ : Env) : Option (Ty.denote .real) := some ((0 : Int) : ℝ)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .natural) := some (0)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .integer) := Functions.castNZ.apply (v1 ρ)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .rational) := Functions.castZQ.apply (v2 ρ)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .real) := Functions.castQR.apply (v3 ρ)
theorem eval_0 (ρ : Env) : (Expr.eval ρ n0) = (v0 ρ) := rfl
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v0 ρ) (v4 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_0 ρ) (eval_4 ρ)) (Numeric.sound ρ n0 n4 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n0) (Expr.eval ρ n4) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_0 ρ) (eval_4 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n0) : (Expr.eval ρ n0) = (Expr.eval ρ n4) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_0 (ρ : Env) : Value.Defined (v0 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v0 ρ) := (total_0 ρ)
def d0 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n0 ↔ (d0 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_0 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n0 := Eq.mpr (congrArg Value.Defined (eval_0 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t1 γ).eval ξ ρ) (FunctionScalar.n4.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n4.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t1 γ).eval ξ ρ)) : ((BindingCertificate.t1 γ).eval ξ ρ) = (FunctionScalar.n4.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
