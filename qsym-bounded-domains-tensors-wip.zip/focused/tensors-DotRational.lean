import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .rational := (.rat ((2) / (1) : ℚ))
def n15 : Expr .bool := (.bool true)
def n17 : Expr .bool := (.nonzeroQ n2)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v2 ρ)
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_17 (ρ : Env) : (Expr.eval ρ n17) = (v17 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v17 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_17 ρ) (eval_15 ρ)) (Numeric.sound ρ n17 n15 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n17) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_17 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n17) : (Expr.eval ρ n17) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d17 (ρ : Env) : Prop := ∃ x, (v2 ρ) = some x ∧ Functions.nonzeroQ.domain x
theorem domain_17 (ρ : Env) : Value.Defined (v17 ρ) ↔ d17 ρ :=
  Functions.nonzeroQ.defined (v2 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n17 ↔ (d17 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_17 ρ))).trans (domain_17 ρ)
#qsym_check_axioms definedness
theorem total_2 (ρ : Env) : Value.Defined (v2 ρ) :=
  ⟨_, rfl⟩
theorem total_17 (ρ : Env) : Value.Defined (v17 ρ) :=
  Functions.nonzeroQ.total (fun _ => True.intro) (v2 ρ) (total_2 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n17 := Eq.mpr (congrArg Value.Defined (eval_17 ρ)) (total_17 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar0.Certificate

namespace QSym.BindingScalar0.DomainCertificate
def n1 : Expr .rational := (.rat ((1) / (1) : ℚ))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
def n2 : Expr .rational := (.rat ((2) / (1) : ℚ))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
def n3 : Expr .rational := (.invQ n2)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v2 ρ)
def n4 : Expr .rational := (.mulQ n1 n3)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v1 ρ) (v3 ρ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n17 : Expr .bool := (.nonzeroQ n2)
noncomputable def v17 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v2 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q3 (ρ : Env) : Domain.Correct (v3 ρ) (v17 ρ) :=
  Domain.partial1 Functions.invQ (x := (v2 ρ)) (d := (v15 ρ)) (p := (v17 ρ)) (Domain.test_invQ (v2 ρ)) (q2 ρ)
theorem q4 (ρ : Env) : Domain.Correct (v4 ρ) (v17 ρ) :=
  Domain.total2 Functions.mulQ (x := (v1 ρ)) (y := (v3 ρ)) (dx := (v15 ρ)) (dy := (v17 ρ)) (fun _ _ => True.intro) (q1 ρ) (q3 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n4) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q4 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n4 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar0.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar0.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n2 : Expr .rational := (.rat ((2) / (1) : ℚ))
def n3 : Expr .rational := (.invQ n2)
def n4 : Expr .rational := (.mulQ n1 n3)
def n14 : Expr .rational := (.rat ((1) / (2) : ℚ))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v2 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
noncomputable def v3 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v2 ρ)
noncomputable def v4 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v1 ρ) (v3 ρ)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (2) : ℚ)
theorem eval_3 (ρ : Env) : (Expr.eval ρ n3) = (v3 ρ) := rfl
theorem eval_4 (ρ : Env) : (Expr.eval ρ n4) = (v4 ρ) := rfl
theorem eval_14 (ρ : Env) : (Expr.eval ρ n14) = (v14 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v4 ρ) (v3 ρ) :=
  (Generated.r_rational_one_mul (v3 ρ))

theorem p1 (ρ : Env) : Value.Refines (v3 ρ) (v14 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_3 ρ) (eval_14 ρ)) (Numeric.sound ρ n3 n14 rfl)

theorem p2 (ρ : Env) : Value.Refines (v4 ρ) (v14 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n4) (Expr.eval ρ n14) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_4 ρ) (eval_14 ρ)) (p2 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n4) : (Expr.eval ρ n4) = (Expr.eval ρ n14) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d3 (ρ : Env) : Prop := ∃ x, (v2 ρ) = some x ∧ Functions.invQ.domain x
theorem domain_3 (ρ : Env) : Value.Defined (v3 ρ) ↔ d3 ρ :=
  Functions.invQ.defined (v2 ρ)

def d4 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v3 ρ) = some y ∧ Functions.mulQ.domain x y
theorem domain_4 (ρ : Env) : Value.Defined (v4 ρ) ↔ d4 ρ :=
  Functions.mulQ.defined (v1 ρ) (v3 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n4 ↔ (d4 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_4 ρ))).trans (domain_4 ρ)
#qsym_check_axioms definedness
end QSym.BindingScalar0.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
def n15 : Expr .bool := (.bool true)
def n23 : Expr .bool := (.nonzeroQ n5)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v23 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v5 ρ)
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v23 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_23 ρ) (eval_15 ρ)) (Numeric.sound ρ n23 n15 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n23) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_23 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n23) : (Expr.eval ρ n23) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d23 (ρ : Env) : Prop := ∃ x, (v5 ρ) = some x ∧ Functions.nonzeroQ.domain x
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  Functions.nonzeroQ.defined (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n23 ↔ (d23 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_23 ρ))).trans (domain_23 ρ)
#qsym_check_axioms definedness
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  Functions.nonzeroQ.total (fun _ => True.intro) (v5 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n23 := Eq.mpr (congrArg Value.Defined (eval_23 ρ)) (total_23 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar1.Certificate

namespace QSym.BindingScalar1.DomainCertificate
def n1 : Expr .rational := (.rat ((1) / (1) : ℚ))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
def n6 : Expr .rational := (.invQ n5)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v5 ρ)
def n7 : Expr .rational := (.mulQ n1 n6)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v1 ρ) (v6 ρ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .bool := (.nonzeroQ n5)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v5 ρ)
theorem q1 (ρ : Env) : Domain.Correct (v1 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v23 ρ) :=
  Domain.partial1 Functions.invQ (x := (v5 ρ)) (d := (v15 ρ)) (p := (v23 ρ)) (Domain.test_invQ (v5 ρ)) (q5 ρ)
theorem q7 (ρ : Env) : Domain.Correct (v7 ρ) (v23 ρ) :=
  Domain.total2 Functions.mulQ (x := (v1 ρ)) (y := (v6 ρ)) (dx := (v15 ρ)) (dy := (v23 ρ)) (fun _ _ => True.intro) (q1 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n7) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q7 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n7 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar1.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar1.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
def n6 : Expr .rational := (.invQ n5)
def n7 : Expr .rational := (.mulQ n1 n6)
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
noncomputable def v1 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (1) : ℚ)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v5 ρ)
noncomputable def v7 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v1 ρ) (v6 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (3) : ℚ)
theorem eval_6 (ρ : Env) : (Expr.eval ρ n6) = (v6 ρ) := rfl
theorem eval_7 (ρ : Env) : (Expr.eval ρ n7) = (v7 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v7 ρ) (v6 ρ) :=
  (Generated.r_rational_one_mul (v6 ρ))

theorem p1 (ρ : Env) : Value.Refines (v6 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_6 ρ) (eval_22 ρ)) (Numeric.sound ρ n6 n22 rfl)

theorem p2 (ρ : Env) : Value.Refines (v7 ρ) (v22 ρ) :=
  (p0 ρ).trans (p1 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n7) (Expr.eval ρ n22) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_7 ρ) (eval_22 ρ)) (p2 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n7) : (Expr.eval ρ n7) = (Expr.eval ρ n22) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d1 (ρ : Env) : Prop := True
theorem domain_1 (ρ : Env) : Value.Defined (v1 ρ) ↔ d1 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := ∃ x, (v5 ρ) = some x ∧ Functions.invQ.domain x
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  Functions.invQ.defined (v5 ρ)

def d7 (ρ : Env) : Prop := ∃ x y, (v1 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.mulQ.domain x y
theorem domain_7 (ρ : Env) : Value.Defined (v7 ρ) ↔ d7 ρ :=
  Functions.mulQ.defined (v1 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n7 ↔ (d7 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_7 ρ))).trans (domain_7 ρ)
#qsym_check_axioms definedness
end QSym.BindingScalar1.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
def n15 : Expr .bool := (.bool true)
def n23 : Expr .bool := (.nonzeroQ n5)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v23 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v5 ρ)
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_23 (ρ : Env) : (Expr.eval ρ n23) = (v23 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v23 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_23 ρ) (eval_15 ρ)) (Numeric.sound ρ n23 n15 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n23) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_23 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n23) : (Expr.eval ρ n23) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d23 (ρ : Env) : Prop := ∃ x, (v5 ρ) = some x ∧ Functions.nonzeroQ.domain x
theorem domain_23 (ρ : Env) : Value.Defined (v23 ρ) ↔ d23 ρ :=
  Functions.nonzeroQ.defined (v5 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n23 ↔ (d23 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_23 ρ))).trans (domain_23 ρ)
#qsym_check_axioms definedness
theorem total_5 (ρ : Env) : Value.Defined (v5 ρ) :=
  ⟨_, rfl⟩
theorem total_23 (ρ : Env) : Value.Defined (v23 ρ) :=
  Functions.nonzeroQ.total (fun _ => True.intro) (v5 ρ) (total_5 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n23 := Eq.mpr (congrArg Value.Defined (eval_23 ρ)) (total_23 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar2.Certificate

namespace QSym.BindingScalar2.DomainCertificate
def n2 : Expr .rational := (.rat ((2) / (1) : ℚ))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
def n6 : Expr .rational := (.invQ n5)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v5 ρ)
def n9 : Expr .rational := (.mulQ n2 n6)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v2 ρ) (v6 ρ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n23 : Expr .bool := (.nonzeroQ n5)
noncomputable def v23 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v5 ρ)
theorem q2 (ρ : Env) : Domain.Correct (v2 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q6 (ρ : Env) : Domain.Correct (v6 ρ) (v23 ρ) :=
  Domain.partial1 Functions.invQ (x := (v5 ρ)) (d := (v15 ρ)) (p := (v23 ρ)) (Domain.test_invQ (v5 ρ)) (q5 ρ)
theorem q9 (ρ : Env) : Domain.Correct (v9 ρ) (v23 ρ) :=
  Domain.total2 Functions.mulQ (x := (v2 ρ)) (y := (v6 ρ)) (dx := (v15 ρ)) (dy := (v23 ρ)) (fun _ _ => True.intro) (q2 ρ) (q6 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n9) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q9 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n9 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar2.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar2.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n2 : Expr .rational := (.rat ((2) / (1) : ℚ))
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
def n6 : Expr .rational := (.invQ n5)
def n9 : Expr .rational := (.mulQ n2 n6)
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
def n26 : Expr .rational := (.mulQ n2 n22)
def n27 : Expr .rational := (.rat ((2) / (3) : ℚ))
noncomputable def v2 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (1) : ℚ)
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
noncomputable def v6 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v5 ρ)
noncomputable def v9 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v2 ρ) (v6 ρ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (3) : ℚ)
noncomputable def v26 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v2 ρ) (v22 ρ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (3) : ℚ)
theorem eval_6 (ρ : Env) : (Expr.eval ρ n6) = (v6 ρ) := rfl
theorem eval_9 (ρ : Env) : (Expr.eval ρ n9) = (v9 ρ) := rfl
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_26 (ρ : Env) : (Expr.eval ρ n26) = (v26 ρ) := rfl
theorem eval_27 (ρ : Env) : (Expr.eval ρ n27) = (v27 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v6 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_6 ρ) (eval_22 ρ)) (Numeric.sound ρ n6 n22 rfl)

theorem p1 (ρ : Env) : Value.Refines (v9 ρ) (v26 ρ) :=
  Value.refines_function2 Functions.mulQ (Value.refines_refl (v2 ρ)) (p0 ρ)

theorem p2 (ρ : Env) : Value.Refines (v26 ρ) (v27 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_26 ρ) (eval_27 ρ)) (Numeric.sound ρ n26 n27 rfl)

theorem p3 (ρ : Env) : Value.Refines (v9 ρ) (v27 ρ) :=
  (p1 ρ).trans (p2 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n9) (Expr.eval ρ n27) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_9 ρ) (eval_27 ρ)) (p3 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n9) : (Expr.eval ρ n9) = (Expr.eval ρ n27) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d2 (ρ : Env) : Prop := True
theorem domain_2 (ρ : Env) : Value.Defined (v2 ρ) ↔ d2 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d6 (ρ : Env) : Prop := ∃ x, (v5 ρ) = some x ∧ Functions.invQ.domain x
theorem domain_6 (ρ : Env) : Value.Defined (v6 ρ) ↔ d6 ρ :=
  Functions.invQ.defined (v5 ρ)

def d9 (ρ : Env) : Prop := ∃ x y, (v2 ρ) = some x ∧ (v6 ρ) = some y ∧ Functions.mulQ.domain x y
theorem domain_9 (ρ : Env) : Value.Defined (v9 ρ) ↔ d9 ρ :=
  Functions.mulQ.defined (v2 ρ) (v6 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n9 ↔ (d9 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_9 ρ))).trans (domain_9 ρ)
#qsym_check_axioms definedness
end QSym.BindingScalar2.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n11 : Expr .rational := (.rat ((4) / (1) : ℚ))
def n15 : Expr .bool := (.bool true)
def n31 : Expr .bool := (.nonzeroQ n11)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .rational) := some ((4) / (1) : ℚ)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
noncomputable def v31 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v11 ρ)
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl
theorem eval_31 (ρ : Env) : (Expr.eval ρ n31) = (v31 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v31 ρ) (v15 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_31 ρ) (eval_15 ρ)) (Numeric.sound ρ n31 n15 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n31) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_31 ρ) (eval_15 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n31) : (Expr.eval ρ n31) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d11 (ρ : Env) : Prop := True
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d31 (ρ : Env) : Prop := ∃ x, (v11 ρ) = some x ∧ Functions.nonzeroQ.domain x
theorem domain_31 (ρ : Env) : Value.Defined (v31 ρ) ↔ d31 ρ :=
  Functions.nonzeroQ.defined (v11 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n31 ↔ (d31 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_31 ρ))).trans (domain_31 ρ)
#qsym_check_axioms definedness
theorem total_11 (ρ : Env) : Value.Defined (v11 ρ) :=
  ⟨_, rfl⟩
theorem total_31 (ρ : Env) : Value.Defined (v31 ρ) :=
  Functions.nonzeroQ.total (fun _ => True.intro) (v11 ρ) (total_11 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n31 := Eq.mpr (congrArg Value.Defined (eval_31 ρ)) (total_31 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar3.Certificate

namespace QSym.BindingScalar3.DomainCertificate
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
def n11 : Expr .rational := (.rat ((4) / (1) : ℚ))
noncomputable def v11 (ρ : Env) : Option (Ty.denote .rational) := some ((4) / (1) : ℚ)
def n12 : Expr .rational := (.invQ n11)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v11 ρ)
def n13 : Expr .rational := (.mulQ n5 n12)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v5 ρ) (v12 ρ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n31 : Expr .bool := (.nonzeroQ n11)
noncomputable def v31 (ρ : Env) : Option (Ty.denote .bool) := Functions.nonzeroQ.apply (v11 ρ)
theorem q5 (ρ : Env) : Domain.Correct (v5 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q11 (ρ : Env) : Domain.Correct (v11 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q12 (ρ : Env) : Domain.Correct (v12 ρ) (v31 ρ) :=
  Domain.partial1 Functions.invQ (x := (v11 ρ)) (d := (v15 ρ)) (p := (v31 ρ)) (Domain.test_invQ (v11 ρ)) (q11 ρ)
theorem q13 (ρ : Env) : Domain.Correct (v13 ρ) (v31 ρ) :=
  Domain.total2 Functions.mulQ (x := (v5 ρ)) (y := (v12 ρ)) (dx := (v15 ρ)) (dy := (v31 ρ)) (fun _ _ => True.intro) (q5 ρ) (q12 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n13) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q13 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n13 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar3.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar3.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
def n11 : Expr .rational := (.rat ((4) / (1) : ℚ))
def n12 : Expr .rational := (.invQ n11)
def n13 : Expr .rational := (.mulQ n5 n12)
def n28 : Expr .rational := (.rat ((1) / (4) : ℚ))
def n29 : Expr .rational := (.mulQ n5 n28)
def n30 : Expr .rational := (.rat ((3) / (4) : ℚ))
noncomputable def v5 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (1) : ℚ)
noncomputable def v11 (ρ : Env) : Option (Ty.denote .rational) := some ((4) / (1) : ℚ)
noncomputable def v12 (ρ : Env) : Option (Ty.denote .rational) := Functions.invQ.apply (v11 ρ)
noncomputable def v13 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v5 ρ) (v12 ρ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (4) : ℚ)
noncomputable def v29 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v5 ρ) (v28 ρ)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (4) : ℚ)
theorem eval_12 (ρ : Env) : (Expr.eval ρ n12) = (v12 ρ) := rfl
theorem eval_13 (ρ : Env) : (Expr.eval ρ n13) = (v13 ρ) := rfl
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_29 (ρ : Env) : (Expr.eval ρ n29) = (v29 ρ) := rfl
theorem eval_30 (ρ : Env) : (Expr.eval ρ n30) = (v30 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v12 ρ) (v28 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_12 ρ) (eval_28 ρ)) (Numeric.sound ρ n12 n28 rfl)

theorem p1 (ρ : Env) : Value.Refines (v13 ρ) (v29 ρ) :=
  Value.refines_function2 Functions.mulQ (Value.refines_refl (v5 ρ)) (p0 ρ)

theorem p2 (ρ : Env) : Value.Refines (v29 ρ) (v30 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_29 ρ) (eval_30 ρ)) (Numeric.sound ρ n29 n30 rfl)

theorem p3 (ρ : Env) : Value.Refines (v13 ρ) (v30 ρ) :=
  (p1 ρ).trans (p2 ρ)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n13) (Expr.eval ρ n30) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_13 ρ) (eval_30 ρ)) (p3 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n13) : (Expr.eval ρ n13) = (Expr.eval ρ n30) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d5 (ρ : Env) : Prop := True
theorem domain_5 (ρ : Env) : Value.Defined (v5 ρ) ↔ d5 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d11 (ρ : Env) : Prop := True
theorem domain_11 (ρ : Env) : Value.Defined (v11 ρ) ↔ d11 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d12 (ρ : Env) : Prop := ∃ x, (v11 ρ) = some x ∧ Functions.invQ.domain x
theorem domain_12 (ρ : Env) : Value.Defined (v12 ρ) ↔ d12 ρ :=
  Functions.invQ.defined (v11 ρ)

def d13 (ρ : Env) : Prop := ∃ x y, (v5 ρ) = some x ∧ (v12 ρ) = some y ∧ Functions.mulQ.domain x y
theorem domain_13 (ρ : Env) : Value.Defined (v13 ρ) ↔ d13 ρ :=
  Functions.mulQ.defined (v5 ρ) (v12 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n13 ↔ (d13 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_13 ρ))).trans (domain_13 ρ)
#qsym_check_axioms definedness
end QSym.BindingScalar3.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.Certificate

namespace QSym.BindingScalar4.DomainCertificate
def n14 : Expr .rational := (.rat ((1) / (2) : ℚ))
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (2) : ℚ)
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n27 : Expr .rational := (.rat ((2) / (3) : ℚ))
noncomputable def v27 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (3) : ℚ)
def n39 : Expr .rational := (.mulQ n14 n27)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v14 ρ) (v27 ρ)
theorem q14 (ρ : Env) : Domain.Correct (v14 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q27 (ρ : Env) : Domain.Correct (v27 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q39 (ρ : Env) : Domain.Correct (v39 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulQ (x := (v14 ρ)) (y := (v27 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q14 ρ) (q27 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n39) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q39 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n39 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar4.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar4.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n14 : Expr .rational := (.rat ((1) / (2) : ℚ))
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
def n27 : Expr .rational := (.rat ((2) / (3) : ℚ))
def n39 : Expr .rational := (.mulQ n14 n27)
noncomputable def v14 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (2) : ℚ)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (3) : ℚ)
noncomputable def v27 (ρ : Env) : Option (Ty.denote .rational) := some ((2) / (3) : ℚ)
noncomputable def v39 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v14 ρ) (v27 ρ)
theorem eval_22 (ρ : Env) : (Expr.eval ρ n22) = (v22 ρ) := rfl
theorem eval_39 (ρ : Env) : (Expr.eval ρ n39) = (v39 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v39 ρ) (v22 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_39 ρ) (eval_22 ρ)) (Numeric.sound ρ n39 n22 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n39) (Expr.eval ρ n22) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_39 ρ) (eval_22 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n39) : (Expr.eval ρ n39) = (Expr.eval ρ n22) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d14 (ρ : Env) : Prop := True
theorem domain_14 (ρ : Env) : Value.Defined (v14 ρ) ↔ d14 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d27 (ρ : Env) : Prop := True
theorem domain_27 (ρ : Env) : Value.Defined (v27 ρ) ↔ d27 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d39 (ρ : Env) : Prop := ∃ x y, (v14 ρ) = some x ∧ (v27 ρ) = some y ∧ Functions.mulQ.domain x y
theorem domain_39 (ρ : Env) : Value.Defined (v39 ρ) ↔ d39 ρ :=
  Functions.mulQ.defined (v14 ρ) (v27 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n39 ↔ (d39 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_39 ρ))).trans (domain_39 ρ)
#qsym_check_axioms definedness
theorem total_14 (ρ : Env) : Value.Defined (v14 ρ) :=
  ⟨_, rfl⟩
theorem total_27 (ρ : Env) : Value.Defined (v27 ρ) :=
  ⟨_, rfl⟩
theorem total_39 (ρ : Env) : Value.Defined (v39 ρ) :=
  Functions.mulQ.total (fun _ _ => True.intro) (v14 ρ) (v27 ρ) (total_14 ρ) (total_27 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n39 := Eq.mpr (congrArg Value.Defined (eval_39 ρ)) (total_39 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar4.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.Certificate

namespace QSym.BindingScalar5.DomainCertificate
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (3) : ℚ)
def n30 : Expr .rational := (.rat ((3) / (4) : ℚ))
noncomputable def v30 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (4) : ℚ)
def n40 : Expr .rational := (.mulQ n22 n30)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v22 ρ) (v30 ρ)
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q30 (ρ : Env) : Domain.Correct (v30 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q40 (ρ : Env) : Domain.Correct (v40 ρ) (v15 ρ) :=
  Domain.total2 Functions.mulQ (x := (v22 ρ)) (y := (v30 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q22 ρ) (q30 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n40) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q40 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n40 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar5.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar5.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
def n28 : Expr .rational := (.rat ((1) / (4) : ℚ))
def n30 : Expr .rational := (.rat ((3) / (4) : ℚ))
def n40 : Expr .rational := (.mulQ n22 n30)
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (3) : ℚ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (4) : ℚ)
noncomputable def v30 (ρ : Env) : Option (Ty.denote .rational) := some ((3) / (4) : ℚ)
noncomputable def v40 (ρ : Env) : Option (Ty.denote .rational) := Functions.mulQ.apply (v22 ρ) (v30 ρ)
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_40 (ρ : Env) : (Expr.eval ρ n40) = (v40 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v40 ρ) (v28 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_40 ρ) (eval_28 ρ)) (Numeric.sound ρ n40 n28 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n40) (Expr.eval ρ n28) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_40 ρ) (eval_28 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n40) : (Expr.eval ρ n40) = (Expr.eval ρ n28) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d22 (ρ : Env) : Prop := True
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d30 (ρ : Env) : Prop := True
theorem domain_30 (ρ : Env) : Value.Defined (v30 ρ) ↔ d30 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d40 (ρ : Env) : Prop := ∃ x y, (v22 ρ) = some x ∧ (v30 ρ) = some y ∧ Functions.mulQ.domain x y
theorem domain_40 (ρ : Env) : Value.Defined (v40 ρ) ↔ d40 ρ :=
  Functions.mulQ.defined (v22 ρ) (v30 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n40 ↔ (d40 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_40 ρ))).trans (domain_40 ρ)
#qsym_check_axioms definedness
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  ⟨_, rfl⟩
theorem total_30 (ρ : Env) : Value.Defined (v30 ρ) :=
  ⟨_, rfl⟩
theorem total_40 (ρ : Env) : Value.Defined (v40 ρ) :=
  Functions.mulQ.total (fun _ _ => True.intro) (v22 ρ) (v30 ρ) (total_22 ρ) (total_30 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n40 := Eq.mpr (congrArg Value.Defined (eval_40 ρ)) (total_40 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar5.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.Certificate

namespace QSym.BindingScalar6.DomainCertificate
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n16 : Expr .rational := (.rat ((0) / (1) : ℚ))
noncomputable def v16 (ρ : Env) : Option (Ty.denote .rational) := some ((0) / (1) : ℚ)
def n28 : Expr .rational := (.rat ((1) / (4) : ℚ))
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (4) : ℚ)
def n41 : Expr .rational := (.addQ n28 n16)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .rational) := Functions.addQ.apply (v28 ρ) (v16 ρ)
theorem q28 (ρ : Env) : Domain.Correct (v28 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q16 (ρ : Env) : Domain.Correct (v16 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q41 (ρ : Env) : Domain.Correct (v41 ρ) (v15 ρ) :=
  Domain.total2 Functions.addQ (x := (v28 ρ)) (y := (v16 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q28 ρ) (q16 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n41) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q41 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n41 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar6.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar6.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n16 : Expr .rational := (.rat ((0) / (1) : ℚ))
def n28 : Expr .rational := (.rat ((1) / (4) : ℚ))
def n41 : Expr .rational := (.addQ n28 n16)
noncomputable def v16 (ρ : Env) : Option (Ty.denote .rational) := some ((0) / (1) : ℚ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (4) : ℚ)
noncomputable def v41 (ρ : Env) : Option (Ty.denote .rational) := Functions.addQ.apply (v28 ρ) (v16 ρ)
theorem eval_28 (ρ : Env) : (Expr.eval ρ n28) = (v28 ρ) := rfl
theorem eval_41 (ρ : Env) : (Expr.eval ρ n41) = (v41 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v41 ρ) (v28 ρ) :=
  (Generated.r_rational_add_zero (v28 ρ))

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n41) (Expr.eval ρ n28) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_41 ρ) (eval_28 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n41) : (Expr.eval ρ n41) = (Expr.eval ρ n28) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d28 (ρ : Env) : Prop := True
theorem domain_28 (ρ : Env) : Value.Defined (v28 ρ) ↔ d28 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d16 (ρ : Env) : Prop := True
theorem domain_16 (ρ : Env) : Value.Defined (v16 ρ) ↔ d16 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d41 (ρ : Env) : Prop := ∃ x y, (v28 ρ) = some x ∧ (v16 ρ) = some y ∧ Functions.addQ.domain x y
theorem domain_41 (ρ : Env) : Value.Defined (v41 ρ) ↔ d41 ρ :=
  Functions.addQ.defined (v28 ρ) (v16 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n41 ↔ (d41 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_41 ρ))).trans (domain_41 ρ)
#qsym_check_axioms definedness
theorem total_28 (ρ : Env) : Value.Defined (v28 ρ) :=
  ⟨_, rfl⟩
theorem total_16 (ρ : Env) : Value.Defined (v16 ρ) :=
  ⟨_, rfl⟩
theorem total_41 (ρ : Env) : Value.Defined (v41 ρ) :=
  Functions.addQ.total (fun _ _ => True.intro) (v28 ρ) (v16 ρ) (total_28 ρ) (total_16 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n41 := Eq.mpr (congrArg Value.Defined (eval_41 ρ)) (total_41 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar6.ValueCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.Certificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
theorem eval_15 (ρ : Env) : (Expr.eval ρ n15) = (v15 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n15) (Expr.eval ρ n15) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_15 ρ) (eval_15 ρ)) (Value.refines_refl (v15 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n15) : (Expr.eval ρ n15) = (Expr.eval ρ n15) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_15 (ρ : Env) : Value.Defined (v15 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v15 ρ) := (total_15 ρ)
def d15 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n15 ↔ (d15 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_15 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n15 := Eq.mpr (congrArg Value.Defined (eval_15 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.Certificate

namespace QSym.BindingScalar7.DomainCertificate
def n15 : Expr .bool := (.bool true)
noncomputable def v15 (ρ : Env) : Option (Ty.denote .bool) := some true
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (3) : ℚ)
def n28 : Expr .rational := (.rat ((1) / (4) : ℚ))
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (4) : ℚ)
def n42 : Expr .rational := (.addQ n22 n28)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .rational) := Functions.addQ.apply (v22 ρ) (v28 ρ)
theorem q22 (ρ : Env) : Domain.Correct (v22 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q28 (ρ : Env) : Domain.Correct (v28 ρ) (v15 ρ) :=
  Domain.leaf _
theorem q42 (ρ : Env) : Domain.Correct (v42 ρ) (v15 ρ) :=
  Domain.total2 Functions.addQ (x := (v22 ρ)) (y := (v28 ρ)) (dx := (v15 ρ)) (dy := (v15 ρ)) (fun _ _ => True.intro) (q22 ρ) (q28 ρ)
theorem domain_correct (ρ : Env) : Domain.Correct (Expr.eval ρ n42) (Expr.eval ρ Certificate.n15) :=
  Domain.simplify (q42 ρ) (Certificate.refinement ρ)
#qsym_check_axioms domain_correct
theorem domain_total (ρ : Env) : Value.Defined (Expr.eval ρ Certificate.n15) :=
  (domain_correct ρ).total
#qsym_check_axioms domain_total
theorem domain_iff (ρ : Env) : Expr.Defined ρ n42 ↔ (Expr.eval ρ Certificate.n15) = some true :=
  (domain_correct ρ).iff
#qsym_check_axioms domain_iff
end QSym.BindingScalar7.DomainCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.BindingScalar7.ValueCertificate
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
def n28 : Expr .rational := (.rat ((1) / (4) : ℚ))
def n42 : Expr .rational := (.addQ n22 n28)
def n43 : Expr .rational := (.rat ((7) / (12) : ℚ))
noncomputable def v22 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (3) : ℚ)
noncomputable def v28 (ρ : Env) : Option (Ty.denote .rational) := some ((1) / (4) : ℚ)
noncomputable def v42 (ρ : Env) : Option (Ty.denote .rational) := Functions.addQ.apply (v22 ρ) (v28 ρ)
noncomputable def v43 (ρ : Env) : Option (Ty.denote .rational) := some ((7) / (12) : ℚ)
theorem eval_42 (ρ : Env) : (Expr.eval ρ n42) = (v42 ρ) := rfl
theorem eval_43 (ρ : Env) : (Expr.eval ρ n43) = (v43 ρ) := rfl

theorem p0 (ρ : Env) : Value.Refines (v42 ρ) (v43 ρ) :=
  Eq.mp (congrArg₂ Value.Refines (eval_42 ρ) (eval_43 ρ)) (Numeric.sound ρ n42 n43 rfl)

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n42) (Expr.eval ρ n43) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_42 ρ) (eval_43 ρ)) (p0 ρ)
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n42) : (Expr.eval ρ n42) = (Expr.eval ρ n43) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

def d22 (ρ : Env) : Prop := True
theorem domain_22 (ρ : Env) : Value.Defined (v22 ρ) ↔ d22 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d28 (ρ : Env) : Prop := True
theorem domain_28 (ρ : Env) : Value.Defined (v28 ρ) ↔ d28 ρ :=
  iff_true_intro ⟨_, rfl⟩

def d42 (ρ : Env) : Prop := ∃ x y, (v22 ρ) = some x ∧ (v28 ρ) = some y ∧ Functions.addQ.domain x y
theorem domain_42 (ρ : Env) : Value.Defined (v42 ρ) ↔ d42 ρ :=
  Functions.addQ.defined (v22 ρ) (v28 ρ)

theorem definedness (ρ : Env) : Expr.Defined ρ n42 ↔ (d42 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_42 ρ))).trans (domain_42 ρ)
#qsym_check_axioms definedness
theorem total_22 (ρ : Env) : Value.Defined (v22 ρ) :=
  ⟨_, rfl⟩
theorem total_28 (ρ : Env) : Value.Defined (v28 ρ) :=
  ⟨_, rfl⟩
theorem total_42 (ρ : Env) : Value.Defined (v42 ρ) :=
  Functions.addQ.total (fun _ _ => True.intro) (v22 ρ) (v28 ρ) (total_22 ρ) (total_28 ρ)
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n42 := Eq.mpr (congrArg Value.Defined (eval_42 ρ)) (total_42 ρ)
#qsym_check_axioms everywhere_defined
end QSym.BindingScalar7.ValueCertificate
namespace QSym.BindingCertificate
def n1 : Expr .rational := (.rat ((1) / (1) : ℚ))
def n2 : Expr .rational := (.rat ((2) / (1) : ℚ))
def n3 : Expr .rational := (.invQ n2)
def n4 : Expr .rational := (.mulQ n1 n3)
def n5 : Expr .rational := (.rat ((3) / (1) : ℚ))
def n6 : Expr .rational := (.invQ n5)
def n7 : Expr .rational := (.mulQ n1 n6)
def n9 : Expr .rational := (.mulQ n2 n6)
def n11 : Expr .rational := (.rat ((4) / (1) : ℚ))
def n12 : Expr .rational := (.invQ n11)
def n13 : Expr .rational := (.mulQ n5 n12)
def n14 : Expr .rational := (.rat ((1) / (2) : ℚ))
def n15 : Expr .bool := (.bool true)
def n16 : Expr .rational := (.rat ((0) / (1) : ℚ))
def n22 : Expr .rational := (.rat ((1) / (3) : ℚ))
def n27 : Expr .rational := (.rat ((2) / (3) : ℚ))
def n28 : Expr .rational := (.rat ((1) / (4) : ℚ))
def n30 : Expr .rational := (.rat ((3) / (4) : ℚ))
def n39 : Expr .rational := (.mulQ n14 n27)
def n40 : Expr .rational := (.mulQ n22 n30)
def n41 : Expr .rational := (.addQ n28 n16)
def n42 : Expr .rational := (.addQ n22 n28)
def n43 : Expr .rational := (.rat ((7) / (12) : ℚ))
abbrev c0 : List Binding.Ty := []
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n4
noncomputable def t7 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n7
noncomputable def t8 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 0) := .constant Tensor.nilValue
noncomputable def t9 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 1) := .binary Tensor.consValue (t7 γ) (t8 γ)
noncomputable def t10 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 2) := .binary Tensor.consValue (t4 γ) (t9 γ)
noncomputable def t12 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n9
noncomputable def t16 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n13
noncomputable def t17 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 1) := .binary Tensor.consValue (t16 γ) (t8 γ)
noncomputable def t18 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 2) := .binary Tensor.consValue (t12 γ) (t17 γ)
noncomputable def t19 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary (Tensor.dotValue Functions.addQ.apply Functions.mulQ.apply id (0 / 1 : ℚ) 2) (t10 γ) (t18 γ)
noncomputable def t20 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .bool) := .scalar n15
noncomputable def t21 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n14
noncomputable def t22 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Binding.guardValue (t20 γ) (t21 γ)
noncomputable def t23 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n22
noncomputable def t24 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Binding.guardValue (t20 γ) (t23 γ)
noncomputable def t25 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 1) := .binary Tensor.consValue (t23 γ) (t8 γ)
noncomputable def t26 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 2) := .binary Tensor.consValue (t21 γ) (t25 γ)
noncomputable def t27 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n27
noncomputable def t28 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Binding.guardValue (t20 γ) (t27 γ)
noncomputable def t29 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n30
noncomputable def t30 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Binding.guardValue (t20 γ) (t29 γ)
noncomputable def t31 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 1) := .binary Tensor.consValue (t29 γ) (t8 γ)
noncomputable def t32 (γ : Binding.Globals) : Binding.Expr c0 (.vector (.scalar .rational) 2) := .binary Tensor.consValue (t27 γ) (t31 γ)
noncomputable def t33 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary (Tensor.dotValue Functions.addQ.apply Functions.mulQ.apply id (0 / 1 : ℚ) 2) (t26 γ) (t32 γ)
noncomputable def t34 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n16
noncomputable def t35 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Functions.mulQ.apply (t23 γ) (t29 γ)
noncomputable def t36 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Functions.addQ.apply (t35 γ) (t34 γ)
noncomputable def t37 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Functions.mulQ.apply (t21 γ) (t27 γ)
noncomputable def t38 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Functions.addQ.apply (t37 γ) (t36 γ)
noncomputable def t39 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n39
noncomputable def t40 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n40
noncomputable def t41 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n28
noncomputable def t42 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Binding.guardValue (t20 γ) (t41 γ)
noncomputable def t43 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Functions.addQ.apply (t41 γ) (t34 γ)
noncomputable def t44 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n41
noncomputable def t45 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Functions.addQ.apply (t23 γ) (t41 γ)
noncomputable def t46 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n42
noncomputable def t47 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .scalar n43
noncomputable def t48 (γ : Binding.Globals) : Binding.Expr c0 (.scalar .rational) := .binary Binding.guardValue (t20 γ) (t47 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .refl (t4 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t22 γ) := .scalarSimplify n4 n15 n14 QSym.BindingScalar0.DomainCertificate.domain_correct QSym.BindingScalar0.ValueCertificate.refinement
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t20 γ) (t20 γ) := .refl (t20 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t21 γ) (t21 γ) := .refl (t21 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t22 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .rational)) (c := (.scalar .rational)) Binding.guardValue (p2 γ) (p3 γ)
theorem p5 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .guardTrue (t21 γ)
theorem p6 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .trans (p5 γ) (p3 γ)
theorem p7 (γ : Binding.Globals) : Binding.Reduction (t22 γ) (t21 γ) := .trans (p4 γ) (p6 γ)
theorem p8 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t21 γ) := .trans (p1 γ) (p7 γ)
theorem p9 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t21 γ) := .trans (p0 γ) (p8 γ)
theorem p10 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t7 γ) := .refl (t7 γ)
theorem p11 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t24 γ) := .scalarSimplify n7 n15 n22 QSym.BindingScalar1.DomainCertificate.domain_correct QSym.BindingScalar1.ValueCertificate.refinement
theorem p12 (γ : Binding.Globals) : Binding.Reduction (t23 γ) (t23 γ) := .refl (t23 γ)
theorem p13 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t24 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .rational)) (c := (.scalar .rational)) Binding.guardValue (p2 γ) (p12 γ)
theorem p14 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t23 γ) := .guardTrue (t23 γ)
theorem p15 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t23 γ) := .trans (p14 γ) (p12 γ)
theorem p16 (γ : Binding.Globals) : Binding.Reduction (t24 γ) (t23 γ) := .trans (p13 γ) (p15 γ)
theorem p17 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t23 γ) := .trans (p11 γ) (p16 γ)
theorem p18 (γ : Binding.Globals) : Binding.Reduction (t7 γ) (t23 γ) := .trans (p10 γ) (p17 γ)
theorem p19 (γ : Binding.Globals) : Binding.Reduction (t8 γ) (t8 γ) := .refl (t8 γ)
theorem p20 (γ : Binding.Globals) : Binding.Reduction (t9 γ) (t25 γ) := .binary (a := (.scalar .rational)) (b := (.vector (.scalar .rational) 0)) (c := (.vector (.scalar .rational) 1)) Tensor.consValue (p18 γ) (p19 γ)
theorem p21 (γ : Binding.Globals) : Binding.Reduction (t10 γ) (t26 γ) := .binary (a := (.scalar .rational)) (b := (.vector (.scalar .rational) 1)) (c := (.vector (.scalar .rational) 2)) Tensor.consValue (p9 γ) (p20 γ)
theorem p22 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t12 γ) := .refl (t12 γ)
theorem p23 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t28 γ) := .scalarSimplify n9 n15 n27 QSym.BindingScalar2.DomainCertificate.domain_correct QSym.BindingScalar2.ValueCertificate.refinement
theorem p24 (γ : Binding.Globals) : Binding.Reduction (t27 γ) (t27 γ) := .refl (t27 γ)
theorem p25 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t28 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .rational)) (c := (.scalar .rational)) Binding.guardValue (p2 γ) (p24 γ)
theorem p26 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .guardTrue (t27 γ)
theorem p27 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p26 γ) (p24 γ)
theorem p28 (γ : Binding.Globals) : Binding.Reduction (t28 γ) (t27 γ) := .trans (p25 γ) (p27 γ)
theorem p29 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t27 γ) := .trans (p23 γ) (p28 γ)
theorem p30 (γ : Binding.Globals) : Binding.Reduction (t12 γ) (t27 γ) := .trans (p22 γ) (p29 γ)
theorem p31 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t16 γ) := .refl (t16 γ)
theorem p32 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t30 γ) := .scalarSimplify n13 n15 n30 QSym.BindingScalar3.DomainCertificate.domain_correct QSym.BindingScalar3.ValueCertificate.refinement
theorem p33 (γ : Binding.Globals) : Binding.Reduction (t29 γ) (t29 γ) := .refl (t29 γ)
theorem p34 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t30 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .rational)) (c := (.scalar .rational)) Binding.guardValue (p2 γ) (p33 γ)
theorem p35 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t29 γ) := .guardTrue (t29 γ)
theorem p36 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t29 γ) := .trans (p35 γ) (p33 γ)
theorem p37 (γ : Binding.Globals) : Binding.Reduction (t30 γ) (t29 γ) := .trans (p34 γ) (p36 γ)
theorem p38 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t29 γ) := .trans (p32 γ) (p37 γ)
theorem p39 (γ : Binding.Globals) : Binding.Reduction (t16 γ) (t29 γ) := .trans (p31 γ) (p38 γ)
theorem p40 (γ : Binding.Globals) : Binding.Reduction (t17 γ) (t31 γ) := .binary (a := (.scalar .rational)) (b := (.vector (.scalar .rational) 0)) (c := (.vector (.scalar .rational) 1)) Tensor.consValue (p39 γ) (p19 γ)
theorem p41 (γ : Binding.Globals) : Binding.Reduction (t18 γ) (t32 γ) := .binary (a := (.scalar .rational)) (b := (.vector (.scalar .rational) 1)) (c := (.vector (.scalar .rational) 2)) Tensor.consValue (p30 γ) (p40 γ)
theorem p42 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t33 γ) := .binary (a := (.vector (.scalar .rational) 2)) (b := (.vector (.scalar .rational) 2)) (c := (.scalar .rational)) (Tensor.dotValue Functions.addQ.apply Functions.mulQ.apply id (0 / 1 : ℚ) 2) (p21 γ) (p41 γ)
theorem p43 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t38 γ) := .ofEq (fun ξ ρ => rfl)
theorem p44 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t37 γ) := .binary (a := (.scalar .rational)) (b := (.scalar .rational)) (c := (.scalar .rational)) Functions.mulQ.apply (p3 γ) (p24 γ)
theorem p45 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t39 γ) := .ofEq (fun _ _ => rfl)
theorem p46 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t39 γ) := .refl (t39 γ)
theorem p47 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t24 γ) := .scalarSimplify n39 n15 n22 QSym.BindingScalar4.DomainCertificate.domain_correct QSym.BindingScalar4.ValueCertificate.refinement
theorem p48 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t23 γ) := .trans (p47 γ) (p16 γ)
theorem p49 (γ : Binding.Globals) : Binding.Reduction (t39 γ) (t23 γ) := .trans (p46 γ) (p48 γ)
theorem p50 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t23 γ) := .trans (p45 γ) (p49 γ)
theorem p51 (γ : Binding.Globals) : Binding.Reduction (t37 γ) (t23 γ) := .trans (p44 γ) (p50 γ)
theorem p52 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t35 γ) := .binary (a := (.scalar .rational)) (b := (.scalar .rational)) (c := (.scalar .rational)) Functions.mulQ.apply (p12 γ) (p33 γ)
theorem p53 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t40 γ) := .ofEq (fun _ _ => rfl)
theorem p54 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t40 γ) := .refl (t40 γ)
theorem p55 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t42 γ) := .scalarSimplify n40 n15 n28 QSym.BindingScalar5.DomainCertificate.domain_correct QSym.BindingScalar5.ValueCertificate.refinement
theorem p56 (γ : Binding.Globals) : Binding.Reduction (t41 γ) (t41 γ) := .refl (t41 γ)
theorem p57 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t42 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .rational)) (c := (.scalar .rational)) Binding.guardValue (p2 γ) (p56 γ)
theorem p58 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .guardTrue (t41 γ)
theorem p59 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .trans (p58 γ) (p56 γ)
theorem p60 (γ : Binding.Globals) : Binding.Reduction (t42 γ) (t41 γ) := .trans (p57 γ) (p59 γ)
theorem p61 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t41 γ) := .trans (p55 γ) (p60 γ)
theorem p62 (γ : Binding.Globals) : Binding.Reduction (t40 γ) (t41 γ) := .trans (p54 γ) (p61 γ)
theorem p63 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t41 γ) := .trans (p53 γ) (p62 γ)
theorem p64 (γ : Binding.Globals) : Binding.Reduction (t35 γ) (t41 γ) := .trans (p52 γ) (p63 γ)
theorem p65 (γ : Binding.Globals) : Binding.Reduction (t34 γ) (t34 γ) := .refl (t34 γ)
theorem p66 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t43 γ) := .binary (a := (.scalar .rational)) (b := (.scalar .rational)) (c := (.scalar .rational)) Functions.addQ.apply (p64 γ) (p65 γ)
theorem p67 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t44 γ) := .ofEq (fun _ _ => rfl)
theorem p68 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t44 γ) := .refl (t44 γ)
theorem p69 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t42 γ) := .scalarSimplify n41 n15 n28 QSym.BindingScalar6.DomainCertificate.domain_correct QSym.BindingScalar6.ValueCertificate.refinement
theorem p70 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t41 γ) := .trans (p69 γ) (p60 γ)
theorem p71 (γ : Binding.Globals) : Binding.Reduction (t44 γ) (t41 γ) := .trans (p68 γ) (p70 γ)
theorem p72 (γ : Binding.Globals) : Binding.Reduction (t43 γ) (t41 γ) := .trans (p67 γ) (p71 γ)
theorem p73 (γ : Binding.Globals) : Binding.Reduction (t36 γ) (t41 γ) := .trans (p66 γ) (p72 γ)
theorem p74 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t45 γ) := .binary (a := (.scalar .rational)) (b := (.scalar .rational)) (c := (.scalar .rational)) Functions.addQ.apply (p51 γ) (p73 γ)
theorem p75 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t46 γ) := .ofEq (fun _ _ => rfl)
theorem p76 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t46 γ) := .refl (t46 γ)
theorem p77 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t48 γ) := .scalarSimplify n42 n15 n43 QSym.BindingScalar7.DomainCertificate.domain_correct QSym.BindingScalar7.ValueCertificate.refinement
theorem p78 (γ : Binding.Globals) : Binding.Reduction (t47 γ) (t47 γ) := .refl (t47 γ)
theorem p79 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t48 γ) := .binary (a := (.scalar .bool)) (b := (.scalar .rational)) (c := (.scalar .rational)) Binding.guardValue (p2 γ) (p78 γ)
theorem p80 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t47 γ) := .guardTrue (t47 γ)
theorem p81 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t47 γ) := .trans (p80 γ) (p78 γ)
theorem p82 (γ : Binding.Globals) : Binding.Reduction (t48 γ) (t47 γ) := .trans (p79 γ) (p81 γ)
theorem p83 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t47 γ) := .trans (p77 γ) (p82 γ)
theorem p84 (γ : Binding.Globals) : Binding.Reduction (t46 γ) (t47 γ) := .trans (p76 γ) (p83 γ)
theorem p85 (γ : Binding.Globals) : Binding.Reduction (t45 γ) (t47 γ) := .trans (p75 γ) (p84 γ)
theorem p86 (γ : Binding.Globals) : Binding.Reduction (t38 γ) (t47 γ) := .trans (p74 γ) (p85 γ)
theorem p87 (γ : Binding.Globals) : Binding.Reduction (t33 γ) (t47 γ) := .trans (p43 γ) (p86 γ)
theorem p88 (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t47 γ) := .trans (p42 γ) (p87 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t19 γ) (t47 γ) := (p88 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t19 γ).eval ξ ρ = (t47 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t19 γ).eval ξ ρ) ↔ Value.Defined ((t47 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t19 γ).eval ξ ρ = n43.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n43 : Expr .rational := (.rat ((7) / (12) : ℚ))
noncomputable def v43 (ρ : Env) : Option (Ty.denote .rational) := some ((7) / (12) : ℚ)
theorem eval_43 (ρ : Env) : (Expr.eval ρ n43) = (v43 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n43) (Expr.eval ρ n43) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_43 ρ) (eval_43 ρ)) (Value.refines_refl (v43 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n43) : (Expr.eval ρ n43) = (Expr.eval ρ n43) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_43 (ρ : Env) : Value.Defined (v43 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v43 ρ) := (total_43 ρ)
def d43 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n43 ↔ (d43 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_43 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n43 := Eq.mpr (congrArg Value.Defined (eval_43 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t19 γ).eval ξ ρ) (FunctionScalar.n43.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n43.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t19 γ).eval ξ ρ)) : ((BindingCertificate.t19 γ).eval ξ ρ) = (FunctionScalar.n43.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
