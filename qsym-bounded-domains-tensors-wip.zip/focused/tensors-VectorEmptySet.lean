import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n0 : Expr .bool := (.bool true)
def n1 : Expr .bool := (.bool false)
abbrev c0 (δ : ℕ → ℕ) : List Binding.Ty := []
abbrev c1 (δ : ℕ → ℕ) : List Binding.Ty := (.vector (.scalar .real) (δ 0)) :: (c0 δ)
noncomputable def t0 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c1 δ) (.scalar .bool) := .scalar n0
noncomputable def t1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.set (.vector (.scalar .real) (δ 0))) := .set (t0 δ γ)
noncomputable def t2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c1 δ) (.scalar .bool) := .scalar n1
noncomputable def t3 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.set (.vector (.scalar .real) (δ 0))) := .set (t2 δ γ)
noncomputable def t4 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.scalar .bool) := .binary Binding.equalValue (t1 δ γ) (t3 δ γ)
noncomputable def t6 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Expr (c0 δ) (.scalar .bool) := .scalar n1
theorem p0 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t0 δ γ) (t0 δ γ) := .refl (t0 δ γ)
theorem p1 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t1 δ γ) (t1 δ γ) := .set (p0 δ γ)
theorem p2 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t2 δ γ) (t2 δ γ) := .refl (t2 δ γ)
theorem p3 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t3 δ γ) (t3 δ γ) := .set (p2 δ γ)
theorem p4 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t4 δ γ) (t4 δ γ) := .binary (a := (.set (.vector (.scalar .real) (δ 0)))) (b := (.set (.vector (.scalar .real) (δ 0)))) (c := (.scalar .bool)) Binding.equalValue (p1 δ γ) (p3 δ γ)
theorem p5 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t4 δ γ) (t6 δ γ) := .equalUnivEmpty (a := (.vector (.scalar .real) (δ 0))) (fun _ => 0)
theorem p6 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t6 δ γ) (t6 δ γ) := .refl (t6 δ γ)
theorem p7 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t4 δ γ) (t6 δ γ) := .trans (p5 δ γ) (p6 δ γ)
theorem p8 (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t4 δ γ) (t6 δ γ) := .trans (p4 δ γ) (p7 δ γ)
theorem reduction (δ : ℕ → ℕ) (γ : Binding.Globals) : Binding.Reduction (t4 δ γ) (t6 δ γ) := (p8 δ γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : (t4 ξ.natural γ).eval ξ ρ = (t6 ξ.natural γ).eval ξ ρ := Binding.Reduction.sound (reduction ξ.natural γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : Value.Defined ((t4 ξ.natural γ).eval ξ ρ) ↔ Value.Defined ((t6 ξ.natural γ).eval ξ ρ) := Binding.Reduction.defined (reduction ξ.natural γ) ξ ρ
theorem lowered (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env (c0 ξ.natural)) : (t4 ξ.natural γ).eval ξ ρ = n1.eval ξ := Eq.trans (sound γ ξ ρ) rfl
#qsym_check_axioms lowered
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
-- Generated certificate. Check with: lake env lean FILE.lean
namespace QSym.FunctionScalar
attribute [local semireducible] Rat.add Rat.mul Rat.sub Rat.inv
attribute [local irreducible] Value.add Value.mul
set_option maxRecDepth 8192
def n1 : Expr .bool := (.bool false)
noncomputable def v1 (ρ : Env) : Option (Ty.denote .bool) := some false
theorem eval_1 (ρ : Env) : (Expr.eval ρ n1) = (v1 ρ) := rfl

theorem refinement (ρ : Env) : Value.Refines (Expr.eval ρ n1) (Expr.eval ρ n1) :=
  Eq.mpr (congrArg₂ Value.Refines (eval_1 ρ) (eval_1 ρ)) (Value.refines_refl (v1 ρ))
#qsym_check_axioms refinement

theorem simplification (ρ : Env) (h : Expr.Defined ρ n1) : (Expr.eval ρ n1) = (Expr.eval ρ n1) := (refinement ρ).eq_of_defined h
#qsym_check_axioms simplification

theorem total_1 (ρ : Env) : Value.Defined (v1 ρ) :=
  ⟨_, rfl⟩
theorem total_root (ρ : Env) : Value.Defined (v1 ρ) := (total_1 ρ)
def d1 (_ : Env) : Prop := True
theorem definedness (ρ : Env) : Expr.Defined ρ n1 ↔ (d1 ρ) := (Iff.of_eq (congrArg Value.Defined (eval_1 ρ))).trans (iff_true_intro (total_root ρ))
#qsym_check_axioms definedness
theorem everywhere_defined (ρ : Env) : Expr.Defined ρ n1 := Eq.mpr (congrArg Value.Defined (eval_1 ρ)) (total_root ρ)
#qsym_check_axioms everywhere_defined
end QSym.FunctionScalar
namespace QSym.FunctionCertificate
theorem refinement (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) : Value.Refines ((BindingCertificate.t4 ξ.natural γ).eval ξ ρ) (FunctionScalar.n1.eval ξ) :=
  Eq.mpr (congrArg (fun x => Value.Refines x (FunctionScalar.n1.eval ξ)) (BindingCertificate.lowered γ ξ ρ)) (FunctionScalar.refinement ξ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env []) (h : Value.Defined ((BindingCertificate.t4 ξ.natural γ).eval ξ ρ)) : ((BindingCertificate.t4 ξ.natural γ).eval ξ ρ) = (FunctionScalar.n1.eval ξ) :=
  (refinement γ ξ ρ).eq_of_defined h
#qsym_check_axioms refinement
#qsym_check_axioms sound
end QSym.FunctionCertificate
