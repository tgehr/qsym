import QSym.Tensor
import QSym.Binding
import QSym.AxiomCheck
import QSym.Numeric
import QSym.Bag
import QSym.Conditionals
import FocusedRules
import ExtraRules
import AdditionalRules
import NameRules
import RecurrenceRules
import SolverExtraRules
import SelectedRules
import FocusedReplay
import FocusedSum
import FocusedRegion
import TensorRules
namespace QSym.BindingCertificate
def n1 : Expr .natural := (.nat (0))
abbrev c0 : List Binding.Ty := []
abbrev c1 : List Binding.Ty := (.pair (.scalar .real) (.vector (.scalar .natural) 1)) :: c0
noncomputable def t0 (γ : Binding.Globals) : Binding.Expr c1 (.pair (.scalar .real) (.vector (.scalar .natural) 1)) := .var .here
noncomputable def t2 (γ : Binding.Globals) : Binding.Expr c1 (.vector (.scalar .natural) 1) := .unary (fun x => x.map Prod.snd) (t0 γ)
noncomputable def t3 (γ : Binding.Globals) : Binding.Expr c1 (.scalar .natural) := .scalar n1
noncomputable def t4 (γ : Binding.Globals) : Binding.Expr c1 (.scalar .natural) := .binary Tensor.getValue (t2 γ) (t3 γ)
noncomputable def t5 (γ : Binding.Globals) : Binding.Expr c0 (.arrow (.pair (.scalar .real) (.vector (.scalar .natural) 1)) (.scalar .natural)) := .lam (t4 γ)
theorem p0 (γ : Binding.Globals) : Binding.Reduction (t0 γ) (t0 γ) := .refl (t0 γ)
theorem p1 (γ : Binding.Globals) : Binding.Reduction (t2 γ) (t2 γ) := .unary (a := (.pair (.scalar .real) (.vector (.scalar .natural) 1))) (b := (.vector (.scalar .natural) 1)) (fun x => x.map Prod.snd) (p0 γ)
theorem p2 (γ : Binding.Globals) : Binding.Reduction (t3 γ) (t3 γ) := .refl (t3 γ)
theorem p3 (γ : Binding.Globals) : Binding.Reduction (t4 γ) (t4 γ) := .binary (a := (.vector (.scalar .natural) 1)) (b := (.scalar .natural)) (c := (.scalar .natural)) Tensor.getValue (p1 γ) (p2 γ)
theorem p4 (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := .lam (p3 γ)
theorem reduction (γ : Binding.Globals) : Binding.Reduction (t5 γ) (t5 γ) := (p4 γ)
theorem sound (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : (t5 γ).eval ξ ρ = (t5 γ).eval ξ ρ := Binding.Reduction.sound (reduction γ) ξ ρ
theorem domain (γ : Binding.Globals) (ξ : Env) (ρ : Binding.Env c0) : Value.Defined ((t5 γ).eval ξ ρ) ↔ Value.Defined ((t5 γ).eval ξ ρ) := Binding.Reduction.defined (reduction γ) ξ ρ
#qsym_check_axioms sound
#qsym_check_axioms domain
end QSym.BindingCertificate
