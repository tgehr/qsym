from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
root=Path(__file__).resolve().parent;repo=root/'qsym';out=root/'focused'
imports='\n'.join(line for line in (out/'tensors-DotComplexDual.lean').read_text().splitlines() if line.startswith('import '))+'\n'
paths=[]
for source,name,old,new in (
 ('cutoff/Function.lean','StrictCutoff','Functions.leN.apply','Functions.ltN.apply'),
 ('tensors/DotComplexDual.lean','WrongComplexDual','Value.mul Value.conj','Value.mul id')):
 valid=(repo/'build'/source).read_text();corrupt=valid.replace(old,new,1)
 assert valid!=corrupt
 path=out/('reject-'+name+'.lean');path.write_text(corrupt.replace('import QSym\n',imports));paths.append(path)
for name,body in (
 ('TensorIndexOutside','example : Tensor.getValue (some (fun _ : Fin 1 => (7 : ℕ))) (some 1) = some 7 := rfl'),
 ('UnknownDimensionsDiffer','example (n m : ℕ) : Binding.typeEqValue (some (.vector (.scalar .real) n)) (some (.vector (.scalar .real) m)) = some false := rfl')):
 path=out/('reject-'+name+'.lean');path.write_text('import QSym.Tensor\nopen QSym\n'+body+'\n');paths.append(path)
def check(path):
 try:
  r=subprocess.run(['lake','env','bash','-c','export LEAN_PATH="$1:$LEAN_PATH"; exec lean "$2"','check',str(out),str(path)],cwd=repo/'lean',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  output=r.stdout;status=r.returncode
 except subprocess.TimeoutExpired as e:
  output=str(e);status='timeout'
 passed=isinstance(status,int) and status!=0 and any(s in output for s in ('unsolved goals','type mismatch','is false','unexpected axioms')) and not any(s in output for s in ('unknown module','unknown constant','maximum number of heartbeats','maximum recursion depth'))
 path.with_suffix('.log').write_text(output);path.with_suffix('.exit').write_text(str(status)+'\n')
 record={'fixture':path.stem,'exit':status,'correctly_rejected':passed};print(record,flush=True);return record
with ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(check,paths))
(root/'rejections-results.json').write_text(json.dumps(records,indent=2)+'\n')
raise SystemExit(0 if all(r['correctly_rejected'] for r in records) else 1)
